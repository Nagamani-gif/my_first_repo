
import './App.css';

 
import {
  BrowserRouter,
  Route,
  Routes,Navigate
} from "react-router-dom";
import LoginPage from './Components/LoginPage';
import Transactions from './Components/Transactions';

import Home from './Components/Home';
import SalesPeople from './Components/SalesPeople';
import ChangePassword from './Components/ChangePassword';
import DistAccntBalCredit from './Components/DistAccntBalCredit';
import Profile from './Components/Profile';
import NotificationConfigMain from './Components/NotificationConfigMain';
import Subdistributors from './Components/Subdistributors';
import Distributorshierarchyp from './Components/Distributorshierarchyp';
import Postpaidpaymentsp from './Components/Postpaidpaymentsp';
import { useDispatch,useSelector } from 'react-redux';
import { logoutUser } from './reducers/exampleSlice';
import { useState,useEffect, useCallback } from 'react';
import {ResetPassword} from './Components/ResetPassword';
import {PasswordResetVerification} from './Components/PasswordResetVerification';
import {FeatureAssociation} from './Components/FeatureAssociation';
import { QuickTransfer } from './Components/QuickTransfer';
import Samplexius from './Components/Samplexius';
import PublicTelephoneEnquiry from './Components/PublicTelephoneEnquiry';
import PublicTelephones from './Components/PublicTelephones';
//import DistributorFundTransfer from './Components/DistributorFundTransfer';
import BulkTransfer from './Components/BulkTransfer';
import ElectronicRecharge from './Components/EloctronicRecharge';
import DistributorFundTransferSample from './Components/DistributorFundTransferSample';
import RechargePreview from './Components/RechargePreview';
import DataPurchasePreview from './Components/DataPurchasePreview';
import { BalanceAnnulment } from './Components/BalanceAnnulment';
import { BalanceAnnulmentSubmit } from './Components/BalanceAnnulmentSubmit';
// Importing toastify module
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import PostpaidTransaction from './Components/postpaidTransactionReport';
import { setUserSession, resetData } from './reducers/exampleSlice'; // Adjust path as needed
import AddSalesPeople from './Components/AddSalesPeople';
import AddSubdistributor from './Components/AddSubdistributor';
import ModifyProfile from './Components/ModifyProfile';
import CancelPage from './Components/CancelPage';
import BlockPage from './Components/BlockPage';
import ChangePasswordPage from './Components/ChangePasswordPage';
import CsrfAttack from './Components/CsrfAttack';
import { Button, IconButton, useMediaQuery, useTheme } from '@mui/material';
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import CloseIcon from "@mui/icons-material/Close";
import useIdleTimer from './Components/useIdleTimer';
import { LoginOutlined } from '@mui/icons-material';
import SendIcon from '@mui/icons-material/Send';
import TermsAndConditions from './Components/TermsAndConditions';
import { t } from 'i18next';
import BlankPage from './Components/BlankPage';
import ExpireSoonPage from './Components/ExpireSoonPage';
import Distributorpaymentsp from './Components/DistributorPayment';
import DistributorpaymentHistory from './Components/DistributorPaymentHistory';

import PortInReport from './Components/PortInReport';
import JasperReports from './Components/JasperReports';
import BalanceAnnulmentReport from './Components/BalanceAnnulmentreport';
import PendingTrans from './Components/PendingTrans';
import DistributorPaymentsHistoryReport from './Components/DistributorPaymentsHistoryReport'; 
import DistributorPayments from './Components/DistributorPayments';
import Packetsales from './Components/Packetsales';
import BillPaymentsReport from './Components/BillPaymentsReport';
import AccountStatusReport from './Components/AccountStatusReport';
import FundTransferReport from './Components/FundTransferReport';
import FundTransferReversalReport from './Components/FundTransferReversalReport';
import POSTransactionsReport from './Components/POSTransactionsReport';
import ReversalTrasactionReport from './Components/ReversalTrasactionReport';
import MassiveTransfers from './Components/MassiveTransfers';
import Lateralfundreversalreport from './Components/Lateralfundreversalreport';
import PartnerStatusReport from './Components/PartnerStatusReport';
import Mvnereportp from './Components/Mvnereportp';
import Salestargetreport from './Components/Salestargetreport';


function App() {
  const dispatch = useDispatch();
  let isLoggedIn = useSelector((state) => state.example.isLoggedIn); // Get isLoggedIn from Redux state
  console.log("isLoggedIn===>",isLoggedIn);

  useEffect(() => {
    const sessionId = localStorage.getItem('sessionId');
    const user = JSON.parse(localStorage.getItem('user'));
    if (sessionId && user) {
      dispatch(setUserSession({ sessionId, user }));
    } else {
      dispatch(resetData());
      //window.location.href = '/gig-nation';
    }
  }, [dispatch]);

  const currentPath = window.location.pathname.trim();
  console.log('currentPath:::::::::::::::',currentPath)
  const authToken = localStorage.getItem('sessionId');
  if (authToken && currentPath !== '/gig-nation') {
    isLoggedIn = localStorage.getItem("isLoggedIn");
   const storedUserData = localStorage.getItem("userData");

    if (storedUserData) {
        try {
            const parsedUserData = JSON.parse(storedUserData);
            console.log("userdata===", parsedUserData);
        } catch (error) {
            console.error("Failed to parse userData:", error);
        }
    } else {
        console.log("No userData found in localStorage.");
    }
}



  // useEffect(() => {
  //   // Check if authentication token is present in localStorage or sessionStorage
  //   const authToken = localStorage.getItem('sessionId'); // or sessionStorage.getItem('authToken');
  //   console.log("authToken===>",authToken);
  //   let sessionTimeout;
  //   if (authToken) {
  //     sessionTimeout = setTimeout(() => {
  //       handleSessionTimeout();
  //     }, 10 * 60 * 1000); // 10 minutes 10 * 60 * 1000
  //   }

  //   return () => {
  //     if (sessionTimeout) {
  //       clearTimeout(sessionTimeout);
  //     }
  //   };
  // }, [isLoggedIn]); // Depend on isLoggedIn to reset the timeout on login state change
// SESSION TIMEOUT STARTS ========================
const theme = useTheme();
const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
const [open, setOpen] = useState(false);
const [counter, setCounter] = useState(15);

const handleClose = () => {
  setOpen(false);
}; 
const handleIdle = () => {
  // Perform logout logic here, e.g., redirect to login page
  // toast.info('Session timed out. Redirecting to login page.');
  setOpen(true);
};
  useEffect(() => {
  if (open) {
    setCounter(15);
    const countdown = setInterval(() => {
      setCounter(prevCounter => (prevCounter > 0 ? prevCounter - 1 : prevCounter));
    }, 1000);

    return () => clearInterval(countdown);
    }
}, [open]);



const handleSessionTimeout = useCallback(() => {
  //  alert('Session timed out. Redirecting to login page.');
    dispatch(logoutUser());
    // setIsLoggedIn(false);
    isLoggedIn=false;
    window.location.href = '/gig-nation'; // Adjust to your login page path
  });

useIdleTimer(handleIdle, 600000, isLoggedIn); // 10 minutes timeout


// IF USER CLOSSES THE TAB DIRECTLY
// useEffect(() => {
//   const clearLocalStorage = () => {
//     localStorage.clear();
//   };
 
//   window.addEventListener('unload', clearLocalStorage);
 
//   // Clean up the event listener on component unmount
//   return () => {
//     window.removeEventListener('unload', clearLocalStorage);
//   };
// }, []);

      useEffect(() => {
        if (counter === 0) {
          handleSessionTimeout();
        }
      }, [counter, handleSessionTimeout]);
      // SESSION TIMEOUT ENDS ===========================



const setData=(userData)=>{
  console.log("user data===",userData)
localStorage.setItem("userData", JSON.stringify(userData));
localStorage.setItem("isLoggedIn",true);
}

// const allowedKeys = [
//   "distributorfundstransfer", "balanceAnnulmentp", "quicktransferp",
//   "partnerbulkfundtransfersp", "topupphonep", "viewsalespeoplep",
//   "addsalespersonp", "viewsubgroups", "distributorshierarchyp",
//   "addsubgroupp", "featureassociation", "publictelephoneuploadp",
//   "publictelephoneenquiryp", "postpaidpaymentsp", "postpaidtransactionreportp"
// ];
// console.log("isLoggedIn===>",isLoggedIn);

//  const exampleData = JSON.parse(localStorage.getItem("userData"))

// const allNavItemsClean = exampleData.userPrivileges
//   .flatMap(obj => Object.values(obj)) // Get all values (arrays or strings)
//   .flat() // Flatten nested arrays
//   .filter(Boolean) // Remove empty/null
//   .map(item => item) // Keep only the part after "_"
//   .filter(item => allowedKeys.includes(t(item))); // Keep only allowed

// console.log("subMenu--> list == "+allNavItemsClean);


     

//    let topMenuLinks = exampleData.userPrivileges;

// // Extract and sort the top menu keys
// let topMenuLinks2 = topMenuLinks.map(obj => Object.keys(obj)[0]);
// topMenuLinks2.sort();

// // Create array of translated labels (t(link))
// const translatedLinks = topMenuLinks2.map(link => t(link));

// console.log("top--> list == "+translatedLinks); 
let finalList = [];
// Safely parse userData and userPrivileges from localStorage
let exampleData = null;
try {
  const rawUserData = localStorage.getItem("userData");
  exampleData = rawUserData ? JSON.parse(rawUserData) : null;
} catch (e) {
  console.error("Failed to parse userData in App:", e);
}

if (exampleData && Array.isArray(exampleData.userPrivileges)) {
  const userPrivileges = exampleData.userPrivileges;
  finalList = [
    // Sub-menu items
    ...userPrivileges
      .flatMap(obj => Object.values(obj))
      .flat()
      .filter(Boolean),
    // Top menu translated keys
    ...userPrivileges
      .map(obj => Object.keys(obj)[0])
      .sort()
      .map(link => t(link))
  ];
}
 
// Remove duplicates (handle empty finalList safely)
const mergedListUnique = [...new Set(finalList || [])];
 
console.log("merged list == ", mergedListUnique);

let mergedListUniquess
if(finalList!=null){
 mergedListUniquess = [...new Set(
  finalList
    .filter(item => typeof item === "string" && item.trim() !== "" && !item.startsWith("NaN"))
    .map(item => t(item))
)];
}


console.log("mergedListUniquess =", mergedListUniquess);

// /newPaymentAlerts
// /notificationConfigMain
// /changePassword
// /resetPassword
// /profile


//menu list

  const handleLogoutForcefully =()=>{
   // fetchData();
    dispatch(logoutUser());
   // navigate('/logout');  
  }

const routeConfig = [
  { path: "/changepasswordpage", element: <ChangePasswordPage /> },
  { path: "/home", element: <Home /> },
  { path: "/blankpage", element: <BlankPage /> },
  { path: "/transaction", element: <JasperReports /> },
  { path: "/sales-people", element: <SalesPeople /> },
  { path: "/changePassword", element: <ChangePassword /> },
  { path: "/profile", element: <Profile /> },
  { path: "/newPaymentAlerts", element: <DistAccntBalCredit /> },
  { path: "/notificationConfigMain", element: <NotificationConfigMain /> },
  { path: "/subdistributors", element: <Subdistributors /> },
  { path: "/distributorshierarchyp", element: <Distributorshierarchyp /> },
  { path: "/postpaid-payments", element: <Postpaidpaymentsp /> },
  { path: "/resetPassword", element: <ResetPassword /> },
  { path: "/passwordResetVerification", element: <PasswordResetVerification /> },
  { path: "/featureAssociation", element: <FeatureAssociation /> },
  { path: "/quickTransfer", element: <QuickTransfer /> },
  { path: "/public-telephones-Enquiry", element: <PublicTelephoneEnquiry /> },
  { path: "/public-telephones", element: <PublicTelephones /> },
  { path: "/bulk-transfer", element: <BulkTransfer /> },
  { path: "/electronic-recharge", element: <ElectronicRecharge /> },
  { path: "/distributor-fund-transfer", element: <DistributorFundTransferSample /> },
  { path: "/sample", element: <Samplexius /> },
  { path: "/recharge-preview", element: <RechargePreview /> },
  { path: "/data-purchase-preview", element: <DataPurchasePreview /> },
  { path: "/balanceAnnulment", element: <BalanceAnnulment /> },
  { path: "/balanceAnnulmentSubmit", element: <BalanceAnnulmentSubmit /> },
  { path: "/postpaidtransactionreportp", element: <PostpaidTransaction /> },
  { path: "/addsalespersonp", element: <AddSalesPeople /> },
  { path: "/addsubgroupp", element: <AddSubdistributor /> },
  { path: "/modifyProfile", element: <ModifyProfile /> },
  { path: "/distributorpayment", element: <Distributorpaymentsp /> },
  { path: "/distributorpaymenthistory", element: <DistributorpaymentHistory /> },
  { path: "/accountstatusreportp", element: <AccountStatusReport /> },
  { path: "/portinreport", element: <PortInReport /> },
  { path: "/transactions", element: <Transactions /> },
  { path: "/balanceAnnulmentReportp", element: <BalanceAnnulmentReport /> },
  { path: "/pendingtransactions", element: <PendingTrans /> },
  { path: "/distributorPaymentsHistoryReport", element: <DistributorPaymentsHistoryReport /> },
  { path: "/distributorpayments", element: <DistributorPayments /> },
  { path: "/packetsalesreportp", element: <Packetsales /> },
  { path: "/billpaymentsreportp", element: <BillPaymentsReport /> },
  { path: "/fundtransferreportsp", element: <FundTransferReport /> },
  { path: "/distributortransferreversalreportp", element: <FundTransferReversalReport /> },
  { path: "/postranslogrptp", element: <POSTransactionsReport /> },
  { path: "/reversaltransactionreport", element: <ReversalTrasactionReport /> },
  { path: "/massivetransferssreportp", element: <MassiveTransfers /> },
  { path: "/lateralfundreversalreport", element: <Lateralfundreversalreport /> },
  { path: "/partnerStatusReportp", element: <PartnerStatusReport /> },
  { path: "/mvnereportp", element: <Mvnereportp /> },
  { path: "/salestargetreportp", element: <Salestargetreport /> }
];



function ProtectedRoute({ children, path, mergedListUnique }) {


    const rawData = localStorage.getItem("userData");
  let exampleData = null;

  try {
    exampleData = rawData ? JSON.parse(rawData) : null;
  } catch (e) {
    console.error("Invalid userData:", e);
  }
      if (!exampleData) {
    localStorage.removeItem("sessionId");
    localStorage.removeItem("userData"); 
    localStorage.removeItem("isLoggedIn");
    localStorage.setItem("isLoggedIn", false);
    localStorage.removeItem("channels");
    localStorage.removeItem("denominations");
    localStorage.removeItem("LOGIN_ID");

    return <Navigate to="/logout" replace />;
  }


  let alwaysAllowedPaths =
   [
        "/changepasswordpage",
        "/home",
        "/modifyProfile",
        "/passwordResetVerification",
        "/recharge-preview",
        "/data-purchase-preview",
        "/profile"

      ];
  


 let profileAllowedPaths =
  exampleData.USER_TYPE_ID !== 6 && exampleData.PARENT_ID === ''
    ?  [
        "/newPaymentAlerts",
        "/notificationConfigMain",
        "/changePassword",
        "/resetPassword",
        "/profile",
        "/distributorPaymentsHistoryReport"
      ]
    : [
        "/changePassword",
        "/resetPassword",
        "/profile",
      ];


  const userPrivileges = exampleData.userPrivileges || [];
// 👉 check if "e_transactions" exists in array
const hasETransactions = userPrivileges.some(obj => obj.hasOwnProperty("e_transactions"));
const hasProfile = userPrivileges.some(obj => obj.hasOwnProperty("a_profile"));
const hasEle = userPrivileges.some(obj => obj.hasOwnProperty("b_sellprepaidcards"));




if (hasETransactions) {
  mergedListUnique = [...mergedListUnique, "/transaction"];
}


if (hasEle) {
  mergedListUnique = [...mergedListUnique, "/electronic-recharge"];
}



if (hasProfile) {
  mergedListUnique = [...mergedListUnique, ...profileAllowedPaths];
}


 // mergedListUnique = [...mergedListUnique, ...alwaysAllowedPaths];


  // Allow if it's in the always-allowed list
  if (alwaysAllowedPaths.includes(path)) {
    return children;
  }
//alert(path)
//commented by srilatha
  // Regular permission check (exact match)
  const hasAccess = mergedListUnique.some(menuItem =>
    menuItem.toLowerCase() === path.toLowerCase()
   //menuItem.toLowerCase().includes(path.toLowerCase())
  );
  if(!hasAccess){
   // handleLogoutForcefully();
       localStorage.removeItem('sessionId');
       localStorage.removeItem('userData'); 
       localStorage.removeItem('isLoggedIn'); // Remove sessionId on logout
       localStorage.setItem("isLoggedIn",false);
       localStorage.removeItem('channels');
       localStorage.removeItem('denominations');
       localStorage.removeItem('LOGIN_ID');
       //sessionStorage.removeItem('LOGIN_ID');
       
  }
  return hasAccess ? children : <Navigate to="/logout" replace />;
}

//  function ProtectedRoute({ children, path, mergedListUnique }) {
//   const rawData = localStorage.getItem("userData");
//   let exampleData = null;

//   try {
//     exampleData = rawData ? JSON.parse(rawData) : null;
//   } catch (e) {
//     console.error("Invalid userData:", e);
//   }

//   // Central logout handler
//   const forceLogout = () => {
//     localStorage.removeItem("sessionId");
//     localStorage.removeItem("userData"); 
//     localStorage.removeItem("isLoggedIn");
//     localStorage.setItem("isLoggedIn", false);
//     localStorage.removeItem("channels");
//     localStorage.removeItem("denominations");
//     localStorage.removeItem("LOGIN_ID");
//   };

//   // If no userData → logout
//   if (!exampleData) {
//     forceLogout();
//     return <Navigate to="/logout" replace />;
//   }

//   // Always allowed paths
//   const alwaysAllowedPaths =
//     exampleData.USER_TYPE_ID !== 6 && exampleData.PARENT_ID === ""
//       ? [
//           "/newPaymentAlerts",
//           "/notificationConfigMain",
//           "/changePassword",
//           "/changepasswordpage",
//           "/resetPassword",
//           "/profile",
//           "/distributorPaymentsHistoryReport",
//           "/home",
//           "/modifyProfile",
//           "/transaction"
//         ]
//       : [
//           "/changepasswordpage",
//           "/changePassword",
//           "/resetPassword",
//           "/profile",
//           "/home",
//           "/transaction"
//         ];

//   if (alwaysAllowedPaths.includes(path)) {
//     return children;
//   }

//   // Regular permission check
//   const hasAccess = mergedListUnique?.some(
//     menuItem => menuItem.toLowerCase() === path.toLowerCase()
//   );

//   if (!hasAccess) {
//     forceLogout();
//     return <Navigate to="/" replace />;
//   }

//   return children;
// }

  


return (
  <>
  <BrowserRouter basename="/gig-nation">
  {/* <div className="container my-2" style={{marginTop: '-16px !important'}}> */}
  <div className="container telefonica_container" style={{marginTop: '3px'}}>

    <Routes>
    <Route path="/recharge-preview" element={<RechargePreview/> }></Route>
      <Route path="/" element={<LoginPage gettingdata={setData}/> } />
      <Route path="/showTermsConditions" element={<TermsAndConditions /> }></Route>
      <Route path='blockpage' element={<BlockPage  gettingdata={setData} />} ></Route>
      <Route path='expiresoon' element={<ExpireSoonPage  gettingdata={setData} />} ></Route>
      <Route path="/logout" element={<CancelPage gettingdata={setData} ></CancelPage>} ></Route>
     {/* {isLoggedIn ? ( 
        <> 
          <Route path="/changepasswordpage" element={<ChangePasswordPage gettingdata={setData} ></ChangePasswordPage>} ></Route>  
          <Route path="/home" element={<Home/> } />
          <Route path="/blankpage" element={<BlankPage/> } />
          <Route path="/transaction" element={<JasperReports/>} />
          <Route path="/sales-people" element={<SalesPeople/>} />
          <Route path="/changePassword" element={<ChangePassword/>} />
          <Route path="/profile" element={<Profile/>} />
          <Route path="/newPaymentAlerts" element={<DistAccntBalCredit/>} />
          <Route path="/notificationConfigMain" element={<NotificationConfigMain/>} />
          <Route path="/subdistributors" element={<Subdistributors/> } />
          <Route path="/distributorshierarchyp" element={<Distributorshierarchyp/> } />
          <Route path="/postpaid-payments" element={<Postpaidpaymentsp/> } />
          <Route path="/resetPassword" element={<ResetPassword/> }></Route>
          <Route path="/passwordResetVerification" element={<PasswordResetVerification/> }></Route>
          <Route path="/featureAssociation" element={<FeatureAssociation/> }></Route>
          <Route path="/quickTransfer" element={<QuickTransfer/> }></Route>
          <Route path="/public-telephones-Enquiry" element={<PublicTelephoneEnquiry/> }></Route>
          <Route path="/public-telephones" element={<PublicTelephones/> }></Route>
           <Route path="/bulk-transfer" element={<BulkTransfer/> }></Route>
          <Route path="/electronic-recharge" element={<ElectronicRecharge/> }></Route>
          <Route path="/distributor-fund-transfer" element={<DistributorFundTransferSample/> }></Route>
          <Route path="/sample" element={<Samplexius/> }></Route>
          <Route path="/recharge-preview" element={<RechargePreview/> }></Route>
          <Route path="/data-purchase-preview" element={<DataPurchasePreview/> }></Route>
          <Route path="/balanceAnnulment" element={<BalanceAnnulment/> }></Route>
          <Route path="/balanceAnnulmentSubmit" element={<BalanceAnnulmentSubmit/> }></Route>
          <Route path="/postpaidtransactionreportp" element={<PostpaidTransaction/> }></Route>
          <Route path="/postpaid-payments" element={<Postpaidpaymentsp/> }></Route>
          <Route path="/transaction" element={<Transactions/> }></Route>
          <Route path="/addsalespersonp" element={<AddSalesPeople/> }></Route>
          <Route path="/addsubgroupp" element={<AddSubdistributor /> }></Route> 
          <Route path="/modifyProfile" element={<ModifyProfile /> }></Route>
          <Route path="/distributorpayment" element={<Distributorpaymentsp /> }></Route>
          <Route path="/distributorpaymenthistory" element={<DistributorpaymentHistory /> }></Route>
          
          <Route path="/accountstatusreportp" element={<AccountStatusReport /> }></Route>
          <Route path="/portinreport" element={<PortInReport /> }></Route>
          <Route path="/transactions" element={<Transactions /> }></Route>
          <Route path="/balanceAnnulmentReportp" element={<BalanceAnnulmentReport /> }></Route>
          <Route path="/pendingtransactions" element={<PendingTrans /> }></Route>
          <Route path="/distributorPaymentsHistoryReport" element={<DistributorPaymentsHistoryReport /> }></Route>
          <Route path="/distributorpayments" element={<DistributorPayments /> }></Route>
          <Route path="/packetsalesreportp" element={<Packetsales /> }></Route>
          <Route path="/billpaymentsreportp" element={<BillPaymentsReport /> }></Route>
          <Route path="/fundtransferreportsp" element={<FundTransferReport /> }></Route>
          <Route path="/distributortransferreversalreportp" element={<FundTransferReversalReport /> }></Route>
          
          <Route path="/postranslogrptp" element={<POSTransactionsReport /> }></Route>
          <Route path="/reversaltransactionreport" element={<ReversalTrasactionReport /> }></Route>
          <Route path="/massivetransferssreportp" element={<MassiveTransfers /> }></Route>
          <Route path="/lateralfundreversalreport" element={<Lateralfundreversalreport /> }></Route>

          <Route path="/partnerStatusReportp" element={<PartnerStatusReport /> }></Route>
          <Route path="/mvnereportp" element={<Mvnereportp /> }></Route>
          <Route path="/salestargetreportp" element={<Salestargetreport /> }></Route> */}









          
          
          {/* <Route path="/csrf" element={<CsrfAttack /> }></Route> */}


         {/* </>
     ) : (
        <Route path="*" element={<Navigate to="/" replace />} /> 
    )}   */}
      {isLoggedIn ? (
<>
          {routeConfig.map(({ path, element }) => (
<Route
              key={path}
              path={path}
              element={
<ProtectedRoute path={path} mergedListUnique={mergedListUniquess}>
                  {element}
</ProtectedRoute>
              }
            />
          ))}
          {/* Catch-all: if no match, redirect to /home */}
<Route path="*" element={<Navigate to="/home" replace />} />
</>
      ) : (
        // If not logged in → any route goes to login
<Route path="*" element={<Navigate to="/" replace />} />
      )}
    </Routes>
  </div>
</BrowserRouter> 

{currentPath !== '/gig-nation' && (
<Dialog
          fullScreen={fullScreen}
          open={open}
          onClose={handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "25px" }}
            className={"headerTxt"}
            align="center"
          >
            {""}
          </DialogTitle>
          
          <DialogContent>
            <DialogContentText>
              <p style={{color: '#000',fontSize: '13px'}}>Your session is about to expire. Click on <span style={{color: '#3399FF'}}>“Keep me signed In”</span> to Continue.</p>
              <p style={{textAlign:'center',fontSize: '13px'}}><span className={'timerr'}>00.{counter<10 ? '0'+counter : counter}</span> seconds left</p>
            <div align="center" className={"maxLimit_buttons"} gap={1}>
                <Button className={'hoverEffectButton'} onClick={handleSessionTimeout} size="small" variant="contained" endIcon={<LoginOutlined />}> 
                 {t("Logout")}
                </Button>
                <Button className={'hoverEffectButton'} onClick={handleClose} size="small" variant="contained" endIcon={<SendIcon />}>
                   Keep me signed In
                </Button>
              </div>
            </DialogContentText>
          </DialogContent>
        </Dialog>
         )}
        {/* MODAL ENDS HERE */}
        
       {/* <ToastContainer containerId="GlobalApplicationToast"
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />  */}
                   
   </>
  );
}


export default App;

// code for forcefull logout