import {Header ,SubDistMenu, Footer, PaymentManagerHeading, LeftMenu, JasperLeftMenu, JasperTopMenu, LeftBgImage} from './PageComponents';
import TopMenu from './TopMenu';
import { useSelector } from 'react-redux';
import axios from 'axios';
import {useEffect, useRef, useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

import { Box, Button, Checkbox, FormControl, InputLabel, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField } from '@mui/material';
import { KeyboardReturn, Search} from '@mui/icons-material';

import SendIcon from '@mui/icons-material/Send';
import RotateLeftIcon from '@mui/icons-material/RotateLeft';
import i18n from './i18n';
import { ToastContainer, toast } from "react-toastify";




function FeatureAssociation(){
   // sessionStorage.setItem("selectedIndex", 4);
  sessionStorage.setItem("selectedLink", "d_subdistributors");

    const {t} = useTranslation();

    const exampleData = JSON.parse(localStorage.getItem("userData"))
    const partnerLoginId = exampleData.LOGIN_ID;
    const userTypeId =  exampleData.USER_TYPE_ID;
    const localeVar = i18n.language;


    const [featuresList, setFeaturesList] = useState([]);
    const [state, setState] = useState('initial');
    const [resultMessage, setResultMessage] = useState('');
    const toastId = useRef(null);
const [Error , setError]= useState('');
    console.log("featuresList size = "+featuresList.length);

   

    const search = async() => {
        console.log("in search start");

        const distIdentityInput = document.getElementById('distIdentity');
        let distId = distIdentityInput.value.trim(); // Trim spaces
        distId=distId.toUpperCase();
       setHeaderCheckbox(false);

        if(distId === ""){
          
            if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('2480_016')); 
              }
              distIdentityInput.value = "";
              distIdentityInput.focus();
            return;
        }

        let userName = process.env.REACT_APP_USERNAME;
        let password = process.env.REACT_APP_PASSWORD;

        try{
            const apiUrl = window.config.apiUrl + process.env.REACT_APP_FEATUREASSOCIATION;
            const response = await axios.post(apiUrl, {
                                                 userName,
                                                 password,
                                                 localeVar,
                                                distId,
                                                partnerLoginId,
                                                userTypeId
                                            });

            console.log("response data = ",response.data);
            const data = response.data;
            const errorMsg = data.resultMessage;
           
                                     
            console.log("data.featuresList size = "+(data.featuresList).length);
            console.log(data.featuresList);
            setFeaturesList(data.featuresList);
            const featureddlist= data.featuresList;
            const initiallyCheckedRows = featureddlist.filter(feature => feature.profileSelected === "checked").map(feature => feature.profileId);
            setCheckedRows(initiallyCheckedRows);
            setTemporaryCheckedRows(initiallyCheckedRows);
            setState('search');

            if(errorMsg==="Distributor Does Not Exist" || errorMsg==="No Existe el distribuidor")   {
                setResultMessage(t('feature1'));
           } 
           else{
            console.log("errorMsg-->",errorMsg);
            setResultMessage(errorMsg);
           }   
       
            console.log("in search end");

        } catch  {
          console.log("error in search");
        }
    }
    const [selectedRowData, setSelectedRowData] = useState(null);
    const [headerCheckbox, setHeaderCheckbox] = useState(false);
    const [checkedRows, setCheckedRows] = useState([]);
  const [temporaryCheckedRows, setTemporaryCheckedRows] = useState([]);
  useEffect(() => {
    // setHeaderCheckbox(temporaryCheckedRows.length === featuresList.length);
  }, [temporaryCheckedRows, featuresList]);

    const checkAllFunction = (event) => {
    //    let sz=parseInt(size);

    //    if(document.getElementById("checkAll").checked)
    //    {
    //        for(let j=0; j<sz; j++ )
    //             document.getElementById(chkBoxName + j).checked = true;
    //    }
    //    else
    //    {
    //        for(let j=0; j<sz; j++)
    //         document.getElementById(chkBoxName + j).checked = false;
    //    }
    // const isChecked = event.target.checked;
    // setHeaderCheckbox(isChecked);
    // setCheckedRows(isChecked ? featuresList.map((item) => item.profileId) : []);
 const { checked } = event.target;
  setHeaderCheckbox(checked);

    setTemporaryCheckedRows((prevCheckedRows) => {
    if (checked) {
      // If checking all, only check rows where adminAccess is not disabled
      const enabledRows = featuresList
        .filter(feature => feature.adminAccess !== "disabled")
        .map(feature => feature.profileId);

      return enabledRows; // Set the enabled rows
    } else {
      // If unchecking all, clear the state
      return [];
    }
  });
   
  //     if(document.getElementById("checkAll").checked)
  //     {
  //         for(let j=0; j<sz; j++ )
  //              document.getElementById(chkBoxName + j).checked = true;
  //     }
  //     else
  //     {
  //         for(let j=0; j<sz; j++)
   //         document.getElementById(chkBoxName + j).checked = false;
  //     }
  }

    const unCheck = (event, id) => {
        
        // console.log("in unCheck");

        // if(document.getElementById(mainCheckBox) != null){

        //     if(isCheckAll(size, chkBoxName)){
        //         document.getElementById(mainCheckBox).checked = true;
        //     }
        //     else{
        //         document.getElementById(mainCheckBox).checked = false;
        //     }
        // }
        const isChecked = event.target.checked;
    // const newCheckedRows = isChecked
    //   ? [...checkedRows, id]
    //   : checkedRows.filter((rowId) => rowId !== id);
    // setCheckedRows(newCheckedRows);
    const newCheckedRows = isChecked
    ? [...temporaryCheckedRows, id]
    : temporaryCheckedRows.filter((rowId) => rowId !== id);

  setTemporaryCheckedRows(newCheckedRows);

    const selectedRow = featuresList.find((item) => item.profileId === id);
    if (isChecked && selectedRow) {
      setSelectedRowData(selectedRow);
        }
  setHeaderCheckbox(newCheckedRows.length === featuresList.length);

    }

    const isCheckAll = (size,chkBoxName) => {
        var j=0;
        var atleastOneChecked=0;
        var sz=parseInt(size);
    
        for(j=0;j<sz;j++)
            if(document.getElementById(chkBoxName + j) != null && document.getElementById(chkBoxName + j).checked)
                ++atleastOneChecked;
    
        if(parseInt(atleastOneChecked)==sz)
            return 1;
        else
            return 0;
    }
    
   const doSubmit = async() => {
        const features = [];
        let userName = process.env.REACT_APP_USERNAME;
        let password = process.env.REACT_APP_PASSWORD;

        for(let i = 0; i < featuresList.length; i++){
            if(document.getElementById("chk"+i).checked){
                features.push(document.getElementById("profileId"+i).value);
            }
        }
        console.log("features="+features);


        const distId = document.getElementById('distIdentity').value.toUpperCase();
        

        const apiUrl = window.config.apiUrl + process.env.REACT_APP_SET_FEATUREASSOCIATION;
        const response = await axios.post(apiUrl, {
                                            userName,
                                            password,
                                            distId,
                                            partnerLoginId,
                                            userTypeId,
                                            features,
                                            localeVar
                                        });
        
        const data = response.data;

        console.log( "data ResultMsg::::",data.resultMessage);

        setResultMessage(data.resultMessage);
        
        setFeaturesList([]);
       setHeaderCheckbox(false);
        
   }

   const navigate = useNavigate();
   const handleReturn = () => {
     navigate(-1);
   };
  const handleReset =() =>{
setFeaturesList([]);
setState('initial');
// setHeaderCheckbox(true);
console.log(headerCheckbox, "HeaderCheckbox??????????????????????")
document.getElementById('distIdentity').value ="";
  }
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const fetchChannels=async () => {
    //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
    const apiUrl3 = window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
    console.log(apiUrl3);
    const response3 = await axios.post(apiUrl3, {
      userName,
      password,
      localeVar,
      channelTransAl: "",
    });
    // const[channels]=response.data;
 
    localStorage.setItem("channels", JSON.stringify(response3.data.channels));
    //console.log(JSON.stringify(response.data.channels));
    //  setsalesData(JSON.stringify(response.data.channels));
  }
  

  useEffect(() => {
    // Set the browser title
      document.title = t('2472_020');
  }, []);

useEffect(()=>{
    localStorage.removeItem('channels');
fetchChannels();
})
    return (
        <>
            <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <tbody>
                    <Header />
                    <tr height="65px">
                    <PaymentManagerHeading />
                    <TopMenu menuLink= {localeVar==='en'?"Subdistributors":"Subdistribuidores"}/>
                    </tr>
                    <tr>
                      <LeftBgImage />

                        <td valign="top">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><JasperTopMenu /></tr></table>
<div className={'mL8 input_boxess'}>
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" align="left">
                               
                                <tbody><tr valign="top" height="75%">
                                    <td width="80%" nowrap="">

                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" style={{marginTop: '10px'}}>
                                            <tbody>
                                                {/* <tr>
                                                <td width="100%" align="center" class="redTextBold">{t('042')}</td>
                                            </tr> */}
                                                <tr>
                                                    <td width="100%" align="left">
                                                        <table border="0" cellpadding="0" cellspacing="1" align="left" width="100%">
                                                            <tbody>
                                                                {/* <tr><td colspan="2">&nbsp;</td></tr> */}
                                                                <tr>
                                                                    {/* <td align="center" width="5%">&nbsp;</td> */}
                                                                    <td align="left" width="75%">
                                                                        <table border="0" width="60%" align="left" cellpadding="0" cellspacing="1" bordercolor="red">
                                                                            <tbody><tr>
                                                                                <td class="" align="left">
                                                                                <TextField type="text" style={{marginLeft: '0px', marginTop:'5px', maxWidth:'200px'}} align="left" name="distIdentity" id="distIdentity"  size="20" maxlength="25" label={
                                    <span>
                                      {`${t('008')}`}
                                    </span>} className={'sampleInput mb5'}  />
                                                                                <Button className={'hoverEffectButton'} style={{marginLeft: '20px', marginTop:'8px'}} size="small" variant="contained" endIcon={<Search />} onClick={search}>{t('043')}</Button>
                                                                                </td>
                                                                            </tr>
                                                                            </tbody></table>
                                                                    </td>
                                                                </tr>

                                                                {/* <tr><td align="center" colspan="2">&nbsp;</td></tr> */}

                                                                { resultMessage !== '' &&
                                                                    <>
                                                                        <tr><td  style={{color: 'red'}} class="redTxt" colspan="2" align="center">{resultMessage}</td></tr>
                                                                    </>
                                                                }

                                                                <tr><td align="center" colspan="2">&nbsp;</td></tr>
                                                                {/* <tr><td align="center" colspan="2">&nbsp;</td></tr> */}
                                                                                                                   
                                                                <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', marginTop:'7px' }}>
                                                                <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">   
                                                                <TableHead>
                                                                <TableRow className={'darkgray subdistributor_table'}>
                                                                    <TableCell width="10%" nowrap=""><input type="checkbox" disabled={state === 'initial'} checked={state === 'initial' ? false : headerCheckbox}
  style={{marginTop: '3px', cursor: 'pointer'}} id="checkAll" onChange={checkAllFunction} /></TableCell>
                                                                    <TableCell width="90%" nowrap="">{/*Profile Name*/}{t('044')}</TableCell> </TableRow>
                                                                </TableHead>
                                                            <TableBody>
                                                            {featuresList.length > 0 ? 
                                                            
                                                                featuresList.map((feature, index) => 
                                                                    <TableRow class={index % 2 === 0 ? "lightyellow" : "lightgreen" }>
                                                                        <TableCell class="smallerTxt" align="center" style={{textAlign: 'center'}}>
                                                                            {/* <input type="checkbox"  /> */}
                                                                            <Checkbox
                                                                            id={feature.chk}
                                                                            checked={temporaryCheckedRows.includes(feature.profileId)}
                                                                            onChange={feature.adminAccess !== "disabled" ? (event) => unCheck(event, feature.profileId) : null}
                                                                            disabled={feature.adminAccess === "disabled"} // Disable checkbox for rows where adminAccess is "disabled"
                                                                            />
                                                                          
                                                                            {/* <Checkbox
                                                                            id={feature.chk} 
                                                                            // onChange={() => unCheck(featuresList.length, "chk", "checkAll")} 
                                                                            // checked={feature.profileSelected}
                                                                            disabled={feature.adminAccess === "disabled"}
                                                                           checked={temporaryCheckedRows.includes(feature.profileId)}
                                                                        //    onChange={feature.adminAccess==="" ? (event) => unCheck(event, feature.profileId) : null}
                                                                           onChange={feature.adminAccess !== "disabled" ? (event) => unCheck(event, feature.profileId) : null}
                                                                            /> */}
                                                                            <input type="hidden" id={feature.hidProfileId} value={feature.profileId} />
                                                                        </TableCell>
                                                                        <TableCell class="smallerTxt" width="90%" style={{textAlign:'center'}} align="center">{feature.profileName}</TableCell>	
                                                                    </TableRow>
                                                                )
                                                                : 
                                                                <>
                                                                </>
                                                            }




                                                                {/* <TableRow><TableCell align="center" colspan="2">&nbsp;</TableCell></TableRow> */}
                                                                {state === 'initial' ?
                                                                    <>
                                                                        <TableRow><TableCell class="redTxt" style={{color: 'red', textAlign: 'center'}} colspan="2" align="center">{/*Please provide search criteria.*/}{t('038')}</TableCell></TableRow>
                                                                    </>
                                                                    : 
                                                                    <></>
                                                                }
                                                                </TableBody>
                                                            </Table>
                                                            </TableContainer>
                                                                 <tr>
                                                                    <td colspan="2" align="center"></td>
                                                                </tr>
                                                                <tr>&nbsp;</tr>
                                                                
                                                                <tr>
                                                                    <td colspan="2" align="center">
                                                                       
                                                                                <Box style={{display: 'flex', gap: '2px', justifyContent: 'center'}}>
                                                                                {featuresList.length > 0 ?
                                                                            <>
	                                                                                <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />} onClick={doSubmit} >{t('028')}</Button> &nbsp;
                                                                                    <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RotateLeftIcon />} onClick={handleReset} >{t('045')}</Button> &nbsp;		
                                                                                    </>  : 
                                                                            <></>
                                                                        }

                                                                        <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<KeyboardReturn />} onClick={handleReturn} >{t('013')}</Button>		
                                                                                    
                                                                                    </Box>
                                                                          
                                                                          
<br></br>

                                                                    </td>
                                                                </tr>

                                                            </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                    </td>
                                </tr>

                                </tbody></table>
</div>

                        </td>

                        <ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
                    </tr>

                    <tr height="60px">
                        <td colSpan={2}>

                            <Footer />

                        </td>
                    </tr>

                </tbody>
            </table>
        </>
    );
}

export {FeatureAssociation};

