import {
  Box,
  Checkbox,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import React, { useState } from "react";

function Sample() {
    const [subDistributorId, setsubDistributorId] =useState();
    const [mdn, setMdn] =useState();
    const [sdfn, setSdfn] =useState();
    const [sdln, setSdln] =useState();
 const handleInfo=(e) =>{
    e.preventDefault();
    console.log(subDistributorId, mdn, sdfn, sdln)
 }
  return (
    
    <div>
      <form>
        <Box sx={{ flexGrow: 1 }}>
       
          <Grid
            container
            sx={{ width: 1 }}
            spacing={2}
            className={"darkgray"}
            style={{
              justifyContent: "center",
              marginLeft: "0px",
              marginTop: "0px",
              borderBottom: "1px solid #fff",
              paddingInline: "8px",
            }}
          >
            <Grid
              item
              xs={4}
              sx={{ textAlign: "left", padding: "0 !important" }}
            >
              <select name="sel" size="1" id="sel" class="selectBox">
                <option value="Funds Transfer" selected="selected">
                  Funds Transfer
                </option>
                <option value="Lateral Transfer">Lateral Transfer</option>
                <option value="Multi Network Transfer">
                  Multi Network Transfer
                </option>
                <option value="Multi Level Transfer">
                  Multi Level Transfer
                </option>
                <option value="Negative Fund Transfer">
                  Negative Fund Transfer
                </option>
              </select>
            </Grid>
            <Grid
              item
              xs={5}
              sx={{ textAlign: "center", padding: "0 !important" }}
            ></Grid>
            <Grid
              item
              xs={3}
              sx={{ textAlign: "right", padding: "0 !important" }}
            >
              <span className={"whiteBldTxt"}>Records Per Page: </span>
              <select
                name="pagecount"
                size="1"
                id="pagecount"
                class="selectBox"
              >
                <option value="25" selected="selected">
                  25
                </option>
                <option value="50">50</option>
                <option value="75">75</option>
                <option value="100">100</option>
              </select>
            </Grid>
          </Grid>
          <Grid
            container
            sx={{ width: 1 }}
            spacing={2}
            style={{
              justifyContent: "center",
              marginTop: "0px",
              marginLeft: "0",
            }}
          >
            <Grid
              className={"darkgray"}
              item
              xs={3}
              sx={{
                textAlign: "left",
                padding: "0 !important",
                borderRight: "1px solid #fff",
              }}
            >
              <span className={"whiteBldTxt"}>Distributor Id</span>
            </Grid>
            <Grid
              className={"darkgray"}
              item
              xs={3}
              sx={{
                textAlign: "center",
                padding: "0 !important",
                borderRight: "1px solid #fff",
              }}
            >
              <span className={"whiteBldTxt"}>VEERA2252</span>
            </Grid>
            <Grid
              className={"darkgray"}
              item
              xs={6}
              sx={{ textAlign: "left", padding: "0 !important" }}
            >
              <span className={"whiteBldTxt"}>
                Funds to be transfered to :{" "}
              </span>
              <select class="smallerTxt">
                <option value="5"> Sub Distributors</option>
                <option value="6">SalesPerson ID</option>
              </select>
            </Grid>
          </Grid>
          <br />
          <br />
          
          <Grid
            container
            spacing={2}
            sx={{ width: 1 }}
            style={{ marginLeft: "0px" }}
          >
            <Grid item xs={5} sx={{ textAlign: "left" }}>
              <div className={"distributor_left"}>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Sub distributor ID &nbsp;
                  </span>
                  <input
                    size="15"
                    className={"textBoxSmall"}
                    onChange={(e) => setsubDistributorId(e.target.value)}
                    type="text"
                    id=""
                  />
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Sub Distributor First Name &nbsp;
                  </span>
                  <input
                    size="15"
                    className={"textBoxSmall"}
                    onChange={(e) => setSdfn(e.target.value)}
                    type="text"
                    id=""
                    value=""
                  />
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Sub Distributor Company Name &nbsp;
                  </span>
                  <input
                    className={"textBoxSmall"}
                    type="text"
                    id=""
                    value=""
                  />
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Transfer Amount(MXN) &nbsp;
                  </span>
                  <input
                    className={"textBoxSmall"}
                    type="text"
                    id=""
                    value=""
                  />
                </div>
                <br></br>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Near-Zero Threshold Amount(MXN) &nbsp;
                  </span>
                  <input
                    className={"textBoxSmall"}
                    type="text"
                    id=""
                    value=""
                  />
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Transaction Password &nbsp;
                  </span>
                  <input
                    className={"textBoxSmall"}
                    type="password"
                    id=""
                    value=""
                  />
                </div>
              </div>
            </Grid>
            <Grid item xs={2}></Grid>
            <Grid item xs={5} sx={{ textAlign: "right" }}>
              <div className={"distributor_right"}>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>MDN &nbsp;</span>
                  <input
                    size="15"
                    onChange={(e) => setMdn(e.target.value)}
                    className={"textBoxSmall"}
                    type="text"
                    id=""
                    value=""
                  />
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Sub Distributor Last Name &nbsp;
                  </span>
                  <input
                    size="15"
                    className={"textBoxSmall"}
                    onChange={(e) => setSdln(e.target.value)}
                    type="text"
                    id=""
                    value=""
                  />
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Sub Distributor Location &nbsp;
                  </span>
                  <input
                    className={"textBoxSmall"}
                    type="text"
                    id=""
                    value=""
                  />
                  <button className={"inputButton"}>Search</button>
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Account Balance(MXN) &nbsp;
                  </span>
                  <span
                    className={"strongerTxtLable"}
                    style={{ textAlign: "center" }}
                  >
                    620,021.99
                  </span>
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Available Credit Limit(MXN) &nbsp;
                  </span>
                  <span className={"strongerTxtLable"}>0.00</span>
                </div>
                <div className={"distributor_input"}>
                  <span className={"strongerTxtLable"}>
                    Automatic fund transfer can be done &nbsp;
                  </span>
                  <input
                    className={"textBoxSmall"}
                    type="text"
                    id=""
                    value=""
                  />{" "}
                  <span className={"strongerTxtLable"}>
                    &nbsp; times in a month
                  </span>
                </div>
              </div>
            </Grid>
          </Grid>
          <br></br>
          <Grid
            container
            spacing={2}
            sx={{ width: 1 }}
            className={"darkgray"}
            style={{
              justifyContent: "center",
              marginTop: "0px",
              marginLeft: "0px",
              borderBottom: "1px solid #fff",
              paddingInline: "8px",
            }}
          >
            <Grid
              item
              xs={4}
              sx={{ textAlign: "left", padding: "0 !important" }}
            >
              <span className={"whiteBldTxt"}>No.Of records satisfied : 3</span>
            </Grid>
            <Grid
              item
              xs={5}
              sx={{ textAlign: "center", padding: "0 !important" }}
            ></Grid>
            <Grid
              item
              xs={3}
              sx={{ textAlign: "right", padding: "0 !important" }}
            >
              <span className={"whiteBldTxt"}>Displayed records : 1 - 3</span>
            </Grid>
          </Grid>
          
          <TableContainer component={Paper} style={{ boxShadow: "none" }}>
            <Table
              sx={{}}
              size="small"
              aria-label="a dense table"
              className={"subdistributor"}
            >
              <TableHead>
                <TableRow className={"darkgray subdistributor_table"}>
                  <TableCell
                    padding="checkbox"
                    className="subdistributor_checkbox"
                  >
                    <Checkbox
                      color="primary"
                      inputProps={{
                        "aria-label": "select all desserts",
                      }}
                    />
                  </TableCell>

                  <TableCell>Sub Distributor</TableCell>
                  <TableCell align="right">MDN</TableCell>
                  <TableCell align="right">
                    Sub Distributor First Name
                  </TableCell>
                  <TableCell align="right">Sub Distributor Last Name</TableCell>
                  <TableCell align="right">
                    Maximum limit of account(MXN)
                  </TableCell>
                  <TableCell align="right">
                    Current Account Balance(MXN)
                  </TableCell>
                  <TableCell align="right">Transfer Amount(MXN)</TableCell>
                  <TableCell align="right">
                    Post Transfer Balance(MXN)
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow className={"subdistributor_row"}>
                  <TableCell padding="checkbox">
                    <Checkbox
                      color="primary"
                      inputProps={{
                        "aria-label": "select all desserts",
                      }}
                    />
                  </TableCell>
                  <TableCell component="th" scope="row">
                    3334
                  </TableCell>
                  <TableCell align="right">---</TableCell>
                  <TableCell align="right">MAHESH</TableCell>
                  <TableCell align="right">SUB</TableCell>
                  <TableCell align="right">
                    <a href="#">3000001.00</a>
                  </TableCell>
                  <TableCell align="right">1,390.00</TableCell>
                  <TableCell align="right">
                    <input type="text" value="0.00" />
                  </TableCell>
                  <TableCell align="right">
                    <input type="text" value="1,300" />
                  </TableCell>
                </TableRow>
                <TableRow className={"subdistributor_row"}>
                  <TableCell padding="checkbox">
                    <Checkbox
                      color="primary"
                      inputProps={{
                        "aria-label": "select all desserts",
                      }}
                    />
                  </TableCell>
                  <TableCell component="th" scope="row">
                    3334
                  </TableCell>
                  <TableCell align="right">---</TableCell>
                  <TableCell align="right">MAHESH</TableCell>
                  <TableCell align="right">SUB</TableCell>
                  <TableCell align="right">
                    <a href="#">3000001.00</a>
                  </TableCell>
                  <TableCell align="right">1,390.00</TableCell>
                  <TableCell align="right">
                    <input type="text" value="0.00" />
                  </TableCell>
                  <TableCell align="right">
                    <input type="text" value="1,300" />
                  </TableCell>
                </TableRow>
                <TableRow className={"subdistributor_row"}>
                  <TableCell padding="checkbox">
                    <Checkbox
                      color="primary"
                      inputProps={{
                        "aria-label": "select all desserts",
                      }}
                    />
                  </TableCell>
                  <TableCell component="th" scope="row">
                    3334
                  </TableCell>
                  <TableCell align="right">---</TableCell>
                  <TableCell align="right">MAHESH</TableCell>
                  <TableCell align="right">SUB</TableCell>
                  <TableCell align="right">
                    <a href="#">3000001.00</a>
                  </TableCell>
                  <TableCell align="right">1,390.00</TableCell>
                  <TableCell align="right">
                    <input type="text" value="0.00" />
                  </TableCell>
                  <TableCell align="right">
                    <input type="text" value="1,300" />
                  </TableCell>
                </TableRow>
                <TableRow className={"subdistributor_row"}>
                  <TableCell padding="checkbox">
                    <Checkbox
                      color="primary"
                      inputProps={{
                        "aria-label": "select all desserts",
                      }}
                    />
                  </TableCell>
                  <TableCell component="th" scope="row">
                    3334
                  </TableCell>
                  <TableCell align="right">---</TableCell>
                  <TableCell align="right">MAHESH</TableCell>
                  <TableCell align="right">SUB</TableCell>
                  <TableCell align="right">
                    <a href="#">3000001.00</a>
                  </TableCell>
                  <TableCell align="right">1,390.00</TableCell>
                  <TableCell align="right">
                    <input type="text" value="0.00" />
                  </TableCell>
                  <TableCell align="right">
                    <input type="text" value="1,300" />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell colSpan={4}>
                    <input
                      style={{ width: "100%" }}
                      className="smallerTxt"
                      type="text"
                      value="Total Transfer Amount(MXN)"
                    />
                  </TableCell>
                  <TableCell>
                    <span>&nbsp;&nbsp;&nbsp;</span>
                    <input
                      width={1}
                      className="smallerTxt"
                      type="text"
                      value="0.00"
                    />
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
          <Grid
            container
            spacing={2}
            sx={{ width: 1 }}
            className={""}
            style={{
              justifyContent: "right",
              marginTop: "0px",
              marginLeft: "0px",
            }}
          >
            <Grid
              item
              xs={4}
              sx={{ textAlign: "right", padding: "0 !important" }}
            >
              <button className={"inputButton"}>Preview</button>
              <button className={"inputButton"}>Return</button>
            </Grid>
          </Grid>
        </Box>
      </form>
    </div>
  );
}

export default Sample;
