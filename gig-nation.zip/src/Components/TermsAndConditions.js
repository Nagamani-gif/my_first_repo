import React, { useEffect, useState } from 'react'
import Button from '@mui/material/Button';
import { ArrowCircleDownRounded, ArrowCircleUpRounded, KeyboardReturn } from '@mui/icons-material';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router';
import Navbar from './Navbar';
import { Footer } from './PageComponents';
import ExpandCircleDownIcon from '@mui/icons-material/ExpandCircleDown';
const TermsAndConditions = () => {
  
   const [isBottom, setIsBottom] = useState(false);

  const handleScroll = () => {
    const scrolledToBottom =
      window.innerHeight + window.scrollY >= document.body.offsetHeight - 10;
    setIsBottom(scrolledToBottom);
  };


    const [isVisible, setIsVisible] = useState(true);

    const handleScrollToBottom = () => {
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        setTimeout(() => setIsVisible(false), 300); // Delay hiding to match the fade-out duration
      };
  
    const checkScrollPosition = () => {
      const scrolledToBottom =
        window.innerHeight + window.scrollY >= document.body.offsetHeight - 300;
      if (scrolledToBottom) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }
    };
    const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

    useEffect(() => {
    window.addEventListener('scroll', handleScroll);
      return () => {
      window.removeEventListener('scroll', handleScroll);
      };
    }, []);


    const { t } = useTranslation();
    const navigate = useNavigate();
    const handleClick = () => {
        navigate(-1);
    };
    // const [isVisible, setIsVisible] = useState(true);

    // const handleScrollToBottom = () => {
    //     window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    //     setTimeout(() => setIsVisible(false), 300); // Delay hiding to match the fade-out duration
    //   };
  
    // const checkScrollPosition = () => {
    //   const scrolledToBottom =
    //     window.innerHeight + window.scrollY >= document.body.offsetHeight - 300;
    //   if (scrolledToBottom) {
    //     setIsVisible(false);
    //   } else {
    //     setIsVisible(true);
    //   }
    // };
  
    // useEffect(() => {
    //   window.addEventListener('scroll', checkScrollPosition);
    //   return () => {
    //     window.removeEventListener('scroll', checkScrollPosition);
    //   };
    // }, []);
    return (
 
 
        <table>
            <tr>
               
                <Navbar />
                </tr>
            <tr>
                <div className={'termsContainer'}>
 
 
                    <br></br>
                    <center><h4 className='tc1'> <b  >{t('terms_conditions_1')}</b></h4></center>
                    <br></br>
 
                    <p><span className='tc'><b>{t('terms_conditions_2')}</b></span></p>
                    <p><span><b className='tc' >{t('terms_conditions_3')}</b></span></p>
                    <p><span><b className='tc' >{t('terms_conditions_4')}</b></span></p>
                    <p><span><b className='tc' >{t('terms_conditions_5')}</b></span></p>
                    <p><span><b className='tc' ><u>{t('terms_conditions_6')}</u></b></span></p>
                    <p><span><b className='tc' >{t('terms_conditions_7')}</b></span></p>
                    <p><span><b className='tc' ><u>{t('terms_conditions_8')}</u></b></span></p>
                    <p><span><b className='tc' >{t('terms_conditions_9')}</b></span></p>
                    <p><b className='tc' ><u>{t('terms_conditions_10')}</u></b></p>
                    <p><b className='tc' >{t('terms_conditions_11')}</b></p>
                    <p><b className='tc' >{t('terms_conditions_12')}</b></p>
                    <p><b className='tc' >{t('terms_conditions_13')}</b></p>
                    <p><b className='tc' >{t('terms_conditions_14')}</b></p>
                    <p><b className='tc' ><u>{t('terms_conditions_15')}</u></b></p>
                    <p><b className='tc' >{t('terms_conditions_16')}</b></p>
                    <p><b className='tc' ><u>{t('terms_conditions_17')}</u></b></p>
                    <p><b className='tc' >{t('terms_conditions_18')}</b></p>
                    <p><b className='tc' >{t('terms_conditions_19')}</b></p>
                    <ul className='tc' >
                        <li>
                            <p><b>{t('terms_conditions_20')}</b></p>
                        </li>
                        <li>
                            <p><b>{t('terms_conditions_21')}</b></p>
                        </li>
                        <li>
                            <p><b>{t('terms_conditions_22')}</b></p>
                        </li>
                        <li>
                            <p><b>{t('terms_conditions_23')}</b></p>
                        </li>
                        <li>
                            <p><b>{t('terms_conditions_24')}</b></p>
                        </li>
                        <li>
                            <p><b>{t('terms_conditions_25')}</b></p>
                        </li>
                    </ul>
 
 
                    <p><b className='tc' >{t('terms_conditions_26')}</b></p>
 
                    <p><b className='tc' ><u>{t('terms_conditions_27')}</u></b></p>
                    <p><b className='tc' >{t('terms_conditions_28')}</b></p>
 
                    <p><b className='tc' ><u>{t('terms_conditions_29')}</u></b></p>
                    <p><b className='tc' >{t('terms_conditions_30')}</b></p>
 
                    <p><b className='tc' ><u>{t('terms_conditions_31')}</u></b></p>
                    <p><b className='tc' >{t('terms_conditions_32')}</b></p>
                    <p><b className='tc' >{t('terms_conditions_33')}</b></p>
 
                    <p><b className='tc' ><u>{t('terms_conditions_34')}</u></b></p>
                    <p><b className='tc' >{t('terms_conditions_35')}</b></p>
                    <p><b className='tc' >{t('terms_conditions_36')}</b></p>
 
                    <p><b className='tc' ><u>{t('terms_conditions_37')}</u></b></p>
                    <p><b className='tc' >{t('terms_conditions_38')}</b></p>
                    <p><b className='tc' >{t('terms_conditions_39')}</b></p>
                    <p><b className='tc' >{t('terms_conditions_40')}</b></p>
 
 {/* <div style={{position:'fixed', right:'8%', bottom:'10px'}} className={'arrowDown'}><ArrowCircleDownRounded /></div> */}
 
 {/* {isVisible ? ( */}
    {/* <div
    style={{
      position: 'fixed',
      right: '8%',
      bottom: '10px',
      cursor: 'pointer',
      opacity: isTopVisible ? 1 : 0,
      transition: 'opacity 0.3s ease-in-out',
      color:'#39f'
    }}
    className={'arrowDown'}
    onClick={handleScrollToBottom}
  >
    <ExpandCircleDownIcon />
  </div> */}
  {/* ) : ''} */}
  {/* {isBottomVisible && ( */}
        <div
        style={{
            position: 'fixed',
            right: '6%',
            bottom: '10px',
            cursor: 'pointer',
            opacity: 1,
            transition: 'opacity 0.3s ease-in-out',
            color:'#39f'
          }}
          className={'arrowDown'}
          onClick={isBottom ? handleScrollToTop : handleScrollToBottom}
          >
            {isBottom ? <ExpandCircleDownIcon style={{transform:'rotate(180deg)'}} /> : <ExpandCircleDownIcon />}
  </div>
    
                    <table border={0} width="100%" cellSpacing={1} cellPadding={2}>
                        <tbody>
                            <tr>
                                <td align="right">
                                    <Button onClick={handleClick} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<KeyboardReturn />}>
                                        {t('013')}
                                    </Button>
                                </td>
                            </tr>
                            <tr>&nbsp;</tr>
                        </tbody>
                    </table>
 
 
 
                </div>
            </tr>
 
            <tr height="50px">
                <td >
                    <Footer />
                </td>
            </tr>
        </table>
 
 
 
    )
}
 
export default TermsAndConditions