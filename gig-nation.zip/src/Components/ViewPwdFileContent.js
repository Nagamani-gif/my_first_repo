import React, { useEffect, useState } from 'react'
import SendIcon from '@mui/icons-material/Send';
import i18n from './i18n';
import {
    Box,
    Button,
    Checkbox,
    FormControl,
    Grid,
    InputLabel,
    MenuItem,
    Paper,
    Select,
    Tab,
    Table,
    TableBody,
    TableContainer,
    TableHead,
    TableRow,
    Tabs,
    TextField,
    Typography,
    TableCell,
    DialogTit,
    DialogTitle,
    Dialog,
    IconButton,
    DialogContent,
    DialogContentText,
  } from "@mui/material";
  import {KeyboardReturn, CancelRounded } from '@mui/icons-material';
import axios from 'axios';
import { useTheme } from '@mui/material';
import { useSelector } from 'react-redux';
import CloseIcon from "@mui/icons-material/Close";
import { useMediaQuery } from '@mui/material';
import { useTranslation } from 'react-i18next';



const ViewPwdFileContent = ({fileName}) => {
   // alert(fileName);
    const {t} = useTranslation();
    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
    const [popopen, setPopopen] = useState(false);
    const [data, setData] = useState([]);

    const exampleData = JSON.parse(localStorage.getItem("userData"))
    const partnerId = exampleData.LOGIN_ID;
    let localeVar=i18n.language;
    const userName = process.env.REACT_APP_USERNAME;
    const password =  process.env.REACT_APP_PASSWORD;
    
    //const fileName="SUPERADMIN-pwd-validations.txt";
    //console.log(partnerId);
   let check="";
   let currentStringArr=[];
    
    const handlePopup = () => {
      setPopopen(true);
      fetchData();
  }
    const fetchData = async() => {
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_PASSWORDRULES_FILE_READ_URL;
      
      const response = await axios.post(apiUrl, {
          userName,
          password,
          localeVar,
          fileName   
      });
    
      const { responseCode } = response.data;

      check=response.data.responseCode;
   
    if(check==="00"){
      currentStringArr=response.data.currentString;
      setData(currentStringArr);
    }
    console.log("currentStringArr=="+currentStringArr);
   }
  
    // MODAL CLOSING FUNCTION
    const handleClose = () => {
      setPopopen(false);
    };
 
    
 


   
    // const submit = async() => {
 
    //     const apiUrl = 'http://10.10.19.202:8080/airmanage/rest/partner/doQuickFundTransfer';
    //     const response = await axios.post(apiUrl, {  
    //                                         partnerLoginId,
    //                                         localeVar: "en"
    //                                     });
    //     const data = response.data;
 
    // }
 
    return(
        <>
        <span onClick={() => {handlePopup()}} className="pageLink1" style={{color: 'blue', textDecoration: 'underline'}}>{t('5162')}</span>
                     {/* MODAL STARTS HERE */}
                     <Dialog
          fullScreen={fullScreen}
          open={popopen}
          onClose={() => {handleClose()}}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "25px" }}
            className={"headerTxt"}
            align="center"
          >
           
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={() => {handleClose()}}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
            }}
          >
            <CloseIcon />
          </IconButton>
          <DialogContent>
            <DialogContentText>
            <TableContainer component={Paper} className={'shadowTable passwordRulespopup'} style={{ maxHeight: '300px' }}>
            <Table sx={{ minWidth: 500 }} size="small" className={''} stickyHeader aria-label="sticky table">
                  <TableHead >
                    <TableRow className={'darkgray subdistributor_table'}>
                      <TableCell  colSpan={4} align="center" sx={{backgroundColor: "#3399FF", color: "white"}}>
                      {t('242488')}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
{data.length>0 ?
(data.map((data, index) => (
  <TableRow key={index}>
    <TableCell className="strongerTxt" align='center'>
        <span>{data}</span>
    </TableCell>
  </TableRow>
))):(<TableRow>
<TableCell className="strongerTxt" align='center'>
No DATA FOUND
</TableCell>
</TableRow>)}

{/* {data && data.map((data)=>(
  <span>{data}</span>
))} */}
 
                  </TableBody>
                </Table>
              </TableContainer>
              <br></br>
              <div align="center" gap={1}>
                {/* <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}>
                 Submit
                </Button>&nbsp; */}
                <Button className={'hoverEffectButton'} onClick={() => {handleClose()}} size="small" variant="contained" endIcon={<CancelRounded />}>
                    Close
                </Button>
              </div>
            </DialogContentText>
          </DialogContent>
        </Dialog>
        {/* MODAL ENDS HERE */}
       
        </>
    );
}

export default ViewPwdFileContent