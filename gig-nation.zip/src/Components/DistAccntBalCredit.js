import React, { useState, useEffect, useRef, Fragment } from 'react';
import axios from 'axios';
import { Footer, Header, LeftBgImage, LeftMenu, PaymentManagerHeading, ProfileMenu } from './PageComponents';
import TopMenu from './TopMenu';
import { useSelector } from 'react-redux';

import { useTranslation } from 'react-i18next';

//import { appendScript, removeScript } from './calendar/AddCalendar';

import TextField from '@mui/material/TextField';

import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'

//import {DatePicker2} from './DatePicker';

//import {DateTimePicker} from '@mui/x-date-pickers/DateTimePicker';

//import { Example } from './DatePicker2';
import { useNavigate } from 'react-router-dom';
import { Box, Button, FormControl, InputLabel, MenuItem, Select, styled } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import { KeyboardReturn, AccountBalance} from '@mui/icons-material';
import i18n from './i18n';
import { ToastContainer, toast } from "react-toastify";


function DistAccntBalCredit() {
  //sessionStorage.setItem("selectedIndex", 1);
 sessionStorage.setItem("selectedLink", "a_profile");
  const {t} = useTranslation();

    const exampleData = JSON.parse(localStorage.getItem("userData"))
    const partnerLoginId = exampleData.LOGIN_ID;
    const [partnerId, setPartnerId] = useState('');
    const [accountBalance, setAccountBalance] = useState('');
    const [credit, setCredit] = useState('');
    const [date, setDate] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const [depositBalance, setDepositBalance] = useState(true);
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;

    const [deposit, setDeposit] = useState('');
    const localeVar=i18n.language;
    const toastId = useRef(null);


    useEffect(() => {
      // Set the browser title
      document.title = t('2472_013');
    }, []);
    
    
    


    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const apiUrl = window.config.apiUrl + process.env.REACT_APP_GET_BALANCE;
                const response = await axios.post(apiUrl, {
                  userName,
                  password,
                  partnerLoginId
                });
                const data = response.data;
                setPartnerId(data.distributorId);
                setAccountBalance(data.accountBalance);
                setCredit(data.creditOrBalance);
                setDate(data.todayDate);


                console.log("response",data);
            } catch (error) {
                setError(error.message);
            } finally {
                setLoading(false);
            }
        };


        fetchData();
    }, []);


    const depositAmount = (msg) => {
      setDeposit(msg);
      setDepositBalance(false);
    }

    const navigate = useNavigate();
    const handleReturn = () => {
      navigate(-1);
    };

    return (
      
        <>

<table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
     <tbody>
          <Header/>
       <tr height="65px">
       <PaymentManagerHeading />
       <TopMenu menuLink= {localeVar==='en'?"Profile":"Perfil"}/>
     </tr>
     <tr>
        {/* <td valign="top" style={{borderRightStyle: 'solid', borderRightWidth: '1pt',borderColor: "rgb(51 153 255)"}} nowrap="nowrap">

    </td> */}
<LeftBgImage />
<table border={0} width="100%" cellSpacing={0} cellPadding={1}>
  <tbody>
    <ProfileMenu/>
    <tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
    </tr>
  </tbody>
</table>
<div className={'mL8 distAccnt'}>
  {/* <Box className={'distPaymentt'} sx={{display:'flex', marginBottom:'17px', width:'80%', gap: '10%', alignItems:'center'}}>
    <p className="labelText">{t('008')} : <b> {partnerId} </b></p>
    <p className="labelText">{t('009')}&nbsp;(MXN) : <b>{accountBalance}</b></p>
    <p className="labelText">{t('010')} / {t('011')}&nbsp;(MXN) : <b>{credit}</b></p>
  </Box> */}
            {/* <table border="0" bordercolor="green" cellpadding="0" cellspacing="0" width="100%">
                <tbody>
                    <tr>
<td colspan="3" align="center">
    <table border="0" align="center" width="100%">
        <tbody><tr>
            <td width="80%" align="left" class="labelText">{t('008')} : {partnerId}</td>
        </tr>
            <tr>
                <td width="80%" nowrap="" align="left" class="labelText">{t('009')}&nbsp;(MXN) : {accountBalance}</td>
            </tr>
            <tr>
                <td width="80%" align="left" class="labelText">{t('010')}<big>/</big>{t('011')}&nbsp;(MXN) : {credit}</td>	</tr>
                <tr>&nbsp;</tr>	
                </tbody></table>	</td>
</tr>
                </tbody>
            </table> */}


            { deposit !== '' ? <table align="left"><tr><td style={{padding:'0'}} align="left"><font color='red' size="2">{deposit}</font></td></tr></table> : <></> }



            { depositBalance ? <></> : 

            <table border="0" align="left" width="100%">
                <tbody>
                    <tr>
                        <td align="left" id="middlerowbuttons">


                            <Box style={{display: 'flex', gap: '0px', marginBottom:'10px', justifyContent: 'flex-start'}}>
	                            {/* <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<AccountBalance />} onClick={() => {setDepositBalance(true); setDeposit('')}} >{t('012')}</Button> &nbsp; */}
                              <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<KeyboardReturn />} onClick={handleReturn} >{t('013')}</Button>		
                            </Box>

                        </td>
                    </tr>
                </tbody>
            </table>

            }

            { depositBalance && (deposit === '') ? <table align="left"><tr> <td style={{padding:'0'}}><DepositBalance f={depositAmount}/></td> </tr> </table> : <> </> }

            <table border="0" align="left" width="100%">
            <tbody>
              {/* <tr><td>&nbsp;</td></tr> */}
              <tr>
                <td className={'redText'}>
                            {/*Distributor Account Balance/Credit information on date*/}<div style={{marginBottom:'10px'}}>{t('6822')} : {t('007')} - {date}</div> {/*17/04/2024*/}
                            </td>
              </tr>


            </tbody>
          </table>
            </div>
    </tr>

    


    <tr height="60px">
        <td colSpan={2}>

        <Footer/>

        </td>
      </tr>
    </tbody>
    </table>
        </>
    );
}

function DepositBalance({f}){

  const {t} = useTranslation();
  const [paymentTypeValue, setPaymentTypeValue] = useState('cash');
  const [selectedBank, setSelectedBank] = useState(false);
  const [totalAmount, setTotalAmount] = useState('');
  const [bankList, setBankList] = useState([]);
  const [deposit, setDeposit] = useState('');
  const [dateValue, setDateValue] = useState(null);
  const [bankName, setbankName]=useState('1:BANAMEX');
  const toastId = useRef(null);
  var dateValue2 =  '';
  const [payref, setPayref] = useState('');
  const [depositAmt, setDepositAmt] = useState('');
  const [transactionPwd, setTransactionPwd] = useState('');
  const [isMandate, setIsMandate] = useState(false);
  const [isMandate1, setIsMandate1] = useState(false);
  const [isMandate2, setIsMandate2] = useState(false);
  const handleBlur = () => {
    if (payref.trim() === "") {
      setIsMandate(true);
    } else {
      setIsMandate(false);
    }
  };
  const handleTransactionBlur = () => {
    if (transactionPwd.trim() === "") {
      setIsMandate2(true);
    } else {
      setIsMandate2(false);
    }
  }
  if(dateValue != null){
    var d = new Date(dateValue);
    dateValue2 =  d.getDate() + "/" + (d.getMonth() + 1)  + "/" + d.getFullYear();
    console.log("date = "+ d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear());
  }

  const userName = process.env.REACT_APP_USERNAME;
  const password = process.env.REACT_APP_PASSWORD;
  const exampleData = JSON.parse(localStorage.getItem("userData"))
  const partnerLoginId = exampleData.LOGIN_ID;

  function handlePaymentType(e){
    setPaymentTypeValue(e.target.value);
    if(e.target.value === 'bank'){
      setSelectedBank(true);
      getBanks();
    }else if(e.target.value === 'cash'){
      setSelectedBank(false);
    }
  }
  const handleDoubleClick = (e) => {
    e.preventDefault(); // Prevent default behavior
    e.stopPropagation(); // Stop event propagation
  };
  const getBanks = async() => {
    //toast.error("in getBanks function");
    //toast.error(t('locale'));
    try {
        const apiUrl = window.config.apiUrl + process.env.REACT_APP_GETBANKS;
        const response = await axios.post(apiUrl, {
          userName,
          password,
          partnerLoginId
        });
        const data = response.data;

        console.log("response"+data.BANK_LIST);

        setBankList(data.BANK_LIST);

    } catch (error) {
      console.log("error in getBanks");
    }
  }

  const calculateTaxAndDiscount = async() => {
    console.log("Entered CalculateTx function")
    let depositAmount = document.getElementById('depositamount').value;
    if (depositAmount.trim() === "") {
      setIsMandate1(true);
    } else {
      setIsMandate1(false);
    }
    if(depositAmount != '')
    {
    try{
      
        console.log(depositAmount);
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_CALTAXDISCOUNT;
      const response = await axios.post(apiUrl, {
          userName,
          password,
        "partnerId":partnerLoginId,
        depositAmount
    });
    const taxAndDiscountData = response.data;
  console.log(response);
    console.log("taxAndDiscountData.distributorId="+taxAndDiscountData.distributorId);
    console.log("taxAndDiscountData.totBilAmount="+taxAndDiscountData.totBilAmount);

    setTotalAmount(response.data.totBilAmount);

    //document.getElementById('totBilAmount').value = taxAndDiscountData.totBilAmount;

    }catch{
      console.log("error occured in calculateTaxAndDiscount");
    }
  }
    else{
      setTotalAmount('');
    }

  }
  const doSubmit = async() => {

    if(document.getElementById('depositamount').value.length === 0 || document.getElementById('depositamount').value.trim() === ""){
      if (!toast.isActive(toastId.current)) {     
        toastId.current = toast.error(t('015')); 
      }
     // toast.error('Please Enter Deposit Amount');
      document.getElementById('depositamount').focus();
      return;
    }
        // toast.error(document.getElementById('payrefno').value);
        if(document.getElementById('payrefno').value.length === 0 || document.getElementById('payrefno').value.trim() === ""){
          // toast.error('Please Enter Valid Payment Reference Number');
          if (!toast.isActive(toastId.current)) {     
            toastId.current = toast.error(t('014')); 
          }
          document.getElementById('payrefno').focus();
          return;
        }

    if(document.getElementById('transactionpassword').value.length === 0 || document.getElementById('transactionpassword').value.trim() === ""){
      
      if (!toast.isActive(toastId.current)) {     
        toastId.current = toast.error(t('016')); 
      }
     // toast.error('Please enter Transaction Password');
      document.getElementById('transactionpassword').focus();
      return;
    }


    // let paymentType = document.getElementById('paymentType').value;
    let paymentType = paymentTypeValue;
    let depositAmount = document.getElementById('depositamount').value;
    let transactionpassword = document.getElementById('transactionpassword').value;
    
    let totBilAmount = document.getElementById('totBilAmount').value;
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
    
    // let bankName = '';
    // if(selectedBank){
    //   bankName = document.getElementById('bankName').value;
    // }
    //let date = document.getElementById(':r1:').value;
    const handleInput = (e) => {
      // Ensure the value only contains digits
      e.target.value = e.target.value.replace(/[^0-9]/g, '');
    };
    let payrefno =  document.getElementById('payrefno').value;

    var localeVar = i18n.language

    try{
    const apiUrl = window.config.apiUrl + process.env.REACT_APP_DEPOSITBAL;
    const response = await axios.post(apiUrl, {
                              userName,
                              password,
                              "partnerId":partnerLoginId,
                              paymentType,
                              bankName,
                              dateValue2,
                              payrefno,
                              depositAmount,
                              totBilAmount,
                              transactionpassword,
                              localeVar
                            });

    const insertedData = response.data;

    //setDeposit(insertedData.msg);

if(insertedData.msg==='SUCCESS'){
  f(t('017'))

}
// else if(insertedData.msg !== '')
//   {
//     console.log(response.data,"response.data---------")

// }
else{
     console.log("insertedData.msg-->",insertedData.msg)
     if(!toast.isActive(toastId.current) )  {
      toastId.current = toast.error(response.data.msg); 
    }
    if(response.data.msg === t("2480_020")){
      setTransactionPwd('');
      document.getElementById('transactionpassword').focus();

    }
    // f(insertedData.msg);
}
    //console.log("deposit="+deposit);

    } catch {
      console.log('error in doSubmit');
    }

  }

  const Str2Hex = (str) => {
    var tmp = str;
    var str = '';
    var c;
    for (var i=0; i<tmp.length; i++) {
      c = tmp.charCodeAt(i);
      //str += d2h(c) + ' ';
      str += d2h(c) + 'xf0cccxX';
    }
    return str;
  }

  const d2h=(d)=> {return d.toString(16);}

  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };
  const RedAsterisk = styled('span')({
    color: 'red',
  });
  const numvalidate = (event) => {
    const keyCode = event.keyCode || event.which;
    const keyValue = String.fromCharCode(keyCode);
    const regex = /^[0-9\b]+$/; // Only allows numbers and backspace
    
    // Prevent non-numeric input
    if (!regex.test(keyValue)) {
      event.preventDefault();
      return false;
    }
  
    return true;
  };
  const localeVar = i18n.language;
  return(

    <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="es">

    <>
    {/* <div><DatePicker /></div>
    <div><DateTimePicker /></div>
    <div>&nbsp;</div>
    <div><DatePicker2 /></div>
    <div>&nbsp;</div>
    <div><Example /></div>  */}


  
  <table border="0" align="left" width="100%">
<tbody>
  
  {/* <tr>
	<td width="100%" colspan="5" class="redText" align="center">
		{t('012')}
	</td>
</tr>
<tr>&nbsp;</tr> */}
{ deposit !== '' ? <tr><td><font color='red'>{deposit}</font></td></tr> : <></>}

{ deposit === 'SUCCESS' ? <tr><td><font color='red'>{t('017')}</font></td></tr> : 
                                deposit === 'FAILED' ? <tr><td><font color='red'>{t('018')}</font></td></tr> : <></> }

<tr>
<td align="left" style={{padding:'0'}} width="100%">
<table width="60%" border="0">
<tbody><tr>
  {/* <td>&nbsp;</td> */}
{/* <td width="100%" align="left" class="labelText" nowrap="">{t('019')}&nbsp;</td> */}
<td style={{padding:'0'}}>
{/* <select name="paymentType" size="1" onChange={handlePaymentType} id="paymentType" style={{width: '140px'}} class="selectBox">
  <option value="cash">{t('020')}</option>
  <option value="bank">{t('021')}</option>
</select> */}
<FormControl className={'selected_formcontrol'} sx={{ minWidth: 280 }} size="small">
      <InputLabel id="demo-select-small-label">{t('019')}</InputLabel>
      <Select
       label={t('019')}
       className={'bankSelect'}
        labelId="demo-select-small-label"
        id="demo-select-small"
        value={paymentTypeValue}
        onChange={handlePaymentType}
        onDoubleClick={handleDoubleClick} // Add double-click handler
      >
        {/* <MenuItem value={t('020')}>{t('020')}</MenuItem>
        <MenuItem value={t('021')}>{t('021')}</MenuItem> */}
        <MenuItem value="cash">{t('020')}</MenuItem>
        <MenuItem value="bank">{t('021')}</MenuItem>
      </Select>
    </FormControl>
</td>
</tr>
{selectedBank ? 
  <>
    <tr id="trBankNames" /*style={{display: 'none'}}*/>
    {/* <td width="50%" align="left" class="labelText" nowrap="">{t('022')}&nbsp;</td> */}
    <td style={{padding:'0'}}>

    {/* <select name="bankName" size="1" id="bankName" style={{width: '140px'}} class="selectBox">
      <option value="1:BANAMEX">BANAMEX</option>
      <option value="2:SANTANDER">SANTANDER</option>
      <option value="3:BANCOMER">BANCOMER</option>
      <option value="4:HSBC">HSBC</option>
    </select> */}

    {/* <select name="bankName" size="1" id="bankName" style={{width: '140px'}} class="selectBox">
        {bankList.map((bank) => (
          <option value={bank.BANK_ID+":"+bank.BANK_NAME}>{bank.BANK_NAME}</option>
        )
        )}
    </select> */}
    <FormControl className={'selected_formcontrol'} sx={{minWidth: 280 }} size="small">
      <InputLabel id="demo-select-small-label">{t('022')}</InputLabel>
      <Select
      label={t('022')}
      name="bankName" size="1" 
      id="bankName"
        labelId="demo-select-small-label"
        value={bankName}
        onChange={(e)=>setbankName(e.target.value)}
        className={'bankSelect selected_dropdown'} 
      >
         {bankList.map((bank) => (
          <MenuItem value={bank.BANK_ID+":"+bank.BANK_NAME}>{bank.BANK_NAME}</MenuItem>

         ))}
      </Select>
    </FormControl>

    </td>
    </tr>
    <tr id="trBankdate"  /*style={{display: 'none'}}*/ >
    {/* <td class="strongerTxtLable" align="left" nowrap="">{t('023')}  </td> */}
    <td style={{padding:'0'}} align="left" nowrap="">
    <LocalizationProvider
      dateAdapter={AdapterDayjs}
      adapterLocale={localeVar === 'en' ? 'en' : 'es'} // Dynamically set the locale
    >



        <DatePicker
       className={'datePickerrr'}
                value={dateValue}
                onChange={(newValue) => setDateValue(newValue)}
        label={t('023')} // This serves as the floating label
        inputFormat=" " // Keeps the input field empty unless a date is selected
        renderInput={(params) => (
          <TextField
            {...params}
            id="datePicker"
            InputLabelProps={{
              shrink: true, // Always shrink the label to allow for a floating effect
            }}
            placeholder={!dateValue ? t('023') : ''} // Show the placeholder only if no date is selected
            fullWidth
            variant="outlined"
            sx={{ width: "119px", height: "40px", padding: '20px' }}
            
          />
        )}
        />
    </LocalizationProvider>
    </td>
    </tr>
  </>

: <></> }

{console.log("date:::::::",dateValue)}

<tr>
  {/* <td><font color="red">*</font></td> */}
{/* <td width="80%" align="left" className="labelText" nowrap="" >{t('024')}<span style={{color:'red'}}>*</span></td> */}
<td style={{padding:'0'}} nowrap=""><TextField type="text"  value={payref}  name="payrefno" maxlength="30"  id="payrefno" label={
        <span>
          {`${t('024')}`}
          <RedAsterisk>*</RedAsterisk>
        </span>}
         onChange={(e) => setPayref(e.target.value)}
        onBlur={handleBlur}
        className={`sampleInput mb5 ${isMandate ? "mandateField" : ""}`}
          inputProps={{ maxLength: 30 }} // Properly set maxLength to 30
         />
</td>
</tr>
<tr>
{/* <td><font color="red">*</font></td> */}
{/* <td width="80%" align="left" class="labelText" nowrap="">{t('025')}&nbsp;(MXN)
</td> */}
<td style={{padding:'0'}}>
<TextField 
  type="text" 
  value={depositAmt} 
  name="depositamount" 
  id="depositamount" 
  maxLength="10" 
  label={
<span>
      {`${t('025')} (MXN)`}
<RedAsterisk>*</RedAsterisk>
</span>
  }
  onInput={(e) => {
    // Allow only digits and one decimal point, and limit to 10 characters
    const value = e.target.value;
    e.target.value = value
      .replace(/[^0-9.]/g, '')        // Remove all non-digit and non-decimal characters
      .replace(/(\..*)\./g, '$1')     // Allow only one decimal point
      .slice(0, 10);                  // Limit to 10 characters
  }}
  onChange={(e) => setDepositAmt(e.target.value)}
  onBlur={calculateTaxAndDiscount} 
  className={`sampleInput mb5 ${isMandate1 ? "mandateField" : ""}`} 
/>
</td>
</tr>
<tr>
  {/* <td>&nbsp;</td> */}
{/* <td width="80%" align="left" class="labelText" nowrap="">{t('026')}&nbsp;(MXN)<span style={{color:'red'}}>*</span>
</td> */}
<td><TextField type="text" id='totBilAmount' name="totBilAmount" maxlength="10" label={
        <span>
          {`${t('026')} (MXN)`}
        </span>} size="18"  InputProps={{
        readOnly: true, // Makes the TextField read-only
      }} className={'sampleInput mb5'} value={totalAmount}/>
</td>

</tr>
<tr>
  {/* <td><font color="red">*</font></td> */}
{/* <td width="80%" align="left" class="labelText" nowrap="">{t('027')}<span style={{color:'red'}}>*</span>
</td> */}
<td style={{padding:'0'}}>
  <TextField type="password" name="transactionpassword" label={
        <span>
          {`${t('027')} `}
          <RedAsterisk>*</RedAsterisk>
        </span>} id="transactionpassword" inputProps={{ maxLength: 10 }} value={transactionPwd} onChange={(e) => setTransactionPwd(e.target.value)} 
        onBlur={handleTransactionBlur}
        className={`sampleInput mb5 ${isMandate2 ? "mandateField" : ""}`} />
</td>
</tr>

{/* <tr><td>&nbsp;</td></tr> */}
</tbody></table>

</td>
</tr>
</tbody></table>
<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
<table border="0" align="left" width="100%">
<tbody><tr>
	 <td align="left" id="middlerowbuttons">
	 
 
	
	<Box style={{display: 'flex', gap: '8px', marginBottom:'10px', justifyContent: "flex-start"}}>
	<Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />} onClick={doSubmit} >{t('028')}</Button>
	
  <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<KeyboardReturn />} onClick={handleReturn} >{t('013')}</Button>		</Box>

   
    </td>
    
 </tr>


</tbody></table>

    </>

    </LocalizationProvider>

    );
}

export default DistAccntBalCredit;
