import { Footer, Header, JasperTopMenu, LeftBgImage, PaymentManagerHeading } from './PageComponents'
import TopMenu from './TopMenu'
import axios from 'axios';
import { Box,Grid, InputLabel, Typography } from '@mui/material'
import i18n from './i18n';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import { ToastContainer, toast } from "react-toastify";
import { useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';
import {CancelRounded,KeyboardReturn, Payments, Print} from '@mui/icons-material';
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import { useTranslation } from 'react-i18next';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import TextField from '@mui/material/TextField';
import React, { useState} from 'react';
import ReactToPrint from "react-to-print";
import PrintIcon from '@mui/icons-material/Print';
import { useRef, useEffect } from "react";




const Postpaidpaymentsp = () => {
  //sessionStorage.setItem("selectedIndex", 7);
  sessionStorage.setItem("selectedLink", "n_postpaidpayments");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
  console.log("exampleData LOGIN_ID====>"+exampleData.LOGIN_ID);
    //setting For user login
    const partnerLoginId = exampleData.LOGIN_ID;
    const currencyId = exampleData.partnerCurrencyId;
    const currencySymbol =exampleData.systemCurrencySymbol; 
    const partnerId = exampleData.LOGIN_ID;
  const [selectedValue, setSelectedValue] = useState('');
    const [selectedOption, setSelectedOption] = useState('option1');
        const [Option1Items, setOption1Items] = useState([]);
        const [mdn, setMdn] = useState('');
        const [scl, setScl] = useState('');
        const [paymentAmount, setPaymentAmount] = useState('');
        const [transactionDate, setTransactionDate] = useState('');
        const [outstandingAmount, setOutstandingAmount] = useState();
        const [TotalRecords, setTotalRecords] = useState(0);
        const [payMode, setPayMode] = useState(0);
        const [TotalRecords1, setTotalRecords1] = useState(0);
        const [partialPaymentAmount, setPartialPaymentAmount] = useState('0.00');
        const [creditPaymentAmount1, setCreditPaymentAmount1] = useState('0.00');
        const [enqBillingCode,setEnqBillingCode]=useState('');
        let userName = process.env.REACT_APP_USERNAME;
        let password = process.env.REACT_APP_PASSWORD;
        let componentRef = useRef();
        let condition ='';
        const toastId = useRef(null);
        const [showError, setShowError] = useState(false);
        const [showError1, setShowError1] = useState(t('2025'));
        
        const prevShowError = useRef(false);

        useEffect(() => {
          if (showError) {
            prevShowError.current = true; // Preserve the error state once set
          }
        }, [showError]);
        
        const fetchDataMdn = async () => {
          
          clearDataScl();
          setShowError(false);
          try {

            if(mdn === null || mdn === '' || mdn === undefined)  {
              if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('7011')); 
                setShowError1(true);
              }
              //toast.error(t('7011'));
            }  
             else if(mdn.length < 10)                 
              {
                if(!toast.isActive(toastId.current) )  {
                  toastId.current = toast.error(t('7012')); 
                  
                }
              setShowError(true);
            //  toast.error(t('7012'));
            }
            else{
             
              // clearDataScl();
            const apiUrl = window.config.apiUrl + process.env.REACT_APP_POSTPAIDPAYMENTSP_URL;
            const response = await axios.post(apiUrl, {
              userName,
              password,
              partnerLoginId, localeVar, mdn, scl:'',
            });

            const responseData = response.data;
            console.log('response=========>', responseData);
            if(responseData.responseCode==1123){
          
              setShowError1(false)
              setShowError(true);
              setTotalRecords(false);
              setOption1Items(false);
            }
            else if (responseData.responseCode === '129') {
              if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('4943')); 
              }
              return;
            }
            else if (!(responseData.responseCode === '00')) {
              // if(!toast.isActive(toastId.current) )  {
              //   toastId.current = toast.error(responseData.responseDescription); 
              // }
              setShowError1(true);
             // toast.error(responseData.responseDescription);
              return;
            }
            else{
            const listUserItems1 = responseData.postpaidpaymentMainArray.flatMap(item => item.ListUser);
            const listUserItems2 = responseData.postpaidpaymentMainArray.flatMap(item => item.totalToPay);
            const listUserItems3 = responseData.postpaidpaymentMainArray.flatMap(item => item.transactionDate);
            setOutstandingAmount(listUserItems2.toString());
            setPaymentAmount(listUserItems2.toString());
            setTransactionDate(listUserItems3.join(", "));
            console.log("listUserItems2=======>", listUserItems2);
            console.log('result:', listUserItems1);
            setOption1Items(listUserItems1);
            const mdnlistUserItems = responseData.postpaidpaymentMainArray;
            setTotalRecords(mdnlistUserItems);
            console.log('result:', mdnlistUserItems);
            
            
          }}} catch (error) {
            console.error('Error fetching data:', error);
          }
        };

        useEffect(() => {
          // Set the browser title
          document.title = t('2472_012');
        }, []);
        
        
        


const handlePaymentTypeChange = (e) => {
  setPayMode(e.target.value);

};
const handleBlur = (setValue) => {
  setValue((prevValue) => {
    // Ensure the value has two decimal places
    let formattedValue = parseFloat(prevValue).toFixed(2);

    // Prefix a 0 if the value is a single-digit number below 10
    if (formattedValue < 10) {
      formattedValue = formattedValue.padStart(5); // '5' includes the decimal places (e.g., 06.00)
    }

    // Default to '0.00' if the value is empty
    return prevValue === '' ? '0.00' : formattedValue;
  });
};

const handleChangeWithFormat = (event, setValue) => {
  let inputValue = event.target.value;

  // Ensure the value is numeric and within the allowed 10 digits
  if (/^\d*\.?\d{0,2}$/.test(inputValue)) {
    setValue(inputValue);
  }
};



const fetchData = async () =>{
  

  const apiUrl = window.config.apiUrl + process.env.REACT_APP_DOPAYMENT_URL;
  console.log('partnerId=======>',partnerId);
  console.log('localeVar=======>',localeVar);
  console.log('mdn=======>',mdn);
  console.log('scl=======>',scl);
  console.log('paymentAmount=======>',paymentAmount);
  console.log('payMode=======>',payMode);
  console.log('outstandingAmount=======>',outstandingAmount);
  console.log('currencySymbol=======>',currencySymbol);
  console.log('transactionDate=======>',transactionDate);
  
        const response = await axios.post(apiUrl, {
          userName,
          password,
          partnerId, localeVar, mdn, scl,paymentAmount,currencyId,payMode,outstandingAmount,currencySymbol,transactionDate
        });

        const responseData = response.data;
        console.log('response=======>',responseData);
        if (!(responseData.responseCode === '00')) {
          setShowError1(true);
         // toast.error(responseData.responseDescription);
          return;
        }
        else{
        const listUserItems1 = responseData.paymentMainArray.flatMap(item => item.map);
        console.log('response1=======>',listUserItems1);
       
        setTotalRecords1(listUserItems1);
}}

const paynowPayment = () => {
  

  let item ='';
  for ( item of TotalRecords) {
    console.log("item.totalToPay====>", item.totalToPay); 
}

    if(payMode == '0')
    {
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('7013')); 
      }
     // toast.error(t('7013'));
    }
    else if(payMode== 'FP'){
       condition = window.confirm(t('7014'));
if(condition==true){
  fetchData();
  
}
    }
    else if(payMode=='PP'){
      
         if(partialPaymentAmount >= item.totalToPay ){
          if(!toast.isActive(toastId.current) )  {
            toastId.current = toast.error(t('7015')+item.totalToPay);
          }
         // toast.error(t('7015')+item.totalToPay);
         }
         else if(partialPaymentAmount === '0.00'|| partialPaymentAmount === '00.00'){
          if(!toast.isActive(toastId.current) )  {
            toastId.current = toast.error(t('7016'));
          }
         // toast.error(t('7016'));
         }
         else if(partialPaymentAmount < item.totalToPay ){

          condition = window.confirm(t('7014'));
          if(condition==true){
            fetchData();
            
          }
         }
         else{
          fetchData();
         }

    }

    else if(payMode=='CP'){
      
      if(creditPaymentAmount1 <= item.totalToPay && creditPaymentAmount1 > 0){
        if(!toast.isActive(toastId.current) )  {
          toastId.current = toast.error(t('7017'));
        }
       // toast.error(t('7017'));
             }
             else if(creditPaymentAmount1  == '0.00' || creditPaymentAmount1 === '00.00'){
              if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('7016'));
              }
             // toast.error(t('7016')); 
             }

        else if(Number(creditPaymentAmount1) < Number(item.enqBillCreditLimit)){
          condition =  window.confirm(t('7018'));
if(condition==true){
  fetchData();
}

             }
             else if(creditPaymentAmount1 >= item.enqBillCreditLimit ){
              condition = window.confirm(t('7014'));
              if(condition==true){
                fetchData();
                
              }
             }

    }
     
    }

        const fetchDataScl = async () => {
          
          try {
            if (scl === null || scl === '' || scl === undefined) {
              if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('7011')); 
              }
            } else {
              //setMdn('');
              
              const apiUrl = window.config.apiUrl + process.env.REACT_APP_POSTPAIDPAYMENTSP_URL;
              const response = await axios.post(apiUrl, {
                userName,
                password,
                partnerLoginId, localeVar, mdn, scl
              });
              const responseData = response.data;
              console.log('response=========>', responseData);
              if (responseData.responseCode === '1000') {
                if(!toast.isActive(toastId.current) )  {
                  toastId.current = toast.error(responseData.responseDescription); 
                }
               
                return;
              }
              else if (responseData.responseCode === '129') {
                if(!toast.isActive(toastId.current) )  {
                  toastId.current = toast.error(t('4943')); 
                }
              // if (!(responseData.responseCode === '00')) {
              //   if(!toast.isActive(toastId.current) )  {
              //     toastId.current = toast.error(responseData.responseDescription); 
              //   }
               // toast.error(responseData.responseDescription);
                return;
              }


              const listUserItems1 = responseData.postpaidpaymentMainArray.flatMap(item => item.ListUser);
              const listUserItems2 = responseData.postpaidpaymentMainArray.flatMap(item => item.totalToPay);
              const listUserItems3 = responseData.postpaidpaymentMainArray.flatMap(item => item.transactionDate);
              const listUserItems4 = responseData.postpaidpaymentMainArray.flatMap(item => item.subscriberMDN);
              setOutstandingAmount(listUserItems2.toString());
              setPaymentAmount(listUserItems2.toString());
              setTransactionDate(listUserItems3.join(", "));
              setMdn(listUserItems4.toString());
              setOption1Items(listUserItems1);
              console.log('responseData.error', responseData.error);
              const sclListUserItems = responseData.postpaidpaymentMainArray;
              setTotalRecords(sclListUserItems);
              console.log('result:', sclListUserItems);
              console.log('enqBillingCode=SCL=====',sclListUserItems[0].enqBillingCode);
              setEnqBillingCode(sclListUserItems[0].enqBillingCode);
            
              console.log('data', responseData);
            }
          } catch (error) {
            console.error('Error fetching data:', error);
          }
        };

          const clearData=()=>{
            setMdn('');
            setScl('');
            
        }  
        const clearDataScl=()=>{
          // setMdn('');
          setScl('');
          
      }  
        const navigate = useNavigate();
        const handleReturn = () => {
          navigate(-1);
        }
  const handleOptionChange = (e) => {

    const selectedValue = e.target.value;
    setSelectedOption(selectedValue); // Update the selected option
    console.log('Selected option:', selectedValue);
    setShowError1(true);
          // setSelectedOption(e.target.value);
          // console.log('selectedOption' , selectedOption);
          if(selectedOption === 'option1') {
                setScl('');
          } else {
            setMdn('');
          }
          //setMessage('Please provide search criteria.');
        };
      
        const reload = () => {
          window.location.reload();
        }
      
return (
  <div>

  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
       <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
    <TopMenu menuLink= {localeVar==='en'?"PostPaid Payments":"Pagos de PostPago"}/>
  </tr>

  <tr>
   <LeftBgImage />
    {/* </tr>  */}
<td valign="top">
<title>Prepaid Movistar - View Sales People</title>
<div className={'mL8 input_boxess'}>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="left"height="100%">
    <tbody>
      <tr className={'postpaid'}><JasperTopMenu /></tr>
     <tr valign="top">
       <td width="80%">
        {/* body starts */}
            <table border={0} bordercolor="green" width="100%"cellSpacing={0}align="left">
                     <tr><td>&nbsp;</td></tr> 
             {/* <tr>
               <td colSpan={10} align="left" width="100%">
                <b><font className="headingText">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{t('0166')}</font></b> 
                </td>
            </tr>  */}
          </table>
       {TotalRecords1 === 0 && (
              <div>
              <FormControl style={{ width: '100%', paddingLeft: '12px', 
                 marginTop: '14px' }} align="left">
                  <RadioGroup
                      row
                      aria-labelledby="demo-row-radio-buttons-group-label"
                      name="row-radio-buttons-group"
                      value={selectedOption}
                      onChange={handleOptionChange}> 
                      <Grid container style={{ marginLeft: '0px', marginTop: '-15px' }} spacing={0} width={1}>
                          <Grid item xs={2} align="left">
                            <FormControlLabel className={`strongerTxtLable borderWhite ${selectedOption === 'option1' ? 'selectedRadio' : ''}`} value="option1"control={<Radio size="small" />} label= {t('0156')} />
                            </Grid>
                          <Grid item xs={3} align="left">
                            <FormControlLabel className={`strongerTxtLable borderWhite ${selectedOption === 'option2' ? 'selectedRadio' : ''}`} value="option2" control={<Radio size="small" />} label= {t('0157')} />
                          </Grid>
          </Grid>
      </RadioGroup>
          </FormControl>
          
              {selectedOption === 'option1' && (
              
                <div>
                            
                <br />
               <Box style={{display:'flex', gap:'20px'}} >
 












{/* <TextField label={
                                                            <span>
                                                              {`${t('0156')}`}
                                                            </span>}
                                                             className={'sampleInput mb5'}
                                                              style={{marginLeft: '0px', width:'250px'}}
                                                               type="number" name="mdnUi"

                                                               inputProps={{ maxLength: 10 }}  
                                                                size="18" 
                                                                 value={mdn}  
                                                                 onChange={e => setMdn(e.target.value)} 
                                    /> */}


<TextField
    label={
                                                            <span>
                                                              {`${t('0156')}`}
        </span>
    }
    className={'sampleInput mb5'}
    style={{ marginLeft: '0px', width: '250px' }}
    type="text"  
    name="mdnUi"
    inputProps={{ maxLength: 10 }}  
    size="18"
    value={mdn}
    onChange={e => {
        const value = e.target.value;
        // Validate input: Only numeric values and max length of 10
        if (/^\d*$/.test(value) && value.length <= 10) {
            setMdn(value);
        }
    }}
/>









<div style={{marginTop: '3px'}}>
                  <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}
                  onClick={fetchDataMdn}>{t('0163')}</Button>
                 <Button className={'hoverEffectButton'} style={{marginLeft:'8px'}} size="small" variant="contained" endIcon={<CancelRounded />}
                  onClick={clearData}>{t('0164')}</Button>
    </div>
</Box>
{/* Table and enqBillingCode */}
<Box display="flex" justifyContent="space-between" alignItems="center" style={{ marginTop: '18px' }}>
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', width: '75%' }}>
    <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
      {/* Your Table Rows and Columns Here */}
    </Table>
  </TableContainer>

  {/* enqBillingCode aligned to the right */}
  <div className="strongerTxtLable1" style={{ marginLeft: '20px' }}>
    <b>{enqBillingCode}</b>
  </div>
</Box>
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', marginTop: '5px' }}>
    <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
      <TableHead>
        <TableRow className={'darkgray subdistributor_table'}>
          <TableCell width="20%" className="whiteboldtext">{t('0158')}</TableCell>
          <TableCell width="20%" className="whiteboldtext">{t('0159')}</TableCell>
          <TableCell width="20%" className="whiteboldtext">{t('0160')}</TableCell>
          <TableCell width="20%" className="whiteboldtext">{t('0161')}</TableCell>
          <TableCell width="20%" className="whiteboldtext">{t('01622')}</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {Option1Items.length > 0 ? (
          Option1Items.map((item, index) => (
            <React.Fragment key={index}>
              <TableRow>
                <TableCell className="arlCtrBlk" align="center">{item.enqBillingCode}</TableCell>
                <TableCell className="arlCtrBlk" align="center">{item.enqPrvBalanceAmount}</TableCell>
                <TableCell className="arlCtrBlk" align="center">
                {item.enqBillDate ? item.enqBillDate.replace('.0', '') : ''}
                  </TableCell>
                <TableCell className="arlCtrBlk" align="center">
                {item.enqBillPaymentExpairyDate ? item.enqBillPaymentExpairyDate.replace('.0', '') : ''}
                  </TableCell>
                <TableCell className="arlCtrBlk" align="center">{item.enqBillStatus}</TableCell>
              </TableRow>
            </React.Fragment>
          ))
        ) : (
          <TableRow>
          <TableCell colSpan={10} align="center" style={{ color: 'red' }} className="redTxt">
            {showError1 ? t('7053') : prevShowError.current || showError ? t('7054') : null}
          </TableCell>
        </TableRow>
         
        )
        }

{/* {showError && (
<p style={{color: 'red', fontSize: '11px', textAlign: 'center', position: 'absolute',marginLeft:'460px',}}>
                {t('7054')}
                </p>
                 )} */}

      </TableBody>
    </Table>
  </TableContainer>

  &nbsp; &nbsp;  
  {TotalRecords.length > 0 && (
  <div style={{ display: 'flex', justifyContent: 'left' }}>
        <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '500px', width: '600px' }}>
          <Table sx={{ minWidth: 620 }} size="small" className={''} stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow className="darkgray">
              <TableCell colSpan={2} width="24%" className="whiteboldtext" style={{ textAlign: 'left', paddingLeft: '43.5%' }}>{t('7050')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {TotalRecords.length > 0 ? (
                TotalRecords.map((item, index) => (
                  <React.Fragment key={index}>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7019')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqPrvBalanceAmount}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7020')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqPrvPaymentAmount}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7021')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqAdjustmentAmount}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7022')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqSubTotalAmount}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7023')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqBalanceAmountToPay}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7024')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.totalToPay}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7025')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">
                      {item.transactionDate ? item.transactionDate.replace('.0', '') : ''} {/* Removes the .0 */}
                        </TableCell>
                    </TableRow>
                  </React.Fragment>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={2} align="center" style={{ color: 'red' }} className="redTxt">
                  
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <div style={{ marginLeft: '20px', marginTop: '3%', textAlign: 'left' }}>
  {TotalRecords.length > 0 && TotalRecords.map((item, index) => (
    <div key={index}>
    <td style={{ width: '80px' }}></td>
   <div >
   &nbsp; 
   <td style={{ fontSize: '120%',marginTop:'30%'}}>{t('7026')} {item.totalToPay} </td>
   </div>
<br />
<br />
<br />
   <tr>
       
        <td width="20%">
          <FormControl sx={{ minWidth: 230, marginTop:'-15px' }} size="small" className={'selected_formcontrol'}>
          <InputLabel id="demo-select-small-label">{t('7049')}</InputLabel>
            <Select name="payMode" value={payMode} onChange={handlePaymentTypeChange} className={'selected_dropdown'} labelId="demo-select-small-label" id="demo-select-small"
                                    label={t('7049')}>
              <MenuItem value="0">{t('7027')}</MenuItem>
              <MenuItem value="FP">{t('7028')}</MenuItem>
              <MenuItem value="PP">{t('7029')}</MenuItem>
              <MenuItem value="CP">{t('7030')}</MenuItem>
            </Select>
          </FormControl>
        </td>
      </tr>
      
      <td width="100%" style={{ display: 'block',  marginTop: '-3%' }}>
        {payMode === 'FP' && (
          <tr>
            <td colSpan={2}>
              <TextField value={item.totalToPay} readOnly/>
            </td>
          </tr>
        )}

        {payMode === 'PP' && (
          
          <tr>
            <td colSpan={2}>
              <TextField
                value={partialPaymentAmount}
                onChange={(e) => handleChangeWithFormat(e, setPartialPaymentAmount)}
                onBlur={() => handleBlur(setPartialPaymentAmount)}
                inputProps={{ maxLength: 10, inputMode: 'numeric' }} // Limits input to 10 digits
              />
            </td>
          </tr>
          
        )}

        {payMode === 'CP' && (
          <>
            <tr>
              <td colSpan={2}>
                <TextField
                  value={creditPaymentAmount1}
                  onChange={(e) => handleChangeWithFormat(e, setCreditPaymentAmount1)}
                  onBlur={() => handleBlur(setCreditPaymentAmount1)}
                  inputProps={{ maxLength: 10, inputMode: 'numeric' }} // Limits input to 10 digits
                />
              </td>
            </tr>
           
            <tr>
            <td colSpan={2} style={{ display: 'block',marginTop: '4%' }}>
                <TextField value={item.enqBillCreditLimit} readOnly />
              </td>
            </tr>
          </>
        )}
      </td>
    </div>
  ))}

  <tr align="right">
   
    
    <Box style={{display:'flex', gap:'8px', marginTop:'10px'}}>
    <Button className={'hoverEffectButton'} style={{}} size="small" variant="contained" endIcon={<Payments />}
        onClick={paynowPayment}>{t('7031')}</Button>
        <Button className={'hoverEffectButton'} style={{  }} size="small" variant="contained" endIcon={<KeyboardReturn />}
        onClick={handleReturn}>{t('0165')}</Button>
    </Box>
  </tr>
</div>

                
      </div>
      )}
      
                </div>
                
              )}
        
              {selectedOption === 'option2' && (
            
                <div>
                  &nbsp; 
               
<Box style={{display:'flex', gap:'20px'}} >










{/* <TextField label={
                                                            <span>
                                                              {`${t('0157')}`}
                                                            </span>}
                                                              className={'sampleInput mb5'}
                                                              style={{marginLeft: '0px', width:'250px'}}
                                                              type="number"
                                                              name="SCL" 
                                                               inputProps={{ maxLength: 10 }} 
                                                                size="18"
                                                              value={scl} 
                                                              onChange={e => setScl(e.target.value)}
                                           /> */}

<TextField
    label={
                                                            <span>
                                                              {`${t('0157')}`}
        </span>
    }
    className={'sampleInput mb5'}
    style={{ marginLeft: '0px', width: '250px' }}
    type="text"  
    name="SCL"
    inputProps={{ maxLength: 8 }}  
    size="18"
    value={scl}
    onChange={e => {
        const value = e.target.value;
        // Check if value is numeric and length is <= 10
        if (/^\d*$/.test(value) && value.length <= 10) {
            setScl(value);
        }
    }}
/>









                <div style={{marginTop: '3px'}}>
                  <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}
                  onClick={fetchDataScl}>{t('0163')}</Button>
                 <Button className={'hoverEffectButton'} style={{marginLeft:'8px'}} size="small" variant="contained" endIcon={<CancelRounded />}
                  onClick={clearData}>{t('0164')}</Button>
               </div>
                    </Box>

{/* Table and enqBillingCode */}
<Box display="flex" justifyContent="space-between" alignItems="center" style={{ marginTop: '18px' }}>
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', width: '75%' }}>
    <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
      {/* Your Table Rows and Columns Here */}
    </Table>
  </TableContainer>

  {/* enqBillingCode aligned to the right */}
  <div className="strongerTxtLable1" style={{ marginLeft: '20px' }}>
    <b>{enqBillingCode}</b>
  </div>
</Box>

 <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', marginTop: '5px' }}>
    <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
      <TableHead>
        <TableRow className={'darkgray subdistributor_table'}>
          <TableCell width="20%" className="whiteboldtext">{t('0158')}</TableCell>
          <TableCell width="20%" className="whiteboldtext">{t('0159')}</TableCell>
          <TableCell width="20%" className="whiteboldtext">{t('0160')}</TableCell>
          <TableCell width="20%" className="whiteboldtext">{t('0161')}</TableCell>
          <TableCell width="20%" className="whiteboldtext">{t('0162')}</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {Option1Items.length > 0 ? (
          Option1Items.map((item, index) => (
            <React.Fragment key={index}>
              <TableRow>
                <TableCell className="arlCtrBlk" align="center">{item.enqBillingCode}</TableCell>
                <TableCell className="arlCtrBlk" align="center">{item.enqPrvBalanceAmount}</TableCell>
                <TableCell className="arlCtrBlk" align="center">
                {item.enqBillDate ? item.enqBillDate.replace('.0', '') : ''}
                  </TableCell>
                <TableCell className="arlCtrBlk" align="center">
                {item.enqBillPaymentExpairyDate ? item.enqBillPaymentExpairyDate.replace('.0', '') : ''}
                  </TableCell>
                <TableCell className="arlCtrBlk" align="center">{item.enqBillStatus}</TableCell>
              </TableRow>
            </React.Fragment>
          ))
        ) : (
          <TableRow>
            <TableCell colSpan={10} align="center" style={{ color: 'red' }} className="redTxt">
            {t('2025')}
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  </TableContainer>

  &nbsp; &nbsp; 
  {TotalRecords.length > 0 && (
  <div style={{ display: 'flex', justifyContent: 'left' }}>
        <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '500px', width: '600px' }}>
          <Table sx={{ minWidth: 620 }} size="small" className={''} stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow className="darkgray">
              <TableCell colSpan={2} width="24%" className="whiteboldtext" style={{ textAlign: 'left', paddingLeft: '43.5%' }}>{t('7050')}</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {TotalRecords.length > 0 ? (
                TotalRecords.map((item, index) => (
                  <React.Fragment key={index}>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7019')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqPrvBalanceAmount}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7020')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqPrvPaymentAmount}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7021')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqAdjustmentAmount}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7022')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqSubTotalAmount}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7023')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.enqBalanceAmountToPay}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7024')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">{item.totalToPay}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="arlCtrBlk" align="left">{t('7025')}</TableCell>
                      <TableCell className="arlCtrBlk" align="center">
                      {item.transactionDate ? item.transactionDate.replace('.0', '') : ''} {/* Removes the .0 */}
                    </TableCell>
                    </TableRow>
                  </React.Fragment>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={2} align="center" style={{ color: 'red' }} className="redTxt">
                 
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <div style={{ marginLeft: '20px', marginTop: '3%', textAlign: 'left' }}>
  {TotalRecords.length > 0 && TotalRecords.map((item, index) => (
    <div key={index}>
    <td style={{ width: '80px' }}></td>
   <div >
   &nbsp; 
   <td style={{ fontSize: '120%',marginTop:'30%'}}>{t('7026')} {item.totalToPay} </td>
   </div>

<br />
<br />
<br />
   <tr>
       
        <td width="20%">
          <FormControl sx={{ minWidth: 230, marginTop:'-15px' }} size="small" className={'selected_formcontrol'}>
          <InputLabel id="demo-select-small-label">{t('7049')}</InputLabel>
            <Select name="payMode" value={payMode} onChange={handlePaymentTypeChange} className={'selected_dropdown'} labelId="demo-select-small-label" id="demo-select-small"
                                    label={t('7049')}>
              <MenuItem value="0">{t('7027')}</MenuItem>
              <MenuItem value="FP">{t('7028')}</MenuItem>
              <MenuItem value="PP">{t('7029')}</MenuItem>
              <MenuItem value="CP">{t('7030')}</MenuItem>
            </Select>
          </FormControl>
        </td>
      </tr>
      
      <td width="100%" style={{ display: 'block',marginTop: '-3%' }}>
        {payMode === 'FP' && (
          <tr >
            <td colSpan={2} >
              <TextField value={item.totalToPay} readOnly/>
            </td>
          </tr>
        )}

        {payMode === 'PP' && (
          <tr>
            <td colSpan={2}>
              <TextField
                value={partialPaymentAmount}
                onChange={(e) => handleChangeWithFormat(e, setPartialPaymentAmount)}
                onBlur={() => handleBlur(setPartialPaymentAmount)}
                inputProps={{ maxLength: 10, inputMode: 'numeric' }} // Limits input to 10 digits
              />
            </td>
          </tr>
        )}

        {payMode === 'CP' && (
          <>
            <tr>
              <td colSpan={2} >
                <TextField
                  value={creditPaymentAmount1}
                  onChange={(e) => handleChangeWithFormat(e, setCreditPaymentAmount1)}
                  onBlur={() => handleBlur(setCreditPaymentAmount1)}
                  inputProps={{ maxLength: 10, inputMode: 'numeric' }} // Limits input to 10 digits
                />
              </td>
            </tr>
            
            <tr>
              <td colSpan={2} style={{ display: 'block',marginTop: '4%' }}>
                <TextField value={item.enqBillCreditLimit} readOnly />
              </td>
            </tr>
          </>
        )}
      </td>
    </div>
  ))}

  <tr align="right">
    
    <Box style={{display:'flex', gap:'8px',  marginTop:'10px'}}>
    <Button className={'hoverEffectButton'} style={{}} size="small" variant="contained" endIcon={<Payments />}
        onClick={paynowPayment}>{t('7031')}</Button>
        <Button className={'hoverEffectButton'} style={{  }} size="small" variant="contained" endIcon={<KeyboardReturn />}
        onClick={handleReturn}>{t('0165')}</Button>
    </Box>
  </tr>
</div>


      </div>
      )}
      

                </div>

    )}
      
    <tbody>


      {(!TotalRecords || TotalRecords.length === 0) && (
    <tr> 
        <td width="70%" className="strongerTxt"></td>
        <td width="30%" textAlign= "right">
        <Button className={'hoverEffectButton'} style={{marginTop: '15px' ,marginLeft: '280px'}} size="small" variant="contained" endIcon={<KeyboardReturn />}
        onClick={handleReturn}>{t('0165')}</Button>
                </td></tr> 
  )}
  
        <tr>&nbsp;</tr>
        </tbody>
    </div>  
       

)}
 <tr>&nbsp;</tr>
<div>

{TotalRecords1.length > 0 && (
  
<div style={{ display: 'flex', justifyContent: 'center' }}>
<Box className={'displayFlexCenter print-center-content flexDirectionColumn'} ref={(el) => (componentRef = el)}>
      <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '500px', width: '500px' }}>
        <Table sx={{ minWidth: 500 }} size="small" className={''} stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow className="darkgray">
            <TableCell colSpan={2} width="24%" className="whiteboldtext" style={{ textAlign: 'left', paddingLeft: '45%' }}>{t('7032')}</TableCell>
            </TableRow>
          </TableHead>
          
          <TableBody>
            {TotalRecords1.length > 0 ? (
              TotalRecords1.map((item, index) => (
                <React.Fragment key={index}>
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7033')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.distributor}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7034')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.physicalAddress}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7035')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.RFC}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7036')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.pointOfSale}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7037')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px' ,padding: '5px'}}>{item.addressOfPointOfSales}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7038')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.clientAccountNumber}</TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7039')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.clientName}</TableCell>
                  </TableRow>

                  
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7040')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.mobileNumberOfClient}</TableCell>
                  </TableRow>
                  
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7041')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.numberOfFolio}</TableCell>
                  </TableRow>
                  
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7042')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.authorizationNumber}</TableCell>
                  </TableRow>
                  
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7043')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.placeAndDateOfExpedition}</TableCell>
                  </TableRow>
                  
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7044')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px' ,padding: '5px'}}>{item.quantity}</TableCell>
                  </TableRow>
                  
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7045')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.discriptionOfService}</TableCell>
                  </TableRow>
                  
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px',padding: '5px' }}>{t('7046')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px',padding: '5px' }}>{item.unitValue}</TableCell>
                  </TableRow>
                  
                  <TableRow>
                    <TableCell className="arlCtrBlk" align="left" style={{ fontSize: '11px' ,padding: '5px'}}>{t('7047')}</TableCell>
                    <TableCell className="arlCtrBlk" align="center" style={{ fontSize: '11px' ,padding: '5px'}}>{item.total}</TableCell>
                  </TableRow>
                </React.Fragment>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={2} align="center" style={{ color: 'red' }} className="redTxt">
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      </Box>
      <div style={{ marginLeft: '15px', marginTop: '3%', textAlign: 'left' }}>

      <Box style={{display:'flex', gap:'8px',}} >
                <ReactToPrint
          trigger={() => <Button className={'hoverEffectButton'} style={{marginTop: '360px' ,}} size="small" variant="contained" endIcon={<PrintIcon />}> 
         {t('7048')} </Button>} content={() => componentRef}/>
      <Button className={'hoverEffectButton'} style={{marginTop: '360px', }} size="small" variant="contained" endIcon={<KeyboardReturn/>}
       onClick={reload}>{t('0165')}</Button>
              </Box>
    </div>

    </div>
   
    )}

  
</div>
&nbsp;
    </td></tr>
</tbody>
</table>




</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</div>


<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
</td>
</tr>
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
</tbody>
</table>



  </div>

  
)
};

export default Postpaidpaymentsp;
