/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import { LeftMenu, Header, Footer, PaymentManagerHeading, JasperTopMenu, LeftBgImage } from './PageComponents';
import { Link } from "react-router-dom";
import TopUpPhone from "./TopUpPhone";
import { PlayArrow } from "@mui/icons-material";
import i18n from "./i18n";
import { useTranslation } from 'react-i18next';
import React, { useState, useEffect } from 'react';

function ElectronicRecharge(){
 // sessionStorage.setItem("selectedIndex", 2);
  sessionStorage.setItem("selectedLink", "b_sellprepaidcards");
  const localeVar=i18n.language;
  const {t} = useTranslation();

  useEffect(() => {
    // Set the browser title
    // document.title = "Prepaid Movistar";
    document.title = t('2472_008');
  }, []);
  return (
      
    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
    <tbody>
         <Header/>
      <tr height="65px">
        <PaymentManagerHeading />
        <TopMenu menuLink= {localeVar==='en'?"Electronic Recharge":"Recarga Electrónica"}/>
      </tr>
      <tr>
      <LeftBgImage />
        <td valign="top">
          <meta httpEquiv="Content-Type" content="text/html; charset=ISO-8859-1" />
          <title>homepage</title>
          <JasperTopMenu />
          <div class="mL8">
          <TopUpPhone />
          </div>
        {/* <table width="100%" height="100%" cellSpacing={20} cellPadding={150} border={0} align="center">
          <tbody>
              <tr valign="top">
                  <td align="center" className="headerTxt"> 
                  <TopUpPhone />
                  </td>
                </tr>   
            </tbody>
        </table> */}

        </td>
      </tr>

      
      <tr height="60px">
        <td colSpan={2}>
       <Footer/>
        </td>
      </tr>
    </tbody></table>
  );
}

export default ElectronicRecharge;
