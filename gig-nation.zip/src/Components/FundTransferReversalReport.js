/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { ArrowDownward, ArrowUpward, UnfoldMore } from '@mui/icons-material';
// import React, { useState, useEffect, useCallback ,useRef} from 'react';
import dayjs from 'dayjs';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { CloudDownload, KeyboardReturn,DoneAllRounded,RestartAltRounded, SaveRounded } from '@mui/icons-material';
import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, LeftBgImage,TransactionTopMenu, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button,Menu, CircularProgress, FormControl, Grid, InputLabel,Autocomplete, MenuItem, Pagination, Paper, Select, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, styled } from "@mui/material";
import React, { useState, useEffect, useCallback ,useRef} from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
// import { CancelRounded, CloudDownload, KeyboardReturn } from "@mui/icons-material";
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
 import ExcelJS from 'exceljs';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { ToastContainer, toast } from "react-toastify";
// import { useRef, useEffect } from "react";
import pdfMake from "pdfmake/build/pdfmake";
import { FixedSizeList } from 'react-window';
import pdfFonts from "pdfmake/build/vfs_fonts";

function FundTransferReversalReport(){
  const dropdownItemStyle = {
  display: 'block',
  width: '100%',
  padding: '8px 12px',
  textAlign: 'left',
  background: 'none',
  border: 'none',
  cursor: 'pointer',
  fontSize: '14px',
  fontFamily: 'inherit',
  outline: 'none',
};

  sessionStorage.setItem("selectedLink", "e_transactions");
 const dropdownRef = useRef(null);
     const exampleData = JSON.parse(localStorage.getItem("userData"));
   const [partnerLoginId, setPartnerLoginId] = useState(exampleData.LOGIN_ID);

  const [page, setPage] = useState(1);
 const [perpage, setPerPage] = useState(10);
  const {t}=useTranslation();
 const localeVar=i18n.language;
  const [submitted, setSubmitted] = useState(false);
 
     const [trans, setTrans] = useState("---");
// const [sortDirection, setSortDirection] = useState(null); // 'asc' or 'desc'
// const [sortedItems, setSortedItems] = useState(items); // To hold sorted data

const [sortedItems, setSortedItems] = useState([]);
const [sortDirection, setSortDirection] = useState(null);

      // const [download, setDownload] = useState('');
      //  const [download, setDownload] = useState('');
    // const exampleData = JSON.parse(localStorage.getItem("userData")) ;
    const [items, setItems] = useState([]);
    const [isLoading, setIsLoading]=useState(false);
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
    const [sourceMdn, setSourceMdn] = useState('');
    const [destMdn, setDestMdn] = useState('');
     
    let reportDays = process.env.REACT_APP_ReportDays;
          
     const [apply,setApply] =useState(false);
          // const [transID, setTransID] = useState('6');

          const [transID, setTransID] = useState(""); // initial empty string to send on Apply
const [transIDDisplay, setTransIDDisplay] = useState("6"); // show 3045 by default
          const [personId, setPersonId] = useState("");
          
          const [status, setStatus] = useState('N');
    
          //  const [startDateTime, setStartDateTime] = useState(null);
         const now = dayjs();
         const midnightToday = dayjs().startOf('day');
       
         const [startDateTime, setStartDateTime] = useState(midnightToday);
         const [startDate, setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
         const [endDateTime, setEndDateTime] = useState(now);
         const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));
             const [showError, setShowError] = useState(false);
              // const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
              const toastId = useRef(null);
const closeTimeoutRef = useRef(null);
 const [anchorEl, setAnchorEl] = useState();

  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);


  const [mdn, setMdn] = useState('');



    const [partnerList, setPartnerList] = useState([]);
const [loginType, setLoginType] = useState('');
const [pId, setPID] = useState('');

 //for spi dropdown
const defaultOption = { partnerId: "---" };
const fullPartnerList = [defaultOption, ...partnerList];
const LISTBOX_PADDING = 8; 
const [loading, setLoading] = useState(false);
let startRecord = (page - 1) * perpage + 1;
let endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);

  const navigate = useNavigate();

  console.log("totalRecords++++++++++++",totalRecords);


  const handleChangePage = async (event, newPage) => {

    const isValid = validateDateRange({
             startDateTime,
             endDateTime,
             reportDays,
             toast,
             toastId,
             t,
             submitted
           });
       
        if (!isValid) {
        setSubmitted(false);  // reset submit flag
        return;
      }
    
    if(!apply){
    
    if (!toast.isActive(toastId.current)) {
          toastId.current = toast.error(t('apply_validation'));
         setSubmitted(false);
        }
    return false;
    
    }
    

  event.preventDefault();
  setPage(newPage);

};

  useEffect(() => {
  if (!submitted) return;
  fetchData();           // runs every time `page` changes
}, [page,submitted]);
  
 //date validation 
  const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
    // debugger;
    const start = new Date(startDateTime);
    const end = new Date(endDateTime);
    const oneDay = 1000 * 60 * 60 * 24

    console.log("start",start);
     console.log("end",end);
      console.log("oneDay",oneDay);

    if (end < start) {
      if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t('error.date.one'));

      }
      return false;
    }

    const diffDays = Math.floor((end - start) / oneDay);
    console.log("diffDays:", diffDays);

    if (diffDays >= reportDays) {
      if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t('error.config.days') + " " + reportDays);


      }
      return false;
    }

    return true;
  };

 const handleSubmit =async () => {

try {
const isValid = validateDateRange({
        startDateTime,
        endDateTime,
        reportDays,
        toast,
        toastId,
        t
      });

if (!isValid){
  setApply(false);
  return;
} 


      await fetchData();
      setPage(1);
      setSubmitted(true);
      setApply(true);
    } catch (error) {
      console.error("An error occurred:", error);
    } // Enable watching page changes
  };


const fetchPartnerData = async (typeId) => {
  try {
     console.log("typeId========>",typeId);
    setLoading(true); // Start loading
    const apiUrl = window.config.apiUrlJasper+'/getChildPartners';
    const response = await axios.post(apiUrl, {
      userName,
      password,
      partnerTypeId: typeId,
      partnerId: partnerLoginId,
      localeVar,
    });

    const partnerData = response.data.summaryPartnerArray || [];
    console.log("partnerData========>",partnerData);
    const activePartners = partnerData.filter(p => p.status === "Y");
    setPartnerList(activePartners);
  } catch (err) {
    console.error("Error fetching partner data:", err);
  } finally {
    setLoading(false); // End loading
  }
};

useEffect(() => {
  if (transIDDisplay) {
    fetchPartnerData(transIDDisplay);
  }
}, [transIDDisplay]);


useEffect(() => {
  if (items && items.length) {
 
    console.log("items===>",items)
    setSortedItems(items);
  }
}, [items]);


const RedAsterisk = styled('span')({
    color: 'red',
  });

const parseDate = (dateStr) => {
  // Expected format: DD/MM/YYYY HH:mm:ss
  const [datePart, timePart] = dateStr.split(' ');
  const [day, month, year] = datePart.split('/');
  return new Date(`${year}-${month}-${day}T${timePart}`);
};

const handleSortByDate = () => {
  const newDirection = sortDirection === 'asc' ? 'desc' : 'asc';

  const sorted = [...sortedItems].sort((a, b) => {
    const dateA = parseDate(a.fundTransferDate);
    const dateB = parseDate(b.fundTransferDate);
    return newDirection === 'asc' ? dateA - dateB : dateB - dateA;
  });

  setSortedItems(sorted);
  setSortDirection(newDirection);
};


  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);





const fetchData = async () => {

console.log("userName==>",userName);
console.log("personId==>",personId);
  setIsLoading(true);
  try {
    const apiUrl = window.config.apiUrlJasper+ '/getFundTransferReversal';
    const response = await axios.post(apiUrl, {
      userName,
      password,
      toDist: personId.trim(),
      fromMDN: sourceMdn,
      toMDN: destMdn,
      distType: transIDDisplay,
      transType:'REV',//
      fromDate: startDate,
      toDate: endDate,
      partnerId:partnerLoginId,
      localeVar,
      levelFlag: status,
      begRecNo:  startRecord+'',
      endRecNo: ((endRecord < 10 ? '10' : endRecord)+''),
      download: "N"
    });

    const reportData = response.data.fundTransferReversalReport;
    console.log("response.data.fundTransferReversalReport=====>", reportData);

    if (Array.isArray(reportData) && reportData.length > 0) {
  const firstTransType = reportData[0].transType;
  const transLabel = getTransferTypeLabel(firstTransType, t);
  console.log("Mapped Transfer Type ====>", transLabel);

  setTrans(transLabel);
  setItems(reportData);
  setTotalRecords(response.data.noRows);
  setShowError(false); // clear error state if it was set previously
} else {
  // Clear previous data
  setItems([]);
  setTotalRecords(0);
  setTrans('');
  if (!toast.isActive(toastId.current)) {
    setShowError(true);
  }
}

  } catch (error) {
    console.error('An error occurred:', error);
  } finally {
    setIsLoading(false);
  }
};
const getTransferTypeLabel = (transType, t) => {
  if (!transType) return "---";

  const map = {
    AN: t("FUNDAN"),
    CFT: t("FUNDCFT"),
    LFT: t("FUNDLFT"),
    ML: t("FUNDML"),
    MN: t("FUNDMN"),
    NF: t("FUNDNF"),
    TCT: t("FUNDTCT"),
    FT: t("FUNDFT"),
    RFT: t("FUNDRFT"),
  };

  return map[transType] || "---";
};

  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };


const doReset = async () => {
 setSourceMdn("");
 setDestMdn("");
 setTransID(""); 
  setTransIDDisplay("6");
 setPersonId("");
  setStartDateTime(midnightToday);
  setEndDateTime(now);
  setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
setEndDate(now.format('DD/MM/YYYY HH:mm:ss'));
 setStatus("N");


}



 const fetchDataDownload = async () => {
 const isValid = validateDateRange({
           startDateTime,
           endDateTime,
           reportDays,
           toast,
           toastId,
           t,
           submitted
         });
     
      if (!isValid) {
      setSubmitted(false);  // reset submit flag
      return;
    }
    
    if(!apply){
    
    if (!toast.isActive(toastId.current)) {
          toastId.current = toast.error(t('apply_validation'));
         setSubmitted(false);
        }
    return false;
    
    }

      try {
 
          const apiUrlDownload = window.config.apiUrlJasper+ '/getFundTransferReversal';
          console.log('API URL:', apiUrlDownload);
          // console.log('Partner Login ID:', partnerLoginId);
  
      const responseDownload = await axios.post(apiUrlDownload, {
      userName,
      password,
      toDist: personId.trim(),
      fromMDN: sourceMdn,
      toMDN: destMdn,
      distType: transIDDisplay,
      transType:'REV',//
      fromDate: startDate,
      toDate: endDate,
      partnerId:partnerLoginId,
      localeVar,
      levelFlag:status,
      begRecNo: "0",
      endRecNo: "0",
      download: "N"
          });
  
          console.log('Response:', responseDownload);
  
          if (!responseDownload.data || !responseDownload.data.fundTransferReversalReport) {
              throw new Error('Invalid API response');
          }
          const downloadData = responseDownload.data.fundTransferReversalReport.map(partner => ({
                fundTransferId: partner.fundTransferId,
              fundTransferDate: partner.fundTransferDate,
              fundTransAmount: partner.fundTransAmount,
              currencySymbol: partner.currencySymbol,
              transType: partner.transType,
              fromAccount: partner.fromAccount,
              fromParentDistComp: partner.fromParentDistComp,
              fromSalesPersonMDN: partner.fromSalesPersonMDN,
              fromAccType: partner.fromAccType,
              fromPartnerCompName: partner.fromPartnerCompName,
               fromMainPartnerId: partner.fromMainPartnerId,
                fromMainDistCompName: partner.fromMainDistCompName,
              fromAccPreBalance: partner.fromAccPreBalance,
              fromAccPostBalance: partner.fromAccPostBalance,
              toAccount: partner.toAccount,
                toParentDistComp:partner.toParentDistComp,
              toSalesPersonMDN: partner.toSalesPersonMDN,
              toAccType: partner.toAccType,
             toPartnerCompName: partner.toPartnerCompName,
               toMainPartnerId: partner.toMainPartnerId,
                 toMainDistCompName: partner.toMainDistCompName,
              toAccPreBalance: partner.toAccPreBalance,
              toAccPostBalance: partner.toAccPostBalance,
              replenChannelDesc: partner.replenChannelDesc,
               parentTransId: partner.parentTransId,
                revTransferDate: partner.revTransferDate,
                 revTransAmount: partner.revTransAmount,
                   comments: partner.comments,
                     levl: partner.levl,
                   bankRefferenceId: partner.bankRefferenceId
              
          }));
  
          console.log('Download Data:', downloadData);
  
          return downloadData;
      } catch (error) {
          console.error('Error fetching data:', error);
          return [];
      }
  };


  const totalPages = Math.ceil(totalRecords / recordsPerPage);



  // =========================================

  const DownloadXL = async () => {

  const downloadItems = await fetchDataDownload(); 
  if (!downloadItems || downloadItems.length === 0) return;

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('FundTransferReversalReport', {
    pageSetup: { paperSize: 9, orientation: 'landscape' }
  });

  // === Set 30 columns width
  worksheet.columns = new Array(40).fill({ width: 40 });
 const endOfReportText = t('0171');
  // === Insert Title Row (Row 1)
  worksheet.insertRow(1, [
    localeVar === 'en' ? 'FundTransferReversalReport' : 'Reversa de Transferencia de Fondos'
  ]);
  worksheet.mergeCells('A1:AD1');
  worksheet.getCell('A1').font = { bold: true, size: 14 };
  worksheet.getCell('A1').alignment = { horizontal: 'center' };

  const summaryRow = worksheet.insertRow(2, new Array(30).fill(''));

  summaryRow.getCell(1).value = `${t('032')} : ${downloadItems.length}`;
  summaryRow.getCell(1).alignment = { horizontal: 'left' };

  // summaryRow.getCell(30).value = `${t('033')} : 1 - ${downloadItems.length}`;
  // summaryRow.getCell(30).alignment = { horizontal: 'right' };

  // summaryRow.font = { italic: true, size: 10 };





  // === Group Header Row (Row 3)
  const groupHeaders = [
    ...Array(5).fill(t('')),
    ...Array(9).fill(t('624')),
    ...Array(9).fill(t('625')),
    ...Array(7).fill(t('627'))
  ];
  const headerRow1 = worksheet.addRow(groupHeaders);
  worksheet.mergeCells('A3:E3'); // ""
  worksheet.mergeCells('F3:N3'); // 624
  worksheet.mergeCells('O3:W3'); // 625
  worksheet.mergeCells('X3:AD3'); // 627

  headerRow1.eachCell((cell, colNumber) => {
    // if (cell.value) {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
      fgColor: { argb: 'FFFFFFFF' }
        // fgColor: { argb: '3399FF' }
      };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    // }
  });


  const columnHeaders = [
    t('616'), t('023'), t('6827'), t('251620'), t('617'),
    t('623'), t('3132'), t('2046'), t('072'), t('1146'),
    t('628'), t('629'), t('1150'), t('618'), t('623'),
    t('3132'), t('2046'), t('072'), t('1146'), t('628'),
    t('629'), t('1150'), t('618'), t('621'), t('630'),
    t('631'), t('632'), t('633'), t('626'), t('619')
  ];
  const headerRow2 = worksheet.addRow(columnHeaders);

  headerRow2.eachCell(cell => {
    cell.font = { bold: true };
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' }
      // fgColor: { argb: '3399FF' }
    };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.border = {
      top: { style: 'thin' },
      left: { style: 'thin' },
      bottom: { style: 'thin' },
      right: { style: 'thin' }
    };
  });

  // === Add Data Rows (Starting from Row 5)
  downloadItems.forEach(item => {
    const row = [
      item.fundTransferId,
      item.fundTransferDate,
      item.fundTransAmount,
      item.currencySymbol,
      // item.transType,
      item.transType,
      item.fromAccount,
      item.fromParentDistComp,
      item.fromSalesPersonMDN,
      item.fromAccType,
      item.fromPartnerCompName,
      item.fromMainPartnerId,
      item.fromMainDistCompName,
      item.fromAccPreBalance,
      item.fromAccPostBalance,
      item.toAccount,
      item.toParentDistComp,
      item.toSalesPersonMDN,
      item.toAccType,
      item.toPartnerCompName,
      item.toMainPartnerId,
      item.toMainDistCompName,
      item.toAccPreBalance,
      item.toAccPostBalance,
      item.replenChannelDesc,
      item.parentTransId,
      item.revTransferDate,
      item.revTransAmount,
      item.comments,
      item.levl,
      item.bankRefferenceId
    ];
    worksheet.addRow(row);
     
  });
const endOfReportRow = worksheet.addRow([endOfReportText]);
     worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
     endOfReportRow.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };

// Optional: Make it bold or styled if needed
endOfReportRow.getCell(1).font = { bold: true };
  // === Generate Excel File
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  saveAs(blob, 'FundTransferReversalReport.xlsx');
};



const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}
const handleMdnChange = (e) => {
  const value = e.target.value;
  if (/^\d{0,10}$/.test(value)) {
    setMdn(value);
  }
};

  const handleEndDateTimeChange = (newValue) => {
      setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };
  const handleStartDateTimeChange = (newValue) => {
      setApply(false);
    setStartDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setStartDate(formattedDateTime);
    console.log("startDate::::::", newValue)
    console.log("startDate::::::", formattedDateTime)
  };



useEffect(() => {
  if (!endDateTime) {
    setEndDateTime(dayjs()); // 👈 Set default to current date-time
  }
}, [endDateTime]);



const handleDownloadPdf = async () => { 
  const downloadItems = await fetchDataDownload(); // same data as Excel
  if (!downloadItems || downloadItems.length === 0) return;

  const totalRecords = downloadItems.length;
  const startRecord = 1;
  const endRecord = downloadItems.length;

  const tableBody = [];

  // === First Row: Group Header Row ===
  const Mainheaders = [
    { text: t(''), colSpan: 5, style: 'mainHeader', alignment: 'center' },
    ...Array(4).fill({}),
    { text: t('624'), colSpan: 9, style: 'mainHeader', alignment: 'center' },
    ...Array(8).fill({}),
    { text: t('625'), colSpan: 9, style: 'mainHeader', alignment: 'center' },
    ...Array(8).fill({}),
    { text: t('627'), colSpan: 7, style: 'mainHeader', alignment: 'center' },
    ...Array(6).fill({})
  ];
  tableBody.push(Mainheaders);

  // === Column Headers (2nd row) ===
  const headers = [
    t('616'), t('023'), t('6827'), t('251620'), t('617'), t('623'), t('3132'), t('2046'),
    t('072'), t('1146'), t('628'), t('629'), t('1150'), t('618'), t('623'), t('3132'), t('2046'),
    t('072'), t('1146'), t('628'), t('629'), t('1150'), t('618'), t('621'), t('630'),
    t('631'), t('632'), t('633'), t('626'), t('619')
  ];
  tableBody.push(headers.map(header => ({ text: header, style: 'tableHeader' })));

  // === Data Rows ===
  downloadItems.forEach(item => {
    const row = [
      item.fundTransferId,
      item.fundTransferDate,
      item.fundTransAmount,
      item.currencySymbol,
      // item.transType,
      item.transType,
      item.fromAccount,
      item.fromParentDistComp,
      item.fromSalesPersonMDN,
      item.fromAccType,
      item.fromPartnerCompName,
      item.fromMainPartnerId,
      item.fromMainDistCompName,
      item.fromAccPreBalance,
      item.fromAccPostBalance,
      item.toAccount,
      item.toParentDistComp,
      item.toSalesPersonMDN,
      item.toAccType,
      item.toPartnerCompName,
      item.toMainPartnerId,
      item.toMainDistCompName,
      item.toAccPreBalance,
      item.toAccPostBalance,
      item.replenChannelDesc,
      item.parentTransId,
      item.revTransferDate,
      item.revTransAmount,
      item.comments,
      item.levl,
      item.bankRefferenceId
    ];
    tableBody.push(row.map(val => ({ text: String(val), fontSize: 5 })));
  });

  const content = [
    {
      text: localeVar === 'en' ? 'Fund Transfer Reversal Report' : 'Reversa de Transferencia de Fondos',
      style: 'title',
      alignment: 'center',
      margin: [0, 0, 0, 10]
    },
     {
  columns: [
    {
      text: `${t('032')} : ${totalRecords}`,
      alignment: 'left',
      fontSize: 8
    }
    // ,
    // {
    //   text: `${t('033')} : ${startRecord} - ${endRecord}`,
    //   alignment: 'right',
    //   fontSize: 8
    // }
  ],
  margin: [0, 0, 0, 5]
},
    {
      style: 'tableExample',
      table: {
        headerRows: 2,
        widths: new Array(30).fill(30), // 30 columns
        body: tableBody
      },
      layout: {
        fillColor: function (rowIndex) {
          return rowIndex === 0 ? '#3399FF' : rowIndex === 1 ? '#3399FF' : null;
        }
      }
    },
    {
      text: t('0171'),
      style: 'endText',
      alignment: 'center',
      margin: [0, 10, 0, 0]
    }
  ];



  // === PDF Definition ===
  const docDefinition = {
    content: content,
    styles: {
      title: { fontSize: 12, bold: true },
      tableExample: { margin: [0, 5, 0, 10] },
      mainHeader: { bold: true, fontSize: 6, color: '#000' },
      tableHeader: { bold: true, fontSize: 5, color: '#fff', alignment: 'center' },
      endText: { italics: true, bold: true, decoration: 'underline', fontSize: 8 }
    },
    pageOrientation: 'landscape',
    pageSize: 'A3',
    pageMargins: [10, 10, 10, 10],
    defaultStyle: {
      fontSize: 5
    }
  };

  // === Generate PDF ===
  pdfMake.createPdf(docDefinition).download('FundTransferReversalReport.pdf');
};

const handleDownloadCsv = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  const formatAmount = (value) => {
    const num = parseFloat(value);
    return !isNaN(num) ? num.toFixed(2) : '0.00';
  };

  const formatDateTime = (value) => {
    if (!value) return "---";
    const date = new Date(value);
    if (isNaN(date.getTime())) return value;
    const pad = (n) => (n < 10 ? '0' + n : n);
    return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

  const totalRecords = downloadItems.length;
  const startRecord = 1;
  const endRecord = downloadItems.length;

  const title = t('637');
 


  const summaryText = `${t('032')}  : ${totalRecords}`;

const groupHeaders = [
    t(''),  t(''),  t(''),  t(''),  t(''),  
    t('624'),
     t(''),  t(''),  t(''),  t(''),  t(''),  t(''),t(''),t(''),
    t('625'),
    t(''),  t(''),  t(''),  t(''),  t(''),  t(''),t(''),t(''),
    t('627'),
    t(''),  t(''),  t(''),  t(''),  t(''),  t('')
  ];

  const columnHeaders = [
    t('616'), t('023'), t('6827'), t('251620'), t('617'),
    t('623'), t('3132'), t('2046'), t('072'), t('1146'),
    t('628'), t('629'), t('1150'), t('618'), t('623'),
    t('3132'), t('2046'), t('072'), t('1146'), t('628'),
    t('629'), t('1150'), t('618'), t('621'), t('630'),
    t('631'), t('632'), t('633'), t('626'), t('619')
  ];

  const rows = downloadItems.map(item => [
    item.fundTransferId ?? "---",
    item.fundTransferDate,
    item.fundTransAmount,
    item.currencySymbol ?? "---",
    item.transType ?? "---",

    item.fromAccount ?? "---",
    item.fromParentDistComp ?? "---",
    item.fromSalesPersonMDN ?? "---",
    item.fromAccType ?? "---",
    item.fromPartnerCompName ?? "---",
    item.fromMainPartnerId ?? "---",
    item.fromMainDistCompName ?? "---",
    item.fromAccPreBalance,
    item.fromAccPostBalance,

    item.toAccount ?? "---",
    item.toParentDistComp ?? "---",
    item.toSalesPersonMDN ?? "---",
    item.toAccType ?? "---",
    item.toPartnerCompName ?? "---",
    item.toMainPartnerId ?? "---",
    item.toMainDistCompName ?? "---",
    item.toAccPreBalance,
    item.toAccPostBalance,

    item.replenChannelDesc ?? "---",
    item.parentTransId ?? "---",
    item.revTransferDate,
    item.revTransAmount,
    item.comments ?? "---",
    item.levl ?? "---",
    item.bankRefferenceId ?? "---"
  ]);

  const escapeCSV = (value) => {
    if (value == null) return '';
    const strVal = String(value).trim().replace(/"/g, '""');

    if (/^\d+\.\d{2}$/.test(strVal)) {
      return `="${strVal}"`;
    } else if (/^\d{2}\/\d{2}\/\d{4}/.test(strVal)) {
      return `="${strVal}"`;
    } else {
      return `"${strVal}"`;
    }
  };


  const totalCols = columnHeaders.length;
const centerIndex = Math.floor(totalCols / 2);

  const csvLines = [];

const titleRow = Array(totalCols).fill('');
titleRow[centerIndex] = title;

  // csvLines.push(`"${title}"`);
  csvLines.push(titleRow.map(escapeCSV).join(','));
  csvLines.push(`"${summaryText}"`);
  csvLines.push(groupHeaders.map(escapeCSV).join(','));
  csvLines.push(columnHeaders.map(escapeCSV).join(','));

  rows.forEach(row => {
    csvLines.push(row.map(escapeCSV).join(','));
  });



 
// create empty columns, place text in middle
const centeredRow = Array(totalCols).fill('');
centeredRow[centerIndex] = t('0171');
 
csvLines.push(centeredRow.map(escapeCSV).join(','));
 

  // csvLines.push(t('0171'));

  let csvContent = csvLines.join('\n');

  const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const fileName = 'FundTransferReversalReport.csv';

  if (navigator.msSaveBlob) {
    navigator.msSaveBlob(blob, fileName);
  } else {
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
   const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };


const handleTransIDChange = (event) => {
  const selectedValue = event.target.value;

  // Map 6 (3045) to empty string for backend
  if (selectedValue === "6") {
    setTransID(""); // send empty string to backend
    setTransIDDisplay("6"); // still show 3045 on UI
  } else {
    setTransID(selectedValue);
    setTransIDDisplay(selectedValue);
  }
};

//for sales person identity drop down performance 
function renderRow(props) {
  const { data, index, style } = props;
  return React.cloneElement(data[index], {
    style: {
      ...style,
      top: style.top + LISTBOX_PADDING,
    },
  });
}
const ListboxComponent = React.forwardRef(function ListboxComponent(props, ref) {
  const { children, ...other } = props;
  const itemCount = Array.isArray(children) ? children.length : 0;
  const itemSize = 36;

  return (
    <div ref={ref} {...other}
     style={{ overflow: 'hidden' }}>
      <FixedSizeList
        height={Math.min(8, itemCount) * itemSize + 2 * LISTBOX_PADDING}
        itemCount={itemCount}
        itemSize={itemSize}
        width="100%"
      >
        {({ index, style }) =>
          renderRow({
            data: children,
            index,
            style,
          })
        }
      </FixedSizeList>
    </div>
  );
});
return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Transactions":"Transacciones"}/>
  </tr>

  <tr>

<div style={{ display: 'flex' }}> 
    <LeftBgImage1 />
</div>

<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    
    <tbody>
   <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
     {/* <TransactionTopMenu /> */}
      <NavLink
            to="/FundTransferReversalReport"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${"menuHighlight" ? 'addingDynClass' : ''}`
            }><Tab label={t('r_distributortransferreversalreportp')} /></NavLink>
   </Tabs>
  </Box>
    
              
<div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="80%">
            {/* body starts */}

    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>

          
<Box style={{display:'flex', gap:'12px',marginTop:'10px'}}> 

 {/* First Dropdown: Sales Person / Distributor */}
      <FormControl className="selected_formcontrol" sx={{ minWidth: 210, ml: 0 }} size="small">
        <InputLabel id="transID-label">
          {t('607')}<RedAsterisk>*</RedAsterisk>
        </InputLabel>
        <Select
          className="bankSelect"
          value={transIDDisplay}
          labelId="transID-label"
          id="transID"
          label={t('607')}
          onChange={handleTransIDChange}
        >
          <MenuItem value="6">{t("sales")}</MenuItem>
          <MenuItem value="5">{t("2480_017")}</MenuItem>
        </Select>
      </FormControl>


 <Box display="flex" alignItems="center">
  <Autocomplete
  className="selected_formcontrol"
  sx={{
    minWidth: 210, // ✅ keep dropdown trigger width
    ml: 0,
    '& .MuiAutocomplete-endAdornment': {
      right: 10,
    },
    '& .MuiAutocomplete-popupIndicator': {
      transform: 'scale(1.5)', // 🔥 Make dropdown arrow bigger
    },
  }}
  size="small"
  options={fullPartnerList}
  loading={loading}
  getOptionLabel={(option) => option?.partnerId || ""}
  onChange={(event, newValue) =>
    setPersonId(newValue?.partnerId === "---" ? "" : newValue?.partnerId || "")
  }
  value={fullPartnerList.find(p => p.partnerId === personId) || defaultOption}
  filterOptions={(options, { inputValue }) =>
    options.filter((option) =>
      option.partnerId?.toLowerCase().includes(inputValue.toLowerCase())
    )
  }
  renderInput={(params) => (
    <TextField
      {...params}
      label={t('609')}
      InputProps={{
        ...params.InputProps,
        endAdornment: (
          <>
            {loading ? <CircularProgress size={20} sx={{ mr: 2 }} /> : null}
            {params.InputProps.endAdornment}
          </>
        ),
      }}
    />
  )}
  ListboxComponent={ListboxComponent}
  disableListWrap
  slotProps={{
    popper: {
      sx: {
        '& .MuiAutocomplete-listbox': {
          fontSize: '0.7rem', // reduce font size
          padding: 0,
        },
        '& .MuiAutocomplete-option': {
          minHeight: '28px',
        },
      },
    },
  }}
/>
 
</Box>

 <TextField type="text" 
    name="sourceMdn" 
    id="sourceMdn" className={'sampleInput mb5'}
     onChange={e => setSourceMdn(e.target.value)} 
     
      value={sourceMdn} label={                        
        <span>
        {`${t('605')}`}
       </span>} style={{width:'180px'}} 
       maxLength={10}
  pattern="\d{10}"
       />
                                <TextField type="text"  name="destMdn" id="destMdn" className={'sampleInput mb5'}
                                  onChange={e => setDestMdn(e.target.value)} value={destMdn} label={
                                    
                                    <span>
                                      {`${t('606')}`}
                                    </span>} style={{width:'180px'}} />

    </Box>

  <Box  style={{display:'flex',gap:'12px'}}>        

    <FormControl className={'selected_formcontrol'} sx={{ minWidth: 210}} size="small">
                      <InputLabel id="demo-select-small-label"> {t('610')} <RedAsterisk>*</RedAsterisk></InputLabel>
                                  <Select className={'bankSelect'}labelId="demo-select-small-label" id="demo-select-small"
                                    label={ t('610')} value={status} onChange={e => setStatus(e.target.value)}>
                                    {/* <MenuItem value="E">{t('2616011')}</MenuItem> */}
                                    <MenuItem value="Y">{t('2616020')}</MenuItem>
                                    <MenuItem value="N">{t('2616021')}</MenuItem>
                                  </Select>
                    </FormControl>                       
                                     
 <LocalizationProvider
  dateAdapter={AdapterDayjs}
  adapterLocale={localeVar === 'en' ? 'en' : 'es'}
  style={{ marginLeft: '5px' }}
>
  <DateTimePicker
    style={{ maxWidth: '150px' }}
    className={'datePickerrr'}
    value={startDateTime || dayjs().startOf('day')} // 👈 Default to today at 00:00
    onChange={handleStartDateTimeChange}
    ampm={false} // Use 24-hour format
    label={
     <span>
      {`${t('80')}`} <RedAsterisk>*</RedAsterisk>
      </span>
    }
    format="DD/MM/YYYY HH:mm:ss"
    inputFormat=" " // Optional: you may want to change this for better display
    renderInput={(params) => (
      <TextField
        {...params}
        InputLabelProps={{
          shrink: true,
        }}
        placeholder={!startDateTime ? t('80') : ''}
        fullWidth
        variant="outlined"
        sx={{ width: '140px', height: '40px', padding: '20px' }}
      />
    )}
  />

</LocalizationProvider>
                 <LocalizationProvider
  dateAdapter={AdapterDayjs}
  adapterLocale={localeVar === 'en' ? 'en' : 'es'}
  style={{ marginLeft: '5px' }}
>
  <DateTimePicker
    style={{ marginTop: '20px', maxWidth: '150px' }}
    className={'datePickerrr mt20'}
    label={
    <span>
      {t('81')} <RedAsterisk>*</RedAsterisk>
    </span>
    }
    format="DD/MM/YYYY HH:mm:ss"
    value={endDateTime || dayjs()} // 👈 Default to current date and time
    onChange={handleEndDateTimeChange}
    ampm={false}
    renderInput={(params) => <TextField {...params} />}
  />
</LocalizationProvider>



          <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
              <Box>
                    <Button className={'hoverEffectButton'} style={{marginTop:'3px'}} size="small" variant="contained" onClick={() => handleSubmit()} endIcon={<CheckCircleIcon />}>{t('602')}</Button>
                    </Box>
                    <Box>
                    <Button className={'hoverEffectButton'} style={{marginTop:'3px'}} size="small" variant="contained" onClick={() => doReset()} endIcon={<RestartAltRounded/>}>{t('603')}</Button>
                    </Box>
                    
             </Box>

</Box>
   {/* <Box style={{display:'flex',gap:'20px', marginTop:'10px'}}>
            </Box> */}

         
           <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "15px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>

        <Grid
                        item
                        xs={5}
                        sx={{ textAlign: "right", padding: "0 !important" }}>
                       {totalRecords >0 ?
                          <><span className={"strongerTxtLable"}>
                                                    {t('032')} : {totalRecords}
                                                  </span><span className={"strongerTxtLable"}>
                                                      &nbsp; / &nbsp;
                                                      {/* {t('033')} : {startRecord} - {endRecord} */}
                                                        {t('033')} : {startRecord} - {totalRecords < 10 ? totalRecords : endRecord}
                                                    </span></>   :
                            <></>}
                      </Grid>
              </Grid>
             
                  <div style={{ height: "5px" }}></div>
                    
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        
        
           <TableHead>
 <TableRow className="darkgray" style={{
             position: 'sticky',
             top: 0,
             backgroundColor: '#d3d3d3',
             zIndex: 2,
           }}>
      <TableCell colSpan={5}></TableCell>
            <TableCell colSpan={9} align="center">{t('624')}</TableCell>
            <TableCell colSpan={9} align="center">{t('625')}</TableCell>
            <TableCell colSpan={7} align="center">{t('627')}</TableCell>
  </TableRow>
</TableHead>
        <TableHead>
         <TableRow className="darkgray" style={{
                            position: 'sticky',
                            top: 27, // Adjust based on height of previous sticky row (usually ~48px)
                            backgroundColor: '#f5f5f5',
                            zIndex: 2,
                          }} >
          <TableCell className="whiteboldtext" align="center" >{t('616')}</TableCell>
           <TableCell
  className="whiteboldtext"
  align="center"
  onClick={handleSortByDate}
  style={{ cursor: 'pointer', userSelect: 'none', display: 'flex-center', justifyContent: 'center', alignItems: 'center' }}
>
  {t('023')}&nbsp;
  {sortDirection === 'asc' ? (
    <ArrowUpward fontSize="small" />
  ) : sortDirection === 'desc' ? (
    <ArrowDownward fontSize="small" />
  ) : (
    <UnfoldMore fontSize="small" />
  )}
</TableCell>
             <TableCell className="whiteboldtext" align="center">{t('6827')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('251620')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('617')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('623')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('3132')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('2046')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('072')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('1146')}</TableCell>	
                  <TableCell className="whiteboldtext" align="center">{t('628')}</TableCell>
                  <TableCell className="whiteboldtext" align="center">{t('629')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('1150')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('618')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('623')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('3132')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('2046')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('072')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('1146')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('628')}</TableCell>
                  <TableCell className="whiteboldtext" align="center">{t('629')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('1150')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('618')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('621')}</TableCell>	
                <TableCell className="whiteboldtext" align="center">{t('630')}</TableCell>	
                  <TableCell className="whiteboldtext" align="center">{t('631')}</TableCell>	
                   <TableCell className="whiteboldtext" align="center">{t('632')}</TableCell>	
                  <TableCell className="whiteboldtext" align="center">{t('633')}</TableCell>
                <TableCell className="whiteboldtext" align="center">{t('626')}</TableCell>	
                 <TableCell className="whiteboldtext" align="center">{t('619')}</TableCell>	
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
            <TableRow>
              <TableCell colSpan={30} align="center" className={'spinnerDiv'}>
              {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : items.length > 0 ? (
              sortedItems.map((item, index) => (
              <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
           <TableCell align="center">{item.fundTransferId}</TableCell>
       <TableCell align="center">{item.fundTransferDate}</TableCell>
        <TableCell align="center">{item.fundTransAmount}</TableCell>
        <TableCell align="center">{item.currencySymbol}</TableCell>
         <TableCell align="center">{item.transType}</TableCell>
        <TableCell align="center">{item.fromAccount}</TableCell> 
      <TableCell align="center">{item.fromParentDistComp}</TableCell>  
        <TableCell align="center">{item.fromSalesPersonMDN}</TableCell> 
          <TableCell align="center">{item.fromAccType}</TableCell>  
           <TableCell align="center">{item.fromPartnerCompName}</TableCell>
            <TableCell align="center">{item.fromMainPartnerId}</TableCell>
             <TableCell align="center">{item.fromMainDistCompName}</TableCell>
            <TableCell align="center">{item.fromAccPreBalance}</TableCell>
       <TableCell align="center">{item.fromAccPostBalance}</TableCell>
       <TableCell align="center">{item.toAccount}</TableCell> 
      <TableCell align="center">{item.toParentDistComp}</TableCell>  
        <TableCell align="center">{item.toSalesPersonMDN}</TableCell> 
          <TableCell align="center">{item.toAccType}</TableCell>  
           <TableCell align="center">{item.toPartnerCompName}</TableCell>
            <TableCell align="center">{item.toMainPartnerId}</TableCell>
             <TableCell align="center">{item.toMainDistCompName}</TableCell>
            <TableCell align="center">{item.toAccPreBalance}</TableCell>
            <TableCell align="center">{item.toAccPostBalance}</TableCell>
           <TableCell align="center">{item.replenChannelDesc}</TableCell>
          <TableCell align="center">{item.parentTransId}</TableCell>
           <TableCell align="center">{item.revTransferDate}</TableCell>
             <TableCell align="center">{item.revTransAmount}</TableCell>
               <TableCell align="center">{item.comments}</TableCell>
                 <TableCell align="center">{item.levl}</TableCell>
                   <TableCell align="center">{item.bankRefferenceId}</TableCell>
              </TableRow>
            ))
          ) : (
            // Show 'No data found' message if no items are found after loading
                     <TableRow>
                            <TableCell colSpan={30} align="center" className="redTxt" style={{ color: 'red' }}>
                             {submitted ? t("2481_061") : t("038")}
                            </TableCell>
                         </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>

    <br></br>
<Table>
<tfoot>

<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>
 
 
{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table> 


  <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                            {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,
                                                 }}
                                               >
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{t('638')}</MenuItem>
                                                  <MenuItem onClick={() => { setAnchorEl(null); DownloadXL(); }}>{t('639')}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{t('640')}</MenuItem>
                                                
                                               </Menu>
                                             </div>
                                              : <></>}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</td></tr>
</div>

</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
</td></tr>
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  );
}

export default FundTransferReversalReport;
