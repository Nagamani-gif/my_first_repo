import { Button, Grid, TableContainer, TableRow, TextField, Typography } from '@mui/material'
import React, { useEffect, useRef, useState } from 'react'
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import { v4 as uuidv4 } from 'uuid';
// Importing toastify module
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import Paper from '@mui/material/Paper';
import { CallMissedOutgoingRounded, KeyboardReturn, RemoveRedEyeRounded } from '@mui/icons-material';
import { useNavigate } from 'react-router';
import { useTranslation } from 'react-i18next';
import i18n from "./i18n";
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import { red } from '@mui/material/colors';
import CircularProgress from '@mui/joy/CircularProgress';

function TopUpPhone() {
  const tableRef = useRef(null);
  sessionStorage.setItem("selectedLink", "b_sellprepaidcards");
  
  let initialRechargeType = "";

  console.log('sessionStorage.getItem("rechargeTypeFromRechargePreview")', sessionStorage.getItem("rechargeTypeFromRechargePreview"))

if(sessionStorage.getItem("rechargeTypeFromRechargePreview") !== "" ){
  initialRechargeType = sessionStorage.getItem("rechargeTypeFromRechargePreview");
}else {
  initialRechargeType = 'AIRDAT'
}

console.log("initialRechargeType", initialRechargeType)

    const [selectedValue, setSelectedValue] = useState(initialRechargeType);
    const [cellularNumber, setCellularNumber] = useState('');
    const [selectedDenomValue, setSelectedDenomValue] = useState(null);
    const [showAccountBal, setShowAccountBal] = useState(false);
    const [rechargeType, setRechargeType] = useState(false);
    const [typicalRecharge, setTypicalRecharge] = useState(false);
    const [rechargeTypesList, setRechargeTypesList] = useState([]);
    const [accountBalance, setAccountBalance] = useState()
    const [feeSupportFlag, setFeeSupportFlag] = useState()
    const [showOther, setShowOther] = useState(false)
    const [otherAmount, setOtherAmount] = useState('')
    const [isLoading, setIsLoading]=useState(false);
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;

    const location = useLocation();
    const toastId = useRef(null);

 

    const navigate = useNavigate();
    const {t} = useTranslation();
     const [rechargeInfo, setRechargeInfo] = useState([
        {
            id: uuidv4(),
            denomValue: '2.0',
            airTime: '1',
            packetPlanValue: '9.0',
            validityDays: '1'
        },
        {
            id: uuidv4(),
            denomValue: '9.0',
            airTime: '9',
            packetPlanValue: '9.0',
            validityDays: '1'
        },
        {
            id: uuidv4(),
            denomValue: '29.0',
            airTime: '10',
            packetPlanValue: '8.0',
            validityDays: '80000'
        },
        {
            id: uuidv4(),
            denomValue: '2.0',
            airTime: '1',
            packetPlanValue: '9.0',
            validityDays: '1'
        },
        {
            id: uuidv4(),
            denomValue: '9.0',
            airTime: '9',
            packetPlanValue: '9.0',
            validityDays: '1'
        },
        {
            id: uuidv4(),
            denomValue: '29.0',
            airTime: '10',
            packetPlanValue: '8.0',
            validityDays: '80000'
        }
     ]);

     const exampleData = JSON.parse(localStorage.getItem("userData")) 
     const partnerLoginId = exampleData.LOGIN_ID;
     const localeVar = i18n.language;


    // useEffect(() => (
    //               async() => {
                    
    // //  const exampleData = JSON.parse(localStorage.getItem("userData")) 
    // //  const partnerLoginId = exampleData.LOGIN_ID;
    // //  const localeVar = i18n.language;
    //               let apiUrl = process.env.REACT_APP_PREPAID_TOP_UP;
    //               let response = await axios.post(apiUrl,{
    //                               "partnerLoginId": partnerLoginId,
    //                               "selectedValue":"",
    //                               "localeVar":localeVar
    //                               });
    //               // console.log("response.data.rechargeTypesList", response.data.rechargeTypesList);
    //               setRechargeTypesList(response.data.rechargeTypesList);
    //               console.log("rechargeTypesList", rechargeTypesList);
    //               }
    //   ), []);


      const getRechargeTypes = async() => {


                  let apiUrl = window.config.apiUrl + process.env.REACT_APP_PREPAID_TOP_UP;
                  let response = await axios.post(apiUrl,{
                                  userName,
                                  password,
                                  "partnerLoginId": partnerLoginId,
                                  "selectedValue":"",
                                  "localeVar":localeVar
                                  });
                   console.log("response.data++++++++", response.data);
                  setRechargeTypesList(response.data.rechargeTypesList);
                  if(!response.data.rechargeTypesList){
                    setIsLoading("false")
                  }else{
                    setIsLoading("true")
                  }
                  console.log("rechargeTypesList", response.data.rechargeTypesList);
                  }





    const handleRadioChange = (event) => {
        setSelectedValue(event.target.value);
        navigate('.', {
          replace: true,
          state: { ...location.state, responseDescription: '' }  // Clear the variable
        });
        console.log(event.target.value);
        // setTimeout(handleGoClick(), 5000);
        if (tableRef.current) {
          tableRef.current.scrollTop = 0;
        }
        setOtherAmount('');
      };

      

      const getPlanList = async() => {
        let apiUrl = window.config.apiUrl + process.env.REACT_APP_GET_PLAN_DETAILS;
        let response = await axios.post(apiUrl, {
                        userName,
                        password,
                        "partnerLoginId":partnerLoginId,
                        "selectedValue":selectedValue
                        })
          console.log("response.data", response.data)
          console.log("feeSupportFlag", response.data.feeSupportFlag)
          setRechargeInfo(response.data.rechargeTypesMainDataList);
          setAccountBalance(response.data.accountBalance);
          setFeeSupportFlag(response.data.feeSupportFlag);
      }

useEffect(()=>{
  const getData = async () => {
    try {
      // Call the async function to get data
      await getRechargeTypes();
    } catch (error) {
      console.error("Error fetching recharge types:", error);
    }
  };

  // Call the async function
  getData();
    if(selectedValue === "DAT" /*t('0131')*/ || selectedValue === "SMS" /*t('0132')*/){
      setRechargeType(true);
      setShowOther(false)
    }
    else if(selectedValue === "REC" /*t('0133')*/){
      setTypicalRecharge(true);
      setRechargeType(false);
    } 
    else{
      setRechargeType(false);
      setTypicalRecharge(false);
      setShowOther(false)
    }
    // Perform the action for the "Go" button
  console.log('Selected Value:', selectedValue);
  setShowAccountBal(true);
  getPlanList();  
  setSelectedDenomValue(null);

},[selectedValue])
      // const handleGoClick=()=>{
        
       
      // }

      const {rechargeType2, responseDescription, fromRechargePreview} = location.state || {};
     
      console.log("fromRechargePreview", fromRechargePreview)
      console.log("responseDescription", responseDescription)
 
 
      if(fromRechargePreview !== undefined && fromRechargePreview === "Y"){
        // setSelectedValue(rechargeType2);
      }


      const handlePreview=()=>{
        console.log("Cellular Number", cellularNumber);
        const cellularRegex = /^\d{10}$/;
        if (cellularNumber === '') {
          if(!toast.isActive(toastId.current) )  {
            toastId.current = toast.error(t("cellular1")); 
          }
          return;
        }
        if (otherAmount === '' && showOther) {
          if(!toast.isActive(toastId.current) )  {
            toastId.current = toast.error(t("amount")); 
          }
          return;
        }
        if (cellularNumber === '') {
          if(!toast.isActive(toastId.current) )  {
            toastId.current = toast.error(t("cellular1")); 
          }
          return;
        }
        if (!cellularRegex.test(cellularNumber)) {
          if (!toast.isActive(toastId.current)) {
            toastId.current = toast.error(t("cellular2")); 
          }
          return;
        }
        if (selectedDenomValue === null) {
          if(!toast.isActive(toastId.current) )  {
            toastId.current = toast.error(t("cellular3")); 
          }
          return;
        }
        // Continue with the preview logic
        console.log("Selected Denomination Value", selectedDenomValue);
         // Find the selected row data
         var selectedRow = {};
         if(selectedValue == "AIRDAT" || selectedValue == "AIRSMS"){
           selectedRow = rechargeInfo.find(row => row.AIR_SMS_DENOM_ID === selectedDenomValue);
         } else if(selectedValue == "DAT" || selectedValue == "SMS"){
           selectedRow = rechargeInfo.find(row => row.DAT_PACKET_ID === selectedDenomValue);
         } else {
           selectedRow = rechargeInfo.find(row => row.recDenomId === selectedDenomValue);
           
           if(otherAmount){
            console.log("otherAmount",otherAmount);
           }

         }
         
        // Redirect to the other component with the selected row data
        navigate('/recharge-preview', { state: { selectedRow, cellularNumber, selectedValue, feeSupportFlag, otherAmount} });
      }
      const handleDenomValueRadio = (event, id) => {
        setSelectedDenomValue(id);
      };
      const handleCellularChange=(e)=>{
        let newValue=e.target.value;
        const regex = /^\d*$/;
        if(regex.test(newValue)){
          setCellularNumber(newValue);
        }
      }
      const [isMandate, setIsMandate] = useState(false);
      const [isMandate1, setIsMandate1] = useState(false);
      const handleCellularBlur = () => {
        if (cellularNumber.trim() === "") {
          setIsMandate(true);
        } else {
          setIsMandate(false);
        }
      };
      // const handleOtherAmountBlur = () => {
      //   if (otherAmount.trim() === "") {
      //     setIsMandate1(true);
      //   } else {
      //     setIsMandate1(false);
      //   }
      // };
      // const handleOtherAmount=(e)=>{
      //   let newValue=e.target.value;
      //   const regex= /^\d*\.?\d*$/;
      //   if(regex.test(newValue)){
      //     setOtherAmount(newValue);
      //   }
      // }
      // const handleOtherAmount=(e)=>{
      //   let newValue=e.target.value;
      //   const regex= /^\d*\.?\d*$/;
      //   if(regex.test(newValue)){
      //     let formattedValue = parseFloat(newValue || "0").toFixed(1); // Ensures 1 digit after the decimal
      //     setOtherAmount(formattedValue);
      //   }
      // }

      const handleOtherAmount=(e)=>{
        let newValue=e.target.value;
        const regex= /^\d*\.?\d*$/;
      
        if (newValue === "") {
          setOtherAmount(""); // Allow clearing the field
          return;
        }
      
        if(regex.test(newValue)){
          setOtherAmount(newValue); // Store as is while typing
        }
      };
      
      const handleOtherAmountBlur = () => {
        if (otherAmount.trim() === "" || isNaN(otherAmount)) {
          setOtherAmount("");  // Clear invalid values
          setIsMandate1(true);
        } else {
          setOtherAmount(parseFloat(otherAmount).toFixed(2)); // Round to 2 decimal places
          setIsMandate1(false);
      }
      };
      
      const handleOther = (value) => {
        if(value == "-1.0"){
          setShowOther(true);
        }
      }

      const RedAsterisk = styled('span')({
        color: 'red',
      });


    return (
      <div>
      { isLoading && (
       rechargeTypesList && rechargeTypesList.length>0 ?<>
        <div className={'input_boxess'}>
            {/* <Typography
                className={"headingText"}
                sx={{ fontSize: "9pt", fontWeight: "bold" }}
                variant="body1"
                component="h2"
            >
                {t('0136')}
            </Typography> */}
       <br />
            { responseDescription !== "" ? <p  align="center"  style={{color:"red", marginBottom:'0', fontSize:"larger",fontWeight:"bold"}}>{responseDescription}</p> : '' }
            
            <FormControl style={{ width: '100%' }}>
                <RadioGroup
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    value={selectedValue}
                    onChange={(e) => {handleRadioChange(e)}}
                >
                    {/* <Grid container style={{ marginLeft: '20px', marginTop: '20px' }} spacing={0} width={1}>
                        <Grid item xs={4} >
                            <FormControlLabel className={'strongerTxtLable'} value={t('0129')} control={<Radio size="small" />} label={t('0129')} />
                        </Grid>
                        <Grid item xs={4}>
                            <FormControlLabel className={'strongerTxtLable'} value={t('0130')} control={<Radio size="small" />} label={t('0130')} />
                        </Grid>
                        <Grid item xs={4}>
                            <FormControlLabel className={'strongerTxtLable'} value={t('0131')} control={<Radio size="small" />} label={t('0131')} />
                        </Grid>
                        <Grid item xs={4}>
                            <FormControlLabel className={'strongerTxtLable'} value={t('0132')} control={<Radio size="small" />} label={t('0132')}/>
                        </Grid>
                        <Grid item xs={4}>
                            <FormControlLabel className={'strongerTxtLable'} value={t('0133')} control={<Radio size="small" />} label={t('0133')} />
                        </Grid>
                    </Grid> */}

                    <Grid container style={{ marginLeft: '10px', marginTop: '0px', gap:'20px' }} spacing={0} width={1}>
                        {rechargeTypesList.size !== 0 && 
                          rechargeTypesList.map((item, index) => 
                                <Grid item key={item.transCode}>
                                  <FormControlLabel  className={`strongerTxtLable borderWhite ${selectedValue === item.transCode ? 'selectedRadio' : ''}`}  value={item.transCode} control={<Radio size="small" />} label={item.transDesc} />
                                </Grid>
                          )
                        }
                    </Grid>  

                </RadioGroup>
            </FormControl>
           <ToastContainer 
                  position="top-right"
                  autoClose={3000}
                  hideProgressBar={false}
                  newestOnTop={false}
                  closeOnClick
                  rtl={false}
                  pauseOnFocusLoss
                  draggable
                  pauseOnHover
                  style={{
                    width: "fit-content",
                    minWidth: "300px",
                    minHeight: "100px",
                    fontSize: "18px",
                  }}
                />
                
           {showAccountBal ? (
             <div className={'recharge_info'}>
     <br />
             {rechargeInfo.length==0 ? <></> : 
             <>
             {/* <Typography className={'strongerTxtLable'} style={{paddingBottom:'5px', paddingTop:'10px'}}>{t('0139')}: $ {accountBalance}  619497.99</Typography> */}
            
             <Typography className={''}>
              {/* {t('0140')}: */}
               <TextField 
               value={cellularNumber} 
               style={{width:'200px'}} 
               label={
                                    <span>
                                      {`${t('0140')}`}
                                      <RedAsterisk>*</RedAsterisk>
                                    </span>} 
                                    inputProps={{ maxLength: 10 }}
                                    onChange={handleCellularChange} 
                                    onBlur={handleCellularBlur}
                                    className={`sampleInput mb5 ${isMandate ? 'mandateField' : ''}`} type="text" />
            </Typography></>}

             {showOther && 

             <>
              <Typography className={''}>
                {/* {t('049')}:  */}
                {/* <input id="otherAmount" value={otherAmount} onChange={handleOtherAmount} className={"textBoxSmall"} type="text" /> */}
                <TextField 
                id="otherAmount"
               value={otherAmount} 
               style={{width:'200px'}} 
               label={
                                    <span>
                                      {`${t('049')}`}
                                      <RedAsterisk>*</RedAsterisk>
                                    </span>} 
                                    // inputProps={{ maxLength: 10 }}
                                    onChange={handleOtherAmount} 
                                    onBlur={handleOtherAmountBlur}
                                    className={`sampleInput mb5 ${isMandate1 ? 'mandateField' : ''}`} type="text" />
                </Typography>
             </>
             }
             
             
             <Grid container spacing={0} style={{width: '100%', marginTop:'23px'}}>
             <Grid item xs={12}>
             {!rechargeType ? !typicalRecharge ? (

              /* Recharge + Data, Recharge + SMS */
            (rechargeInfo.length===0) ? (<div style={{textAlign: 'center',
              fontSize: '13px',
              marginTop: '20px'}}><span style={{color:'red', textAlign:'center'}}>{t("6407")}</span></div>): (<>
        <TableContainer ref={tableRef} component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', marginTop: '0px' }}>
       <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
         <TableHead>
           <TableRow className={'darkgray subdistributor_table'}>
             <TableCell></TableCell>
             <TableCell align="center">{t('0141')}</TableCell>
             <TableCell align="center">{t('0142')}</TableCell>
             {!typicalRecharge ? <TableCell align="center">{t('0143')}</TableCell> : ''}
             {!typicalRecharge ? <TableCell align="center">{t('0144')}</TableCell> : ''}
           </TableRow>
         </TableHead>
         <TableBody>
           {rechargeInfo.length>0 ? rechargeInfo.map((row) => (
             <>
             <TableRow key={row.AIR_SMS_DENOM_ID}>
               <TableCell style={{padding: '0'}} component="th" scope="row" align='center'>
                 <Radio checked={selectedDenomValue === row.AIR_SMS_DENOM_ID} value={row.AIR_SMS_DENOM_ID} onChange={(event) => handleDenomValueRadio(event, row.AIR_SMS_DENOM_ID)} style={{height: '30px',}} size="small" />
               </TableCell>
               <TableCell align="center" className={'smallerTxt'}>{row.AIR_SMS_DENOM_VALUE}</TableCell>
               <TableCell align="center" className={'smallerTxt'}>{row.AIR_SMS_AIR_TIME}</TableCell>
               {!typicalRecharge ?  <TableCell align="center" className={'smallerTxt'}>{row.AIR_SMS_PACKET_VALUE}</TableCell> : ''}
               {!typicalRecharge ? <TableCell align="center" className={'smallerTxt'}>{row.AIR_SMS_VALIDITY_DAYS}</TableCell> : ''}
             </TableRow>
             </>
           )) : <><TableRow><TableCell colSpan={5} style={{textAlign: 'center', color:"red"}}>{t('085')}</TableCell></TableRow></> }
         </TableBody>
       </Table>
     </TableContainer>
              </>)
       
     ) : 
     
     (           /* typical recharge */
      (rechargeInfo.length===0) ? (<div style={{textAlign: 'center',
        fontSize: '13px',
        marginTop: '20px'}}><span style={{color:'red', textAlign:'center'}}>{t("6407")}</span></div>): (<>
     <TableContainer ref={tableRef} component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', marginTop: '0px' }}>
      <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
        <TableHead>
          <TableRow className={'darkgray subdistributor_table'}>
            <TableCell></TableCell>
            <TableCell align="center">{t('0142')}</TableCell>
            <TableCell align="center">{t('0141')}</TableCell>
            {/* {!typicalRecharge ? <TableCell align="center">{t('0143')}</TableCell> : ''}
            {!typicalRecharge ? <TableCell align="center">{t('0144')}</TableCell> : ''} */}
          </TableRow>
        </TableHead>
        <TableBody>
          {rechargeInfo.length>0 ?  rechargeInfo.map((row) => (
            <>
            <TableRow key={row.recDenomId}>
              <TableCell style={{padding: '0'}} component="th" scope="row" align='center'>
                <Radio checked={selectedDenomValue === row.recDenomId} value={row.recDenomId} onChange={(event) => {handleDenomValueRadio(event, row.recDenomId); handleOther(row.REC_DENOM_VALUE)}} style={{height: '30px',}} size="small" />
              </TableCell>
              <TableCell align="center" className={'smallerTxt'}>{row.REC_AIR_TIME ==  "-1.0" ? t('other') : row.REC_AIR_TIME}</TableCell>
              <TableCell align="center" className={'smallerTxt'}>{row.REC_DENOM_VALUE == "-1.0" ? "" : row.REC_DENOM_VALUE }</TableCell>
              {/* <TableCell align="center" className={'smallerTxt'}>{row.REC_DENOM_VALUE == "-1.0" ? t('other') : row.REC_DENOM_VALUE }</TableCell> */}
              {/* {!typicalRecharge ?  <TableCell align="center" className={'smallerTxt'}>{row.AIR_SMS_PACKET_VALUE}</TableCell> : ''}
              {!typicalRecharge ? <TableCell align="center" className={'smallerTxt'}>{row.AIR_SMS_VALIDITY_DAYS}</TableCell> : ''} */}
            </TableRow>
            </>
          )) : <><TableRow><TableCell colSpan={5} style={{textAlign: 'center',color:"red"}}>{t('085')}</TableCell></TableRow></>}
        </TableBody>
      </Table>
    </TableContainer></>)
    )
     
     
     : ( /* Data Packet, SMS Packet */
      (rechargeInfo.length===0) ? (<div style={{textAlign: 'center',
        fontSize: '13px',
        marginTop: '20px'}}><span style={{color:'red', textAlign:'center'}}>{t("6407")}</span></div>): (<>
      <TableContainer ref={tableRef} component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', marginTop: '0px' }}>
      <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
        <TableHead>
          <TableRow className={'darkgray subdistributor_table'}>
            <TableCell></TableCell>
            <TableCell align="center">{t('0153')}</TableCell>
            <TableCell align="center">{t('0154')}</TableCell>
            <TableCell align="center">{t('0155')}</TableCell>
            <TableCell align="center">{t('0150')}</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rechargeInfo.length>0 ? rechargeInfo.map((row) => (
            <>
            <TableRow key={row.DAT_PACKET_ID}>
              <TableCell style={{padding: '0'}} component="th" scope="row" align='center'>
                <Radio checked={selectedDenomValue === row.DAT_PACKET_ID} value={row.DAT_PACKET_ID} onChange={(event) => handleDenomValueRadio(event, row.DAT_PACKET_ID)} style={{height: '30px',}} size="small" />
              </TableCell>
              <TableCell align="center" className={'smallerTxt'}>{row.DAT_PACKET_PLAN_NAME}</TableCell>
              <TableCell align="center" className={'smallerTxt'}>{row.DAT_PACKET_DESC}</TableCell>
              <TableCell align="center" className={'smallerTxt'}>{row.DAT_PACKET_VALUE}</TableCell>
              <TableCell align="center" className={'smallerTxt'}>{row.DAT_VALIDITY_DAYS}</TableCell>
            </TableRow>
            </>
          )) : <><TableRow><TableCell colSpan={5} style={{textAlign: 'center',color:"red"}}>{t('085')}</TableCell></TableRow></>}
        </TableBody>
      </Table>
    </TableContainer> </> )
     )}
             </Grid>
             </Grid>
             <Grid container spacing={0} style={{ width: '100%', marginTop:'10px' }}>
                        <Grid item xs={12} style={{ justifyContent: "flex-end", display: 'flex', gap: '8px' }}>
                        {/* <Button className={'hoverEffectButton'} size="small" variant="contained" onClick={() => handleGoClick()} endIcon={<CallMissedOutgoingRounded />}>{t('0134')}</Button> */}
           {rechargeInfo.length===0 ? <></> : <Button className={'hoverEffectButton moveRight'} size="small" variant="contained" onClick={handlePreview} endIcon={<RemoveRedEyeRounded />}>{t('0145')}</Button>}
                        <Button className={'hoverEffectButton moveRight'} size="small" onClick={() => navigate(-1)} variant="contained" endIcon={<KeyboardReturn />}>{t('0135')}</Button>

                        </Grid>
                    </Grid>
             {/* <Button className={'hoverEffectButton moveRight'} size="small" variant="contained" onClick={handlePreview} endIcon={<RemoveRedEyeRounded />}>{t('0145')}</Button> */}
              
             </div>
           ): ''}
           <br />
        </div>
      </>:
      <>
    <div align="center" style={{ color: 'red', fontSize: 'larger', fontWeight: 'bold', marginTop:'50px' }}>
      No records found
      <Grid container spacing={0} style={{ width: '100%', marginTop:'10px' }}>
                        <Grid item xs={12} style={{ justifyContent: "flex-end", display: 'flex', gap: '8px' }}>
                        <Button className={'hoverEffectButton moveRight'} size="small" onClick={() => navigate(-1)} variant="contained" endIcon={<KeyboardReturn />}>{t('0135')}</Button>
                        </Grid>
      </Grid>
     </div>
      </> 
   ) }
  {!isLoading && <div style={{textAlign:'center', fontSize: 'larger', fontWeight: 'bold', marginTop:'50px' }}> {t("Processing...")}  <CircularProgress size="sm" /></div>}



</div>

    )
}

export default TopUpPhone
