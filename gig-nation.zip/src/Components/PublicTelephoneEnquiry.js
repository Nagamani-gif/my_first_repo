import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Footer, Header, JasperTopMenu, LeftBgImage, PaymentManagerHeading, PublicEnquiry } from './PageComponents';
import {Box,Pagination, Button, Table,Grid, TableCell, TableRow, TextField } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import { CancelRounded, KeyboardReturn } from '@mui/icons-material';
import TopMenu from './TopMenu';
import {
  Paper,
  TableContainer,
  TableHead,
} from "@mui/material";
import i18n from './i18n';
import { useTranslation } from 'react-i18next';

export default function PublicTelephoneEnquiry() {
  //sessionStorage.setItem("selectedIndex", 6);
  sessionStorage.setItem("selectedLink", "f_publictelephones");

const localeVar=i18n.language;
const {t} = useTranslation();
//   const [userName, setUserName] = useState(process.env.REACT_APP_USERNAME);
//   const [password, setPassword] = useState(process.env.REACT_APP_PASSWORD);
  const exampleData = JSON.parse(localStorage.getItem("userData"))
  const partnerLoginId = exampleData.LOGIN_ID;
  console.log("partnerLoginId===>"+exampleData.LOGIN_ID);
  const [partnerId, setPartnerId] = useState('');
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsFound, setRecordsFound] = useState(0);
  const [enquiryData, setEnquiryData] = useState([]);
  const [sortOrder, setSortOrder] = useState('');
  const [sortedValue, setSortedValue] = useState('');

  const [activeCurrencyPrecision, setActiveCurrencyPrecision] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [submit, setSubmit] = useState(false);
  const [recordsPerPage] = useState(10);
  const [maxValue, setMaxValue] = useState('4'); // Example maxValue
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);

      
  let startRecord=0;
  let endRecord =10;

  
  useEffect(() => {
    // Set the browser title
    document.title = t('b_publictelephoneenquiryp');
  }, []);
  

  document.title = t('b_publictelephoneenquiryp');


  const fetchData = async () => {
    try {
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_PUBLICTELEPHONESENQUIRY_URL;
      const response = await axios.post(apiUrl, {
         userName,
         password,
        partnerLoginId,
        partnerId,
        sortOrder,
        sortedValue,
        startPageNo:startRecord-1,
        endPageNo:endRecord,
        activeCurrencyPrecision,
        localeVar
      });


      const responseData = response.data;
      console.log("Response Data",responseData);
      setEnquiryData(responseData.enquiryList || []);
      setTotalRecords(responseData.totalRecords || 0);
      setRecordsFound(responseData.recordsFound || 0);
      setErrorMsg(responseData.errorMsg || '');
     
    } catch (error) {
      console.error("An error occurred:", error);
      setErrorMsg("An error occurred while fetching data.");
    }
  };

  // useEffect(() => {
  //   fetchData();
  // }, []); // Fetch data when the component mounts

  const totalPages = Math.ceil(recordsFound / recordsPerPage);
  const navigate = useNavigate();

  const handleSubmit = async () => {
    try {
      await fetchData();
    } catch (error) {
      console.error("An error occurred:", error);
    }
    setSubmit(true);
  };

  const handleReturn = () => {
    navigate(-1);
  };

  const clearData = () => {
    setPartnerId('');
  };

  // Generate the cells based on the maxValue
  const generateCells = (data, maxValue) => {
    let tdCountera = 0;
    const cells = [];

    // Add data cells
    data.forEach((item, index) => {
      if (tdCountera < parseInt(maxValue, 10)) {
        cells.push(
          <TableCell key={`data-${index}`} className='arlCtrBlk' align='center'>
            {item.accntBal}
          </TableCell>
        );
        tdCountera++;
      }
    });

    // Fill remaining cells with '--' if necessary
    while (tdCountera < parseInt(maxValue, 10)) {
      cells.push(
        <TableCell key={`empty-${tdCountera}`} className='smallerTxt' align='center'>
          ---
        </TableCell>
      );
      tdCountera++;
    }

    return cells;
  };


  startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
   // fetchData();
  };

  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          
              <Header />
          <tr height="65px">
          <PaymentManagerHeading />
          <TopMenu menuLink= {localeVar==='en'?"Public Telephones":"Teléfonos Públicos"}/>
          </tr>
          <tr>
           <LeftBgImage />

            <td valign="top">
              <title>{t('091')}</title>
              <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                <tbody>
                  <tr>
                    <td>
                      <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                        <tbody>
                          {/* MIDDLE ROW STARTS */}
                          <tr>
                            <td>
                              <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" height="100%">
                                <tbody>
                                  
                                  <tr valign="top">
                                    <td width="80%">
                                      {/* body starts */}
                                      <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center">
                                        <tr><JasperTopMenu /></tr>
                                        <tr>
                                          <td width="100%">
                                            
                                            <table border={0} bordercolor="green" width="100%" cellSpacing={0} align="left">
                                             {/* <tr>&nbsp;</tr> */}
                                              {/* <tr>
                                                <td colSpan={10} align="center" width="100%">
                                                  <b><font className="headingText">&nbsp;{t('091')}</font></b>
                                                </td>
                                              </tr> */}
                                              <tr>
                                                {/* <td align="left" colSpan={2}>&nbsp;</td> */}
                                              </tr>
                                              <tr>&nbsp;</tr>

                                              <tr>
                                                <td align="center" width="100%" colSpan={10}>
                                                <div className={'mL8 input_boxess'} style={{paddingLeft: '11px'}}>
                                                  <table border={0} width="100%" cellPadding={2} cellSpacing={2}>
                                                    <tbody>
                                                      <tr>
                                                        <td className="" align="left" style={{padding:'0'}}> 
                                                          <Box style={{ display:'flex', gap:'15px'}}>
                                                          <TextField type="text" name="partnerId" style={{marginLeft: '0px', maxWidth:'200px'}}
                                                          label={
                                                            <span>
                                                              {`${t('034')}`}
                                                            </span>} className={'sampleInput mb5'}
                                                            onChange={e => setPartnerId(e.target.value)} value={partnerId} maxLength={20} size="15" />
                                                        <Box style={{marginTop:'2px'}}>
                                                          <Button className={'hoverEffectButton'} onClick={handleSubmit} size="small" variant="contained" endIcon={<SendIcon />}>{t('028')}</Button> 
                                                          {/* <input type="button" defaultValue="Clear" className="inputButton" onClick={clearData} /> */}
                                                          <Button className={'hoverEffectButton'} style={{marginLeft:'8px'}} size="small" onClick={clearData}  variant="contained" endIcon={<CancelRounded />}>
                                                           {t('242411')}
                                                          </Button>
                                                        </Box>
                                                          </Box>
                                                        </td>
                                                      </tr>
                                                    </tbody>
                                                  </table>
                                                  </div>
                                                </td>
                                              </tr>
                                              {/* <tr><td width="100%">&nbsp;</td></tr> */}
                                            </table>
                                          </td>
                                        </tr>
                                      </table>
                                      
                                    <div className={'mL8'}>  <table border={0} width="100%" cellPadding={0}>
                                        <tr className="">
                                          {/* <td width="55%" className={'strongerTxtLable'} align="left">{t('059')} : {recordsFound}</td>
                                          <td width="45%" className={'strongerTxtLable'} align="right">{t('060')} : {recordsFound}-{endPageNo} </td> */}
                                        </tr>
                                      </table>

                                      

                                      <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "18px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                  {/* <span className={"strongerTxtLable"}>
                          {t('032')} :  {recordsFound}
                  </span> */}
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
                <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}
                >


{recordsFound >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {recordsFound}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                  {/* <span className={"strongerTxtLable"}>
                          {t('032')} :  {recordsFound}
                  </span>
                  <span className={"strongerTxtLable"}>
                    
                  &nbsp; / &nbsp;
                   {t('033')} : 1-{recordsFound}
                  </span> */}
                </Grid>
              </Grid>
                                      <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                                      <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table" border={0} width="100%">
                                      <TableHead>
                                        <TableRow className={'darkgray subdistributor_table'}>
                                          <TableCell width="10%" className="whiteboldtext">{t('092')}</TableCell>
                                          <TableCell width="10%" className="whiteboldtext">{t('093')}</TableCell>
                                          <TableCell width="10%" className="whiteboldtext">{t('051')}</TableCell>
                                          <TableCell width="10%" className="whiteboldtext">{t('094')}</TableCell>
                                          <TableCell width="10%" className="whiteboldtext">{t('055')}</TableCell>
                                          <TableCell width="10%" className="whiteboldtext">{t('095')}</TableCell>
                                      
                                      {/* Adding the "PM" cell */}
                                      {/* <TableCell className="whiteboldtext">
                                                   {t('2082')}
                                                </TableCell> */}

                                                {/* Dynamically generated cells based on maxValue */}
                                                {maxValue && Array.from({ length: parseInt(maxValue) }, (_, i) => (
                                                  <TableCell key={i} className="whiteboldtext">
                                                    {t('6705')} {i + 1}
                                                  </TableCell>
                                                ))}
                                        </TableRow>
                                        </TableHead>
                                        {/* Iterate over the enquiry data */}

                                        {submit ? (
  enquiryData.length === 0 ? (
    <TableRow align="center">
      <TableCell colSpan="11" className="redTxt" style={{ color: 'red' }} align="center">
      {errorMsg || (t('5548'))}
      </TableCell>
    </TableRow>
  ) : null
) : (
  <TableRow align="center">
    <TableCell colSpan="11" className="redTxt" style={{ color: 'red' }} align="center">
      {t('038')}
    </TableCell>
  </TableRow>
)}

                                 
                                 
                                  {enquiryData.length > 0 ? (                     
                                        enquiryData.map((item, index) => (
                                          <TableRow key={index}>
                                            <TableCell className="arlCTableRowBlk" align="center">{item.partnerId}</TableCell>
                                                <TableCell className="arlCtrBlk" align="center">{item.salesPersonMDN}</TableCell>
                                                <TableCell className="arlCtrBlk" align="center">{item.parentId}</TableCell>
                                            <TableCell className="arlCtrBlk" align="center">{item.partnerType}</TableCell>
                                            <TableCell className="arlCtrBlk" align="center">{item.status}</TableCell>
                                                <TableCell className="arlCtrBlk" align="center">{item.accntBal}</TableCell>
                                                 {/* Additional cells for dynamic columns */}
         {/* Additional cells for dynamic columns */}
         {Array.from({ length: parseInt(maxValue) }, (_, i) => (
              <TableCell key={`dynamic-cell-${i}`} className="arlCtrBlk" align="center">
                {item[`dynamicValue${i + 1}`] == null || item[`dynamicValue${i + 1}`] === 0 ? '---' : item[`dynamicValue${i + 1}`]}
              </TableCell>
            ))}


                                          </TableRow>
                                        )) 
                                      ): <></>}
                                      
                                      {/* : (
                                     <TableRow>
                                      <TableCell colSpan={10} align="center"className="redTxt"style={{color: 'red'}}>
                                          {errorMsg}
                                     </TableCell>
                                 </TableRow> 
                                      )
                                      : <></> } */}
                                      </Table>
                                      </TableContainer>
                                      </div>
                                     <br/>
                                     {enquiryData.length>0?<Pagination
                                      count={totalPages}
                                      page={page}
                                      onChange={handleChangePage}
                                      showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
                                      <table border={0} width="100%" cellSpacing={0} cellPadding={0}>
                                        <tbody>
                                          <tr>
                                            <td width="70%" className="strongerTxt"></td>
                                            <td width="30%" align="right">
                                            <Button
                                            style={{marginTop:'15px'}}
                    className={"hoverEffectButton"}
                    size="small"
                    variant="contained"
                    onClick={handleReturn}
                    endIcon={<KeyboardReturn/>}
                  >
                    {t('242410')}
                  </Button>
                                              {/* <input type="button" defaultValue="Return" className="inputButton" onClick={handleReturn} /> */}
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>{/* MIDDLE ROW ENDS HERE  */}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                 
                </tbody>
              </table>
            </td>
          </tr>
          <tr height="60px">
                    <td colSpan={2}>
                      <Footer />
                    </td>
                  </tr>
        </tbody>
      </table>
    </div>
  );
}
