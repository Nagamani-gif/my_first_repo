/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable react/jsx-no-comment-textnodes */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/alt-text */
import React from 'react'
import { Footer, Header, JasperTopMenu, LeftBgImage, PaymentManagerHeading, SalesPeopleMenu } from './PageComponents'
import TopMenu from './TopMenu'
import { useState,useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import SendIcon from '@mui/icons-material/Send';
import {CancelRounded,KeyboardReturn} from '@mui/icons-material';
import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { blue } from '@mui/material/colors';
import { Button, Box , Paper, Tab, Table, TableBody, TableCell, TableContainer, Pagination,TableHead, TableRow, TextField, Grid } from '@mui/material';




export default function SalesPeople() {
  const {t} = useTranslation();
  //sessionStorage.setItem("selectedIndex", 3);
  sessionStorage.setItem("selectedLink", "c_salespeople");
   const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
  console.log("exampleData LOGIN_ID====>"+exampleData.LOGIN_ID);

  //setting For user login
  const partnerLoginId = exampleData.LOGIN_ID;
  const [toAcctType, setToAcctType] = useState(exampleData.USER_TYPE_ID)
  console.log("toAcctType::::::::::::::::",toAcctType);
  const [salesId, setSalesId] = useState('');
  const [salesMDN1, setSalesMDN1] = useState('');
  const [salesStatus, setSalesStatus] = useState('A');
  const [salesData, setSalesData] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [partnerId, setPartnerId] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [startPageNo, setstartPageNo] = useState(0);
  const [endPageNo, setendPageNo] = useState();
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
  
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;


  const fetchChannels=async () => {
    //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
    const apiUrl3 = window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
    console.log(apiUrl3);
    const response3 = await axios.post(apiUrl3, {
      userName,
      password,
      localeVar,
      channelTransAl: "",
    });
    // const[channels]=response.data;

    localStorage.setItem("channels", JSON.stringify(response3.data.channels));
    //console.log(JSON.stringify(response.data.channels));
    //  setsalesData(JSON.stringify(response.data.channels));
  }
  
  
  let localeVar=i18n.language;
  console.log(localeVar);
  let status="A";


  useEffect(() => {
    // Set the browser title
    // document.title = "Prepaid Movistar -  View Sales People";
    document.title = t('2472_006');
  }, []);


  useEffect(() => {
    fetchData(); // Fetch data when the component mounts
    fetchChannels();
  }, []); // Empty dependency array ensures this effect runs only once on mount


  if(salesStatus==="A"){
    status="";
  }else if(salesStatus==="Y"){
    status="Y";
  }else if(salesStatus==="N"){
    status="N";
  }
  const fetchData = async () => {
    localStorage.removeItem('channels');
    try {
      // Fetch data from API
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_SALESPEOPLE_URL;
      const response = await axios.post(apiUrl, {
        userName,
        password,
        partnerLoginId,
        localeVar,
        salesId:encodeURIComponent(salesId.trim()),
        salesMDN1,
        salesStatus:status,
        startPageNo:startRecord-1,
        endPageNo:endRecord,
      });
      const responseData = response.data;
      console.log("responseData:::",responseData);
      // Set data from response
      setSalesData(responseData.salesList);
      setTotalRecords(responseData.totalRecords);
      // setRecordsFound(responseData.recordsFound);
      setPartnerId(responseData.partnerId);
      setCompanyName(responseData.companyName);
    } catch (error) {
      console.error("An error occurred:", error);
      // Handle error, e.g., display error message to the user
    }
  };
  let startRecord=0;
  let endRecord =10;

  const handleSubmit1=async (e)=>{
    e.preventDefault(); 
      startRecord=0;
      endRecord=10;
      setPage(1)
      //fetchData();
    try {
      console.log("status",salesStatus);
      fetchData();
    } catch (error) {
      console.error("An error occurred:", error);
    }
      
  }

  startRecord = (page - 1) * perpage + 1;
  endRecord = totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);
  const totalPages = Math.ceil(totalRecords / perpage);


  const handleChangePage = (event, newPage) => {
    setPage(newPage);   
};

useEffect(() => {
  const loadData = async () => {
    await fetchData(); // Fetch data when the component mounts or dependencies change
  };

  loadData();
}, [startRecord, endRecord]); // Dependencies array ensures effect runs when page or totalRecords change



  const navigate = useNavigate();
    const handleReturn = () => {
      // Go back to the previous page
      navigate(-1);
    }

    const distclick =(distId,toAcctType)=>{
      navigate('/profile', { state: {distId,toAcctType} })
    }

  const clearData=()=>{
  setSalesId('');
  setSalesMDN1('');
  setSalesStatus('A');
}

  return (
    <div>
    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
     <tbody>
         <Header/>
    <tr height="65px">
    <PaymentManagerHeading />
      <TopMenu menuLink= {localeVar==='en'?"Sales People":"Personas de Venta"}/>
    </tr>
    <tr>
     <LeftBgImage />

  <td valign="top">
  <title>Prepaid Movistar - View Sales People</title>
  <div className={'mL8 input_boxess'}>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
  <tbody>
    <tr>
     <td>
       <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
        <tbody>
                    {/* MIDDLE ROW STARTS */}
   <tr>
    <td>
    <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
      <tbody>
       <tr valign="top">
         <td width="80%">
              {/* body starts */}
    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" style={{marginTop: '0px'}}>
    <tr className={'postpaid'}> <JasperTopMenu /> </tr> 
         <tr><td width="100%">
           <table border={0} bordercolor="green" width="100%"cellSpacing={0}align="left">
           <tr>&nbsp;</tr>
            <Box style={{display:'flex', gap:'20px'}}>


            <TextField type="text"name="salesId" className={'sampleInput mb5'}
      label={
        <span>
          {`${t('053')}`}
        </span>} style={{maxWidth:'250px',width:'210px'}}
                                                  onChange={e => setSalesId(e.target.value)} value={salesId} size="15" defaultValue="" />




                                                <TextField
                                                  type="text"
                                                  name="salesMDN1"
                                                  label={<span>{`${t('054')}`}</span>}
                                                  style={{ maxWidth: '250px',width: '175px' }}
                                                  className={'sampleInput mb5'}
                                                  value={salesMDN1}
                                                  onChange={e => {
                                                    const value = e.target.value;
                                                    if (/^\d*$/.test(value) && value.length <= 25) {
                                                      setSalesMDN1(value);
                                                    }
                                                  }}
                                                  inputProps={{ maxLength: 25 }}
                                                  size="15"
                                                  defaultValue=""
                                                />







      <FormControl className={'selected_formcontrol'} sx={{  minWidth: 120 }} size="small">
      <InputLabel id="demo-select-small-label">{t('055')}</InputLabel>

      <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
      label="salesStatus"value={salesStatus} onChange={e => setSalesStatus(e.target.value)}>
        <MenuItem value="A" selected>{t('056')}</MenuItem>
        <MenuItem value="Y">{t('057')}</MenuItem>
        <MenuItem value="N">{t('058')}</MenuItem>
      </Select>
    </FormControl>
    <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
      <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}
      onClick={handleSubmit1}>{t('028')}</Button>
      {/* <input type="button" defaultValue="Submit" className="inputButton" onClick={handleSubmit}/> */}
      {/* <input type="button" defaultValue="Clear" className="inputButton" onClick={clearData}/> */}
      <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelRounded />}
      onClick={clearData}>{t('003')}</Button>
      </Box>
      </Box>
  </table>
</td></tr>
</table>
<Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "6px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                  {/* <span className={"strongerTxtLable"}>
                          {t('032')} : {totalRecords}
                  </span> */}
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               
             
                <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {salesData.length >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
                   
              </Grid>
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', marginTop: '5px' }}>
  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table"> 
    <TableHead>
      <TableRow className={'darkgray subdistributor_table'}> 
      <TableCell width="20%" className="whiteboldtext">{t('053')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('054')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('061')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('062')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('009')} (MXN)</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('055')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('063')}</TableCell>
      </TableRow>
      </TableHead>  
      <TableBody>
  {salesData.length > 0 ? (
  salesData.map((salesItem, index) => (
  <TableRow key={index}>
    <TableCell className="arlCtrBlk"  align="center" >
    <span style={{color:"#3399FF", cursor:'pointer'}} onClick={()=>{distclick(salesItem.PARTNER_ID,toAcctType)}}>{salesItem.PARTNER_ID}</span></TableCell>
    <TableCell  class="arlCtrBlk" align="center">{salesItem.SALESPERSON_MDN}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{salesItem.PARTNER_FIRST_NAME} {salesItem.PARTNER_LAST_NAME}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{salesItem.LOCATION_DESC}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{salesItem.ACCNT_BAL}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{salesItem.STATUS}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{salesItem.SCL_CLIENT_CODE}</TableCell>
  </TableRow>
))
) : (
<TableRow><TableCell colSpan={7} align="center"className="redTxt" style={{color: 'red'}}>
          {(t("085"))} {/* No record(s) founddddddddd */}
        </TableCell>
    </TableRow>
)}

      </TableBody>
    </Table>
    </TableContainer>
    <br/>
                                                      {salesData.length> 0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
 <table border={0}width="100%" cellSpacing={0} cellPadding={0}>
  <tbody>
    <tr>
     <td width="70%" className="strongerTxt"></td>
      <td width="30%" align="right">
      <Button className={'hoverEffectButton'} style={{marginTop: '15px'}} size="small" variant="contained" endIcon={<KeyboardReturn />}
       onClick={handleReturn}>{t('013')}</Button>
         {/* <input type="button"defaultValue="Return" className="inputButton" onClick={handleReturn}/> */}
       </td></tr>
       <tr>&nbsp;</tr>
       </tbody>
      </table>
  </td></tr>
</tbody>
  </table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
 </table>
</td></tr>
</tbody>
</table>
</div>
</td></tr>
<tr height="60px"><td colSpan={2}>
      <Footer/>
      </td>
    </tr>
    </tbody>
</table>
    </div>
  )
}
