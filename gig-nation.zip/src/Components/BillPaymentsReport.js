/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, Menu, CircularProgress, FormControl, Grid, InputLabel, MenuItem, Pagination, Paper, Radio, RadioGroup, Select, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, TableSortLabel, styled } from "@mui/material";
import React, { useState, useEffect, useCallback } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CloudDownload, KeyboardReturn,DoneAllRounded,RestartAltRounded, SaveRounded } from '@mui/icons-material';
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
 import ExcelJS from 'exceljs';
import SendIcon from '@mui/icons-material/Send';
import SaveIcon from '@mui/icons-material/Save';
import { useRef } from "react";
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { ToastContainer, toast } from "react-toastify";
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import 'dayjs/locale/es'; // Spanish locale
import 'dayjs/locale/en'; // English locale (optional, dayjs default is English)


function BillPaymentsReport(){
  
  sessionStorage.setItem("selectedLink", "e_transactions");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerId ,setPartnerId]= useState(exampleData.LOGIN_ID);
// const [partnerId ,setPartnerId]= useState('');
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  let reportDays = process.env.REACT_APP_ReportDays;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
   const toastId = useRef(null);
 const [subscriberMdn, setSubscriberMdn] = useState('');
    const [subscriberSclCode, setSubscriberSclCode] = useState(''); 
    const [paymentType, setPaymentType] = useState(' '); 
    const [transactionId, setTransactionId] = useState('');
    const [paymentAmount, setPaymentAmount] = useState('');
    const [authorizationId, setAuthorizationID] = useState('');
    const [canalId, setCanalId] = useState('');
    const [terminalId, setTerminalId] = useState('');
    const [sucursalId, setSucursalId] = useState('');
    const [statusFlag , setStatusFlag ] = useState(' ');
    const [transactionCategory, setTransactionCategory] = useState('P');

  const now = dayjs();  
  const midnightToday = dayjs().startOf('day');

  const [startDateTime, setStartDateTime] = useState(midnightToday);
  const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
  const [endDateTime, setEndDateTime] = useState(now);
  const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));


    // const [startDateTime, setStartDateTime] = useState(dayjs().startOf('day')); // Set today's date
    //  const [endDateTime, setEndDateTime] = useState(dayjs);
     const [hierarchyMode, setHierarchyMode] = useState('N');
    const [levelFlag, setLevelFlag] = useState('N');    
    const [transactionType, setTansactionType] = useState('P');
    const [download, setDownload] = useState('N');
    const[salesStatus ,setSalesStatus ] = useState('');
    const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState();
      const closeTimeoutRef = useRef(null);
      const [statusId, setStatusId] = useState('F');
  const [showParentOrderId, setShowParentOrderId] = useState(false);
 const transactionIdRef = useRef(null);
 const paymentAmountRef = useRef(null);
 const [order, setOrder] = useState('asc');
 const[enableButton, setEnableButton] = useState(false);
 
 const [orderBy, setOrderBy] = useState('transactionDate');
     console.log("totalRecords++++++++++++", totalRecords)
  let startRecord=0;
  let endRecord =10;




  const handleChangePage = async (event, newPage) => {
  event.preventDefault();
  
 const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t
    });

    if (!isValid){
      return false;
    }

 if(enableButton) {
          toast.error(`${t('apply_validation')}`);
        return;
    }
    
  setPage(newPage);



  await fetchData(newPage); // fetch data for the selected page
};


  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);

const handleSubmit1 = async (e) => {
  e.preventDefault();
  const firstPage = 1;
  setPage(firstPage);
  await fetchData(firstPage); // fetch data for page 1


};

const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24;

  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
    }
    return false;
  }

  return true;
};



  const RedAsterisk = styled('span')({
    color: 'red',
  });

 const fetchData = async (pageNumber = 1) => {
  const startRecord = (pageNumber - 1) * perpage + 1;
  const endRecord = startRecord + perpage - 1;
  
    setIsLoading(true);
    try {
			// Validation logic
       const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t
    });
 
     if (transactionId.trim() !== '' && !/^-?\d+$/.test(transactionId)) {
       if (!toast.isActive(toastId.current)) {
         toastId.current = toast.error(`${t('alrt_02')} ${t('2480_0019')} ${t('2480_052')}.`, {
         onClose: () => {
        transactionIdRef.current?.focus();  // Focus after toast closes
          }
        });
      }
      return;
    }

    if (paymentAmount.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(paymentAmount)) {

       if (!toast.isActive(toastId.current)) {
         toastId.current = toast.error(`${t('alrt_01')} ${t('2480_0019')} ${t('0123')}.`, {
         onClose: () => {
        paymentAmountRef.current?.focus();  // Focus after toast closes
          }
        });
      }
        return;
     }
       
  
    if (!isValid) return;
     setStatusId('N');
     setShowParentOrderId(transactionType === 'R');
    setEnableButton(false);
      const apiUrl = window.config.apiUrlJasper +'/billPaymentReport';
      const response = await axios.post(apiUrl, {
        userName,
        password,          
        partnerId,
        subscriberMdn,
        subscriberSclCode,
        paymentType,
        transactionId,
        paymentAmount,
        statusFlag,
        fromDate:startDate,
        toDate:endDate,
        levelFlag,
        transactionType,
        transactionCategory, 
        authorizationId,
        canalId,
        terminalId,
        sucursalId,
        startPage: startRecord,
        endPage: endRecord,
        download : 'N',
        localeVar
      });
      console.log("response::::::",response);
      if (response.status === 200) {
        setItems(response.data.summaryConfigArray);
        setTotalRecords(response.data.totalRecords);
      }
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };


  const handleSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };
   const clearData = () => {
    setSubscriberMdn('');
    setSubscriberSclCode(''); 
    setPaymentType(' '); 
   setTransactionId('');
    setPaymentAmount('');
    setAuthorizationID('');
    setCanalId('');
   setTerminalId('');
   setSucursalId('');
    setStatusFlag(' ');
   setTransactionCategory('P');
   resetDateTime();
    setHierarchyMode('N');
    setLevelFlag('N');    
   setTansactionType('P');
  setDownload('N');
  setSalesStatus('---');
  //  setItems([]);
    setPage(1);
    setPerPage(10);
    setTotalRecords(0);
    setStatusId('F');
    }


const resetDateTime = () => {
    const now = dayjs();
   setStartDateTime(now.startOf('day'));
   setEndDateTime(dayjs());
   setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'))
   setEndDate(now.format('DD/MM/YYYY HH:mm:ss'))
    console.log("Reset:", now.format());
  };


    const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
 
   const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };
  


  const formatDateForCSV = (d) => {
  if (!d) return "";

  // Split date and time
  const [datePart, timePart = "00:00:00"] = d.split(" "); // default time if missing
  const [day, month, year] = datePart.split("/").map(Number);

  const [h = 0, m = 0, s = 0] = (timePart || "").split(":").map(Number);

  // Format as DD/MM/YYYY HH:mm:ss
  const formatted =
    `${String(day).padStart(2,"0")}/${String(month).padStart(2,"0")}/${year} ` +
    `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;

  // Force Excel to treat as text
  return `="${formatted}"`;
};

  
// const formatDateForCSV = (d) => {
//   if (!d) return "";
//   const [datePart, timePart] = d.split(" ");
//   const [day, month, year] = datePart.split("/").map(Number);
//   const [hours, minutes, seconds] = timePart.split(":").map(Number);

//   const formatted =
//     year + "-" +
//     String(month).padStart(2, "0") + "-" +
//     String(day).padStart(2, "0") + " " +
//     String(hours).padStart(2, "0") + ":" +
//     String(minutes).padStart(2, "0") + ":" +
//     String(seconds).padStart(2, "0");

//   // Force Excel to treat as text
//   return `="${formatted}"`;
// };


    const sortedItems = [...items].sort((a, b) => {
    const valA = a[orderBy] || '';
    const valB = b[orderBy] || '';
    if (valA < valB) return order === 'asc' ? -1 : 1;
    if (valA > valB) return order === 'asc' ? 1 : -1;
    return 0;
  });




const handleDownloadPdf = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;
  const totalRecords = downloadItems.length;
  const startRecord = 1;
  const endRecord = totalRecords;

  const tableBody = [];

  // === 2) Column Headers ===
  const headers = [];
headers.push(t('2481_034'));
headers.push(t('2480_052'));
if (transactionType === 'R') {
 headers.push(t('2481_057'));
}
headers.push(t('2481_002'));
headers.push(t('251608'));
headers.push(t('008'));
headers.push(t('2481_020'));
headers.push(t('2481_035'));
headers.push(t('2481_022'));
headers.push(t('2481_036'));
headers.push(t('2481_023'));
headers.push(t('2481_018'));
headers.push(t('subscriberCellularNumber'));
headers.push(t('2481_029'));
headers.push(t('2481_004'));
headers.push(t('2481_003'));
headers.push(t('2481_005'));
headers.push(t('0122'));
headers.push(t('0123'));
headers.push(t('2616037'));
headers.push(t('261608'));
headers.push(t('2481_037'));
headers.push(t('errordesp'));
headers.push(t('2481_060'));
headers.push(t('2481_038'));
headers.push(t('2481_039'));

  tableBody.push(
  headers.map(function(header) {
    return { text: header, style: 'tableHeader' };
  })
);

console.log("transactionType 456" , transactionType)
  // === 3) Table Rows ===
  downloadItems.forEach(item => {
  const row = [];

 
  row.push(item.Transaction_Date || '---');
  row.push(item.Transaction_Id || '---');
  if (transactionType === 'R') {
  row.push(item.Parent_Trans_Id || '---');
  }
  row.push(item.Authorization_Id || '---');
  row.push(item.Distributor_Name || '---');
  row.push(item.Distributor_Id || '---');
  row.push(item.Levl || '---');
  row.push(item.Partner_Parent_Id || '---');
  row.push(item.Parent_Name || '---');
  row.push(item.Main_Partner || '---');
  row.push(item.Main_Dist_Name || '---');
  row.push(item.Trans_Category || '---');
  row.push(item.Subscriber_Mdn || '---');
  row.push(item.Subscriber_Scl_Code || '---');
  row.push(item.Terminal_Id || '---');
  row.push(item.Canal_Id || '---');
  row.push(item.Sucursal || '---');
  row.push(item.Payment_Type_Description || '---');
  row.push(item.Payment_Amount != null ? Number(item.Payment_Amount).toFixed(2) : '---');
  row.push(item.Channel || '---');
  row.push(item.Status_Code || '---');
  row.push(item.Payment_Reference_Number || '---');
  row.push(item.Status_Description || '---');
  row.push(item.Reference_Id || '---');
  row.push(item.GW_Response_Code || '---');
  row.push(item.Reversal_Flag || '---');

  // Ensure row has exactly 26 items
 while (row.length < headers.length) row.push('---');

  tableBody.push(row.map(function(val) {
    return { text: val, fontSize: 5, alignment: 'center' };
  }));
  
});



  // === 4) PDF Definition ===
  const docDefinition = {
    content: [
    {
      text: localeVar === 'en' ? "Bill Payment Report" : "Informe de Pago de Factura",
      style: 'title',
      alignment: 'center',
      margin: [0, 0, 0, 10]
    },
      {
        columns: [
          {
            text: `${t('032')} : ${totalRecords}`,
            alignment: 'left',
            fontSize: 8
          },
          {
          //  text: `${t('033')} : ${startRecord} - ${totalRecords < 10 ? totalRecords :endRecord}`,
            //alignment: 'right',
            //fontSize: 8
          }
        ],
        margin: [0, 0, 0, 5]
      },
    {
      style: 'tableExample',
      table: {
          headerRows: 2,
          widths: new Array(headers.length).fill('*'),
        body: tableBody
      },
      layout: {
         fillColor: (rowIndex) => (rowIndex === 0 ? '#3399FF' : null)
      }
    },
    {
      text: t('0171'),
      style: 'endText',
      alignment: 'center',
      margin: [0, 10, 0, 0]
    }
    ],
    styles: {
      title: { fontSize: 12, bold: true },
      tableExample: { margin: [0, 5, 0, 10] },
      mainHeader: { bold: true, fontSize: 6, color: '#000' },
      tableHeader: { bold: true, fontSize: 5, color: '#fff', alignment: 'center', fillColor: '#3399FF' },
      endText: { italics: true, bold: true, decoration: 'underline', fontSize: 8 }
    },
    pageOrientation: 'landscape',
    pageSize: 'A2',
    pageMargins: [10, 10, 10, 10],
    defaultStyle: { fontSize: 5 }
  };

  pdfMake.createPdf(docDefinition).download('BillPaymentReport.pdf');
};



const handleDownloadCsv = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  const totalRecords = downloadItems.length;
  const startRecord = 1;
  const endRecord = downloadItems.length;

  const title =` ${t('u_billpaymentsreportp')} `;

  const summaryText1 = `${t('032')} : ${totalRecords}`; // Goes to column A
const summaryText2 = `${t('033')} : ${startRecord} - ${(totalRecords < 10 ? totalRecords : endRecord)}`; // Goes to column Z
  const headers = [];
headers.push(t('2481_034'));
headers.push(t('2480_052'));
if (transactionType === 'R') {
 headers.push(t('2481_057'));
}
headers.push(t('2481_002'));
headers.push(t('251608'));
headers.push(t('008'));
headers.push(t('2481_020'));
headers.push(t('2481_035'));
headers.push(t('2481_022'));
headers.push(t('2481_036'));
headers.push(t('2481_023'));
headers.push(t('2481_018'));
headers.push(t('subscriberCellularNumber'));
headers.push(t('2481_029'));
headers.push(t('2481_004'));
headers.push(t('2481_003'));
headers.push(t('2481_005'));
headers.push(t('0122'));
headers.push(t('0123'));
headers.push(t('2616037'));
headers.push(t('261608'));
headers.push(t('2481_037'));
headers.push(t('errordesp'));
headers.push(t('2481_060'));
headers.push(t('2481_038'));
headers.push(t('2481_039'));
/*
  const rows = downloadItems.map(item => [
          item.transactionDate ||    '---',
          item.authrizationId||    '---',
          item.orderId||    '---',
             item.parenetOrderId||    '---',
          item.partnerCompanyName ||    '---',
          item.partnerId ||    '---',
          item.partnerParent ||     '---',
          item.mainPartner ||      '---',
          item.subscriberMdn  ||      '---',
          item.NORequeAccepted||    '---',
          item.queueProcessingTime||    '---',
          item.promationPlan || '----',
          item.altramiraPlanName||    '---',
          item.terminalId||    '---',
          item.canalId||    '---',
          item.sucursalId||    '---',
          item.packetCode||    '---',
          item.transactionCategory||    '---',
         Number(item.paymentAmount).toFixed(2)||    '---',
          item.statusCode||    '---',
          item.errorreason||    '---',
          item.bonus||    '---',
          item.level||    '---',
          item.bankReferenceId||    '---',
          item.parentName||    '---',
            item.mainDistributorName||    '---'
  ]);
*/

const tableBody = [];

downloadItems.forEach(item => {
  const row = [];

 
row.push(formatDateForCSV(item.Transaction_Date));
  row.push(item.Transaction_Id || '---');
  if (transactionType === 'R') {
  row.push(item.Parent_Trans_Id || '---');
  }
  row.push(item.Authorization_Id || '---');
  row.push(item.Distributor_Name || '---');
  row.push(item.Distributor_Id || '---');
  row.push(item.Levl || '---');
  row.push(item.Partner_Parent_Id || '---');
  row.push(item.Parent_Name || '---');
  row.push(item.Main_Partner || '---');
  row.push(item.Main_Dist_Name || '---');
  row.push(item.Trans_Category || '---');
  row.push(item.Subscriber_Mdn || '---');
  row.push(item.Subscriber_Scl_Code || '---');
  row.push(item.Terminal_Id || '---');
  row.push(item.Canal_Id || '---');
  row.push(item.Sucursal || '---');
  row.push(item.Payment_Type_Description || '---');
  row.push(
  item.Payment_Amount != null && !isNaN(item.Payment_Amount)
    ? `="${Number(item.Payment_Amount).toFixed(2)}"`  // Always 2 decimal places
    : '---'
);
  row.push(item.Channel || '---');
  row.push(item.Status_Code || '---');
  row.push(item.Payment_Reference_Number || '---');
  row.push(item.Status_Description || '---');
  row.push(item.Reference_Id || '---');
  row.push(item.GW_Response_Code || '---');
  row.push(item.Reversal_Flag || '---');



  // Ensure row has exactly 26 columns
  console.log('row.length  123' , row.length );


  // Format each cell
  tableBody.push(row);
});

  
  const escapeCSV = value => {
    if (value == null) return '';
    const stringValue = String(value).replace(/"/g, '""');
    return `"${stringValue}"`;
  };

  const csvLines = [];

  // === Line 1: Title
 // csvLines.push(`"${title}"`);

const titleRow = Array(26).fill('""'); // 26 columns A–Z
titleRow[12] = `"${title}"`; // Put title in column M (index 12)
csvLines.push(titleRow.join(','));


  // === Line 2: Summary text
  // Create a line with value in column A and Z
const emptyCells = Array(24).fill('""').join(','); // 24 empty cells for columns B to Y
const summaryLine = `"${summaryText1}"`;

csvLines.push(summaryLine);
  // === Line 3: Group Headers


  // === Line 4: Column Headers
  csvLines.push(headers.map(escapeCSV).join(','));


// === Data Rows
tableBody.forEach(row => {
  csvLines.push(row.map(escapeCSV).join(','));
});
const endOfReportText = t('0171');
  // === Final Line: End of Report
const endRow = Array(26).fill('""');

// Put the text only in column M (index 12)
endRow[12] = `"${endOfReportText}"`;

// Add the line to the CSV
csvLines.push(endRow.join(','));
 const BOM = '\uFEFF'; // UTF-8 BOM
const csvContent = BOM + csvLines.join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const fileName = 'BillPaymentReport.csv';

  if (navigator.msSaveBlob) {
    navigator.msSaveBlob(blob, fileName);
  } else {
  const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  }
};


  const fetchDataDownload = async () => {

 const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t
    });

    if (!isValid){
      return false;
    }

 if(enableButton) {
          toast.error(`${t('apply_validation')}`);
        return;
    }
   
    try {
      setDownload('Y');
      setEnableButton(false);
      let userName = process.env.REACT_APP_USERNAME;
      let password = process.env.REACT_APP_PASSWORD;
        const apiUrlDownload = window.config.apiUrlJasper +'/billPaymentReport';
        console.log('API URL:', apiUrlDownload);
        console.log('Partner Login ID:', partnerId);

        const responseDownload = await axios.post(apiUrlDownload, {
          userName,
          password,
           partnerId,
        subscriberMdn,
        subscriberSclCode,
        paymentType,
        transactionId,
        paymentAmount,
        statusFlag,
        fromDate:startDate,
        toDate:endDate,
        levelFlag,
        transactionType,
        transactionCategory, 
        authorizationId,
        canalId,
        terminalId,
        sucursalId,
        download,localeVar
        });

        console.log('Response:', responseDownload);

        if (!responseDownload.data || !responseDownload.data.summaryConfigArray) {
            throw new Error('Invalid API response');
        }
        const downloadData = responseDownload.data.summaryConfigArray.map(partner => ({
            Transaction_Date: partner.Transaction_Date,
            Transaction_Id: partner.Transaction_Id,
            Parent_Trans_Id:partner.Parent_Trans_Id,
            Authorization_Id: partner.Authorization_Id,
            Distributor_Name: partner.Distributor_Name,
            Distributor_Id: partner.Distributor_Id,
            Levl: partner.Levl,
            Partner_Parent_Id: partner.Partner_Parent_Id,
            Parent_Name: partner.Parent_Name,
            Main_Partner :partner.Main_Partner,
            Main_Dist_Name :partner.Main_Dist_Name,
            Trans_Category :partner.Trans_Type,
            Subscriber_Mdn: partner.Subscriber_Mdn,
            Subscriber_Scl_Code :partner.Subscriber_Scl_Code,
            Terminal_Id        :partner.Terminal_Id,
            Canal_Id           :partner.Canal_Id,
            Sucursal              :partner.Sucursal,
            Payment_Type_Description                 :partner.Payment_Type_Description,
            Payment_Amount : Number(partner.Payment_Amount).toFixed(2),
            Channel : partner.Channel,
            Status_Code : partner.Status_Code,
            Payment_Reference_Number : partner.Payment_Reference_Number,
  Status_Description : partner.Status_Description,
            Reference_Id : partner.Reference_Id,
            GW_Response_Code : partner.GW_Response_Code,
            Reversal_Flag : partner.Reversal_Flag

        }));

        console.log('Download Data:', downloadData);

        return downloadData;
    } catch (error) {
        console.error('Error fetching data:', error);
        return [];
    }
};


var fromDate='';
if(startDateTime != null){
  var d = new Date(startDateTime);
  var month= d.getMonth()+1;

  var day = d.getDate();
  var year = d.getFullYear();
  var hours = d.getHours();
  var minutes = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;

  // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
  fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
  console.log("StartDate = "+ day + "/" + month + "/" + year + " " + hours + ":" + minutes);
} 




var toDate='';
if(endDateTime != null){
  var d = new Date(endDateTime);
  var month2= d.getMonth()+1;
  var hours1 = d.getHours();
  var minutes1 = d.getMinutes();


  // Ensure that hours and minutes are always two digits
  hours1 = hours1 < 10 ? '0' + hours1 : hours1;
  minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;


  toDate =  d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1;
  console.log("EndDate = "+ d.getDate() + "/" +month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1);
}
const formatSpanishNumbers = (date) => {
    return new Intl.DateTimeFormat('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  const handleEndDateTimeChange = (newValue) => {
    setEndDateTime(newValue);
    setEnableButton(true);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };


   const handleStartDateTimeChange = (newValue) => {
      setStartDateTime(newValue); 
       setEnableButton(true);
     const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
     setStartDate(formattedDateTime);
      console.log("startDate::::::",newValue)
       console.log("startDate::::::",formattedDateTime)
    };
	
	


 // Get current date and time
    const currentDate = new Date();
    const formattedDate = currentDate.toLocaleDateString('en-US', {
      weekday: 'short', 
      year: 'numeric', 
      month: 'numeric', 
      day: 'numeric'
    });
    const formattedTime = currentDate.toLocaleTimeString('en-US', {
      hour: 'numeric', 
      minute: 'numeric'
    });
  
  
  
  
  const totalPages = Math.ceil(totalRecords / recordsPerPage);
    startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);


  
  const DownloadXL = async () => {
   const downloadItems = await fetchDataDownload();
if (!downloadItems || downloadItems.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('BillPaymentReport' , {
      pageSetup: { paperSize: 9, orientation: 'landscape' }
    });
  
    // === Set 30 columns width
    worksheet.columns = new Array(30).fill({ width: 30 });
    const endOfReportText = t('0171');
  
    // === Insert Title Row (Row 1)
    worksheet.insertRow(1, [
     localeVar==='en'?"Bill Payment Report":"Informe de Pago de Factura",
    ]);
    worksheet.mergeCells('A1:AD1');
    worksheet.getCell('A1').font = { bold: true, size: 14 };
    worksheet.getCell('A1').alignment = { horizontal: 'center' };
  
    // === Insert Summary Row (Row 2) with left and right alignment
    const summaryRow = worksheet.insertRow(2, new Array(30).fill(''));
  
    summaryRow.getCell(1).value = `${t('032')} : ${downloadItems.length}`;
    summaryRow.getCell(1).alignment = { horizontal: 'left' };
  
   /* summaryRow.getCell(24).value = `${t('033')} : 1 - ${downloadItems.length}`; summaryRow.getCell(24).alignment = { horizontal: 'right' }; summaryRow.font = { italic: true, size: 10 };
  */
  
  
   
    // === Column Headers (Row 4)
   const headers = [];
headers.push(t('2481_034'));
headers.push(t('2480_052'));
if (transactionType === 'R') {
 headers.push(t('2481_057'));
}
headers.push(t('2481_002'));
headers.push(t('251608'));
headers.push(t('008'));
headers.push(t('2481_020'));
headers.push(t('2481_035'));
headers.push(t('2481_022'));
headers.push(t('2481_036'));
headers.push(t('2481_023'));
headers.push(t('2481_018'));
headers.push(t('subscriberCellularNumber'));
headers.push(t('2481_029'));
headers.push(t('2481_004'));
headers.push(t('2481_003'));
headers.push(t('2481_005'));
headers.push(t('0122'));
headers.push(t('0123'));
headers.push(t('2616037'));
headers.push(t('261608'));
headers.push(t('2481_037'));
headers.push(t('errordesp'));
headers.push(t('2481_060'));
headers.push(t('2481_038'));
headers.push(t('2481_039'));
  const headerRow2 = worksheet.addRow(headers);

    headerRow2.eachCell(cell => {
       cell.font = { bold: true };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' }
        // fgColor: { argb: '3399FF' }
      };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
        cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
        };
    });
  
    // === Add Data Rows (Starting from Row 5)
  
downloadItems.forEach(item => {
  const row = [];

 
  
  row.push(item.Transaction_Date || '---');
  row.push(item.Transaction_Id || '---');
  if (transactionType === 'R') {
  row.push(item.Parent_Trans_Id || '---');
  }
  row.push(item.Authorization_Id || '---');
  row.push(item.Distributor_Name || '---');
  row.push(item.Distributor_Id || '---');
  row.push(item.Levl || '---');
  row.push(item.Partner_Parent_Id || '---');
  row.push(item.Parent_Name || '---');
  row.push(item.Main_Partner || '---');
  row.push(item.Main_Dist_Name || '---');
  row.push(item.Trans_Category || '---');
  row.push(item.Subscriber_Mdn || '---');
  row.push(item.Subscriber_Scl_Code || '---');
  row.push(item.Terminal_Id || '---');
  row.push(item.Canal_Id || '---');
  row.push(item.Sucursal || '---');
  row.push(item.Payment_Type_Description || '---');
  row.push(item.Payment_Amount != null ? Number(item.Payment_Amount).toFixed(2) : '---');
  row.push(item.Channel || '---');
  row.push(item.Status_Code || '---');
  row.push(item.Payment_Reference_Number || '---');
  row.push(item.Status_Description || '---');
  row.push(item.Reference_Id || '---');
  row.push(item.GW_Response_Code || '---');
  row.push(item.Reversal_Flag || '---');

    worksheet.addRow(row);
    });

    // === End of Report Message
    const endOfReportRow = worksheet.addRow([endOfReportText]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, headers.length);
    endOfReportRow.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
    endOfReportRow.getCell(1).font = { bold: true };

    // === Generate Excel File
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
    saveAs(blob, 'BillPaymentReport.xlsx');
};





const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}



return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Bill Payment Report":"Informe de Pago de Factura"}/>
  </tr>

  <tr>
  

<div style={{ display: 'flex' }}> 
    <LeftBgImage1 />
</div>

<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
   <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
       <NavLink
            to="/billpaymentsreportp"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab label={ t('2481_058')} /></NavLink>
   </Tabs>
  </Box>
  <div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="80%">
            {/* body starts */}
          

    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>


          
               <Box style={{display:'flex', gap:'12px',marginTop:'10px'}}> 
                  <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       { `${t('subscriberCellularNumber')}`} 
                       
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setSubscriberMdn(e.target.value)} value={subscriberMdn} size="15" defaultValue=""
               />

                    <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                     {`${t('2481_029')}`} 
                     
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setSubscriberSclCode(e.target.value)} value={subscriberSclCode} size="15" defaultValue=""
               />

 <FormControl className={'selected_formcontrol'} sx={{  minWidth: 150 }} size="small">
                       <InputLabel id="demo-select-small-label">{t('0122')}</InputLabel>
 
                      <Select className={'bankSelect'}  labelId="demo-select-small-label" id="demo-select-small"
                       label={
                     <span>
                     {`${t('0122')}`} 
                     
                        </span>} style={{maxWidth:'250px',width:'210px'}}value={paymentType} onChange={e => setPaymentType(e.target.value)}>
                      <MenuItem value=' '>{'---'}</MenuItem>
               <MenuItem value="PP">{t('7029')}</MenuItem>
              <MenuItem value="FP">{t('7028')}</MenuItem>
              <MenuItem value="CP">{t('7030')}</MenuItem>
                      </Select>
                    </FormControl>

    <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2480_052')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setTransactionId(e.target.value)} value={transactionId} inputRef={transactionIdRef} size="15" defaultValue=""/>


          <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('0123')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setPaymentAmount(e.target.value)} value={paymentAmount} inputRef={paymentAmountRef} size="15" defaultValue=""
               />           
</Box>


   <Box style={{display:'flex',gap:'12px'}}>

        <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_002')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setAuthorizationID(e.target.value)} value={authorizationId} size="15" defaultValue=""
               />


                   <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_003')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setCanalId(e.target.value)} value={canalId} size="15" defaultValue=""
               />

               
                   <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_004')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setTerminalId(e.target.value)} value={terminalId} size="15" defaultValue=""
               />
               <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_005')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setSucursalId(e.target.value)} value={sucursalId} size="15" defaultValue=""
               />
        <FormControl className={'selected_formcontrol'} sx={{  minWidth: 180 }} size="small">
            <InputLabel id="demo-select-small-label">{t('055')}</InputLabel>
            <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
                 label={
                     <span>
                       {`${t('055')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}} value={statusFlag} 
              onChange={e =>setStatusFlag(e.target.value)}>
                <MenuItem value=" ">---</MenuItem>
              <MenuItem value="S">{t('2481_030')}</MenuItem>
              <MenuItem value="F">{t('2481_031')}</MenuItem>
              <MenuItem value="I">{t('2481_011')}</MenuItem>
              <MenuItem value="R">{t('2481_009')}</MenuItem>
            </Select>
        </FormControl>

</Box>
<Box style={{display:'flex',gap:'12px'}}>

          <FormControl className={'selected_formcontrol'} sx={{  minWidth: 180 }} size="small">
            <InputLabel id="demo-select-small-label">{t('2481_018')} 
            <RedAsterisk>*</RedAsterisk></InputLabel>
            <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
                 label={
                     <span>
                       {`${t('2481_018')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}} value={transactionType} 
              onChange={e =>setTansactionType(e.target.value)}>
              <MenuItem value="P">{t('2481_032')}</MenuItem>
              <MenuItem value="R">{t('2481_033')}</MenuItem>
                </Select>
        </FormControl>


  <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                
                  className={'datePickerrrjasper'}
                  // label="Select Date and Time"
                  value={startDateTime}
                  onChange={handleStartDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
                  // label={t('80')} // This serves as the floating label
                  label={
                    <span>
                      {`${t('80')}`} <RedAsterisk>*</RedAsterisk>
                    </span>}
                    format="DD/MM/YYYY HH:mm:ss"
                  inputFormat=" " // Keeps the input field empty unless a date is selected
                  renderInput={(params) => <TextField
                    {...params}
                    InputLabelProps={{
                      shrink: true, // Always shrink the label to allow for a floating effect
                    }}
                    placeholder={!startDateTime ? t('80') : ''} // Show the placeholder only if no date is selected
                    fullWidth
                    variant="outlined"
                    sx={{ width: "140px", height: "40px", padding: '20px' }}
                  />}
                />
                
              </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}   adapterLocale={localeVar === 'en' ? 'en' : 'es'} >
                <DateTimePicker
              
               className={'datePickerrrjasper'}
               label={
                <span>
                  {`${t('81')}`} <RedAsterisk>*</RedAsterisk>
                </span>}
                format="DD/MM/YYYY HH:mm:ss"
                  value={endDateTime}
                  onChange={handleEndDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
               renderInput={(params) => <TextField {...params} />} />

              </LocalizationProvider>
			  
			  

 <FormControl className={'selected_formcontrol'} sx={{  minWidth: 150 }} size="small">
                       <InputLabel id="demo-select-small-label">{t('2481_025')} <RedAsterisk>*</RedAsterisk></InputLabel>
 
                      <Select className={'bankSelect'}  labelId="demo-select-small-label" id="demo-select-small"
                      value={levelFlag}  label={
                     <span>
                       {`${t('2481_025')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}  onChange={e => setLevelFlag(e.target.value)}>
                        <MenuItem value="Y">{t('Y')}</MenuItem>
                        <MenuItem value="N">{t('N')}</MenuItem>
                      </Select>
                    </FormControl>




        <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
            onClick={handleSubmit1}
            >
              {t('2616028')} 
              </Button>
           
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
            onClick={clearData}
            >
              {t('2472_27')}
            </Button>
               {/* <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SaveIcon />}
            //onClick={clearData}
            >
              {t('2616030')}
            </Button> */}
               </Box>
           
            </Box>

           <Grid
                          container
                          spacing={2}
                          sx={{ width: 1 }}
                          className={""}
                          style={{
                            justifyContent: "center",
                            marginTop: "5px",
                            marginBottom: '0px',
                            marginLeft: "0px",
                            borderBottom: "1px solid #fff",
                            paddingInline: "0px",
                          }}
                        >
                          <Grid
                            item
                            xs={4}
                            sx={{ textAlign: "left", padding: "0 !important" }}
                          >
                          </Grid>
                          <Grid
                            item
                            xs={3}
                            sx={{ textAlign: "center", padding: "0 !important" }}
                          ></Grid>
                         <Grid
                            item
                            xs={5}
                            sx={{ textAlign: "right", padding: "0 !important" }}>
                           {totalRecords >0 ?
                              <><span className={"strongerTxtLable"}>
                                                        {t('032')} : {totalRecords}
                                                      </span><span className={"strongerTxtLable"}>
                                                          &nbsp; / &nbsp;
                                                          {t('033')} : {startRecord} - {totalRecords < 10 ? totalRecords :endRecord}
                                                        </span></>   :
                                <></>}
                          </Grid>
                        </Grid>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
        <TableRow className="darkgray">
            <TableCell align="center" sortDirection={orderBy === 'Transaction_Date' ? order : false} >
            <TableSortLabel   style={{ color: 'white' }} // correct camelCase
              active={orderBy === 'Transaction_Date'}
              direction={orderBy === 'Transaction_Date' ? order : 'asc'}
              onClick={() => handleSort('Transaction_Date')}
               className="largeSortLabel"
            >
              {t('2481_034')}
            </TableSortLabel>  </TableCell>
        <TableCell align="center">{t('2480_052')} </TableCell>
      
    {showParentOrderId && (<TableCell align="center">{t('2481_057')} </TableCell>)}
        <TableCell align="center">{t('2481_002')} </TableCell>
        <TableCell align="center">{t('251608')} </TableCell>
        <TableCell align="center">{t('008')} </TableCell>
        <TableCell align="center">{t('2481_020')} </TableCell>
        <TableCell align="center">{t('2481_035')} </TableCell>
        <TableCell align="center">{t('2481_022')} </TableCell>
        <TableCell align="center">{t('2481_036')} </TableCell>
        <TableCell align="center">{t('2481_023')} </TableCell>
        <TableCell align="center">{t('2481_018')} </TableCell>
        <TableCell align="center">{t('subscriberCellularNumber')}</TableCell>
        <TableCell align="center">{t('2481_029')} </TableCell>
        <TableCell align="center">{t('2481_004')} </TableCell>
        <TableCell align="center">{t('2481_003')} </TableCell>
        <TableCell align="center">{t('2481_005')} </TableCell>
        <TableCell align="center">{t('0122')} </TableCell>
        <TableCell align="center">{t('0123')} </TableCell>
        <TableCell align="center">{t('2616037')} </TableCell>
        <TableCell align="center">{t('261608')} </TableCell>
        <TableCell align="center">{t('2481_037')} </TableCell>
        <TableCell align="center">{t('errordesp')} </TableCell>
        <TableCell align="center">{t('2481_060')} </TableCell>
        <TableCell align="center">{t('2481_038')} </TableCell>
        <TableCell align="center">{t('2481_039')} </TableCell>

      
          
           
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
                 <TableRow>
                      <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
                      {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
                      </TableCell>
                    </TableRow>
                  ) : sortedItems.length > 0 ? (
                    // Show table rows when data is available
                    sortedItems.map((item, index) => (
                      <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
                
                <TableCell align="center">&nbsp;{item.Transaction_Date|| '---'}&nbsp;</TableCell>  
                <TableCell align="center">&nbsp;{item.Transaction_Id|| '---'}&nbsp;</TableCell>
               {showParentOrderId  && (<TableCell align="center">{item.Parent_Trans_Id || '---'}</TableCell> )}
                <TableCell align="center">{item.Authorization_Id|| '---'}</TableCell>
                <TableCell align="center">{item.Distributor_Name|| '---'}</TableCell>
                 <TableCell align="center">&nbsp;{item.Distributor_Id|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Levl|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Partner_Parent_Id|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Parent_Name|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Main_Partner|| '---'}&nbsp;</TableCell>
                 <TableCell align="center">&nbsp;{item.Main_Dist_Name|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Trans_Type|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Subscriber_Mdn|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Subscriber_Scl_Code|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Terminal_Id|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Canal_Id|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Sucursal|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Payment_Type_Description|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{Number(item.Payment_Amount).toFixed(2)|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.Channel || '---'}&nbsp;</TableCell>
                <TableCell align="center">{item.Status_Code|| '---'}&nbsp;</TableCell>{/* need to change this value*/}
                <TableCell align="center">{item.Payment_Reference_Number|| '---'}&nbsp;</TableCell>
                <TableCell align="center">{item.Status_Description|| '---'}&nbsp;</TableCell>
                <TableCell align="center">{item.Reference_Id|| '---'}&nbsp;</TableCell>
                <TableCell align="center">{item.GW_Response_Code|| '---'}&nbsp;</TableCell>
                <TableCell align="center">{item.Reversal_Flag|| '---'}&nbsp;</TableCell>
             
                </TableRow>
            ))
          ) : (
          statusId === 'F' ? <TableRow>
                      <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                        {t("038")} {/* No data found for the given search criteria */}
                      </TableCell>
                    </TableRow> :
                    <TableRow>
                      <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                        {t("2481_061")} {/* No data found for the given search criteria */}
                      </TableCell>
                    </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
   
 <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                            {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,
                                                 }}
                                               >
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{t('2481_062')}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); DownloadXL(); }}>{t('2481_064')}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{t('2481_063')}</MenuItem>
                                                
                                               </Menu>
                                             </div>
                                              : <></>}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</td></tr>
</div> 
</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>
<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
    width: "auto",           // Let width grow with message
    fontSize: "18px",        // Optional: keep font size
    padding: "8px",          // Optional: spacing inside
    wordBreak: "break-word", // Ensure long words/wrapped text don't overflow
                        }}
                      />
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  );
}

export default BillPaymentsReport;
