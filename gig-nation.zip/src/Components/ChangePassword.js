/* eslint-disable no-redeclare */
/* eslint-disable no-unused-vars */

import {
  Footer,
  Header,
  LeftBgImage,
  PaymentManagerHeading,
  ProfileMenu,
} from "./PageComponents";
import TopMenu from "./TopMenu";
import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";
import SendIcon from "@mui/icons-material/Send";
import {
  KeyboardReturn,
  CancelRounded,
  PasswordRounded,
} from "@mui/icons-material";
import Button from "@mui/material/Button";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import { useNavigate } from "react-router-dom";
import i18n from "./i18n";
import { ToastContainer, toast } from "react-toastify";
import PasswordRulesPopUp from "./PasswordRulesPopUp";
import { Box, Grid, styled, TextField } from "@mui/material";

export default function ChangePassword() {
  //sessionStorage.setItem("selectedIndex", 1);
 sessionStorage.setItem("selectedLink", "a_profile");
  const exampleData = JSON.parse(localStorage.getItem("userData"));
  const partnerLoginId = exampleData.LOGIN_ID;
  const userTypeId = exampleData.USER_TYPE_ID;
  const partnerEmailId = exampleData.LOGIN_USER_EMAIL_ID;
  const localeVar = i18n.language;

  const [error, setError] = useState("");
  const [oldPassword, setOldPassword] = useState("");
  const [partnerPassword, setPartnerPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [selectedChannels, setSelectedChannels] = useState("W");
  const [loading, setLoading] = useState(false);
  const [ruleArray, setRuleArray] = useState([]); // State to store ruleArray
  const [statusArray, setstatusArray] = useState([]); // State to store ruleArray
  const { t } = useTranslation();
  const [skipPasswordRules, setSkipPasswordRules] = useState(false);
  const navigator = useNavigate();
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
    const toastId = useRef(null);
    const [visible , setVisible ] = useState(false); // State to store ruleArray

  const fetchData = async () => {

    setLoading(true);
    try {
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_CHANGEPWD_URL;
      const response = await axios.post(apiUrl, {
      userName,
      password,
          methodName: 'getPasswordRules',
          partnerId: partnerLoginId,
          partnerTypeId: userTypeId,
          partnerLoginId: userTypeId,
          localeVar: localeVar,
          channelPwdType:selectedChannels,
          checkChangePw: 'false',
          profId: '0',
          hrsBtwnDays: '0',
          pwdPriorCount: '0',
          pwdChngHrs: '0',
          _pwdHrStatus: 'N',
          SITE_LANGUAGE: 'eng',
          changePwdVar: 'firstTime'
        }
      );

      const Code = response.data.responseCode
      console.log("response.data", response.data)
      console.log("Code", Code);
      const responseData=response.data;
      if(responseData.responseDescription=="Passward Rules not Applicable to Given PartnerId"){
        setVisible(false);
        console.log("VISIBLEEEE FALSE")
      }
      else{
        setVisible(true);
        console.log("VISIBLEEEE TRUE")

      }
      if (Code === '99') {
        setSkipPasswordRules(true)
      }

      const { ruleList, statusList } = response.data;

      // Extract rulearray and statusarray

      // Set ruleArray state
      setRuleArray(ruleList.rulearray);
      setstatusArray(statusList.statusarray);

      console.log("ruleArray==", ruleArray);
      console.log("status array==", statusArray);

      // Do something with the arrays
      // console.log('Rule Array:', ruleArray);
      // console.log('Status Array:', statusArray);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    // Set the browser title
    document.title = t('2472_015');
  }, []);

useEffect(() => {

    fetchData(); // Call the fetch function when the component mounts


  }, [selectedChannels]); // Dependency array with pageNumber as the dependency

  const ChangePwd = async (oldPass, newPass, selectedChannel) => {
    try {
      setLoading(true);
      var partnerpass = newPass;
      var oldpass = oldPass;
      var channel = selectedChannel;
      console.log("partnerpass====", partnerpass);
      console.log("oldpass=======", oldpass);

      const apiUrl = window.config.apiUrl + process.env.REACT_APP_CHANGEPWD_URL;
  
      const response = await axios.post(apiUrl
        
        , {
          
            userName,
            password,
          partnerId: partnerLoginId,
          methodName: 'changePasswordResult',
          partnerPassword: partnerpass,
          oldPassword: oldpass,
          channel: channel,
          channelPwdType:selectedChannels,
          localeVar: localeVar,
          partnerEmailId: partnerEmailId,
          partnerTypeId: userTypeId
        }, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: '',
        },
      }
      );


      const jsonData = JSON.stringify(response.data, null, 2);

      console.log("data====", jsonData)

      if (response.data.status === "ALTERED") {
        localStorage.setItem("ALTERED", true);
        console.log("ALTERED====", localStorage.getItem("ALTERED"))
        let pwdMsg = true;
        clearData();
       // navigator('/profile', { state: { pwdMsg } })
        navigate('/profile', { state: { pwdMsg: '' } });  // Reset pwdMsg
      }
      else if (response.data.status === "WRONG_OLD_PWD") {
        if(!toast.isActive(toastId.current) )  {
          toastId.current = toast.error(t('24801')); 
        }
        
        // toast.error(t('24801'))
        clearData();
        return;
       // navigate("/changepasswordpage")
       
      }
      else if (response.data.status === "timeRem") {
        if(!toast.isActive(toastId.current) )  {
          toastId.current = toast.error(t('25160002') + response.data.pwdChgHrs + t('25160003')); 
        }
        
        // toast.error(t('24801'))
        clearData();
        return;
       // navigate("/changepasswordpage")
       
      }
      else if (response.data.tmpMsgVar === "reuse") {
        if(!toast.isActive(toastId.current) )  {
          toastId.current = toast.error(t('25160004')); 
        }
        
        // toast.error(t('24801'))
        clearData();
        return;
       // navigate("/changepasswordpage")
       
      } 
      else {
        navigator('/changePassword')
      }



    } catch (error) {
      console.error('Error fetching password validation parameters:', error);
      setLoading(false);
      // Handle error
    }

    setLoading(true);
  };



  //const rarr = ruleArray;
  //const sarr = statusArray

  const getTypeByIdForRule = (id) => {
    const rule = ruleArray.find(item => item.id === id);
    return rule ? rule.type : null;
  };

  const getTypeByIdSatus = (id) => {
    const rule = statusArray.find(item => item.id === id);
    return rule ? rule.type : null;
  };


  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

  const verifyPwdRules = () => {


    let strTemp = "";
    let space=" ";

    const partnerpwd = document.getElementById('partnerPassword');
    if (getTypeByIdSatus('0') === 'Y' && partnerPassword.length < getTypeByIdForRule('0')) {
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(strTemp + t('2424221') +space+ getTypeByIdForRule('0') +space+ t('2424218') + strTemp); 
      }
      // toast.error(strTemp + t('2424221') +space+ getTypeByIdForRule('0') +space+ t('2424218') + strTemp);
      partnerpwd.focus();
      return false;
    }

    if (getTypeByIdSatus('7') === 'Y' && partnerPassword.length > getTypeByIdForRule('7')) {
      if(!toast.isActive(toastId.current) )  {
        toastId.current =  toast.error(strTemp + t('2424222') +space+ getTypeByIdForRule('7') + space+t('2424218') + strTemp); 
      }
      // toast.error(strTemp + t('2424222') +space+ getTypeByIdForRule('7') + space+t('2424218') + strTemp);
      partnerpwd.focus();
      return false;
    }


    const specialChars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^*";
    if (!IsCharactersInBag(partnerPassword, specialChars)) {
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(strTemp + t('2424223') + strTemp);
      }
      // toast.error(strTemp + t('2424223') + strTemp);
      partnerpwd.focus();
      return false;
    }


    if (getTypeByIdSatus('1') === 'Y' && getTypeByIdForRule('1') === "Y" &&
      (IsCharsInBag(partnerPassword, "0123456789") === false ||
        IsCharsInBag(partnerPassword, "abcdefghijklmnopqrstuvwxyz") === false ||
        IsCharsInBag(partnerPassword, "ABCDEFGHIJKLMNOPQRSTUVWXYZ") === false ||
        checkCharCount(partnerPassword) < 2
      )
    ) //3 validation - alphanumeric
    {
      if(!toast.isActive(toastId.current) )  {
        toastId.current =  toast.error(strTemp + t('2424224') + strTemp);
      }
      // toast.error(strTemp + t('2424224') + strTemp);
      partnerpwd.focus();
      return false;
    }



    if (getTypeByIdSatus('2') === 'Y' && getTypeByIdForRule('2') === "N" && isConsecutives(partnerPassword))			//4 Consecutive
    {
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(strTemp + t('2424225') + strTemp);
      }
      // toast.error(strTemp + t('2424225') + strTemp);
      partnerpwd.focus();
      return false;
    }

    if (getTypeByIdSatus('2') === 'Y' && getTypeByIdForRule('2') === "Y" && !isConsecutives(partnerPassword))			//4 Consecutive
    {
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(strTemp + t('2424226') + strTemp);
      }
      // toast.error(strTemp + t('2424226') + strTemp);
      partnerpwd.focus();
      return false;
    }

    //if(pwdStatusArray[9] === 'Y' && pwdRulesArray[9].length > 0 && ((pwdRulesArray[9].toUpperCase()).indexOf(newPassword.toUpperCase()) != -1)) // || doesPwdContainPwdChar(pwdRulesArray[9],newPassword) === true) )
    if (getTypeByIdSatus('9') === 'Y' && getTypeByIdForRule('9').length > 0 && !(checkPwdWords(getTypeByIdForRule('9'), partnerPassword))) // || doesPwdContainPwdChar(pwdRulesArray[9],newPassword) === true) )
    {
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(strTemp + t('2424227') + strTemp);
      }
      // toast.error(strTemp + t('2424227') + strTemp);
      partnerpwd.focus();
      return false;
    }

    if (getTypeByIdSatus('8') === 'Y' && getTypeByIdForRule('8').length > 0 && (checkPwdChars(getTypeByIdForRule('8'), partnerPassword) === false)) {
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(strTemp + t('2424228') + strTemp);
      }
      // toast.error(strTemp + t('2424228') + strTemp);
      partnerpwd.focus();
      return false;
    }

    return true;

  }
  const IsCharactersInBag = (str, bag) => {
    for (let i = 0; i < str.length; i++) {
      if (bag.indexOf(str[i]) === -1) {
        return false;
      }
    }
    return true;
  };


  const IsCharsInBag = (s, bag) => {
    var i;
    for (i = 0; i < s.length; i++) {
      var c = s.charAt(i);

      if (bag.indexOf(c) !== -1)
        return true;

    }
    return false;
  }



  const Str2Hex = (str) => {
    var tmp = str;
    var str = '';
    var c;
    for (var i = 0; i < tmp.length; i++) {
      c = tmp.charCodeAt(i);
      //str += d2h(c) + ' ';
      str += d2h(c) + 'xf0cccxX';
    }
    return str;
  }

  const reverse = (str) => {
    return str.split("").reverse().join("");
  }


  // eslint-disable-next-line no-unused-vars
  const doesPwdContainPwdChar = (str, newPassword) => {
    var tmpFlag = false;

    for (var i = 0; i < newPassword.length; i++) {
      var c = newPassword.charAt(i);

      if (str.indexOf(c) !== -1) {
        tmpFlag = true;
        break;
      }
    }

    return tmpFlag;
  }



  const d2h = (d) => { return d.toString(16); }
  const h2d = (h) => { return parseInt(h, 16); }


  const isBlank = (s) => {

    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i);
      if ((c !== ' ') &&
        (c !== '\n') &&
        (c !== '\t'))
        return false;
    }
    return true;
  }

  const isConsecutives = (str) => {
    var str;
    var flag = false;

    for (var i = 1; i < str.length - 1; i++) {
      var ch1 = str.charCodeAt(i - 1);
      var ch2 = str.charCodeAt(i);
      var ch3 = str.charCodeAt(i + 1);

      if ((parseInt(ch1) >= 48 && parseInt(ch1) <= 57 && parseInt(ch2) >= 48 && parseInt(ch2) <= 57)
        || (parseInt(ch2) >= 48 && parseInt(ch2) <= 57 && parseInt(ch3) >= 48 && parseInt(ch3) <= 57)
      ) {
        if ((parseInt(ch1) === (parseInt(ch2) - 1)) || (parseInt(ch2) === (parseInt(ch3) - 1))) {
          flag = true;
          break;
        }
      }
    }
    return flag;
  }




  const checkCharCount = (str) => {
    var count = 0;

    for (var i = 0; i < str.length; i++) {
      var ch1 = str.charCodeAt(i);

      if ((parseInt(ch1) >= 97 && parseInt(ch1) <= 122) || (parseInt(ch1) >= 65 && parseInt(ch1) <= 90))
        count++;
    }
    return count;
  }


  const checkPwdWords = (str, newPassword) => {
    var words = str.split(" ");

    for (var index = 0; index < words.length; index++) {
      var word = words[index];

      if (newPassword.toUpperCase().indexOf(word.toUpperCase()) >= 0) {
        return false;
      }
      else continue;
    }
    return true;
  }


  const checkPwdChars = (str, newPassword) => {
    var tmpFlag = false;

    for (var i = 0; i < newPassword.length; i++) {
      var c = newPassword.charAt(i);

      if (str.indexOf(c) !== -1) {
        tmpFlag = true;
        break;
      }
    }

    return tmpFlag;
  }


  const verifyPassword = (e) => {

    fetchData();


    e.preventDefault();


    let oldpwd = document.getElementById("oldPassword");
    if (!oldPassword.trim()) {

      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('2424211')); 
      }
      // toast.error(t('2424211'));
      oldpwd.focus();
      return;
    }
    else if (oldpwd.length == 0) {
     if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('2424212')); 
      }
     // toast.error(t('2424212'));

      document.forms[0].oldPassword.focus();
      document.forms[0].oldPassword.value = "";
      return;
    }
    let partnerpwd = document.getElementById("partnerPassword");
    if (!partnerPassword.trim()) {
        if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('2424213')); 
      }
    //  toast.error(t('2424213'));
      partnerpwd.focus();
      return;
    }
    
    let confirmPwdField = document.getElementById("confirmPassword");

    if (!confirmPassword.trim()) {
      // If confirmPassword is empty or just spaces
      if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t('2424214'));  // Show an error message if empty
      }
      confirmPwdField.focus();  // Set focus on the field
      return;
    }
    
    if (partnerPassword.trim() !== confirmPassword.trim()) {
      // If passwords do not match
      setPartnerPassword("");
      setConfirmPassword("");
      if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t('2424215'));  // Show an error message if passwords don't match
      }
      confirmPwdField.focus();  // Set focus on the field
      return;
    }
    

    // Additional validations specific to "U" value of chValue
    const chValue = selectedChannels;//for selected USSD change
    const pwdLength = 4; // Assuming pwdLength is 10 for "U" value

    if (chValue === "U" && isNaN(Number(partnerPassword))) {
       if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('2424216')); 
      }
      //toast.error(t('2424216'));
      partnerpwd.focus();
      return;
    }

    if (chValue === "U" && partnerPassword.trim().length > pwdLength) {
         if(!toast.isActive(toastId.current) )  {
        toastId.current =  toast.error(t('2424217') +" "+ pwdLength +" "+ t('2424218'));
      }
    //  toast.error(t('2424217') + pwdLength + t('2424218'));
    setPartnerPassword("");
    setConfirmPassword("");
      partnerpwd.focus();
      return;
    }

    if (oldPassword.trim() === partnerPassword.trim()) {
       if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('2424219')); 
      }
      setOldPassword("");
      setPartnerPassword("");
      setConfirmPassword("");
     // toast.error(t('2424219'));
      partnerpwd.focus();
      return;
    }
    var selected = selectedChannels;

    console.log("selected channel=", selected);
    if (!skipPasswordRules) {
      if (verifyPwdRules() !== false) {

        // All validations passed
        console.log('Password change request can be submitted.');


        var hexOldPwdData = Str2Hex(oldPassword);
        // Str2Hex(document.forms[0].oldPassword.value);
        var revOldPwd = reverse(hexOldPwdData);
        // document.forms[0].oldPassword.value = revOldPwd;

        var hexPtnrPwdData = Str2Hex(partnerPassword);
        var revPtnrPwd = reverse(hexPtnrPwdData);
        // document.forms[0].partnerPassword.value = revPtnrPwd;

        var hexCfmPwdData = Str2Hex(confirmPassword);
        var revCfmPwd = reverse(hexCfmPwdData);
        // document.forms[0].confirmPassword.value = revCfmPwd;


        setOldPassword(revOldPwd);
        setPartnerPassword(revPtnrPwd);
        setConfirmPassword(revCfmPwd);

        ChangePwd(revOldPwd, revPtnrPwd, selected);

      }
    } else {
	 
      }
 if(skipPasswordRules){
      // All validations passed
      console.log('Password change request can be submitted.');


      var hexOldPwdData = Str2Hex(oldPassword);
      // Str2Hex(document.forms[0].oldPassword.value);
      var revOldPwd = reverse(hexOldPwdData);
      // document.forms[0].oldPassword.value = revOldPwd;

      var hexPtnrPwdData = Str2Hex(partnerPassword);
      var revPtnrPwd = reverse(hexPtnrPwdData);
      // document.forms[0].partnerPassword.value = revPtnrPwd;

      var hexCfmPwdData = Str2Hex(confirmPassword);
      var revCfmPwd = reverse(hexCfmPwdData);
      // document.forms[0].confirmPassword.value = revCfmPwd;


      setOldPassword(revOldPwd);
      setPartnerPassword(revPtnrPwd);
      setConfirmPassword(revCfmPwd);

      ChangePwd(revOldPwd, revPtnrPwd, selected);
    }
  };

const handleChannelChange=(event)=>{
  const value = event.target.value;
  setSelectedChannels(value);
 
  // Clear passwords if selected channel is 'U' or 'W'
  if (value === 'U' || value === 'W') {
    setOldPassword("");
    setConfirmPassword("");
    setPartnerPassword("");
  }
}




  const clearData = () => {
    setOldPassword("");
    setPartnerPassword("");
    setConfirmPassword("");
  };

  const RedAsterisk = styled("span")({
    color: "red",
  });
  const [isMandate, setIsMandate] = useState(false);
  const [isMandate1, setIsMandate1] = useState(false);
  const [isMandate2, setIsMandate2] = useState(false);
  const handleBlur = () => {
    if (oldPassword.trim() === "") {
      setIsMandate(true);
    } else {
      setIsMandate(false);
    }
  };
  const handlePartnerPwd = () => {
    if (partnerPassword.trim() === "") {
      setIsMandate1(true);
    } else {
      setIsMandate1(false);
    }
  };
  const handleConfirmPwd = () => {
    if (confirmPassword.trim() === "") {
      setIsMandate2(true);
    } else {
      setIsMandate2(false);
    }
  };
  return (
    <div>
      <form>
        <table
          border={0}
          cellPadding={0}
          cellSpacing={0}
          id="inSideLayoutTable"
          height={600}
          width={1000}
          align="center"
        >
          <tbody>
           <Header />
            <tr height="65px">
              <PaymentManagerHeading />
              <TopMenu
                menuLink={localeVar === "en" ? "Profile" : "Perfil"}
              />
            </tr>
            <tr>
              {/* <td
                valign="top"
                style={{
                  borderRightStyle: "solid",
                  borderRightWidth: "1pt",
                  borderColor: "rgb(51 153 255)",
                }}
                nowrap="nowrap"
              >
                <br />
                &nbsp; <br />
              </td> */}
              <LeftBgImage/>
              <td valign="top">
                <meta
                  httpEquiv="Content-Type"
                  content="text/html; charset=ISO-8859-1"
                />
                <title>homepage</title>
                <ProfileMenu />
                <form method="post">
                  <table
                    width="100%"
                    height="100%"
                    cellSpacing={20}
                    cellPadding={150}
                    border={0}
                    align="left"
                  >
                    <tbody>
                      <table
                        border={0}
                        cellPadding={0}
                        cellSpacing={0}
                        width="100%"
                        height="100%"
                        align="left"
                      >
                        <tbody>
                          <tr>&nbsp;</tr>
                          <tr>
                            <td>
                              <div className={"mL8 distAccnt"}>
                                <Box
                                  className={"displayFlex"}
                                  style={{ justifyContent: "space-between",  paddingTop:'2px',    alignItems: 'flex-start' }}
                                >
                                  {/* <p style={{marginBottom:'17px'}} className="strongerTxtLable">
                                    {t("242403")} : <b>{partnerLoginId}</b>
                                  </p> */}
                                  <Box>
                                <FormControl
                                  className={"selected_formcontrol"}
                                  sx={{ minWidth: 280 }}
                                  size="small"
                                >
                                  <InputLabel id="demo-select-small-label">
                                    {t("242404")}
                                  </InputLabel>
                                                        <Select
                                                          labelId="demo-select-small-label"
                                                          id="demo-select-small"
                                    className={"selected_dropdown bankSelect"}
                                    label={t("242404")}
                                    name="selectedChannels"
                                    value={selectedChannels}
                                    // onChange={(e) =>
                                    //   setSelectedChannels(e.target.value)   }
                                    onChange={(e) => handleChannelChange(e)}>
                                    <MenuItem value=""></MenuItem>
                                    <MenuItem value="W">WEB</MenuItem>
                                    <MenuItem value="U">USSD</MenuItem>
                                                          {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                        </Select>
                                                      </FormControl>
                               <Box>
                               <TextField
                                  type="password"
                                  label={
                                    <span>
                                      {`${t("242405")}`}
                                      <RedAsterisk>*</RedAsterisk>
                                    </span>
                                  }
                                  size="20"
                                  name="oldPassword"
                                  id="oldPassword"
                                  value={oldPassword}
                                  maxLength="30"
                                  onChange={(e) =>
                                    setOldPassword(e.target.value)
                                  }
                                  onBlur={handleBlur}
                                  className={`sampleInput mb5 ${isMandate ? 'mandateField' : ''}`}

                                />
                               </Box>
                               <Box>
                               <TextField type="password" size="24" name="partnerPassword" id='partnerPassword' value={partnerPassword} maxLength={24} 
                                 
                                  label={
                                    <span>
                                      {`${t("242406")}`}
                                      <RedAsterisk>*</RedAsterisk>
                                    </span>
                                  }
                                  onChange={(e) => setPartnerPassword(e.target.value)} 
                                  onBlur={handlePartnerPwd}
                                  className={`sampleInput mb5 ${isMandate1 ? 'mandateField' : ''}`} />
                               </Box>
                               <Box>
                               <TextField type="password" size="24" name="confirmPassword" id='confirmPassword' value={confirmPassword} maxLength={24} 
                                label={
                                  <span>
                                    {`${t("242407")}`}
                                    <RedAsterisk>*</RedAsterisk>
                                  </span>
                                } onChange={(e) => setConfirmPassword(e.target.value)}
                                onBlur={handleConfirmPwd}
                                className={`sampleInput mb5 ${isMandate2 ? 'mandateField' : ''}`} />

                               </Box>
                                  </Box>
                                  {/* <Box>
                                   &nbsp; <PasswordRulesPopUp visible={visible} />
                                  </Box> */}
                                  <Box>
 
  {/* Render PasswordRulesPopUp only when selectedChannels is not "U" (USSD) */}
    <PasswordRulesPopUp visible={visible} />
                                  </Box>
                                </Box>
                               
                               <div style={{gap: '8px',display:'flex'}}>
                                                       {/* <input type="submit" defaultValue="Submit" className="inputButton" onClick={verifyPassword}/> */}
                                                       <Button className={'hoverEffectButton'} size="small" variant="contained" onClick={verifyPassword} endIcon={<SendIcon />}>
                                                        {t('242409')}
                                                      </Button>
                                                      {/* <input type="button" defaultValue="Return" className="inputButton" onClick={""} /> */}
                                                      <Button className={'hoverEffectButton'} size="small" variant="contained" onClick={handleReturn} endIcon={<KeyboardReturn />}>
                                                        {t('242410')}
                                                      </Button>
                                                      {/* <input type="button" defaultValue="Clear"className="inputButton" onClick={clearData}/> */}
                                                      <Button className={'hoverEffectButton'} size="small" variant="contained" onClick={clearData} endIcon={<CancelRounded />}>
                                                        {t('242411')}
                                                      </Button>
                                                     </div>
                              </div>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </tbody>
                  </table>
                   <ToastContainer 
                    position="top-right"
                    autoClose={3000}
                    hideProgressBar={false}
                    newestOnTop={false}
                    closeOnClick
                    rtl={false}
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover
                    style={{
                      width: "fit-content",
                      minWidth: "300px",
                      minHeight: "100px",
                      fontSize: "18px",
                    }}
                  /> 
                 
                </form>
              </td>
            </tr>
            <tr height="60px">
              <td colSpan={2}>
                <link
                  href="/airmanage/networkadmin/stylesheets/abcstyles-new.css"
                  rel="stylesheet"
                  type="text/css"
                />
                <Footer />
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
}
