// src/hooks/useSessionInterceptor.js

import axios from 'axios';
import { useDispatch } from 'react-redux';
import { logoutUser } from '../reducers/exampleSlice'; // Adjust this import according to your project structure

const useSessionInterceptor = () => {
  const dispatch = useDispatch();

  // Adding Axios response interceptor
  // axios.interceptors.response.use(
  //   (response) => {
  //     // If the response is successful, return the response
  //     return response;
  //   },

    axios.interceptors.response.use(
    (response) => {
      // If the response is successful, return the response

   if (
        typeof response.data === "string" &&
        response.data.includes("<title>Login") // adjust check for your app's login page
      ) {
        console.error("Session expired (login page returned)");
        localStorage.clear();
        dispatch(logoutUser());
        window.location.href = "/gig-nation";
        return Promise.reject({ message: "Session expired" });
      }

      return response;
    },
    (error) => {
      if (error.code === 'ERR_NETWORK') {
        // Handle network errors (e.g., server down or unreachable)
        console.error("Network error detected:", error.message);
        // Optionally log out the user or display a message
        alert("The server is currently unavailable. Please try again later.");
        dispatch(logoutUser()); // Log out the user (optional)
        localStorage.removeItem('sessionId');
        window.location.href = '/gig-nation'; // Redirect to login page or show a proper message
      } 
      else if (error.response && error.response.status === 401) {
        // Handle session expiration
        console.error("Session expired or unauthorized access");
        localStorage.removeItem('sessionId');
        dispatch(logoutUser());
        window.location.href = '/gig-nation'; // Redirect to login page 
      }

      // Pass the error to the calling code
      return Promise.reject(error);
    }
  );
};

export default useSessionInterceptor;
