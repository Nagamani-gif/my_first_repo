import React, { useState, useEffect, useRef} from "react";
import { useLocation } from 'react-router-dom';
import axios from "axios";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Button,
  Checkbox,
  MenuItem,
  Select,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  TableContainer,
  Paper,
  DialogContentText,
  FormControl,
} from "@mui/material";
import { AddCardRounded, ArrowRight, CancelRounded } from "@mui/icons-material";
import SendIcon from "@mui/icons-material/Send";
import i18n from "./i18n";
import { useTranslation } from "react-i18next";
import { toast, ToastContainer } from "react-toastify";

function ConfigurationNotificationPopup({setnotificationListObj,configId} ) {

  const location = useLocation();
  const { distId } = location.state || {}; 

  const [partnerId, setPartnerId] = useState(distId || ''); // Initialize partnerId

  const { t } = useTranslation();
  const [rows, setRows] = useState([]);
  const [newRow, setNewRow] = useState({
    eventId: "",
    deliveryMethod: "Email",
    selfAlert: false,
    otherDistributionList: "",
    childAlertSubscription: "None",
    status: "A",
  });
  const [addEventId, setaddEventId] = useState('');
  const [error, setError] = useState('');
  const [selectedRows, setSelectedRows] = useState([]);
  const [flag, setFlag] = useState(false);
  const [submittedData, setSubmittedData] = useState([]);
  const [open, setOpen] = useState(false); // Initially set to false to hide the dialog box
  const [eventOptions, setEventOptions] = useState([]);
  const exampleData = JSON.parse(localStorage.getItem("userData"));
  const partnerLoginId = exampleData.LOGIN_ID;
  const [isSubmit, setIsSubmit] = useState(false);
  let localeVar = i18n.language;
  const [eventId, setEventId] = useState('');
  const [serachByStatus, setSerachByStatus] = useState('');
  const [notifConfigList, setNotifConfigList] = useState([]);
  const [showModifybtn, setShowModifybtn] = useState(false);
  const [checkBox,setCheckBox ]=useState(0);
  const [checkBoxdisabled, setCheckBoxdisabled] = useState(true);
  const [editableRows, setEditableRows] = useState({});
  const [showAddRow, setShowAddRow] = useState(false);
  const [rowCountString,setRowCountString ]=useState(0);
  const [showSubmitButton, setShowSubmitButton] = useState(false);
  const [submit, setSubmit] = useState(false);
  const [eventArray,setEventArrey] =useState([]);
  const [showSearchData, setShowSearchData] = useState(false);
  // const [checkBoxs, setCheckBoxs] = useState({
  //   0: true, // Checkbox at index 0 is checked by default
  //   1: true, // Checkbox at index 1 is checked by default
  //   // Add more as needed
  // });
  const [checkBoxs, setCheckBoxs] = useState({});
  const [addList, setAddList] = useState([]);
  const [addPartnerIdd, setAddPartnerIdd] = useState('');
 // adding For Add/Modify Operation
 const [jobFlag, setJobFlag] = useState('');
 const toastId = useRef(null);
 const [showAddBtn,setShowAddBtn] =useState(true);
 const [eventIdDB, setEventIdDB] = useState('');
 const [page, setPage] = useState(1);
 const [id, setId] = useState('');
 const tableRef = useRef(null);
 let userName = process.env.REACT_APP_USERNAME;
 let password = process.env.REACT_APP_PASSWORD;
 console.log("partnerId::::::::::",partnerId)
       useEffect(() => {
         dropdown(); // Fetch data when the component mounts
       },[]);
  useEffect(() => {
    const fetchEventOptions = async (configId) => {
      try {
        const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_EVENTDESC;
        console.log(apiUrl, "apiURL???????????????????");
        const response = await axios.post(apiUrl, {
          userName,
          password,
          partnerLoginId,
          localeVar,
        });
        console.log(response.data);
        const respopnseData = response.data;
        setEventOptions(respopnseData.searchByEventId);
        console.log(respopnseData.searchByEventId);
      } catch (error) {
        console.error("Error fetching event options", error);
      }
    };

    fetchEventOptions();
  }, []);

  useEffect(() => {
      console.log("API URL:", window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_POP_UP);
      console.log("partnerLoginId:", partnerLoginId);
      console.log("partnerId:", partnerId);
      console.log("localeVar:", localeVar);
      
      setId(configId)
      
      
        fetchData(configId)
      
  }, [open]);


  const fetchData = async (configId) => {
   // alert(configId);
    //console.log("endRecord:::::",endRecord);
      try {
        // Fetch data from API
        const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_POP_UP;
        console.log("apiUrl::::",apiUrl);
        const response = await axios.post(apiUrl, {
          userName,
          password,
          partnerLoginId:configId,
          partnerId:configId,
          localeVar,
          eventId,
          serachByStatus,
        });
        const responseData = response.data;
        console.log("REsponse Data:::::",responseData);
        console.log(responseData.cnArrayList,"cnArrayList:::::");
      //  if(responseData.responseCode==="00"){
          // setIsLoading(false);
          if(responseData.cnArrayList!=undefined)
          setNotifConfigList(responseData.cnArrayList);
          else
          setNotifConfigList([])
          setRowCountString(0);
     
    // Check and update `showModifybtn` based on responseData
    updateModifyButtonState(responseData.cnArrayList);
 
 
      } catch (error) {
        console.error("An error occurred:", error);
      }
    };
    
    const dropdown = async ()=>{
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_EVENTDESC;
      const response = await axios.post(apiUrl, {
          userName,
          password,
          partnerLoginId,
          localeVar
    
      });
      const responseDropDown = response.data;
      setEventArrey(responseDropDown.searchByEventId);
      setEventIdDB(responseDropDown.eventIdDB);
      console.log(responseDropDown.searchByEventId);
     }
    const updateModifyButtonState = (cnArrayList) => {
      // Use a useEffect or a separate function to ensure jobFlag is up-to-date
      if (cnArrayList.length > 0 && jobFlag ==! "I") {
        setShowModifybtn(true);
      } else {
        setShowModifybtn(false);
      }
    };
    
    const handleCheckboxSelfAlert = (index, isChecked, field) => {
      console.log("isChecked#############",isChecked);
      const value=isChecked ? 'Y' : 'N'
      handleInputChange(index,value ,field);
    };

        const handleInputChange = (index, value,field) => {
          console.log("INDEX////////////////", index);
          const updatedList = notifConfigList.map((item, i) => {
            if (i === index) {
              return {
                ...item,
               // otherDistributionList: value,
                [field]: value,
      
              };
            }
            return item;
          });
          setNotifConfigList(updatedList);
          console.log("updatedList====",updatedList);
          
      };

  const firstEventId = eventOptions.length > 0 ? eventOptions[0].eventIdDB : '';
  const addNotificationConfig = async () => {
    setError(" ");
   // setShowpagination(false);
    await fetchData(id);
    setShowSubmitButton(true);
    setShowAddRow(true);
    setShowModifybtn(false);
    setRowCountString(prevCount => prevCount + 1);
    setJobFlag("I");
    setAddList(prevRows => [...prevRows, {
        deliveryMethod: 'E',
      selfAlert:'N',
      eventId: firstEventId, // Set default value for eventId
      childAlertSubscription: 'NA', 
      status: 'A' , 
        otherDistributionList: '',
      }]); // Initialize as an empty string
  };

 
  const handleAddRow = async () => {
   // setShowpagination(false);
   await fetchData(id);
    setShowSubmitButton(true);
    setShowAddRow(true);
    setShowModifybtn(false);
    setRowCountString(prevCount => prevCount + 1);
    setJobFlag("I");
    setAddList(prevRows => [...prevRows, {
      deliveryMethod: 'E',
      selfAlert:'N',
      eventId: firstEventId, // Set default value for eventId
      childAlertSubscription: 'NA', 
      status: 'A' , 
        otherDistributionList: '',
        partnerId:distId
      }]); // Initialize as an empty string

setCheckBoxs(prevState => ({
      ...prevState,
      [Object.keys(prevState).length]: true // Set the new checkbox as true (checked)
    }));
    console.log(addList, "Add List///")

    // setShowAddRow(true);
    // setRows([...rows, newRow]);
    // setNewRow({
    //   eventId: eventOptions.length > 0 ? eventOptions[0].eventIdDB : "",
    //   deliveryMethod: "E",
    //   selfAlert: false,
    //   otherDistributionList: "",
    //   childAlertSubscription: "NA",
    //   status: "A",
    // });
    // setFlag(true);
  };

  const checkvalueSelfArlet = (index, isChecked) => {
    const value = isChecked ? 'Y' : 'N';
    handleAdd(index, 'selfAlert', value);
    console.log("selfAlert=====",value)
  };
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
    setShowSearchData(true);
    setError('');
    if (tableRef.current) {
      tableRef.current.scrollTop = 0;
    }
    setCheckBox('');
    // setCheckBoxs('')
    // fetchData();
  };
    
  const handleCheckboxChange = (index, checked) => {
    setCheckBox(prev => ({
      ...prev,
      [index]: checked
    }));
  };
  const handleCheckboxChanges = (index, checked) => {
    setCheckBoxs(prev => ({
      ...prev,
      [index]: checked
    }));
  };
 //adding into list
 const handleAdd = (index, field, value) => {
  const newRows = [...addList];
  newRows[index][field] = value;
  setAddList(newRows);
  console.log("newRows*******************",newRows);
};


const Modify = () => {
  setJobFlag("U");
  // setShowpagination(false);
  setError('');
  // Get selected rows (those with a checked checkbox)
  const ModifyselectedRows = Object.keys(checkBox).filter(index => checkBox[index]);
   setSelectedRows(ModifyselectedRows);

  console.log("selectedRows====", selectedRows);
  // Validation: check if there are no selected rows
  if (ModifyselectedRows.length === 0) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('6099'));
    }
    return; // Exit the function early if no rows are selected
  }else{
  // Update other state variables
  setShowSubmitButton(true);
  setShowModifybtn(false);
  setShowAddBtn(false);
  setCheckBoxdisabled(false);
  // Set editable rows for selected rows
  ModifyselectedRows.forEach(index => {
    setEditableRows(prevRows => ({
      ...prevRows,
      [index]: true
    }));
  });
  console.log("notifConfigList", notifConfigList);
  console.log("Editable Rows...", editableRows)
  }
};
const Update = async () => {
    
  if(jobFlag === 'U'){
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_ADD;
      const response = await axios.post(apiUrl, {
        userName,
        password,
        localeVar,
        partnerLoginId,
        partnerId,
        jobFlag,
        rowCountString,
       notifConfigList
    });
    const responseModifyData = response.data;
    console.log('responseModifyData::::::', responseModifyData);
    setError(responseModifyData.errorMsg);
    console.log('ErrorMsg::::::', error);
    fetchData(id);
    if(responseModifyData.errorMsg ==="Modified successfully."){
      setShowSubmitButton(false);
      // setShowpagination(true);
    }
    setShowSubmitButton(false);
    setRowCountString(0);
    setEditableRows(false);
    setCheckBoxdisabled(true);
    setShowAddBtn(true);
    setShowModifybtn(true);

    
  


  }else if(jobFlag === 'I'){
      try {
        // Fetch data from API
        const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_ADD;
        const response = await axios.post(apiUrl, {
          userName,
          password,
          localeVar,
          partnerLoginId,
          partnerId,
          jobFlag,
          rowCountString,
          addList,
        });

        const responseAddData = response.data;
        setError(responseAddData.errorMsg);
        console.log('ErrorMsg::::::', error);
       console.log(responseAddData,"Response Add data...")

      // if(addPartnerIdd===''){
      //   toast.error("Please enter PartnerId");
      //   setShowSubmitButton(true);
      // }

    //   else if (addEventId==='' ){

    //   //    if(!toast.isActive(toastId.current) )  {
    //   //    toastId.current = toast.error(t('2480_004')); 
    //   //  setShowSubmitButton(true);
    //   //  }
       
    // }
      
     if(responseAddData.errorMsg ==="Added Successfully."){
     // endRecord=totalRecords+rowCountString;
      //console.log('END RECORD...', endRecord);
      //console.log('ROW COUNT STRINGGGGGG', rowCountString);
     await fetchData(id);
      setShowAddRow(false);
      //setShowpagination(true);
      // Reset the row count after submission
      setRowCountString(0);
      setShowModifybtn(true);
      setShowSubmitButton(false);
    }else{
      setShowSubmitButton(true);
    }

        console.log('Response Data ADD:', error);
    
      } catch (error) {
        console.error('An error occurred:', error);
        // Handle error, e.g., display error message to the user
      }
    }
  };

  const handleClose = () => {
    setRows([]);
    setSelectedRows([]);
    setEditableRows([]);
    setSubmittedData([]);
    setFlag(false);
    setOpen(false);
    setShowAddRow(false);
    setShowModifybtn(false);
  };

  const handleOpen = () => {
    setCheckBoxdisabled(true);
    setShowAddBtn(true);
    setTimeout(() => {
    setShowModifybtn(true);
    }, 120)
    setShowSubmitButton(false);
    if (eventOptions.length > 0) {
      setNewRow({
        eventId: eventOptions[0].eventIdDB || "",
        deliveryMethod: "E",
        selfAlert: false,
        otherDistributionList: "",
        childAlertSubscription: "NA",
        status: "A",
        // partnerId:""
      });
    }
    setOpen(true);
  };

  const Submit = ()=>{
   // Update();
     //setShowSubmitButton(false);
     setEditableRows([]);
     setSelectedRows([]);
     setCheckBox("");
     setOpen(false)
     //setCheckBoxs("");
   }
  

  return (
    <div>
   <span className="underline-link" onClick={handleOpen}>
      <ArrowRight className="animated-arrow" style={{color:'#39f'}} /> <span>{t('242482')} </span>
        {/* Click here to Configure Notifications */}
      </span>
      <Dialog open={open} onClose={handleClose} maxWidth="lg" fullWidth>
        <DialogTitle className={"headerTxt"} align="center">
        {t("251658")}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>

          {notifConfigList.length > 0 ? (
 <table border={0} width="100%"cellPadding={0}>
 <tr class="">
 {/* <td width="55%" className={"strongerTxtLable"} align="left">{t('059')} : {totalRecords}</td> */}
  {/* <td width="45%" className={"strongerTxtLable"} align="right">{t('060')} : {startRecord}-{endRecord} </td>  */}
</tr>
</table>
 ) : (
  <table border={0} width="100%"cellPadding={0}>
  <tr class="darkgray">
 </tr>
 </table>

 )}
{/* <Table border={0} cellPadding={1} className="cellSpacing" width="100%" bordercolor="red"> */}








<TableContainer 
component={Paper}
 className={'shadowTable configTable'} style={{ maxHeight: '300px', marginTop: '5px', overflowX: 'hidden' }}>
<Table size="small" className={''} stickyHeader aria-label="sticky table"> 
<TableHead>
    {/* <TableRow>
      <TableCell colSpan={8}></TableCell>
    </TableRow> */}
    <TableRow className="darkgray">
      <TableCell className="whiteboldtext" align="center" />
      {/* <TableCell className="whiteboldtext" align="center">{t('034')}</TableCell> */}
      <TableCell className="whiteboldtext" align="center">{t('000')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('838')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('839')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('840')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('841')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('0162')}</TableCell>
    </TableRow>
  </TableHead>   
  <TableBody>

{notifConfigList.length > 0 || submit || showSubmitButton ? <></> :

<TableRow align="center">
  <TableCell colspan="9" style={{ color: 'red' }} class="redTxt" align="center">
    {/*Please provide search criteria.*/}
    {t('config')}
  </TableCell>
</TableRow>

}
{notifConfigList.length === 0 && submit && !showSubmitButton ?
                                <TableRow align="center">
                                  <TableCell colspan="9" class="redTxt" style={{ color: 'red' }} align="center">
                                    {/*No data found for the given search criteria.*/}
                                    {t('config')}
                                  </TableCell>
                                </TableRow>
                                : <></>
                              }

  
{notifConfigList.length > 0 ? (
    notifConfigList.map((item, index) => (
        <TableRow key={index} className={index % 2 === 0 ? "lightgreen" : "lightyellow"}>
            <TableCell className="smallerTxt" align="center" style={{padding: '0'}}>

            <Checkbox //checked={editableRows[index] || false}
            checked={checkBox[index] || false}
            disabled={checkBoxdisabled ? false : true}
            onChange={e => handleCheckboxChange(index, e.target.checked)}/>
            </TableCell>


            {/* <TableCell className="smallerTxt" align="center">{item.partnerId}</TableCell> */}
            <TableCell className="smallerTxt" align="center">{item.eventDesc}</TableCell>
            <TableCell className="smallerTxt" align="center">{item.deliveryMethod === 'E' ? "E-mail" : "SMS"}</TableCell>
            <TableCell className="smallerTxt" align="center" style={{padding: '0'}}>
                {editableRows[index] ? (
                    <Checkbox
                    checked={item.selfAlert === 'Y'}
                    onChange={e => handleCheckboxSelfAlert(index, e.target.checked,'selfAlert')}/>
                ) : (
                    item.selfAlert === 'Y' ? t('2616020') : t('2616021')
                )}
            </TableCell>
            <TableCell className="smallerTxt" align="center" style={{overflowWrap:"anywhere"}}>
                                {editableRows[index] ? (
                                    <textarea 
                                    className={'textBoxSmall'}
                                    style={{height:'auto'}}
                                    value={item.otherDistributionList}
                                    onChange={e => handleInputChange(index, e.target.value, 'otherDistributionList')}
                                    />
                                ) : (
                                   item.otherDistributionList
                                )}
            </TableCell>
            <TableCell className="smallerTxt" align="center">
                {editableRows[index] ? (
                    <Select  value={item.childAlertSubscription === 'C' ? "C" : "NA"} className={'selected_dropdown'}
                    onChange={e => handleInputChange(index, e.target.value, 'childAlertSubscription')}>
                    <MenuItem value="NA">{t('842')}</MenuItem>
                    <MenuItem value="C">{t('843')}</MenuItem>
                    </Select>
                ) : (
                    item.childAlertSubscription === 'C' ?  t('843') : t('842')
                )}
            </TableCell>
            <TableCell className="smallerTxt" align="center">
                {editableRows[index] ? (
                    <Select  value={item.status === 'A' ?"A":"I"} className={'selected_dropdown'}
                    onChange={e => handleInputChange(index, e.target.value, 'status')}>
                       <MenuItem value="A">{t('057')}</MenuItem>
                      <MenuItem value="I">{t('058')}</MenuItem>
                    </Select>
                ) : (
                    item.status === 'A' ? t('2616014'): t('2616015')
                )}
            </TableCell>
        </TableRow>
    ))
 ) :<></>}




{showAddRow && (
  <>
    {[...Array(rowCountString)].map((_, index) => (
      <TableRow className="lightyellow" key={`addRow-${index}`}>
        <TableCell className="smallerTxt" align="center" style={{padding: '0'}}>
        <Checkbox name={`chkBox-${index}`} id={`chkBox-${index}`} 
            // checked={checkBox[index]}
            checked={checkBoxs[index] || false} 
            onChange={e => handleCheckboxChanges(index, e.target.checked)}/>
        </TableCell>
       
        <TableCell align="center" colSpan={0}>
          <Select name={`eventIdAdd-${index}`}
          style={{width:'195px'}}
          value={addList[index]?.eventId || (eventArray.length > 0 ? eventArray[0].eventIdDB : '')} // Set default value
           onChange={e => handleAdd(index, 'eventId', e.target.value)} className={'selected_dropdown'}>
          {/* onChange={e => setEventSearch(e.target.value)}> */}
            {/* <option value="" selected="selected">Select</option> */}
            {eventArray.map(event => (
              <MenuItem key={event.eventIdDB} value={event.eventIdDB}>{event.eventDescription}</MenuItem>
            ))}
          </Select>
        </TableCell>
        <TableCell align="center" colSpan={0}>
          <Select name={`deliveryMethodAdd-${index}`} id={`deliveryMethodAdd-${index}`}
           value={addList[index]?.deliveryMethod || 'E'} // Set default value to 'E'
            onChange={e => handleAdd(index, 'deliveryMethod', e.target.value)} className={'selected_dropdown'}>
           {/* onChange={e => setDeliveryMethodAdd(e.target.value)}> */}
            <MenuItem value="E">Email</MenuItem>
            <MenuItem value="S">SMS</MenuItem>
          </Select>
        </TableCell>
        <TableCell align="center" colSpan={0} style={{padding: '0'}}>

        <Checkbox id={`selfAlertAdd-${index}`} name={`selfAlertAdd-${index}` }
        checked={addList[index]?.selfAlert === 'Y'}
        onChange={e => checkvalueSelfArlet(index, e.target.checked)}/>
        </TableCell>
        
        <TableCell align="center" colSpan={0}>
          <textarea style={{height:'auto'}}
        name={`otherDistributionListAdd-${index}`} className="textBoxSmall" id={`otherDistributionListAdd-${index}`} rows={2} cols={20} maxLength={512} 
          onChange={e => handleAdd(index, 'otherDistributionList', e.target.value)}/>
            
          {/* onChange={e => setOtherDistributionList(e.target.value)}/> */}
        </TableCell>
        <TableCell align="center" colSpan={0}>
          <Select name={`childAlertSubscriptionAdd-${index}`} id={`childAlertSubscriptionAdd-${index}`} 
          value={addList[index]?.childAlertSubscription || 'NA'} // Set default value to 'NA'
          onChange={e => handleAdd(index, 'childAlertSubscription', e.target.value)} className={'selected_dropdown'}>

           {/* onChange={e => setChildAlertSubscriptionAdd(e.target.value)}> */}
            <MenuItem value="NA">{t('842')}</MenuItem>
            <MenuItem value="C">{t('843')}</MenuItem>
          </Select>
        </TableCell>
        <TableCell align="center">
          <Select name={`serachByStatusAdd-${index}`} id={`serachByStatusAdd-${index}`} 
           value={addList[index]?.status || 'A'} // Set default value to 'A'
          // onChange={e => setSearchByStatus(e.target.value)} >
          onChange={e => handleAdd(index, 'status', e.target.value)} className={'selected_dropdown'}>
            <MenuItem value="A" selected>{t('057')}</MenuItem>
            <MenuItem value="I">{t('058')}</MenuItem>
          </Select>
        </TableCell>
      </TableRow>
    ))}
  </>
)} 

</TableBody>
  </Table>
  </TableContainer>
  </DialogContentText>
  </DialogContent>

        <DialogActions style={{ marginRight: "18.5px", marginBottom: "15px" }}>





        {/* {showAddBtn && ( */}
   {/* <Button id="submitImg" onClick={() => addNotificationConfig()} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<AddCardRounded />}> */}
        {/* Add{t('10')} */}
      {/* </Button> */}
    {/* )} */}
    {showAddBtn && (
          <Button
            onClick={handleAddRow}
            className={"hoverEffectButton"}
            size="small"
            variant="contained"
            endIcon={<AddCardRounded />}
          >
           {t(10)}
          </Button>
 )}
      {showModifybtn && notifConfigList.length !== 0 && (
      <Button id="submitImg" onClick={() =>Modify()} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<AddCardRounded />}>
      {/* Modify */}{t('11')}
    </Button>
    // <input type="button" id="submitImg" Value="Modify" className="inputButton"onClick={() =>Modify()}/>
    )}





{showSubmitButton && (
      <Button  id="submitImg" className={'hoverEffectButton'} onClick={() =>Submit()} size="small" variant="contained" endIcon={<SendIcon />}>
      {/* Submit */}{t('242409')}
    </Button>
    // <input type="button" id="submitImg" Value="Submit" className="inputButton"onClick={() =>Submit()}/>
    )}




          {/* {showSubmitButton && showAddBtn (
            <Button
              onClick={handleSubmit}
              className={"hoverEffectButton"}
              size="small"
              variant="contained"
              endIcon={<SendIcon />}
            >
              {t(2616019)}
            </Button>
          )} */}
          <Button
            onClick={handleClose}
            className={"hoverEffectButton"}
            size="small"
            variant="contained"
            endIcon={<CancelRounded />}
          >
            {t(6810)}
          </Button>
        </DialogActions>
      </Dialog>

      <ToastContainer
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
    </div>
  );
}

export default ConfigurationNotificationPopup;
