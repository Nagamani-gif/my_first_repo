import React, { createContext, useState } from 'react';
import i18n from './i18n'; // Ensure the path is correct

export const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en'); // default language

  const changeLanguage = (lng) => {
    setLanguage(lng);
    i18n.changeLanguage(lng); // Ensure i18n also changes the language
  };

  return (
    <LanguageContext.Provider value={{ language, changeLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};
