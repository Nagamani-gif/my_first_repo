/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable react/jsx-no-comment-textnodes */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect } from 'react';
// eslint-disable-next-line no-unused-vars
import { Footer, Header,JasperLeftMenu,JasperTopMenu,LeftBgImage,PaymentManagerHeading,SubDistMenu } from './PageComponents'
import TopMenu from './TopMenu'
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { FindInPageRounded, KeyboardReturn } from '@mui/icons-material';
import { Box, Button, Grid, MenuItem, Paper, Select, Table, TableCell, TableContainer, TableHead, TableRow, Typography,Pagination,Tabs,Tab, TextField } from '@mui/material';
import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CircularProgress } from '@mui/joy';


const Subdistributors = () => {
 // sessionStorage.setItem("selectedIndex", 4);
  sessionStorage.setItem("selectedLink", "d_subdistributors");

 // PAGINATION
 const [page, setPage] = useState(1);
 const [perpage, setPerPage] = useState(10);
 const [totalRecordsSatisfied, setTotalRecordsSatisfied] = useState(0);

 const styleObj = {
  minHeight: '27px',
  fontSize: '10px',
  padding: '7px 10px',
  maxHeight: '27px',
  margin: '10px 5px 5px 5px',
  
  borderRadius: '5px',
  color: '#1976d2',
  // boxShadow: '0px 6px 15px rgb(25 118 210)',
  // scale: '0.9',
  transition: '0.5s',
  opacity: '1',
  background: '#fff',
  color: '#3399FF',
  border: '1px solid #1976d2',
  textTransform: 'capitalize',
  "&:hover": {
    background: '#3399FF',
    color: '#fff',
    border: '1px solid #3399FF',
    borderRadius: '5px',
  //   boxShadow: '0 4px 6px -1px rgba(0, 0, 0, .1), 0 2px 4px -1px rgb(0 0 0 / 75%)',
  //   transition: '0.5s',
  //   scale: '1',
  },
 "&.Mui-selected": {
  color: '#fff',
  background: '#3399FF',border:' 1px solid #3399FF',
}
};


  const {t}=useTranslation();
const localeVar=i18n.language;
    const exampleData = JSON.parse(localStorage.getItem("userData")) 
    const partnerLoginId = exampleData.LOGIN_ID;
    const distComapnyName=exampleData.COMPANY_NAME;

    const [items, setItems] = useState([]);
    const [filterItems, setfilterItems] = useState([]);
    const [name, setName] = useState('');
    const [totalRecords, setTotalRecords] = useState(0);
    const [isLoading, setIsLoading]=useState(false);
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
    let startRecord=0;
    let endRecord =10;



    const fetchChannels=async () => {
      //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
      const apiUrl3 = window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
      console.log(apiUrl3);
      const response3 = await axios.post(apiUrl3, {
        userName,
        password,
        localeVar,
        channelTransAl: "",
      });
      // const[channels]=response.data;
   
      localStorage.setItem("channels", JSON.stringify(response3.data.channels));
      //console.log(JSON.stringify(response.data.channels));
      //  setsalesData(JSON.stringify(response.data.channels));
    }

useEffect(()=>{
      // Set the browser title
      document.title = t('2472_009');
    }, []);

useEffect(()=>{
  fetchChannels();
})
    



    const fetchData = async () => {
      localStorage.removeItem('channels');
      //alert(startRecord);
      
    try {
        // Fetch data from API
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_SUBDISTIBUTORS_URL;
      //startRecord=startRecord-1;
        const response = await axios.post(apiUrl, {
            userName,
            password,
            partnerLoginId,
           // subdistId:name,
           subdistId: encodeURIComponent(name.trim()),
            startPageNo:startRecord-1,
            endPageNo:endRecord,
            localeVar
        }
      );
        const responseData = response.data;
        setIsLoading(false);
        if(response.data.responseDescription === "SUCCESS"){
          setIsLoading(true);
        // Set data from response
        console.log('responseData:', responseData);
        console.log('result.distButtorsMainArray:', responseData.distButtorsMainArray);
        setItems(responseData.distButtorsMainArray);
        setfilterItems(responseData.distButtorsMainArray.chidDistributors);
        setTotalRecords(responseData.totalRecords);
       // setRecordsFound(responseData.recordsFound);
        }
    } catch (error) {
        console.error("An error occurred:", error);
        // Handle error, e.g., display error message to the user
    }
};

 startRecord = (page - 1) * perpage + 1;
 endRecord =  totalRecords > 0 
 ? Math.min(startRecord + perpage - 1, totalRecords) 
 : (page === 1 ? 10 : page * perpage);
const totalPages = Math.ceil(totalRecords / perpage);


    const handleChangePage = (event, newPage) => {
      setPage(newPage);
     // fetchData();
    };

    useEffect(() => {
      const loadData = async () => {
        await fetchData(); // Fetch data when the component mounts or dependencies change
      };
  
      loadData();
    }, [startRecord, endRecord]); // Dependencies array ensures effect runs when page or totalRecords change
  


    
  const navigate = useNavigate();
    const handleReturn = () => {
      // Go back to the previous page
      navigate(-1);
    }
    
    const distclick =(distId)=>{
      navigate('/profile', { state: {distId} })
    }


const handleSearch = async () => {
  try {
    startRecord=0;
    endRecord =10;
    fetchData();
    setPage(1);
  } catch (error) {
    console.error("An error occurred:", error);
  } 
};

return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
    <TopMenu menuLink= {localeVar==='en'?"Subdistributors":"Subdistribuidores"}/>
  </tr>

  <tr>
   <LeftBgImage />

<td valign="top">
<title>Prepaid Movistar - View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
     <tr valign="top">
       <td width="80%">
      
    <JasperTopMenu />
    <div className={'mL8 input_boxess'}>
    
    <Box
              className={""}
              sx={{ flexGrow: 1}}
            >
              {/* <Typography
                className={"headingText"}
                sx={{ fontSize: "9pt", fontWeight: "bold" }}
                variant="body1"
                component="h2"
              >
                {t('080')}
              </Typography> */}

              {/* <Grid
              container
              spacing={2}
              sx={{ width: 1 }}
              className={""}
              style={{
                justifyContent: "center",
                marginTop: "-5px",
                marginLeft: "0px",
                paddingInline: "0px",
              }}>
            <Grid item xs={6} style={{paddingLeft: '0'}}>
              <span className={"labelText"}>{t('2480_003')}:<b> {partnerLoginId}</b></span>
              
            </Grid>
            <Grid item xs={6} align="right">
            <span className={"labelText"}>{t('082')}: 	<b>{distComapnyName}</b></span>

            </Grid>
              </Grid> */}
      {/* <Box style={{display:'flex', gap:'10%', paddingTop:'10px'}}>
              <p className="strongerTxtLable">{t('069')}: <b>{partnerLoginId}</b></p>
              <p className="strongerTxtLable">{t('082')}: <b>{distComapnyName}</b></p>
            </Box> */}
            <br />
             <Grid style={{marginTop: '0px'}}>
             {/* <span className={"labelText"}>{t('081')}&nbsp;&nbsp; */}
                  <TextField size="12" type="text" maxLength={25} label={
                                    <span>
                                      {`${t('081')}`}
                                    </span>}  value={name} onChange={e => setName(e.target.value)} style={{maxWidth:'200px'}} className={'sampleInput mb5'} />	
                  {/* <button className="inputButton" type="submit" onClick={handleSearch}>Search</button> */}
                  <Button style={{marginLeft: '15px', marginTop:'3px'}} className={'hoverEffectButton'} size="small" onClick={()=>{handleSearch()}} variant="contained" endIcon={<FindInPageRounded />}>
        {t('043')}
      </Button>
             </Grid>
              </Box>
             <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "6px",
                  marginBottom: '5px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                  {/* <span className={"strongerTxtLable"}>
                          {t('032')} : {totalRecords}
                  </span> */}
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               
             
                <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
                   
              </Grid>
    <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow className={'darkgray subdistributor_table'}>
                    <TableCell >{t('083')}</TableCell>
                <TableCell >{t('084')}</TableCell>
                <TableCell >{t('074')}</TableCell>
                <TableCell >{t('031')}</TableCell>
                <TableCell >{t('061')}</TableCell>
                <TableCell >{t('073')}</TableCell>
                <TableCell >{t('009')} (MXN)</TableCell>
                <TableCell >{t('055')}</TableCell>
                <TableCell >{t('063')}</TableCell>	
                    </TableRow>
                  
                  </TableHead>
              
              { isLoading &&(
              items.length > 0  && totalRecords > 0? (
              items.map((item, index) =>  (
              <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} >
              <TableCell className="arlCtrBlk"  align="center" style={{padding:'0px auto'}}>
               <span style={{color:"#3399FF", cursor:'pointer'}} onClick={()=>{distclick(item.partnerId)}}>{item.partnerId}</span></TableCell>
                <TableCell width="20%" style={{padding:'0'}} className="arlCtrBlk">&nbsp;{item.distributorTypeDesc}&nbsp;</TableCell>
                <TableCell width="16%" align="center" style={{padding:'5px'}}>
                <Select style={{padding: '0px', borderRadius: '4px'}} value={item.chidDistributors[0]} className="selected_dropdown">
                {item.chidDistributors.map((option, index) => ( 
                <MenuItem key={index} value={option}>{option}</MenuItem>
                 ))}
                </Select>
                </TableCell>	
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.partnerCompName}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">{item.partnerFirstName} {item.partnerLastName}</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.locationDesc}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.accntBal}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.status}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.sclClientCode}&nbsp;</TableCell>	
                    </TableRow>)
                )  
                    
              ) : (
                    <TableRow><TableCell colSpan={9} align="center"style={{color: 'red'}}className="redTxt">
                            {t('085')}
                          </TableCell>
                    </TableRow> 
              )

            
          )}
          {!isLoading && <><TableRow><TableCell  align="center" colSpan={9}><div className={'spinnerDiv'}> {t("Processing...")}  <CircularProgress size="sm" /></div></TableCell></TableRow></>}
                
            
                  </Table>
                </TableContainer>
                <br/>
                                                      {items.length> 0 ? <Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }

                <Button className={'hoverEffectButton'} style={{marginTop: '15px', float: 'right'}} onClick={handleReturn} size="small" variant="contained" endIcon={<KeyboardReturn />}>
                    {t('242410')}
                </Button>
                </div>
                {/* <input type="button"defaultValue="Return" className="inputButton" onClick={handleReturn}/> */}


    </td></tr>
    <tr>&nbsp;</tr>
</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>

</td></tr>
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
)
};

export default Subdistributors;
