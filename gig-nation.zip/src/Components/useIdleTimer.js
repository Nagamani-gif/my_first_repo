// useIdleTimer.js
import { useEffect, useRef } from 'react';

const useIdleTimer = (onIdle, timeout = 600000, isLoggedIn = true) => {
  const timerRef = useRef(null);

  const resetTimer = () => {
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(onIdle, timeout);
  };

  useEffect(() => {
    if (!isLoggedIn) return;
    const events = ['mousemove', 'keydown', 'click', 'scroll'];

    const handleEvent = () => {
      resetTimer();
    };

    events.forEach(event => {
      window.addEventListener(event, handleEvent);
    });

    resetTimer();

    return () => {
      clearTimeout(timerRef.current);
      events.forEach(event => {
        window.removeEventListener(event, handleEvent);
      });
    };
  }, [timeout, onIdle]);

  return null;
};

export default useIdleTimer;
