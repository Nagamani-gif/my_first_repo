
/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import { Header, Footer, PaymentManagerHeading, LeftBgImage } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, Menu,CircularProgress, FormControl,Grid, InputLabel, MenuItem, Pagination, Paper,Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField ,Dialog, DialogTitle, DialogContent, IconButton} from "@mui/material";
import React, { useState, useEffect, useCallback,useRef } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CancelRounded, CloudDownload, KeyboardReturn } from "@mui/icons-material";
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import ExcelJS from 'exceljs';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import {  toast, ToastContainer } from "react-toastify";
import dayjs from 'dayjs';
import MassiveDetails from "./MassiveDetails";



const MassiveTransfers = () => {
  sessionStorage.setItem("selectedLink", "e_transactions");

  const { t } = useTranslation();
  const localeVar = i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData"))
  const [partnerLoginId, setPartnerLoginId] = useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);

  const now = dayjs();  
  const midnightToday = dayjs().startOf('day');
  const [startDateTime, setStartDateTime] = useState(midnightToday);
  const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
  
  const [endDateTime, setEndDateTime] = useState(now);
  const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));

   const [anchorEl, setAnchorEl] = useState();
   const [userType, setUserType] = useState(" ");
   const closeTimeoutRef = useRef(null);
   const toastId = useRef(null);
 const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();


const [isDialogOpen, setIsDialogOpen] = useState(false);
const [selectedFileId,setSelectedFileId] = useState('');
const [selectedInterfaceType,setSelectedInterfaceType] = useState('');
  const [apply,setApply] =useState(false);

let reportDays = process.env.REACT_APP_ReportDays;

  console.log("totalRecords++++++++++++", totalRecords)
  const handleChangePage = (event, newPage) => {

 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       submitted
     });
 
  if (!isValid) {
  setSubmitted(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmitted(false);
    }
return false;

}

    setPage(newPage);
  };


  useEffect(() => {
    if (!submitted) return;
      fetchData();
  }, [submitted, page]);




  const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
  

const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
   
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      

    }
    return false;
  }

  return true;
};



 const handleEndDateTimeChange = (newValue) => {
  setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };
    const handleStartDateTimeChange = (newValue) => {
      setApply(false);
      setStartDateTime(newValue); 
     const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
     setStartDate(formattedDateTime);
      console.log("startDate::::::",newValue)
       console.log("startDate::::::",formattedDateTime)
    };


      console.log("startDate::::::",startDate)

    const handleSubmit = () => {
       try {
          // Validation logic
        const isValid = validateDateRange({
                      startDateTime,
                      endDateTime,
                      reportDays,
                      toast,
                      toastId,
                      t
                    });
                
if (!isValid){
  setApply(false);
  return;
} 

            startRecord=0;
            endRecord=10;
          fetchData(); // Assuming fetchData is an async function 
          setSubmitted(true);  
          setApply(true);
          setPage(1);
   
       } catch (error) {
           console.error("An error occurred:", error);
       }
      // setSubmit(true);
   };

 const clearData = () => {
    setStartDateTime(midnightToday)
    setEndDateTime(now)
    setUserType(" ");
    setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'))
    setEndDate(now.format('DD/MM/YYYY HH:mm:ss'))
  };


const handleUserType = (e) => {
  const value = e.target.value;
  setUserType(value);
};


  var fromDate = '';
    if (startDateTime != null) {
        var d = new Date(startDateTime);
        var month = d.getMonth() + 1;

        var day = d.getDate();
        var year = d.getFullYear();
        var hours = d.getHours();
        var minutes = d.getMinutes();

        // Ensure that hours and minutes are always two digits
        hours = hours < 10 ? '0' + hours : hours;
        minutes = minutes < 10 ? '0' + minutes : minutes;

        // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
        fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
        console.log("StartDate = " + day + "/" + month + "/" + year + " " + hours + ":" + minutes);
    }

    var toDate = '';
    if (endDateTime != null) {
        var d = new Date(endDateTime);
        var month2 = d.getMonth() + 1;
        var hours1 = d.getHours();
        var minutes1 = d.getMinutes();

        // Ensure that hours and minutes are always two digits
        hours1 = hours1 < 10 ? '0' + hours1 : hours1;
        minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;

        toDate = d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1 + ":" + minutes1;
        console.log("EndDate = " + d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1 + ":" + minutes1);
    }

  useEffect(() => {
    // Set the browser title
    document.title = t('2472_018');
  }, []);


   const [recordsFound, setRecordsFound] = useState(0);
   
  

//popup

  const handleOpen = (fileId,inftType) => {
    setSelectedFileId(fileId);
    setSelectedInterfaceType(inftType);
    setIsDialogOpen(true);
  };

  const handleClose1 = () => {
    setIsDialogOpen(false);
    setSelectedFileId(null);
  };





//excel

const handleDownload = async () => {
    const downloadItems = await fetchDataDownload();
     if (!downloadItems || downloadItems.length === 0) return;
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('MassiveTransfer');
    const headingRow1 = worksheet.addRow([localeVar === 'en' ? "Massive Transfers" : "Transferencias Masivas"]);
    const numberOfColumns = 8; // Adjust this to match the number of columns in your table
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    const headingCell = headingRow1.getCell(1);
    headingCell.font = { bold: true };
    headingCell.alignment = { horizontal: 'center' };
    worksheet.addRow([]); 


const summaryRow = worksheet.addRow([]);
summaryRow.getCell(1).value = `${t('032')} : ${totalRecords}`; // Total records
summaryRow.getCell(5).value = ``; // Displayed range + pages

summaryRow.getCell(1).alignment = { horizontal: 'left' };
summaryRow.getCell(5).alignment = { horizontal: 'right' };

// Merge cells for alignment
worksheet.mergeCells(summaryRow.number, 1, summaryRow.number, 4); // Left half
worksheet.mergeCells(summaryRow.number, 5, summaryRow.number, 8); // Right half

// Spacer Row before headers
worksheet.addRow([]);

    const columnHeaders = [
      t('File ID'),
      t('User Type'),
      t('Interface Type'),
      t('Success'),
      t('Template ID'),
      t('File Name'),
      t('Uploaded Date'),
      t('Process Begin Date'),
      t('Rejected'),
      t('Processing Status'),
      t('Failed'),
      t('Process End Date'),
      t('Channel')
      ];
    const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });
    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
        item.fileID,
        t('LOGIN'+item.usertype),
        item.interfaceType,
        item.sucess,
        t('Template'+item.templateID),
        item.fileName,
        item.uploadeddate,
        item.processbegindate,
        item.rejected,
        item.processingstatus==='C'?t('INTFC'):item.processingstatus==='I'?t('INTFI'):"---",
        item.failed,
        item.processendate,
        t('REP'+item.channelID)
      ]);
      dataRow.eachCell(cell => {
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
        cell.alignment = { horizontal: 'center' }; // Center-align the cell content
      });
    });
    worksheet.addRow([]);

    // const emptyRow3 = worksheet.addRow([]);
    // emptyRow3.hidden = true; // Hide the empty row
    // const endOfReportText = t('0171'); // Replace with your translated text
    // const endOfReportRow = worksheet.addRow([endOfReportText]);
  
    // worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
    // // Style the "End of Report" cell
    // const endOfReportCell = endOfReportRow.getCell(1);
    // endOfReportCell.font = { italic: true, underline: true, bold: true };
    // endOfReportCell.alignment = { horizontal: 'center' };


  worksheet.addRow([]);
  const endOfReportRow = worksheet.addRow([t('0171')]);
  worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
  const endOfReportCell = endOfReportRow.getCell(1);
  endOfReportCell.font = { italic: true, underline: true, bold: true };
  endOfReportCell.alignment = { horizontal: 'center' };

   worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 50 ? 50 : maxLength; // Optional: cap width to 40
  });

    // Protect the worksheet to make it read-only
    worksheet.protect('yourPassword', {
    selectLockedCells: true,
    selectUnlockedCells: true,
    formatCells: true,
      formatColumns: true,
      formatRows: true,
      insertColumns: false,
      insertRows: false,
      insertHyperlinks: false,
      deleteColumns: false,
      deleteRows: false,
      sort: false,
      autoFilter: false,
      pivotTables: false
    });

    // Generate and download the Excel file
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'MassiveTransfer.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

//for pdf
//for pdf

const handleDownloadPdf = async () => {
  const downloadItems = await fetchDataDownload(); // same data as Excel
   if (!downloadItems || downloadItems.length === 0) return;
  const tableBody = [];

  // Table Headers (first row)
  const headers = [
    t('File ID'),
    t('User Type'),
    t('Interface Type'),
    t('Success'),
    t('Template ID'),
    t('File Name'),
    t('Uploaded Date'),
    t('Process Begin Date'),
    t('Rejected'),
    t('Processing Status'),
    t('Failed'),
    t('Process End Date'),
    t('Channel')
  ];
  tableBody.push(headers.map(header => ({ text: header, style: 'tableHeader' })));

  // Table Rows
  downloadItems.forEach(item => {
    const row = [
      item.fileID,
      t('LOGIN'+item.usertype),
      item.interfaceType,
      item.sucess,
      t('Template'+item.templateID),
      item.fileName,
      item.uploadeddate,
      item.processbegindate,
      item.rejected,
      item.processingstatus==='C'?t('INTFC'):item.processingstatus==='I'?t('INTFI'):"---",
      item.failed,
      item.processendate,
      t('REP'+item.channelID)
    ];
    tableBody.push(row);
  });

  // Content Structure
  const content = [
    {
      text: localeVar === 'en' ? "Massive Transfers" : "Transferencias Masivas",
      style: 'title',
      alignment: 'center',
      margin: [0, 0, 0, 10]
    },
     {
  columns: [
    {
      text: `${t('032')} : ${totalRecords}`,
      alignment: 'left',
      fontSize: 8
    },
  ],
  margin: [0, 0, 0, 5]
},
    {
      style: 'tableExample',
      table: {
        headerRows: 1,
        widths: new Array(50).fill(50),
        body: tableBody
      },
      layout: {
        fillColor: function (rowIndex) {
          return rowIndex === 0 ? '#3399FF' : null;
        }
      }
    },
    {
      text: t('0171'),
      style: 'endText',
      alignment: 'center',
      margin: [0, 10, 0, 0]
    }
  ];

  // PDF Definition
  const docDefinition = {
    content: content,
    styles: {
      title: { fontSize: 16, bold: true },
      subheader: { fontSize: 10, bold: true },
      tableExample: { margin: [0, 5, 0, 15] },
      tableHeader: { bold: true, fontSize: 8, color: '#fff' },
      endText: { italics: true, bold: true, decoration: 'underline', fontSize: 10 }
    },
    pageOrientation: 'landscape',
    defaultStyle: {
      fontSize: 8
    }
  };

  pdfMake.createPdf(docDefinition).download('MassiveTransfer.pdf');
};



const formatDateTime = (val) => {
    if (!val || val.trim() === "") return "";

  const parts = val.split(" ");
  if (parts.length < 2) return val;

  const [day, month, year] = parts[0].split("/");
  const [hh = "00", mm = "00", ss = "00"] = parts[1].split(":");

  const dd = day.padStart(2, "0");
  const mmn = month.padStart(2, "0");
  const yyyy = year;
  const hh24 = hh.padStart(2, "0");
  const min = mm.padStart(2, "0");
  const sec = ss.padStart(2, "0");
  return `="${dd}/${mmn}/${yyyy} ${hh24}:${min}:${sec}"`;
};



const handleDownloadCsv = async () => {
  
  const downloadItems = await fetchDataDownload(); // same as in PDF
 if (!downloadItems || downloadItems.length === 0) return;
  const headers = [
    t('File ID'),
    t('User Type'),
    t('Interface Type'),
    t('Success'),
    t('Template ID'),
    t('File Name'),
    t('Uploaded Date'),
    t('Process Begin Date'),
    t('Rejected'),
    t('Processing Status'),
    t('Failed'),
    t('Process End Date'),
    t('Channel')
  ];

    const title = localeVar === 'en'
    ? 'Massive Transfers Report'
    : 'Transferencias Masivas';

const summaryLeft = `${t('032')} : ${totalRecords}`;
  const summaryRight = ``;

  // Title centered visually in 27 columns (middle is around column 14)
  const paddedTitleRow = `${Array(5).fill('').join(',')}${title}\n`;

  // Summary: left in column 1, right in column 27
  const paddedSummaryRow = `${summaryLeft},${Array(5).fill('').join(',')},${summaryRight}\n`;

  // Build CSV content
  let csvContent = '';
  csvContent += paddedTitleRow;
  csvContent += paddedSummaryRow;
  csvContent += '\n'; // empty row for spacing
  csvContent += headers.join(',') + '\n';


  // Convert headers and data rows to CSV format
  downloadItems.forEach(item => {
    const row = [
      item.fileID,
      t('LOGIN'+item.usertype),
      item.interfaceType,
      item.sucess,
      t('Template'+item.templateID),
      item.fileName,
     formatDateTime(item.uploadeddate),
      formatDateTime(item.processbegindate),
      item.rejected,
      item.processingstatus==='C'?t('INTFC'):item.processingstatus==='I'?t('INTFI'):"---",
      item.failed,
      formatDateTime(item.processendate),
      t('REP'+item.channelID)
    ];

    const csvRow = row
      .map(field =>
        typeof field === 'string' && field.includes(',') ? `"${field}"` : field
      )
      .join(',');
    csvContent += csvRow + '\n';
  });

const totalColumns = headers.length;
const centerIndex = Math.floor(totalColumns / 2);
const endRow = Array(totalColumns).fill('');
endRow[centerIndex] = t('0171');
csvContent += '\n';
csvContent += endRow.join(',') + '\n';
  

const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;
  // Create a Blob and trigger download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', 'MassiveTransfer.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};



  const fetchData = async () => {
    localStorage.removeItem('channels');
    setIsLoading(true);
    try {
      const apiUrl = window.config.apiUrlJasper+ '/MassiveTransfer';
       //const apiUrl = window.config.jasperUrl + process.env.REACT_APP_MASSIVE;
  

      const response = await axios.post(apiUrl, {
        userName,
        password,
        localval: localeVar,
        piUserType: userType.trim(),
        piIntfType: 'DFT',
        piUserId: partnerLoginId,
        piBegRecNo: startRecord,
        EndRecNo:  endRecord < 10 ? '10' : endRecord,
        piDownload: '',
        piUploadBegDate:startDate,
        piUploadEndDate: endDate,
      });

      console.log("response::::::", response.data);
      //alert()
      // if (response.status === 200) {
        // if(response.data.MassiveTranferDetails!==undefined){
        setItems(response?.data?.MassiveTranferDetails || []);  // <-- Set items here!
        setTotalRecords(response?.data?.MassiveTranferDetails?.[0]?.noofrows || 0);
       setRecordsFound(response?.data?.MassiveTranferDetails?.[0]?.noofrows || 0);
        // }
      // }
    } catch (error) {
      console.error('An error occurred:', error);
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReturn = () => {
    navigate(-1);
  };
  const fetchDataDownload = async () => {

 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       submitted
     });
 
  if (!isValid) {
  setSubmitted(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmitted(false);
    }
return false;

}


    //alert("hi")
    try {
     const apiUrl = window.config.apiUrlJasper+ '/MassiveTransfer';
      //const apiUrl = window.config.jasperUrl + process.env.REACT_APP_MASSIVE;
    
      console.log('API URL:', apiUrl);
      console.log('Partner Login ID:', partnerLoginId);
      const responseDownload = await axios.post(apiUrl, {
        userName,
        password,
        localval: localeVar,
        piUserType: userType,
        piIntfType: 'DFT',
        piUserId: partnerLoginId,
        piBegRecNo: 0,
        EndRecNo: 0,
        piDownload: 'Y',
        piUploadBegDate: startDate,
        piUploadEndDate: endDate,
      });

      console.log('Response download:', responseDownload);
     // alert("sss"+responseDownload.data.MassiveTranferDetails)

      if (!responseDownload.data.MassiveTranferDetails || !responseDownload.data.MassiveTranferDetails) {
        throw new Error('Invalid API response');
      }


      const downloadData = responseDownload.data.MassiveTranferDetails.map(dto => ({
        fileID: dto.fileID,
        transactionID: dto.transactionID,
        usertype: dto.usertype,
        interfaceType: dto.interfaceType,
        sucess: dto.sucess,
        templateID: dto.templateID,
        fileName: dto.fileName,
        uploadeddate: dto.uploadeddate,
        processbegindate: dto.processbegindate,
        rejected: dto.rejected,
        processingstatus: dto.processingstatus,
        failed: dto.failed,
        processendate:dto.processendate,
        channelID: dto.channelID
      }));


      console.log('Download Data:', downloadData);

      return downloadData;
    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };
  
  const RedAsterisk = styled('span')({
    color: 'red',
  });

  const totalPages = Math.ceil(recordsFound / recordsPerPage);

let startRecord = (page - 1) * perpage + 1;
let endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);

  const highlightSelectedLink = (e) => {
    var x = document.querySelector(".subLinkVisited");
    if (x !== null) {
      x.classList.replace("subLinkVisited", "subLink");
    }
    e.target.classList.replace("subLink", "subLinkVisited");
  }


 

  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          <Header />
          <tr height="65px">
            <PaymentManagerHeading />
            <TopMenu menuLink={localeVar === 'en' ? "Massive Transfers" : "Transferencias Masivas"} />
          </tr>

          <tr>
            {/* <td valign="top"style={{ borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)"}}nowrap="nowrap">

    </td> */}
          
              <LeftBgImage />
  
            <td valign="top">
              <title>MassiveTransfer Report</title>
              <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                <tbody>
                  <tr>
                    <td>
                      <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                        <tbody>
                          {/* MIDDLE ROW STARTS */}
                          <tr>
                            <td>
                              <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" height="100%">
                                <tbody>
                                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
                                    <Tabs style={{ minHeight: '35px' }}>
                                      <NavLink
                                        to="/massivetransferssreportp"
                                        onClick={(e) => highlightSelectedLink(e)}
                                        // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
                                        className={({ isActive }) =>
                                          isActive ? 'activeProfilemenu' : `profile_menu 
                                       ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
                                        }
                                      ><Tab label={t('v_massivetransferssreportp')} /></NavLink>
                                    </Tabs>
                                  </Box>
 <div className={'mL8 input_boxess'}>
                                  <tr valign="top">
                                    <td width="80%">
                                      {/* body starts */}

                                     
                                        <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{ marginTop: '5px' }}>


                                          <Box style={{ display: 'flex', gap: '12px', marginTop: '10px' }}>


  <FormControl className={'selected_formcontrol'} sx={{ minWidth: 150 }} size="small">
                                              <InputLabel
                                                id="demo-select-small-label"
                                                sx={{ backgroundColor: '#fff', padding: '0 5px' }}
                                              >
                                                {t('UserType')}
                                              </InputLabel>
                                              <Select
                                                className={'bankSelect'}
                                                labelId="demo-select-small-label"
                                                id="demo-select-small"
                                                value={userType}
                                                label="Select Channel"
                                                onChange={handleUserType}
                                              >
                                                <MenuItem value=" " selected>---</MenuItem>
                                                <MenuItem value="5">{t('Reprint_47')}</MenuItem>
                                                <MenuItem value="6">{t('LOGIN6')}</MenuItem>

                                              </Select>
                                            </FormControl>


<LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
            <DateTimePicker
                  style={{ maxWidth: '120px' }}
                  className={'datePickerrr'}
                  // label="Select Date and Time"
                  value={startDateTime}
                  onChange={handleStartDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
                  label={
                    <span>
                      {`${t('80')}`}
                   <RedAsterisk>*</RedAsterisk>
                    </span>}
                    format="DD/MM/YYYY HH:mm:ss"
                  inputFormat=" " // Keeps the input field empty unless a date is selected
                  renderInput={(params) => <TextField
                    {...params}
                    InputLabelProps={{
                      shrink: true, // Always shrink the label to allow for a floating effect
                    }}
                    fullWidth
                    variant="outlined"
                    sx={{ width: "140px", height: "40px", padding: '20px' }}
                  />}
                />
                
          </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                  style={{ marginTop: '20px', maxWidth: '150px' }}
               className={'datePickerrr mt20'}
               label={
                <span>
                  {`${t('81')}`}
                  <RedAsterisk>*</RedAsterisk>
                </span>}
                format="DD/MM/YYYY HH:mm:ss"
                  value={endDateTime}
                 onChange={handleEndDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
               renderInput={(params) => <TextField {...params} />} />

              </LocalizationProvider>

                                          




                                            {/* </Box>
<Box style={{display:'flex', gap:'20px'}}> */}


                                            <Box style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'flex-end', marginTop: '-16px' }}>
                                              <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
                                                onClick={handleSubmit}
                                              >
                                                {/* {t('028')} */}{t('Apply')}
                                              </Button>

                                              <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
                                              onClick={clearData}
                                              >
                                                {/* {t('003')} */} {t('Reset')}
                                              </Button>
                                       
                                            </Box>
                                          </Box>
                                          {/* </fieldset>
</Box> */}

                                          {/* </Box> */}
                                          <Grid
                                            container
                                            spacing={2}
                                            sx={{ width: 1 }}
                                            className={""}
                                            style={{
                                              justifyContent: "center",
                                              marginTop: "5px",
                                              marginBottom: '0px',
                                              marginLeft: "0px",
                                              borderBottom: "1px solid #fff",
                                              paddingInline: "0px",
                                            }}
                                          >
                                            <Grid
                                              item
                                              xs={4}
                                              sx={{ textAlign: "left", padding: "0 !important" }}
                                            >
                                            </Grid>
                                            <Grid
                                              item
                                              xs={3}
                                              sx={{ textAlign: "center", padding: "0 !important" }}
                                            ></Grid>
                                            <Grid
                                              item
                                              xs={5}
                                              sx={{ textAlign: "right", padding: "0 !important" }}>
                                              {totalRecords > 0 ?
                                                <><span className={"strongerTxtLable"}>
                                                  {t('032')} : {totalRecords}
                                                </span><span className={"strongerTxtLable"}>
                                                    &nbsp; / &nbsp;
                                                    {t('033')} : {startRecord} - {endRecord}
                                                  </span></> :
                                                <></>}
                                            </Grid>
                                          </Grid>
                                          <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                                            <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
                                              <TableHead>
                                                <TableRow className="darkgray">
                                                  <TableCell align="center">{t('File ID')} </TableCell>
                                                  <TableCell align="center">{t('User Type')} </TableCell>
                                                  <TableCell align="center">{t('Interface Type')} </TableCell>
                                                  <TableCell align="center">{t('Success')} </TableCell>
                                                  <TableCell align="center">{t('Template ID')} </TableCell>
                                                  <TableCell align="center">{t('File Name')} </TableCell>
                                                  <TableCell align="center">{t('Uploaded Date')} </TableCell>
                                                  <TableCell align="center">{t('Process Begin Date')} </TableCell>
                                                  <TableCell align="center">{t('Rejected')} </TableCell>
                                                  <TableCell align="center">{t('Processing Status')} </TableCell>
                                                  <TableCell align="center">{t('Failed')} </TableCell>
                                                  <TableCell align="center">{t('Process End Date')} </TableCell>
                                                  <TableCell align="center">{t('Channel')} </TableCell>

                                                </TableRow>
                                              </TableHead>
                                              <TableBody>
                                                {isLoading ? (
                                                  // Show loading spinner while data is being fetched
                                                  <TableRow>
                                                    <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
                                                      {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
                                                    </TableCell>
                                                  </TableRow>
                                                ) : items.length > 0 ? (
                                                  // Show table rows when data is available
                                                  items.map((item, index) => (
                                                    <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>


                                                     <TableCell align="center"style={{color:"#3399FF", cursor:'pointer'}} 
                                                       onClick={() => handleOpen(item.fileID,item.interfaceType)}>{item.fileID}</TableCell>
                                                      {/* <TableCell align="center">&nbsp;{item.fileID}&nbsp;</TableCell> */}
                                                      <TableCell align="center">&nbsp;{t('LOGIN'+item.usertype)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.interfaceType}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.sucess}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.templateID==="---"?item.templateID:t('Template'+item.templateID)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.fileName}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.uploadeddate}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.processbegindate}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.rejected}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.processingstatus==='C'?t('INTFC'):item.processingstatus==='I'?t('INTFI'):"---"}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.failed}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.processendate}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.channelID==="---"?item.channelID:t('REP'+item.channelID)}&nbsp;</TableCell>

                                                    </TableRow>
                                                  ))
                                                ) : (
                                                  // Show 'No data found' message if no items are found after loading
                                                  <TableRow>
                                                    <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                                                    {submitted ? t("2481_061") : t("038")}
                                                    </TableCell>
                                                  </TableRow>
                                                )}


<Dialog open={isDialogOpen} onClose={handleClose1} maxWidth="lg" fullWidth>
      <DialogTitle>
  <div className={"headerTxt"} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
    <IconButton
      aria-label="close"
      onClick={handleClose1}
      sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
        }}
    >
      <CancelRounded />
    </IconButton>
  </div>
   </DialogTitle>

        <DialogContent>
       <MassiveDetails fileId={selectedFileId} inftType={selectedInterfaceType} handleClose={handleClose}   />
        </DialogContent>
      </Dialog>


                                              </TableBody>
                                            </Table>
                                          </TableContainer>
                                          <br></br>
                                         <Table>
  <tfoot>
    <Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
      <Box
        sx={{ textAlign: "right", padding: "4px 0px 4px 0 !important" }}
        className={'displayFlex'}
      ></Box>

      {items.length > 0 ? (
        <Pagination
          count={totalPages}
          page={page}
          onChange={handleChangePage}
          showFirstButton
          showLastButton
        />
      ) : null}
    </Box>
    <tr></tr>
  </tfoot>
</Table>

                                         <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
  {items.length > 0 ? (
    <div onMouseLeave={handleClose}>
      <Button
        className="hoverEffectButton"
        size="small"
        variant="contained"
        endIcon={<CloudDownload />}
        onMouseEnter={handleHover}
      >
        {t('089')}
      </Button>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        MenuListProps={{
          onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
          onMouseLeave: handleClose,
        }}
      >
<MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{localeVar=="en"?"As":"Como"} PDF</MenuItem>
<MenuItem onClick={() => { setAnchorEl(null); handleDownload(); }}>{localeVar=="en"?"As":"Como"} Excel</MenuItem>
<MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{localeVar=="en"?"As":"Como"} CSV</MenuItem>

      </Menu>
    </div>
  ) : null}

                                            <Button
                                              className={"hoverEffectButton"}
                                              size="small"
                                              variant="contained"
                                              onClick={handleReturn}
                                              endIcon={<KeyboardReturn />}
                                            > {t('013')}</Button>
                                          </div>
                                          <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                                        </table>
                                        </td></tr>
                                      </div>
                                    
                                </tbody>
                              </table>
                            </td>
                          </tr>{/* MIDDLE ROW ENDS HERE  */}
                        </tbody>
                      </table>
                    </td></tr>
                </tbody>
              </table>
            </td></tr>

            <ToastContainer 
                                    position="top-right"
                                    autoClose={3000}
                                    hideProgressBar={false}
                                    newestOnTop={false}
                                    closeOnClick
                                    rtl={false}
                                    pauseOnFocusLoss
                                    draggable
                                    pauseOnHover
                                    style={{
                                      width: "fit-content",
                                      minWidth: "300px",
                                      minHeight: "100px",
                                      fontSize: "18px",
                                    }}
                                  />
            
          <tr height="60px"><td colSpan={2}>
            <Footer />
          </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default MassiveTransfers
