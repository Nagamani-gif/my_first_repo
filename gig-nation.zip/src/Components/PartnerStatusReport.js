/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, LeftBgImage } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, Menu,CircularProgress, FormControl, FormControlLabel, FormLabel, Grid, InputLabel, MenuItem, Pagination, Paper, Radio, RadioGroup, Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, TableSortLabel } from "@mui/material";
import React, { useState, useEffect, useCallback } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CloudDownload, KeyboardReturn,DoneAllRounded,RestartAltRounded, SaveRounded } from '@mui/icons-material';
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
 import ExcelJS from 'exceljs';
 import { useRef } from "react";
import SendIcon from '@mui/icons-material/Send';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { DatePicker, DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import 'dayjs/locale/es'; // Spanish locale
import 'dayjs/locale/en'; // English locale (optional, dayjs default is English)
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';


function PartnerStatusReport(){
  sessionStorage.setItem("selectedLink", "e_transactions");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  let reportDays = process.env.REACT_APP_ReportDays;
  const toastId = useRef(null);
  const [anchorEl, setAnchorEl] = useState();
  const closeTimeoutRef = useRef(null);
   const [totalRecords, setTotalRecords] = useState(0);
   const [recordsPerPage] = useState(10);
    const [page, setPage] = useState(1);
    const [perpage, setPerPage] = useState(10);
    sessionStorage.setItem("selectedLink", "e_transactions");
  const [hierarchyMode, setHierarchyMode] = useState('N');
  const [submitted, setSubmitted] = useState(false);
  const [DistributorID, setDistributorID] = useState('');
  const [CellularNumber, setCellularNumber] = useState('');
  const [recordsFound, setRecordsFound] = useState(0);
  const [mnvoList, setMnvoList] = useState([]);
    const [carrierList, setCarrierList] = useState([]);
    const [ready, setReady] = useState(false);

    // Passing Parameters
    const navigate = useNavigate();
    const[piPartnerID, setPiPartnerID] = useState('');
    const[piMDN, setPiMDN] = useState('');
    const[piDistributorID, setPiDistributorID] = useState('');
    const[piLevelflag, setPiLevelflag] = useState('N');
    const[download, setDownload] = useState('N');
    const[statusId, setStatusId] = useState('F');

  let startRecord=0;
  let endRecord =10;


const handleChangePage = async (event, newPage) => {
  event.preventDefault();
  setPage(newPage);
  await fetchData(newPage); // fetch data for the selected page
};

  useEffect(() => {
    if (partnerLoginId) {
     // fetchData();
    }
  }, [partnerLoginId, page]);


   const RedAsterisk = styled('span')({
      color: 'red',
    });

  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);


  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
 
   const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };

    const clearData = () => {
  setHierarchyMode('N');
    setPiDistributorID('');
    setPiMDN('');
    setPiLevelflag('N');
  }

  
  const handleSubmit1 = async (e) => {
  e.preventDefault();
  // Set column visibility
  const firstPage = 1;
  setPage(firstPage);
  await fetchData(firstPage); // fetch data for page 1
};


const formatter = new Intl.NumberFormat('en-US', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});




  const fetchData = async (pageNumber = 1) => {
  const startRecord = (pageNumber - 1) * perpage + 1;
  const endRecord = startRecord + perpage - 1;
  setIsLoading(true);

    
    try {
      const apiUrl = window.config.apiUrlJasper+ '/PartnerStatusReport';
      const response = await axios.post(apiUrl, {                
        userName,
        password,
        localeVar,
        partnerLoginId,
        piMDN,
        piDistributorID,
        piLevelflag,
        piBegRecNo: startRecord+'',
        EndRecNo: endRecord +'',
        piDownload: 'N'
      });

            setStatusId('N');
            // if (piDistributorID.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(piDistributorID)) {
            //   toast.error(`${t('alrt_01')} in ${t('partnerstatusreport16')}.`);
            //   return;
            //  }
            //    if (piMDN.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(piMDN)) {
            //   toast.error(`${t('alrt_01')} in ${t('partnerstatusreport17')}.`);
            //   return;
            //  }
       
      console.log("response::::::",response);
      if (response.status === 200) {
        setItems(response.data.summaryConfigArray);
        setTotalRecords(response.data.totalRecords);
      }
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };


  const fetchDataDownload = async () => {
    try {
      let userName = process.env.REACT_APP_USERNAME;
      let password = process.env.REACT_APP_PASSWORD;
        const apiUrlDownload = window.config.apiUrlJasper+ '/PartnerStatusReport';
        console.log('API URL:', apiUrlDownload);
        console.log('Partner Login ID:', partnerLoginId);
        setDownload('Y');
         const response = await axios.post(apiUrlDownload, {          
            
        userName,
        password,
        localeVar,
        partnerLoginId,
        piMDN,
        piDistributorID,
        piLevelflag,
        piBegRecNo: startRecord+'',
        EndRecNo: endRecord +'',
        piDownload: 'Y'
       
      });
        console.log('Response:', response.data.summaryConfigArray);
        if (!response.data || !response.data.summaryConfigArray) {
            throw new Error('Invalid API response');
        }

        const downloadData = response.data.summaryConfigArray.map(item => ({
 
          
 partnerID:  item.partnerID  ,
    parentIdentity:      item.parentIdentity ,
    partnerType:      item.partnerType,
    status:      item.status  ,
      maxLimit:       Number(item.maxLimit ).toFixed(2),
    avaliableCreditLimit:       Number(item.avaliableCreditLimit ).toFixed(2),
    accountBalance:      item.accountBalance ,
    currency : item.currency,
     companyName:     item.companyName ,
    cellularNumber:      item.cellularNumber ,
    businessClassification:      item.businessClassification ,
    parnetName:      item.parnetName ,
     mainDistributorName:     item.mainDistributorName ,
    level:      item.level 
    
   


      }));


        console.log('Download Data:', downloadData);

        return downloadData;
    } catch (error) {
        console.error('Error fetching data:', error);
        return [];
    }
};



const handleDownloadPdf = async () => {
  const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;
  const totalRecords = downloadItems.length;
  const startRecord = 1;
  const endRecord = totalRecords;

  const tableBody = [];

  // === 2) Column Headers ===
  const headers = [];
headers.push(t('partnerstatusreport1'));
headers.push(t('partnerstatusreport2'));
headers.push(t('partnerstatusreport3'));
headers.push(t('partnerstatusreport4'));
headers.push(t('partnerstatusreport5'));
headers.push(t('partnerstatusreport6'));
headers.push(t('partnerstatusreport7'));
headers.push(t('partnerstatusreport8'));
headers.push(t('partnerstatusreport9'));
headers.push(t('partnerstatusreport10'));
headers.push(t('partnerstatusreport11'));
headers.push(t('partnerstatusreport12'));
headers.push(t('partnerstatusreport13'));
headers.push(t('partnerstatusreport14'));


  tableBody.push(
  headers.map(function(header) {
    return { text: header, style: 'tableHeader' };
  })
);
  // === 3) Table Rows ===
  downloadItems.forEach(item => {
  const row = [];
row.push(item.partnerID || '---');
  row.push(item.parentIdentity || '---');
  row.push(item.partnerType || '---');
  row.push(item.status || '---');
 row.push(
  item.maxLimit != null && !isNaN(item.maxLimit)
    ? Number(item.maxLimit).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
row.push(
  item.avaliableCreditLimit != null && !isNaN(item.avaliableCreditLimit)
    ? Number(item.avaliableCreditLimit).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
row.push(
  item.accountBalance != null && !isNaN(item.accountBalance)
    ? Number(item.accountBalance).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
  row.push(item.currency || '---');
  row.push(item.companyName || '---');
  row.push(item.cellularNumber || '---');
  row.push(item.businessClassification || '---');
  row.push(item.parnetName || '---');
  row.push(item.mainDistributorName || '---');
  row.push(item.level || '---');

  // Ensure row has exactly 26 items
 while (row.length < headers.length) row.push('---');

  tableBody.push(row.map(function(val) {
    return { text: val, fontSize: 5,alignment: 'center' };
  }));
  
});




  // === 4) PDF Definition ===
  const docDefinition = {
    content: [
    {
      text: localeVar === 'en' ? "Partner Status Report" : "Reporte de Estado del Distribuidor",
      style: 'title',
      alignment: 'center',
      margin: [0, 0, 0, 10]
    },
      {
        columns: [
          {
            text: `${t('032')} : ${totalRecords}`,
            alignment: 'left',
            fontSize: 7
          },
          {
       //     text: `${t('033')} : ${startRecord} - ${totalRecords < 10 ? totalRecords :endRecord}`,
       //     alignment: 'right',
       //     fontSize: 8
          }
        ],
        margin: [0, 0, 0, 5]
      },
    {
      style: 'tableExample',
      table: {
          headerRows: 2,
          widths: new Array(headers.length).fill('*'),
        body: tableBody
      },
      layout: {
         fillColor: (rowIndex) => (rowIndex === 0 ? '#004080' : null)
      }
    },
    {
      text: t('0171'),
      style: 'endText',
      alignment: 'center',
      margin: [0, 10, 0, 0]
    }
    ],
    styles: {
      title: { fontSize: 12, bold: true },
      tableExample: { margin: [0, 5, 0, 10] },
      mainHeader: { bold: true, fontSize: 8, color: '#3399FF' },
      tableHeader: { bold: true, fontSize: 7, color: '#fff', alignment: 'center', fillColor: '#3399FF' },
      endText: { italics: true, bold: true, decoration: 'underline', fontSize: 10 }
    },
    pageOrientation: 'landscape',
    pageSize: 'A3',
    pageMargins: [10, 10, 10, 10],
    defaultStyle: { fontSize: 7 }
  };

  pdfMake.createPdf(docDefinition).download('PartnerStatusReport.pdf');
};



const handleDownloadCsv = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;
  const totalRecords = downloadItems.length;
  const startRecord = 1;
  const endRecord = downloadItems.length;

  const numberOfColumns =14;

  const title =` ${t('n_partnerStatusReportp')} `;

  const summaryText1 = `${t('032')} : ${totalRecords}`; // Goes to column A
const summaryText2 = `${t('033')} : ${startRecord} - ${(totalRecords < 10 ? totalRecords : endRecord)}`; // Goes to column Z

   const headers = [];
headers.push(t('partnerstatusreport1'));
headers.push(t('partnerstatusreport2'));
headers.push(t('partnerstatusreport3'));
headers.push(t('partnerstatusreport4'));
headers.push(t('partnerstatusreport5'));
headers.push(t('partnerstatusreport6'));
headers.push(t('partnerstatusreport7'));
headers.push(t('partnerstatusreport8'));
headers.push(t('partnerstatusreport9'));
headers.push(t('partnerstatusreport10'));
headers.push(t('partnerstatusreport11'));
headers.push(t('partnerstatusreport12'));
headers.push(t('partnerstatusreport13'));
headers.push(t('partnerstatusreport14'));
const tableBody = [];

downloadItems.forEach(item => {
  const row = [];
 row.push(item.partnerID || '---');
  row.push(item.parentIdentity || '---');
  row.push(item.partnerType || '---');
  row.push(item.status || '---');
 row.push(
  item.maxLimit != null && !isNaN(item.maxLimit)
    ? Number(item.maxLimit).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
row.push(
  item.avaliableCreditLimit != null && !isNaN(item.avaliableCreditLimit)
    ? Number(item.avaliableCreditLimit).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
row.push(
  item.accountBalance != null && !isNaN(item.accountBalance)
    ? Number(item.accountBalance).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
  row.push(item.currency || '---');
  row.push(item.companyName || '---');
  row.push(item.cellularNumber || '---');
  row.push(item.businessClassification || '---');
  row.push(item.parnetName || '---');
  row.push(item.mainDistributorName || '---');
  row.push(item.level || '---');


  // Ensure row has exactly 26 columns
  console.log('row.length  123' , row.length );


  // Format each cell
  tableBody.push(row);
});

  
  const escapeCSV = value => {
    if (value == null) return '';
    const stringValue = String(value).replace(/"/g, '""');
    return `"${stringValue}"`;
  };

  const csvLines = [];

  // === Line 1: Title
 const leftPadding = Math.floor((numberOfColumns - 1) / 2);
  const titleRow = Array(leftPadding).fill('').concat(title).concat(Array(numberOfColumns - leftPadding - 1).fill(''));
  csvLines.push(titleRow);

  // === Line 2: Summary text
  // Create a line with value in column A and Z
const emptyCells = Array(14).fill('""').join(','); // 24 empty cells for columns B to Y
const summaryLine = `"${summaryText1}"`;

csvLines.push(summaryLine);
  // === Line 3: Group Headers


  // === Line 4: Column Headers
  csvLines.push(headers.map(escapeCSV).join(','));


// === Data Rows
tableBody.forEach(row => {
  csvLines.push(row.map(escapeCSV).join(','));
});
const endOfReportText = t('0171');
  // === Final Line: End of Report
const endRow = Array(14).fill('""');

// Put the text only in column M (index 12)
endRow[6] = `"${endOfReportText}"`;

// Add the line to the CSV
csvLines.push(endRow.join(','));
 const BOM = '\uFEFF';
  const csvContent = BOM  + csvLines.join('\n');

  

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const fileName = 'PartnerStatusReport.csv';

  if (navigator.msSaveBlob) {
    navigator.msSaveBlob(blob, fileName);
  } else {
  const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  }
};




  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);

const DownloadXL = async () => {
   const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;
    const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('PartnerStatusReport' , {
    pageSetup: { paperSize: 9, orientation: 'landscape' }
  });

  // === Set 30 columns width
  worksheet.columns = new Array(14).fill({ width: 30 });
  const endOfReportText = t('0171');

  // === Insert Title Row (Row 1)
  worksheet.insertRow(1, [
    localeVar === 'en' ? 'Partner Status Report' : 'Reporte de Estado del Distribuidor'
  ]);
  worksheet.mergeCells('A1:N1');
  worksheet.getCell('A1').font = { bold: true, size: 14 };
  worksheet.getCell('A1').alignment = { horizontal: 'center' };

  // === Insert Summary Row (Row 2) with left and right alignment
  const summaryRow = worksheet.insertRow(2, new Array(14).fill(''));

  summaryRow.getCell(1).value = `${t('032')} : ${downloadItems.length}`;
  summaryRow.getCell(1).alignment = { horizontal: 'left' };

 // summaryRow.getCell(24).value = `${t('033')} : 1 - ${downloadItems.length}`;
//  summaryRow.getCell(24).alignment = { horizontal: 'right' };

 // summaryRow.font = { italic: true, size: 10 };



    
  // === Column Headers (Row 4)
   /* const columnHeaders = [
    t('023'), t('2481_002'), t('2481_012'),t('2481_065'), t('1146'), t('2481_013'), 
    t('partnerstatusreport2'), t('2421456'), t('subscriberCellularNumber'), t('2481_024'), t('2481_015'),
     t('2481_016'), t('2481_017'), t('2481_004'), t('2481_003'), t('2481_005'),
      t('1245'), t('2481_018'), t('049'), t('055'), t('errordesp'), t('2481_019'), 
      t('2481_020'), t('2481_021'), t('2481_022'), t('2481_023')   
    ]; */

    
   const headers = [];

   headers.push(t('partnerstatusreport1'));
headers.push(t('partnerstatusreport2'));
headers.push(t('partnerstatusreport3'));
headers.push(t('partnerstatusreport4'));
headers.push(t('partnerstatusreport5'));
headers.push(t('partnerstatusreport6'));
headers.push(t('partnerstatusreport7'));
headers.push(t('partnerstatusreport8'));
headers.push(t('partnerstatusreport9'));
headers.push(t('partnerstatusreport10'));
headers.push(t('partnerstatusreport11'));
headers.push(t('partnerstatusreport12'));
headers.push(t('partnerstatusreport13'));
headers.push(t('partnerstatusreport14'));
  const headerRow2 = worksheet.addRow(headers);

  headerRow2.eachCell(cell => {
    cell.font = { bold: true};
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFFFFFFF' }
      // fgColor: { argb: '3399FF' }
    };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
        cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
        };
    });

  // === Add Data Rows (Starting from Row 5)
  
downloadItems.forEach(item => {
  const row = [];

   row.push(item.partnerID || '---');
  row.push(item.parentIdentity || '---');
  row.push(item.partnerType || '---');
  row.push(item.status || '---');
 row.push(
  item.maxLimit != null && !isNaN(item.maxLimit)
    ? Number(item.maxLimit).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
row.push(
  item.avaliableCreditLimit != null && !isNaN(item.avaliableCreditLimit)
    ? Number(item.avaliableCreditLimit).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
row.push(
  item.accountBalance != null && !isNaN(item.accountBalance)
    ? Number(item.accountBalance).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : '---'
);
  row.push(item.currency || '---');
  row.push(item.companyName || '---');
  row.push(item.cellularNumber || '---');
  row.push(item.businessClassification || '---');
  row.push(item.parnetName || '---');
  row.push(item.mainDistributorName || '---');
  row.push(item.level || '---');


    worksheet.addRow(row);
    });

  // === End of Report Message
    const endOfReportRow = worksheet.addRow([endOfReportText]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, headers.length);
  endOfReportRow.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
  endOfReportRow.getCell(1).font = { bold: true };
        
  // === Generate Excel File
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
  saveAs(blob, 'PartnerStatusReport.xlsx');
};


const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}
  
return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Partner Status Report":"Reporte de Estado del Distribuidor"}/>
  </tr>

  <tr>
  

  <LeftBgImage />

<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
   <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
    <Tabs style={{ minHeight: '35px' }}>
                                      <NavLink
                                        to="/partnerStatusReportp"
                                        onClick={(e) => highlightSelectedLink(e)}
                                        // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
                                        className={({ isActive }) =>
                                          isActive ? 'activeProfilemenu' : `profile_menu 
                                         ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
                                        }
                                      ><Tab label={t('n_partnerStatusReportp')} /></NavLink>
                                    </Tabs>
  </Box>
<div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="80%">
            {/* body starts */}
          

    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>


          
               <Box style={{display:'flex', gap:'12px',marginTop:'10px'}}> 
                           <TextField type="text" name="DistributorID" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {`${t('partnerstatusreport16')}`}
                                                </span>}   style={{ maxWidth: '250px', width: '150px' }}
                                              onChange={e => setPiDistributorID(e.target.value)} value={piDistributorID} size="15" defaultValue=""
                                            />

                                            <TextField type="text" name="CellularNumber" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {`${t('partnerstatusreport17')}`}
                                                </span>} style={{ maxWidth: '250px', width: '150px' }}
                                              onChange={e => setPiMDN(e.target.value)} value={piMDN} size="15" defaultValue=""
                                            />


 <FormControl className={'selected_formcontrol'} sx={{  minWidth: 150 }} size="small">
                <InputLabel id="demo-select-small-label">{t('2481_025')}<RedAsterisk>*</RedAsterisk></InputLabel>
 
                      <Select className={'bankSelect'} style={{ maxWidth: '250px', width: '150px' }} labelId="demo-select-small-label" id="demo-select-small"
                        label={t('2481_025')}    value={piLevelflag} onChange={e => setPiLevelflag(e.target.value)}>
                        <MenuItem value="Y">{t('Y')}</MenuItem>
                        <MenuItem value="N">{t('N')}</MenuItem>
                      </Select>
                    </FormControl>

 <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
   <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
            onClick={handleSubmit1}
            >
              {t('2616028')} 
              </Button>
           
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
            onClick={clearData}
            >
              {t('2481_027')}
            </Button>
         </Box>
</Box>
           <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {totalRecords < 10 ? totalRecords :endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
              </Grid>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
        <TableRow className="darkgray">
        <TableCell align="center">{t('partnerstatusreport1')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport2')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport3')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport4')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport5')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport6')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport7')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport8')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport9')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport10')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport11')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport12')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport13')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport14')} </TableCell>
        
           
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
            <TableRow>
              <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
              {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : items.length > 0 ? (
                                                  // Show table rows when data is available
                                                  items.map((item, index) => (
                                                    <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
                                                      <TableCell align="center">&nbsp;{item.partnerID || '---'}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.parentIdentity || '---'}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.partnerType || '---'}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.status || '---'}&nbsp;</TableCell>


                                                      <TableCell align="center">&nbsp;{formatter.format(item.maxLimit || 0)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{formatter.format(item.avaliableCreditLimit || 0)}&nbsp;</TableCell>
                                                      <TableCell align="center">
                                                        &nbsp;{Number(item.accountBalance || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}&nbsp;
                                                      </TableCell>                                                      <TableCell align="center">&nbsp;{item.currency || '---'}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.companyName || '---'}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.cellularNumber || '---'}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.businessClassification || '---'}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.parnetName || '---'}&nbsp;</TableCell> 
                                                      <TableCell align="center">&nbsp;{item.mainDistributorName || '---'}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.level || '---'}&nbsp;</TableCell>


                </TableRow>
            ))
          ) : (
            // Show 'No data found' message if no items are found after loading

           statusId === 'F' ? <TableRow>
              <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                {t("038")} {/* No data found for the given search criteria */}
              </TableCell>
            </TableRow> :
            <TableRow>
              <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                {t("2481_061")} {/* No data found for the given search criteria */}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
  <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                            {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,
                                                 }}
                                               >
                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{t('2481_062')}</MenuItem>
                                            <MenuItem onClick={() => { setAnchorEl(null); DownloadXL(); }}>{t('2481_064')}</MenuItem>
                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{t('2481_063')}</MenuItem>
                                            </Menu>
                                             </div>
                                              : <></>}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</td></tr>
</div>
</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>
<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
    width: "auto",           // Let width grow with message
    fontSize: "18px",        // Optional: keep font size
    padding: "8px",          // Optional: spacing inside
    wordBreak: "break-word", // Ensure long words/wrapped text don't overflow
                        }}
                      />
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  );
}

export default PartnerStatusReport;
