/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, LeftBgImage, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, CircularProgress, FormControl, Grid, InputLabel, MenuItem, Menu, Pagination, Paper,styled, Select, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField } from "@mui/material";
import React, { useState, useEffect, useCallback, useRef } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { ArrowDownward, ArrowUpward, CloudDownload, KeyboardReturn, UnfoldMore } from "@mui/icons-material";
import {  NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
 import ExcelJS from 'exceljs';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import dayjs from "dayjs";
import { toast, ToastContainer } from "react-toastify";
// import pdfMake from 'pdfmake/build/pdfmake';
// import pdfFonts from 'pdfmake/build/vfs_fonts';


function BalanceAnnulmentReport(){
  
  sessionStorage.setItem("selectedLink", "e_transactions");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);

  const now = dayjs();  
  const midnightToday = dayjs().startOf('day');
  
    const [startDateTime, setStartDateTime] = useState(midnightToday);
    const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
    const [endDateTime, setEndDateTime] = useState(now);
    const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));

  const [status, setStatus] = useState('FT');
  const [hierarchyMode, setHierarchyMode] = useState('N');
 
  const [hasSubmitted, setSubmit] = useState(false);

 const [anchorEl, setAnchorEl] = useState(null);
 const [fromId, setFromId] = useState('');
 const [subDistId, setSubDistId] = useState(partnerLoginId);
 const closeTimeoutRef = useRef(null);
 const toastId = useRef(null);
 const [sortedItems, setSortedItems] = useState([]);
 const [sortDirection, setSortDirection] = useState('desc');
   const [apply,setApply] =useState(false);

  let reportDays = process.env.REACT_APP_ReportDays;



  const navigate = useNavigate();

  console.log("totalRecords++++++++++++",totalRecords)


  const handleChangePage = async (event, newPage) => {

 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       hasSubmitted
     });
 
  if (!isValid) {
  setSubmit(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmit(false);
    }
return false;

}

    setPage(newPage);
  };

    useEffect(() => {
    if (!hasSubmitted) return;
    fetchData();           // runs every time `page` changes
  }, [page,hasSubmitted]);


const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
   
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      

    }
    return false;
  }

  return true;
};


  const handleSubmit1 = (e) => {
    e.preventDefault();
  
    try {
   const isValid = validateDateRange({
         startDateTime,
         endDateTime,
         reportDays,
         toast,
         toastId,
         t,
         hasSubmitted
       });
   
    // if (!isValid) {
    // setSubmit(false);  // reset submit flag
    // return;
    if (!isValid) {
      setApply(false);
      return;
    }
  



    startRecord=0;
    endRecord =10;
    fetchData();
      setPage(1);
      setApply(true);
      setSubmit(true)
    } catch (error) {
      console.error("An error occurred:", error);
    }
  };

 const RedAsterisk = styled('span')({
    color: 'red',
  });



const handleStartDateTimeChange = (newValue) => {
  setApply(false);
  setStartDateTime(newValue);
  const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
  setStartDate(formattedDateTime);
  console.log("startDate:", formattedDateTime);
};

const handleEndDateTimeChange = (newValue) => {
  setApply(false);
  setEndDateTime(newValue);
  const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
  setEndDate(formattedDateTime);
};



  useEffect(() => {
    // Set the browser title
      document.title = t('m_balanceAnnulmentReportp');
  }, []);

 const fetchData = async () => {
  setIsLoading(true);
  try {
    const apiUrl = window.config.apiUrlJasper+ '/balAnnulmentReport';
    const response = await axios.post(apiUrl, {
      userName,
      password,
      fromId,
      subDistId,
      partnerId:partnerLoginId,
      transFromDate: startDate,
      transToDate: endDate,
      transType: status,
      lavelFlag:hierarchyMode,
      startpage: startRecord,
      endpage: endRecord < 10 ? '10' :endRecord,
      localeVar, // Include if required
    });
    console.log("response:", response.data);
    console.log("Total Records:", response.data.noOfRecord);
    if (response.status === 200) {
      setItems(response.data.data); // Fallback to empty array if no data
      setTotalRecords(response.data.noOfRecord); // Use totalRecord from API
    }
  } catch (error) {
    console.error('An error occurred:', error);
    alert(t('Error fetching table data')); // Notify user
  } finally {
    setIsLoading(false);
  }
};
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };
 
 

const handleHover = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handlePdfDownload = async() => {
  const downloadItems = await fetchDataDownload(); // same data as Excel
    if (!downloadItems || downloadItems.length === 0) return;

  const doc = new jsPDF({
    orientation: 'landscape',
     format: [500, 1000],
    unit: 'pt'
  });
const totalRecords = downloadItems[0]?.noOfRecord || downloadItems.length;

doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text(t('m_balanceAnnulmentReportp'), doc.internal.pageSize.getWidth() / 2, 40, { align: 'center' });

  // doc.setFontSize(10);
  // doc.setFont(undefined, 'normal');
  // doc.text(`${t('032')}: ${totalRecords}`, 40, 60);


  // Table Headers (first row)
  const columnHeaders = [
       t('2480_034'),
      t('2480_087'),
      t('2480_049'),
      t('2481_066'),
      t('2616031'),
      t('2616025'),
      t('2480_049'),
      t('2481_066'),
      t('2616032'),
      t('023'),
      t('2616033'),
      t('2616034'),
      t('2616035'),
      t('251620'),
      t('2616036'),
      t('2616037')
  ];
  //tableBody.push(headers.map(header => ({ text: header, style: 'tableHeader' })));

  // Table Rows
 const rows = downloadItems.map(item => [
      item.transId,
      item.fromId,
      item.fromLevel, 
      item.companyName,
      item.sourceCompName,
      item.toId,
      item.tolevel, 
      item.toCompanyName,
      item.destinationCompName,
      item.transactionDate,
      !isNaN(parseFloat(item.annulledAmount)) ? parseFloat(item.annulledAmount).toFixed(2) : '---',
      item.isPartial === 'Y' ? t('2616020') : item.isPartial === 'N' ? t('2616021') : item.isPartial,
       !isNaN(parseFloat(item.actualTransAmt)) ? parseFloat(item.actualTransAmt).toFixed(2) : '---',
      item.currency,
      item.originalTransID,
      item.channel,
   ]);

doc.autoTable({
  startY: 50,
  head: [[
    {
      content: `${t('032')}: ${totalRecords}`,
      colSpan: Math.floor(columnHeaders.length / 2),
      styles: {
        halign: 'left',
        fillColor: [51, 153, 255],
        textColor: [255, 255, 255],
        fontSize: 5
      }
    },

  ]],
  body: [],
  margin: { left: 10, right: 10 }
});

const verticalGap = 1; // 🔧 increase this for more space (10pt ≈ 3.5mm)
const startDataTableY = doc.lastAutoTable.finalY + verticalGap;


doc.autoTable({
    startY: startDataTableY,
    head: [columnHeaders],
    body: rows,
    styles: {
      fontSize: 6,       // Smaller font for more data
      overflow: 'linebreak',
      cellPadding: 1
    },
    headStyles: {
      
      fillColor: [51, 153, 255],
      halign: 'center',
      fontSize: 6
    },
    theme: 'grid',
    margin: { left: 10, right: 10 }
  });

  // Footer
  doc.setFontSize(10);
  doc.setFont(undefined, 'italic');
  doc.text(t('0171'), doc.internal.pageSize.getWidth() / 2, doc.lastAutoTable.finalY + 20, { align: 'center' });

  doc.save('Balance_Annulment_Report_V2.pdf');
};


  const handleCsvDownload = async () => {
   const downloadItems = await fetchDataDownload(); // same as in PDF
    if (!downloadItems || downloadItems.length === 0) return;
  const headers = [
     t('2480_034'),
      t('2480_087'),
      t('2480_049'),
      t('2481_066'),
      t('2616031'),
      t('2616025'),
      t('2480_049'),
      t('2481_066'),
      t('2616032'),
      t('023'),
      t('2616033'),
      t('2616034'),
      t('2616035'),
      t('251620'),
      t('2616036'),
      t('2616037')
  ];

  const totalRecords = downloadItems[0]?.noOfRecord || downloadItems.length;

const middleIndex  = Math.floor(headers.length / 2); // e.g. 16 headers → 8
const titleLine    = Array(middleIndex).fill('').concat(t('m_balanceAnnulmentReportp')).join(',');


const preambleLines = [
  titleLine,                         
  `${t('032')} : ${totalRecords}`, 
  ''                                 
];


  // Convert headers and data rows to CSV format
const headerLine = headers.join(',');

let csvContent = [...preambleLines, headerLine].join('\n') + '\n';

  downloadItems.forEach(item => {
    const row = [
        item.transId,
      item.fromId,
      item.fromLevel, 
      item.companyName,
      item.sourceCompName,
      item.toId,
      item.tolevel, 
      item.toCompanyName,
      item.destinationCompName,
      item.transactionDate,
      !isNaN(parseFloat(item.annulledAmount)) ? parseFloat(item.annulledAmount).toFixed(2) : '---',
      item.isPartial === 'Y' ? t('2616020') : item.isPartial === 'N' ? t('2616021') : item.isPartial,
      !isNaN(parseFloat(item.actualTransAmt)) ? parseFloat(item.actualTransAmt).toFixed(2) : '---',
      item.currency,
      item.originalTransID,
      item.channel,
      
    ];
    const csvRow = row
      .map(field =>
        typeof field === 'string' && field.includes(',') ? `"${field}"` : field
      )
      .join(',');
    csvContent += csvRow + '\n';

    
  });

  const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;

  // Create a Blob and trigger download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', 'BalanceAnnulmentReport.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};



  const handleExcelDownload = async () => {
 
    const downloadItems = await fetchDataDownload();
     if (!downloadItems || downloadItems.length === 0) return;
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('BalanceAnnulmentReport');
    const headingRow1 = worksheet.addRow([localeVar === 'en' ? "Balance Annulment Report" : "Reporte de anulación de saldos"]);
    const numberOfColumns = 17; // A djust this to match the number of columns in your table
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    const headingCell = headingRow1.getCell(1);
    headingCell.font = { bold: true };
    headingCell.alignment = { horizontal: 'center' };
    worksheet.addRow([]); // Empty row


    const totalRecords = downloadItems.length;
   const totalRow = worksheet.addRow([`${t('032')}: ${totalRecords}`]);
 worksheet.addRow([]);
    
 const columnHeaders = [
      t('2480_034'),
      t('2480_087'),
      t('2480_049'),
      t('2481_066'),
      t('2616031'),
      t('2616025'),
      t('2480_049'),
      t('2481_066'),
      t('2616032'),
      t('023'),
      t('2616033'),
      t('2616034'),
      t('2616035'),
      t('251620'),
      t('2616036'),
      t('2616037')
      ];

  const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });


    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
      item.transId,
      item.fromId,
      item.fromLevel, 
      item.companyName,
      item.sourceCompName,
      item.toId,
      item.tolevel, 
      item.toCompanyName,
      item.destinationCompName,
      item.transactionDate,
      !isNaN(parseFloat(item.annulledAmount)) ? parseFloat(item.annulledAmount).toFixed(2) : '---',
      item.isPartial === 'Y' ? t('2616020') : item.isPartial === 'N' ? t('2616021') : item.isPartial,
       !isNaN(parseFloat(item.actualTransAmt)) ? parseFloat(item.actualTransAmt).toFixed(2) : '---',
      item.currency,
      item.originalTransID,
      item.channel,
      ]);
      dataRow.eachCell(cell => {
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
        cell.alignment = { horizontal: 'center' }; // Center-align the cell content
      });
    });
    worksheet.addRow([]);


 worksheet.mergeCells(totalRow.number, 1, totalRow.number, numberOfColumns);
const totalCell = totalRow.getCell(1);
totalCell.font = { bold: true };
totalCell.alignment = { horizontal: 'left' };   // or 'center' if you prefer
//totalCell.border = { top: { style: 'thin' }, bottom: { style: 'double' } };

    const emptyRow3 = worksheet.addRow([]);
    emptyRow3.hidden = true; // Hide the empty row
    const endOfReportText = t('0171'); // Replace with your translated text
    const endOfReportRow = worksheet.addRow([endOfReportText]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
    // Style the "End of Report" cell
    const endOfReportCell = endOfReportRow.getCell(1);
    endOfReportCell.font = { italic: true, underline: true, bold: true };
    endOfReportCell.alignment = { horizontal: 'center' };
   
  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });


    // Protect the worksheet to make it read-only
    worksheet.protect('yourPassword', {
      selectLockedCells: true,
      selectUnlockedCells: true,
      formatCells: true,
      formatColumns: true,
      formatRows: true,
      insertColumns: false,
      insertRows: false,
      insertHyperlinks: false,
      deleteColumns: false,
      deleteRows: false,
      sort: false,
      autoFilter: false,
      pivotTables: false
    });

    // Generate and download the Excel file
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'BalanceAnnulmentReport.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };



const totalPages = Math.ceil(totalRecords / recordsPerPage);

let startRecord = (page - 1) * perpage + 1;
let endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);

const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}


const fetchDataDownload = async () => {


 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       hasSubmitted
     });
 
  if (!isValid) {
  setSubmit(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmit(false);
    }
return false;

}


  try {
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
    const apiUrl = window.config.apiUrlJasper+ '/balAnnulmentReport';
    console.log('API URL:', apiUrl);
    console.log('Partner Login ID:', partnerLoginId);
    const responseDownload = await axios.post(apiUrl, {
      userName,
      password,
      fromId,
      subDistId,
      partnerId:partnerLoginId,
      transFromDate: startDate,
      transToDate: endDate,
      transType: status,
      lavelFlag:hierarchyMode,
      localeVar, // Include if required by the API
    });

    console.log('API Response Download:', responseDownload.data);

    if (!responseDownload.data.data) {
      throw new Error('No data found in API response');
    }

    const downloadData = responseDownload.data.data.map(dto => ({
      transId: dto.transId,
      fromId: dto.fromId,
      fromLevel:dto.fromLevel,
      companyName: dto.companyName,
      sourceCompName: dto.sourceCompName,
      toId: dto.toId,
      tolevel: dto.tolevel, // Use tolevel instead of level
      toCompanyName: dto.toCompanyName,
      destinationCompName: dto.destinationCompName,
      transactionDate: dto.transactionDate,
      annulledAmount:dto.annulledAmount,
      isPartial: dto.isPartial,
      actualTransAmt: dto.actualTransAmt,
      currency: dto.currency,
      originalTransID: dto.originalTransID, // Match case with API (originalTransID)
      channel: dto.channel,
    }));

    console.log('Download Data:', downloadData);

    return downloadData;
  } catch (error) {
    console.error('Error fetching data:', error);
    alert(t('Error fetching data for download')); // Notify user of error
    return [];
  }
}; 


function clearData(){
setFromId('');
setSubDistId(partnerLoginId);
setStartDateTime(midnightToday);
setEndDateTime(now);
setHierarchyMode('N');
setStatus('FT');
setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
setEndDate(now.format('DD/MM/YYYY HH:mm:ss'));

}


useEffect(() => {
  if (items && items.length > 0) {
    setSortedItems(items);
  }
}, [items]);


const parseDate = (dateStr) => {
  // Expected format: DD/MM/YYYY HH:mm:ss
  const [datePart, timePart] = dateStr.split(' ');
  const [day, month, year] = datePart.split('/');
  return new Date(`${year}-${month}-${day}T${timePart}`);
};

const handleSortByDate = () => {
  const newDirection = sortDirection === 'desc' ? 'asc' : 'desc';

  const sorted = [...sortedItems].sort((a, b) => {
    const dateA = parseDate(a.transactionDate);
    const dateB = parseDate(b.transactionDate);
    return newDirection === 'desc' ? dateA - dateB : dateB - dateA;
  });

  setSortedItems(sorted);
  setSortDirection(newDirection);
};


console.log("SortedItems======",sortedItems);


return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Transactions":"Transacciones"}/>
  </tr>

  <tr>
    {/* <td valign="top"style={{ borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)"}}nowrap="nowrap">

    </td> */}

<div style={{ display: 'flex' }}> 
    <LeftBgImage1 />
</div>

<td valign="top">
<title>Prepaid Movistar -Balance Annulment Report</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
   <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
       <NavLink
            to="/balanceAnnulmentReportp"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${ "menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab label={t('m_balanceAnnulmentReportp')} /></NavLink>
   </Tabs>
  </Box>
  <div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="80%">
            {/* body starts */}
          

    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>
          
               <Box style={{display:'flex', gap:'12px',marginTop:'10px'}}> 
              
          <TextField type="text"name="fromId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2616024')}`}
                        </span>} style={{maxWidth:'150px',width:'210px'}}
                        onChange={e => setFromId(e.target.value)} 
                        value={fromId}
                        size="15"            
              // onChange={e => setSalesId(e.target.value)} value={salesId} size="15" defaultValue=""
               />

                   <TextField type="text"name="subDistId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {/* {`${t('053')}`} */}
                      {`${ t(2616025)}`}
                       <RedAsterisk>*</RedAsterisk>
                        </span>} style={{maxWidth:'150px',width:'210px'}}
                        onChange={e => setSubDistId(e.target.value)} 
                        value={subDistId}
                        size="15"
              // onChange={e => setSalesId(e.target.value)} value={salesId} size="15" defaultValue=""
               />
<LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
            <DateTimePicker
                  style={{ maxWidth: '120px' }}
                  className={'datePickerrr'}
                  // label="Select Date and Time"
                  value={startDateTime}
                  onChange={handleStartDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
                  label={
                    <span>
                      {`${t('80')}`}
                   <RedAsterisk>*</RedAsterisk>
                    </span>}
                    format="DD/MM/YYYY HH:mm:ss"
                  inputFormat=" " // Keeps the input field empty unless a date is selected
                  renderInput={(params) => <TextField
                    {...params}
                    InputLabelProps={{
                      shrink: true, // Always shrink the label to allow for a floating effect
                    }}
                    placeholder={!startDateTime ? t('2480_057') : ''} // Show the placeholder only if no date is selected
                    fullWidth
                    variant="outlined"
                    sx={{ width: "140px", height: "40px", padding: '20px' }}
                  />}
                />
                
          </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                  style={{ marginTop: '20px', maxWidth: '150px' }}
               className={'datePickerrr mt20'}
               label={
                <span>
                  {`${t('81')}`}
                  <RedAsterisk>*</RedAsterisk>
                </span>}
                format="DD/MM/YYYY HH:mm:ss"
                  value={endDateTime}
                 onChange={handleEndDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
               renderInput={(params) => <TextField {...params} />} />

              </LocalizationProvider>

 <FormControl className={'selected_formcontrol'} size="small">
            <InputLabel id="demo-select-small-label" sx={{
                      backgroundColor: '#fff',
                      padding: '0 5px',
                    }}>
            {`${ t('2616026')}`}
            <RedAsterisk>*</RedAsterisk>
            </InputLabel>
            <Select className={'bankSelect'}style={{ maxWidth: '270px', width: '240px' }}
             labelId="demo-select-small-label" id="demo-select-small"
              label="status" value={status} 
              onChange={e =>setStatus(e.target.value)}>
              <MenuItem value="FT">{t('622')}</MenuItem>
              <MenuItem value="MN">{t('098')}</MenuItem>
              <MenuItem value="LFT">{t('FUNDLFT')}</MenuItem>
              <MenuItem value="ML">{t('FUNDML')}</MenuItem>
            </Select>
        </FormControl>
        
 <FormControl className={'selected_formcontrol'} sx={{  minWidth: 120 }} size="small">
                <InputLabel id="demo-select-small-label">{`${ t(2616027)}`}<RedAsterisk>*</RedAsterisk>
                </InputLabel>
                    <Select className={'bankSelect'}
                      labelId="demo-select-small-label" id="demo-select-small"
                      label="Modo de jerarquia"value={hierarchyMode} onChange={e => setHierarchyMode(e.target.value)}>
                        <MenuItem value="Y">{t('Y')}</MenuItem>
                        <MenuItem value="N">{t('N')}</MenuItem>
                      </Select>
          </FormControl>





{/* </Box>
<Box style={{display:'flex', gap:'20px'}}> */}


          <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
            onClick={handleSubmit1}
            >
              {t('2616028')} 
              </Button>
           
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
            onClick={clearData}
            >
              {t('2472_27')}
            </Button>
               {/* <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SaveIcon />}
            //onClick={clearData}
            >
              {t('2616030')}
            </Button> */}
               </Box>
            </Box>
{/* </fieldset>
</Box> */}

{/* </Box> */}
           <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
              </Grid>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
          <TableRow className="darkgray">
            <TableCell align="center">{t('2480_034')}</TableCell>
            <TableCell align="center"> {t('2480_087')}</TableCell>
        
            <TableCell align="center">{t('2480_049')}</TableCell>
            <TableCell align="center">{t('2481_066')}</TableCell>
            <TableCell align="center">{t('2616031')}</TableCell>
            {/* <TableCell align="center">{t('019')}</TableCell> */}
            <TableCell align="center">{t('2616025')}</TableCell>
            <TableCell align="center">{t('2480_049')}</TableCell>
            <TableCell align="center">{t('2481_066')}</TableCell>
            <TableCell align="center">{t('2616032')}</TableCell>

<TableCell
  className="whiteboldtext"
  align="center"
  onClick={handleSortByDate}
  style={{ cursor: 'pointer', userSelect: 'none', display: 'flex-center', justifyContent: 'center', alignItems: 'center' }}
>
  {t('023')}&nbsp;
  {sortDirection === 'asc' ? (
    <ArrowUpward fontSize="small" />
  ) : sortDirection === 'desc' ? (
    <ArrowDownward fontSize="small" />
  ) : (
    <UnfoldMore fontSize="small" />
  )}
</TableCell>

            {/* <TableCell align="center">{t('023')}</TableCell> */}



            <TableCell align="center">{t('2616033')}</TableCell>
            <TableCell align="center">{t('2616034')}</TableCell>
            <TableCell align="center">{t('2616035')}</TableCell>
            <TableCell align="center">{t('251620')}</TableCell>
            <TableCell align="center">{t('2616036')}</TableCell>
            <TableCell align="center">{t('2616037')}</TableCell>
           
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
            <TableRow>
              <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
              {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : items.length > 0 ? (
            // Show table rows when data is available
            sortedItems.map((item, index) => (
              <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
               
                <TableCell align="center">&nbsp;{item.transId}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.fromId}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.fromLevel}&nbsp;</TableCell>
                <TableCell align="center">{item.companyName}</TableCell>
                <TableCell align="center">{item.sourceCompName}</TableCell>
                 {/* <TableCell align="center">&nbsp;{item.pmntCardType}&nbsp;</TableCell> */}
                <TableCell align="center">&nbsp;{item.toId}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.tolevel}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.toCompanyName}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.destinationCompName}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.transactionDate}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{Number(item.annulledAmount).toFixed(2)}&nbsp;</TableCell>
                <TableCell align="center">
                  &nbsp;
                  {item.isPartial === 'Y' ? t('2616020') :
                   item.isPartial === 'N' ? t('2616021') :
                   item.isPartial}&nbsp;
                  </TableCell>
                <TableCell align="center">&nbsp;{Number(item.actualTransAmt).toFixed(2)}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.currency}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.originalTransID}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.channel}&nbsp;</TableCell>
              </TableRow>
            ))
          ) : (
            // Show 'No data found' message if no items are found after loading
            <TableRow>
             <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                      
                      {hasSubmitted ? t('2481_061') /* “No data found” */
                                   : t('038') /* “Please provide search criteria” */}</TableCell>
                     </TableRow>
          )}
        </TableBody>
      </Table>
      
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table> 

<div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                            {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,
                                                 }}
                                               >
                                                 <MenuItem onClick={() => { setAnchorEl(null); handlePdfDownload(); }}>{t('2480_080')}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleExcelDownload(); }}>{t('2480_081')}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleCsvDownload(); }}>{t('2480_082')}</MenuItem>
                                               </Menu>
                                             </div>
                                              : <></>}

                                            <Button
                                              className={"hoverEffectButton"}
                                              size="small"
                                              variant="contained"
                                              onClick={handleReturn}
                                              endIcon={<KeyboardReturn />}
                                            > {t('013')}</Button>
                                          </div>
                                          <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</td></tr>
                                      </div>

</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>

<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  );
}

export default BalanceAnnulmentReport;
