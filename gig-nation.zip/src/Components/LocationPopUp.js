import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';
// import { ToastContainer, toast } from "react-toastify";
import { useTranslation } from 'react-i18next';
import {
  Box,
  Button,
  Checkbox,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Tab,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  TextField,
  Typography,
  TableCell,
  Radio 
} from "@mui/material";
import SendIcon from '@mui/icons-material/Send';
import { useTheme, } from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import {ArrowRight, CancelRounded} from '@mui/icons-material';
import { useRef } from "react";
function LocationPopUp({handleSelectedGeographicalLoc}){

    const {t} = useTranslation();

    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
    const [open, setOpen] = useState(false);

    const exampleData = useSelector(state => state.example.data);
    const partnerLoginId = "135"; //exampleData.LOGIN_ID;
    const localeVar = "";
    const userName = process.env.REACT_APP_USERNAME
    const password = process.env.REACT_APP_PASSWORD;
    const profId = "";
    const allregions = "";
    const pageStatus = "";
    const subregions = "";
    const allcities = "";
    const allprovices = "";
    const locname = "";
    const locdesc = "";
    const buffermarket = "";
    const bufferregion = "";
    const bufferprovince = "";

    const [regionList, setRegionList] = useState([]);
    const [subRegionList, setSubRegionList] = useState([]);
    const [provinceList, setProvinceList] = useState([]);
    const [citiesList, setCitiesList] = useState([]);

    const [region, setRegion] = useState(" ");
    const [subRegion, setSubRegion] = useState(" ");
    const [province, setProvince] = useState(" ");
    const [city, setCity] = useState(" ");
    const [zipCode, setZipCode] = useState([]);
    const [locId,setLocId]=useState([]);
    const [selectedZipCode, setSelectedZipCode] = useState("");
    // const toastId = useRef(null);
    const [showError, setShowError] = useState(false);
   
    const handlePopup = () => {
        setOpen(true);
    };
    // MODAL CLOSING FUNCTION
    const handleClose = () => {
        setShowError(false);
        setRegion(" ")
        setSubRegion(" ")
        setProvince(" ")
        setCity(" ")

        setOpen(false);
    };

    useEffect(()=>{
        fetchRegionData();
    },[region, subRegion, province, city]);


   
   

    const fetchRegionData = async() => {
    
        console.log("region", region)
        console.log("subRegion", subRegion)
        console.log("province", province)
        console.log("city", city)

  

        const sRegion=region.split('#');
        const sSubRegion=subRegion.split('#');
        const sProvince=province.split('#');
        const sCity=city.split('#');


       const apiUrl = window.config.apiUrl + process.env.REACT_APP_LOCATION_API_URL;
       //const apiUrl = "http://10.10.19.189:8080/airmanage/rest/partner/locationPopUp";
        const response = await axios.post(apiUrl, {
            userName,
            password,
            partnerLoginId,
            profId,
            allregions:sRegion[0],
            pageStatus:"",
            subregions:sSubRegion[0],
            allcities:sCity[0],
            allprovinces:sProvince[0],
            locname:"",
            locdesc:"",
            buffermarket:"",
            bufferregion:"",
            bufferprovince:""
        });

        const data = response.data;
        console.log("data",data);

        console.log("data.allRegionsList",data.allRegionsList);
        console.log("data.subregionsList",data.subregionsList);
        console.log("data.allprovincesList",data.allprovincesList);
        console.log("data.allcitiesList",data.allcitiesList);
        console.log("data.locationname",data.locationname);
        const LocIdData = data.locId.flatMap(item => item.locId );
        console.log("LocIdData",LocIdData.toString());
        setRegionList(data.allRegionsList);
        setSubRegionList(data.subregionsList);
        setProvinceList(data.allprovincesList);
        setCitiesList(data.allcitiesList);
        setZipCode(data.locationname);
        setLocId(LocIdData.toString());
    }
    const submit = () => {  
      setShowError(false);
      if (!selectedZipCode && zipCode.length > 1) {
         setShowError(true);
  } else{

      let sregion='';
      let sstate='';
      let smunicipality='';
      let scolony='';
      let szipCode='';
      sregion=region.split('#');
      sstate=subRegion.split('#');
      smunicipality=province.split('#');
     scolony=city.split('#');
      szipCode=selectedZipCode;
      const zipCodeString = zipCode.map(item => item.locationname).join(',');

      const selectedobj={
        region,
        subRegion,
        province,
        city,
        zipCodeString
        
      }
      console.log("zipCode1========>",selectedZipCode);
if(zipCode.length >1){
      const selectedLocation=sregion[1]+'-->'+sstate[1]+'-->'+smunicipality[1]+'-->'+scolony[1]+'-->'+szipCode;
      const mapInAddress=smunicipality[1]+','+scolony[1]+','+zipCodeString;
      console.log("selectedobj",selectedobj);
      console.log("selectedLocation",selectedLocation);
      console.log("gmapsearch address"+mapInAddress)
      handleSelectedGeographicalLoc(selectedobj,selectedLocation,mapInAddress,locId);
      setSelectedZipCode(null);
      handleClose();
  }
  else{
    const selectedLocation=sregion[1]+'-->'+sstate[1]+'-->'+smunicipality[1]+'-->'+scolony[1]+'-->'+zipCodeString;
    const mapInAddress=smunicipality[1]+','+scolony[1]+','+zipCodeString;
    console.log("selectedobj",selectedobj);
    console.log("selectedLocation",selectedLocation);
    console.log("gmapsearch address"+mapInAddress)
    handleSelectedGeographicalLoc(selectedobj,selectedLocation,mapInAddress,locId);
    setSelectedZipCode(null);
    handleClose();

  }
  // window.location.reload();
}

}
    return(
        <>
        <tr><td >  <a  className="underline-link" onClick={() => {handlePopup()}}><ArrowRight className="animated-arrow" style={{color:'#39f'}} />  <span> {t("2424300")}</span></a></td></tr>
                     {/* MODAL STARTS HERE */}
        <Dialog
          fullScreen={fullScreen}
          open={open}
          onClose={() => {handleClose()}}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "25px" }}
            className={"headerTxt"}
            align="center"
          >
            
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={() => {handleClose()}}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
            }}
          >
            <CloseIcon />
          </IconButton>
          <DialogContent>
            <DialogContentText>
            <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
            <Table sx={{ minWidth: 500 }} size="small" className={''} stickyHeader aria-label="sticky table">
                  <TableHead >
                    <TableRow className={'darkgray subdistributor_table'}>
                      <TableCell  colSpan={4} align="center" sx={{backgroundColor: "#3399FF", color: "white"}}>
                        {t('geographiclocation')}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <div>      </div>



                  <TableBody>
                  <TableRow className={""}>
                    <TableCell
                      className={"strongerTxt"}
                      style={{ textAlign: "right" }}
                    >
                     {t('251610')}
                    </TableCell>
                    <TableCell className={"strongerTxt"}>
                                            <FormControl className={'width150'} sx={{ minWidth: 120 }} size="small">
                                                {/* <InputLabel id="demo-select-small-label">Payment</InputLabel> */}
                                                <Select
                                                    className={'bankSelect'}
                                                    labelId="demo-select-small-label"
                                                    id="demo-select-small"
                                                    value={region}
                            onChange={(e) => {
                                setRegion(e.target.value);
                                setSubRegion(' ');  // Reset State
                                setProvince(' ');   // Reset Municipality
                                setCity(' ');       // Reset City
                            }}
                                                >

                                                    <MenuItem value=" ">{t('056')}</MenuItem>

                                                    {regionList.length !== 0 && regionList.map((item) => 
                                                        <MenuItem value={item.marketId+'#'+item.markets}>{item.markets}</MenuItem>
                                                    )}

                                                </Select>
                                            </FormControl>
                    </TableCell>
                    <TableCell
                      className={"strongerTxt"}
                      style={{ textAlign: "right" }}
                    >
                     {t('251611')}
                    </TableCell>
                    <TableCell className={"strongerTxt"}>
                                            <FormControl className={'width150'} sx={{ minWidth: 120 }} size="small">
                                                {/* <InputLabel id="demo-select-small-label">Payment</InputLabel> */}
                                                <Select
                                                    className={'bankSelect'}
                                                    labelId="demo-select-small-label"
                                                    id="demo-select-small"
                                                    value={subRegion}
                            onChange={(e) => 
                              {
                                setSubRegion(e.target.value)
                                setProvince(' ');   // Reset Municipality
                                setCity(' ');       // Reset City

                            }}
                                                >

                                                    <MenuItem value=" ">{t('056')}</MenuItem>

                                                    {subRegionList.length !== 0 && subRegionList.map((item) =>
                                                            <MenuItem value={item.regionId+'#'+item.regions}>{item.regions}</MenuItem>
                                                    )}

                                                </Select>
                                            </FormControl>
                    </TableCell>
                  </TableRow>
                  <TableRow className={""}>
                    <TableCell
                      className={"strongerTxt"}
                      style={{ textAlign: "right" }}
                    >
                     {t('251612')}
                    </TableCell>
                    <TableCell className={"strongerTxt"}>
                                            <FormControl className={'width150'} sx={{ minWidth: 120 }} size="small">
                                                {/* <InputLabel id="demo-select-small-label">Payment</InputLabel> */}
                                                <Select
                                                    className={'bankSelect'}
                                                    labelId="demo-select-small-label"
                                                    id="demo-select-small"
                                                    value={province}
                            onChange={(e) => {setProvince(e.target.value)
                              setCity(' ');       // Reset City
                            }}
                                                >
                                                    
                                                    <MenuItem value=" ">{t('056')}</MenuItem>

                                                    {provinceList.length !== 0 && provinceList.map((item) =>  
                                                        <MenuItem value={item.provinceId+'#'+item.province}>{item.province}</MenuItem>
                                                    )}

                                                </Select>
                                            </FormControl>
                    </TableCell>
                    <TableCell
                      className={"strongerTxt"}
                      style={{ textAlign: "right" }}>
                     {t('251613')}
                     
                    </TableCell>
                    <TableCell className={"strongerTxt"}>
                                            <FormControl className={'width150'} sx={{ minWidth: 120 }} size="small">
                                                {/* <InputLabel id="demo-select-small-label">Payment</InputLabel> */}
                                                <Select
                                                    className={'bankSelect'}
                                                    labelId="demo-select-small-label"
                                                    id="demo-select-small"
                                                    value={city}
                                                    onChange={(e) =>setCity(e.target.value)}
                                                >   
                                                    <MenuItem value=" ">{t('056')}</MenuItem>
                            {citiesList.length !== 0 && citiesList.map((item) =>
                                                        <MenuItem value={item.cityId+'#'+item.city}>{item.city}</MenuItem>
                                                       
                                                    )}
                                                </Select>
                                            </FormControl>
                    </TableCell>
                  </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
              <div style={{position: 'relative',}}>
              {showError && (
            <div
              style={{
                color: 'red',
                fontSize: '11px',
                textAlign: 'center',
                position: 'absolute',
                left: '50%',
                transform: 'translateX(-50%)',
                padding: '5px 10px',
                marginTop: '8px' 
              }}
            >
              {t('1246')}
            </div>
          )}
          </div>
             <div style={{ marginTop: '40px' }}>
              {zipCode && (
  <>
  
    {Array.isArray(zipCode) && zipCode.length > 0 && (
                <>
        <TableContainer className={'shadowTable'} style={{ maxHeight: '300px', width: 'max-content', margin: 'auto' }}>
                        <Table sx={{ maxWidth: 100 }} size="small" className={''} stickyHeader aria-label="sticky table">
                        <TableHead >
                    <TableRow className={'darkgray subdistributor_table'}>
                <TableCell className={"strongerTxt"} style={{ textAlign: "center", color: "white", padding: '10px' }}>
                  {t('251650')}
                </TableCell>
                    </TableRow>
                  </TableHead>
            <TableBody style={{display: 'grid', gridGap: '10px',
    gridTemplateColumns: '1fr 1fr 1fr 1fr',
    gridAutoColumns: '1fr'}}>
              {zipCode.map((item, index) => (
                <TableRow key={index}>
                  <TableCell style={{ textAlign: "center", padding: '10px',display:'flex',gap:'0px',border:'0px' }}>
                        <Radio
                        style={{width:'15px',height:'15px',marginRight:'6px',marginTop:'-3px'}}
                          checked={selectedZipCode === item.locationname}
                          onChange={() => setSelectedZipCode(item.locationname)}
                          value={item.locationname}
                          name="zipCodeSelection"
                          inputProps={{ 'aria-label': item.locationname }}
                        />
                      {item.locationname} 
                  </TableCell>
                                </TableRow>
              ))}
                            </TableBody>
                        </Table>
                    </TableContainer>

                    <br></br>

                   <div style={{display:'flex', justifyContent:'center'}}>
                   <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />} onClick={() => submit()} > 
                        {t('26160199')}
                    </Button>&nbsp;
                    <Button className={'hoverEffectButton'} onClick={() => {handleClose()}} size="small" variant="contained" endIcon={<CancelRounded />} >
                    {t('6810')}
                    </Button>

                   </div>
                </>
    )}
  </>
)}
</div>


              
            </DialogContentText>
          </DialogContent>
        </Dialog>
        {/* MODAL ENDS HERE */}
        
        </>
    );
}

export {LocationPopUp}