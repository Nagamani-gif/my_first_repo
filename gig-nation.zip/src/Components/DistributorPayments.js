
/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import { Header, Footer, PaymentManagerHeading, LeftBgImage, JasperTopMenu } from './PageComponents';
import i18n from "./i18n";
import { Box, Menu, Button, CircularProgress, FormControl, FormControlLabel, FormLabel, Grid, InputLabel, MenuItem, Pagination, Paper, Radio, RadioGroup, Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField } from "@mui/material";
import React, { useState, useEffect, useCallback, useRef,useMemo } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CancelRounded, CloudDownload, KeyboardReturn } from "@mui/icons-material";
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import ExcelJS from 'exceljs';
import SendIcon from '@mui/icons-material/Send';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import dayjs from 'dayjs';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
//pdfMake.vfs = pdfFonts.default.pdfMake.vfs;


const DistributorPayments = () => {
  sessionStorage.setItem("selectedLink", "b_sellprepaidcards");

  const { t } = useTranslation();
  const localeVar = i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData"))
  const [partnerLoginId, setPartnerLoginId] = useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [items2, setItems2] = useState([]);
   const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
  const [submitted, setSubmitted] = useState(false);
  const [anchorEl, setAnchorEl] = useState();
  const closeTimeoutRef = useRef(null);
 const [moreDaysSubmit, setMoreDaysSubmit] = useState(false);
  const [hierarchyMode, setHierarchyMode] = useState('N');

 const toastId = useRef(null);
  const [distributorId, setDistributorId] = useState('');
  const [CellularNumber, setCellularNumber] = useState('');

    const now = dayjs();  
    const midnightToday = dayjs().startOf('day');
    const [startDateTime, setStartDateTime] = useState(midnightToday);
    const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
    
    const [endDateTime, setEndDateTime] = useState(now);
    const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));
  // const [startDateTime, setStartDateTime] = useState(dayjs().startOf('day'));
  // const [endDateTime, setEndDateTime] = useState(dayjs());

  const [apply,setApply] =useState(false);

  const [sortConfig, setSortConfig] = useState({ key: '', direction: 'asc' });
  let reportDays = process.env.REACT_APP_ReportDays;

  const formatForOracle = (date) => {
    return dayjs(date).format('DD/MM/YYYY HH:mm:ss');
  };
  

  const navigate = useNavigate();

  console.log("totalRecords++++++++++++", totalRecords)
  const handleChangePage = (event, newPage) => {
     const isValid = validateDateRange({
           startDateTime,
           endDateTime,
           reportDays,
           toast,
           toastId,
           t,
           submitted
         });
     
      if (!isValid) {
      setSubmitted(false);  // reset submit flag
      return;
    }

    if(!apply){
    
    if (!toast.isActive(toastId.current)) {
          toastId.current = toast.error(t('apply_validation'));
         setSubmitted(false);
        }
    return false;
    
    }
    setPage(newPage);
  };

  const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  
  const sortedItems = React.useMemo(() => {
    const sorted = [...items];
    if (sortConfig.key) {
      sorted.sort((a, b) => {
        const aVal = a[sortConfig.key];
        const bVal = b[sortConfig.key];
  
        if (!aVal) return -1;
        if (!bVal) return 1;
  
        if (sortConfig.direction === 'asc') {
          return aVal > bVal ? 1 : -1;
        } else {
          return aVal < bVal ? 1 : -1;
        }
      });
    }
    return sorted;
  }, [items, sortConfig]);
  

 const handleEndDateTimeChange = (newValue) => {
  setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };
    const handleStartDateTimeChange = (newValue) => {
      setApply(false);
      setStartDateTime(newValue); 
     const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
     setStartDate(formattedDateTime);
      console.log("startDate::::::",newValue)
       console.log("startDate::::::",formattedDateTime)
    };


  
const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24;

  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
    }
    return false;
  }

  return true;
};


const handleSubmit =  () => {
    
  const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t,
      submitted
    });


if (!isValid){
  setApply(false);
  return;
} 
    startRecord=0;
    endRecord =10;
     fetchData();
    setPage(1);
    setSubmitted(true);    
    setApply(true);
   // Enable watching page changes
  };

  const clearData = () => {
    setHierarchyMode('N');
    setDistributorId('');
    setCellularNumber('');
    setStartDateTime(dayjs().startOf('day'));
    setEndDateTime(dayjs());
    setMoreDaysSubmit(false);
    setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'))
    setEndDate(now.format('DD/MM/YYYY HH:mm:ss'))

  };
  

  useEffect(() => {
  if (!submitted) return;
      fetchData();
  }, [page,submitted]); // Only runs if page changes and form was submitted




  useEffect(() => {
    // Set the browser title
    document.title = t('2472_018');
  }, []);



  const fetchData = async () => {



    setItems([]);
    setTotalRecords(0)
    localStorage.removeItem('channels');
    setIsLoading(true);
    try {
       const apiUrl = window.config.apiUrlJasper +'/disPlayPaymentReport';              
      // const apiUrl = window.config.jasperUrl + process.env.REACT_APP_DISTPAYMENTS_URL;
       console.log("rz apiUrl-->",apiUrl)
      const response = await axios.post(apiUrl, {
        userName,
        password,
        localval: localeVar,
        distributorId: distributorId,
        fromDate : startDate,
        toDate : endDate,
        partnerId : partnerLoginId,
        levelFlag: hierarchyMode,
        beginingRecordNum:  startRecord,
        endingRecordNum: endRecord < 10 ? '10' :endRecord,
        download: ''
      });
      console.log("rz response::::::", response.data);
      console.log("rz TotalRecords::::::", response.data.summaryConfigArray[0].tot);
      if (response.status === 200) {
        setItems(response.data.summaryConfigArray);  // <-- Set items here!
        setTotalRecords(response.data.summaryConfigArray[0].tot || 0);
      //  setRecordsFound(response.data.summaryConfigArray[0].noRows || 0);
       // setTotalRecords(response.data.tot);
      }
     
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };

//   useEffect(() => {
//     if (partnerLoginId) {
//       fetchData();
//     }
//   }, [partnerLoginId, page]);

  const totalPages = Math.ceil(totalRecords / recordsPerPage);

  let startRecord = (page - 1) * perpage + 1;
let endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);

  const handleReturn = () => {
    navigate(-1);
  };

  const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
 

  const RedAsterisk = styled('span')({
    color: 'red',
  });




const fetchDataDownload = async () => {

 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       submitted
     });
 
if (!isValid) {
  setSubmitted(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmitted(false);
    }
return false;

}

  try {
    const apiUrl = window.config.apiUrlJasper+ '/disPlayPaymentReport';
     //const apiUrl = window.config.jasperUrl + process.env.REACT_APP_DISTPAYMENTS_URL;
    console.log('API URL:', apiUrl);
    console.log('Partner Login ID:', partnerLoginId);

    const responseDownload = await axios.post(apiUrl, {
      userName,
      password,
      localval: localeVar,
      distributorId: distributorId,
      fromDate: startDate,
      toDate: endDate,
      partnerId: partnerLoginId,
      levelFlag: hierarchyMode,
      beginingRecordNum: 0,
      endingRecordNum: 0,
      download: 'Y'
    });

    console.log("rz2 response::::::", responseDownload.data);
    console.log("rz2 TotalRecords::::::", responseDownload.data.summaryConfigArray?.[0]?.tot);
    console.log("rZsummaryConfigArray:", responseDownload.data.summaryConfigArray);

    let downloadData = [];

    if (responseDownload.status === 200 && responseDownload.data.summaryConfigArray) {
      const fetchedItems = responseDownload.data.summaryConfigArray;
      setItems2(fetchedItems);
      setTotalRecords(fetchedItems[0]?.tot || 0);

      downloadData = fetchedItems.map(item => ({
        c1DistributorId: item.c1DistributorId,
        distributorName: item.distributorName,
        level: item.level,
        parentName: item.parentName,
        mainDitributorName: item.mainDitributorName,
        c2AccBlcId: item.c2AccBlcId,
        c6PaymentDate: item.c6PaymentDate,
        c4ReferenceNum: item.c4ReferenceNum,
        c5CreatedBy: item.c5CreatedBy,
        c3PaymentAmount: item.c3PaymentAmount,
        currencySymbol: item.currencySymbol,
        depositAmount: item.depositAmount,
        depositDate: item.depositDate,
        bankName: item.bankName,
        bankReferenceNumber: item.bankReferenceNumber
      }));
    }

    console.log('Download Data:', downloadData);
    return downloadData;
  } catch (error) {
    console.error('Error fetching data:', error);
    return [];
  }
};


 
//excel

const handleDownload = async () => {
    const downloadItems = await fetchDataDownload();
      if (!downloadItems || downloadItems.length === 0) return;
    const totalRecords = downloadItems.length;
  const displayedRecords = downloadItems.length; // Adjust if needed

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('DistributorPayments');
    const numberOfColumns = 15; 

  // Title row
  const headingRow = worksheet.addRow([
    localeVar === 'en' ? "Distributor Payments" : "Pagos de distribuidor"
  ]);
    worksheet.mergeCells(headingRow.number, 1, headingRow.number, numberOfColumns);
    const headingCell = headingRow.getCell(1);
    headingCell.font = { bold: true };
    headingCell.alignment = { horizontal: 'center' };

    worksheet.addRow([]); // Empty row

  // Row with Total and Displayed Records
  const totalRow = worksheet.addRow(new Array(numberOfColumns).fill(''));

  const leftColSpan = Math.floor(numberOfColumns / 2);
  const rightColStart = leftColSpan + 1;
  
  // Total Records - Left
  totalRow.getCell(1).value = localeVar === 'en'
    ? `No. of records satisfied: ${totalRecords}`
    : `No.Total de Registros Encontrados: ${totalRecords}`;
  worksheet.mergeCells(totalRow.number, 1, totalRow.number, leftColSpan);
  totalRow.getCell(1).font = { bold: true };
  totalRow.getCell(1).alignment = { horizontal: 'left' };

  // Displayed Records - Right
  // totalRow.getCell(rightColStart).value = localeVar === 'en'
  //   ? `Displayed Records : ${displayedRecords}`
  //   : `Registros Mostrados : ${displayedRecords}`;
  // worksheet.mergeCells(totalRow.number, rightColStart, totalRow.number, numberOfColumns);
  // totalRow.getCell(rightColStart).font = { bold: true };
  // totalRow.getCell(rightColStart).alignment = { horizontal: 'right' };

    const columnHeaders = [
        t('5597_dis'), t('251608'), t('25160014'), t('25160015'), t('25160016'),
        t('25160017'), t('023'), t('referenceNo'), t('25160018'), t('25160019'),
        t('251620'), t('025'), t('25160020'), t('25160021'), t('25160022')
      ];
    const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });
    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
      item.c1DistributorId ? item.c1DistributorId : '---',
      item.distributorName ? item.distributorName : '---',
      item.level ? item.level : '---',
      item.parentName ? item.parentName : '---',
      item.mainDitributorName ? item.mainDitributorName : '---',
      item.c2AccBlcId ? item.c2AccBlcId : '---',
      item.c6PaymentDate ? item.c6PaymentDate : '---',
      item.c4ReferenceNum ? item.c4ReferenceNum : '---',
      item.c5CreatedBy ? item.c5CreatedBy : '---',
  item.c3PaymentAmount != null
    ? Number(item.c3PaymentAmount).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })
    : '---',
      item.currencySymbol ? item.currencySymbol : '---',
    item.depositAmount != null
    ? Number(item.depositAmount).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })
    : '---',
      item.depositDate ? item.depositDate : '---',
      item.bankName ? item.bankName : '---',
      item.bankReferenceNumber ? item.bankReferenceNumber : '---'
      ]);
      dataRow.eachCell(cell => {
      cell.alignment = { horizontal: 'center' };
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
      });
    });
    worksheet.addRow([]);
    worksheet.addRow([]).hidden = true;
  const emptyRow3 = worksheet.addRow([]);
  emptyRow3.hidden = true;

    const endOfReportText = t('0171'); // Replace with your translated text
    const endOfReportRow = worksheet.addRow([endOfReportText]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
    // Style the "End of Report" cell
    const endOfReportCell = endOfReportRow.getCell(1);
    endOfReportCell.font = { italic: true, underline: true, bold: true };
    endOfReportCell.alignment = { horizontal: 'center' };
 worksheet.columns = new Array(columnHeaders.length).fill({ width: 30 });

    // Protect the worksheet to make it read-only
    worksheet.protect('yourPassword', {
      selectLockedCells: true,
      selectUnlockedCells: true,
      formatCells: true,
      formatColumns: true,
      formatRows: true,
      insertColumns: false,
      insertRows: false,
      insertHyperlinks: false,
      deleteColumns: false,
      deleteRows: false,
      sort: false,
      autoFilter: false,
      pivotTables: false
    });

    // Generate and download the Excel file
    const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'DistributorPayments.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

//for pdf
//for pdf



const handleDownloadPdf = async () => {
    const downloadItems = await fetchDataDownload();
      if (!downloadItems || downloadItems.length === 0) return;
  const totalRecords = downloadItems.length;


    const headers = [
        t('5597_dis'), t('251608'), t('25160014'), t('25160015'), t('25160016'),
        t('25160017'), t('023'), t('referenceNo'), t('25160018'), t('25160019'),
        t('251620'), t('025'), t('25160020'), t('25160021'), t('25160022')
    ];

  const allRows = downloadItems.map(item => [
    item.c1DistributorId || '---',
    item.distributorName || '---',
    item.level || '---',
    item.parentName || '---',
    item.mainDitributorName || '---',
    item.c2AccBlcId || '---',
    item.c6PaymentDate || '---',
    item.c4ReferenceNum || '---',
    item.c5CreatedBy || '---',
  item.c3PaymentAmount != null
    ? Number(item.c3PaymentAmount).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })
    : '---',
    item.currencySymbol || '---',
    item.depositAmount != null
    ? Number(item.depositAmount).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })
    : '---',
    item.depositDate || '---',
    item.bankName || '---',
    item.bankReferenceNumber || '---'
  ]);

  const rowsPerPage = 20; // approximate, you can adjust based on your data
  const totalPages = Math.ceil(allRows.length / rowsPerPage);

  const content = [];

  for (let i = 0; i < totalPages; i++) {
    const start = i * rowsPerPage;
    const end = start + rowsPerPage;
    const currentRows = allRows.slice(start, end);
    const displayedCount = currentRows.length;

    // Only on first page: add title
    if (i === 0) {
      content.push({
        text: localeVar === 'en' ? 'Distributor Payments' : 'Pagos de distribuidor',
          style: 'title',
          alignment: 'center',
        color: '#3399FF',
        margin: [0, 0, 0, 5]
      });
    }

    // Add Total/Displayed Records just after heading, before table
    content.push({
      columns: [
        {
        text: localeVar === 'en'
            ? `No. of records satisfied: ${totalRecords}`
            : `No. Total de Registros Encontrados: ${totalRecords}`,
        alignment: 'left',
          fontSize: 7,
          margin: [0, 0, 0, 4]
      },
      // {
      //     text: localeVar === 'en'
      //       ? `Displayed Records : ${displayedCount}`
      //       : `Registros Mostrados : ${displayedCount}`,
      //     alignment: 'right',
      //     fontSize: 7,
      //     margin: [0, 0, 0, 4]
      //   }
      ]
    });

    // Add the table with headers on every page
    content.push({
          table: {
            headerRows: 1,
        widths: Array(headers.length).fill('auto'),
        body: [
          headers.map(header => ({
            text: header,
            style: 'tableHeader',
            noWrap: false
          })),
          ...currentRows
        ]
          },
          layout: {
        fillColor: (rowIndex) => (rowIndex === 0 ? '#3399FF' : null)
        },
      style: 'tableExample',
      pageBreak: i < totalPages - 1 ? 'after' : undefined
    });

    // End of Report only on last page
    if (i === totalPages - 1) {
      content.push({
          text: t('0171'),
          style: 'endText',
          alignment: 'center',
          margin: [0, 10, 0, 0]
      });
    }
        }

  const docDefinition = {
    content,
      styles: {
        title: { fontSize: 12, bold: true },
      recordCount: { fontSize: 8, bold: true },
        tableExample: { margin: [0, 5, 0, 15] },
      tableHeader: {
        bold: true,
        fontSize: 7,
        color: 'white',
        fillColor: '#3399FF'
      },
      endText: {
        italics: true,
        bold: true,
        decoration: 'underline',
        fontSize: 9
      }
      },
      defaultStyle: {
        fontSize: 6
      },
    pageOrientation: 'landscape',
    pageSize: 'A4'
    };

    pdfMake.createPdf(docDefinition).download('DistributorPayments.pdf');
  };
  
const handleDownloadCsv = async () => {
  const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

  const NULL_DISPLAY = "---";

  const safeVal = (val) =>
    val == null || String(val).trim() === "" ? NULL_DISPLAY : val;

  const formatAmount = (value) => {
    if (value == null || value === "") return NULL_DISPLAY;
    const num = parseFloat(value);
    return !isNaN(num) ? num.toFixed(2) : NULL_DISPLAY;
  };

  // Locale-safe date parsing (handles dd/MM/yyyy and dd/MM/yyyy HH:mm:ss)
  const formatDateTime = (value) => {
    if (!value || value === NULL_DISPLAY) return NULL_DISPLAY;

    let date = new Date(value);
    if (isNaN(date.getTime())) {
      // fallback for dd/MM/yyyy or dd/MM/yyyy HH:mm:ss
      const parts = value.split(/[/\s:]/);
      if (parts.length >= 3) {
        const [day, month, year, hour = '0', min = '0', sec = '0'] = parts;
        date = new Date(year, month - 1, day, hour, min, sec);
      }
    }

    if (isNaN(date.getTime())) return NULL_DISPLAY;

    const pad = (n) => (n < 10 ? "0" + n : n);
    return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

  const escapeCSV = (value) => {
    if (value == null || value === "") return '""';
    const strVal = String(value).trim().replace(/"/g, '""');

    if (/^\d+\.\d{2}$/.test(strVal)) {
      return `="${strVal}"`; // keep decimals in Excel
    } else if (/^\d{2}\/\d{2}\/\d{4}/.test(strVal)) {
      return `="${strVal}"`; // keep dates as text
    } else {
      return `"${strVal}"`;
    }
  };

  const totalRecords = downloadItems.length;
  const headingText =
    localeVar === "en" ? "Distributor Payments" : "Pagos de distribuidor";

  const headers = [
    t("5597_dis"), t("251608"), t("25160014"), t("25160015"), t("25160016"),
    t("25160017"), t("023"), t("referenceNo"), t("25160018"), t("25160019"),
    t("251620"), t("025"), t("25160020"), t("25160021"), t("25160022")
  ];

  const totalColumns = headers.length;
  const centerIndex = Math.floor(totalColumns / 2);

  const csvLines = [];

  // Row 1: Heading
  const headingRowArray = Array(totalColumns).fill("");
  headingRowArray[centerIndex] = headingText;
  csvLines.push(headingRowArray.map(escapeCSV).join(","));

  // Row 2: Record count
  const totalRowText =
    localeVar === "en"
    ? `No. of records satisfied: ${totalRecords}`
    : `No. Total de Registros Encontrados: ${totalRecords}`;
  const countRowArray = Array(totalColumns).fill("");
  countRowArray[0] = totalRowText;
  csvLines.push(countRowArray.map(escapeCSV).join(","));

  // Row 3: Headers
  csvLines.push(headers.map(escapeCSV).join(","));

  // Data rows
  downloadItems.forEach((item) => {
    const row = [
      safeVal(item.c1DistributorId),
      safeVal(item.distributorName),
      safeVal(item.level),
      safeVal(item.parentName),
      safeVal(item.mainDitributorName),
      safeVal(item.c2AccBlcId),
      formatDateTime(item.c6PaymentDate),
      safeVal(item.c4ReferenceNum),
      safeVal(item.c5CreatedBy),
      item.c3PaymentAmount != null
        ? Number(item.c3PaymentAmount).toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })
        : NULL_DISPLAY,
      safeVal(item.currencySymbol),
      item.depositAmount != null
        ? Number(item.depositAmount).toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })
        : NULL_DISPLAY,
      formatDateTime(item.depositDate),
      safeVal(item.bankName),
      safeVal(item.bankReferenceNumber),
    ];
    csvLines.push(row.map(escapeCSV).join(","));
  });


const endRow = Array(totalColumns).fill("");
endRow[centerIndex] = t('0171');
csvLines.push(endRow.join(","));

  // BOM for Excel UTF-8
  const BOM = "\uFEFF";
  const csvContent = BOM + csvLines.join("\n");

  // Download
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.setAttribute("download", "DistributorPayments.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          <Header />
          <tr height="65px">
            <PaymentManagerHeading />
            <TopMenu menuLink={localeVar === 'en' ? "Distributor Payments" : "Pagos de distribuidor"} />
          </tr>

          <tr>
            {/* <td valign="top"style={{ borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)"}}nowrap="nowrap">

    </td> */}
          
              <LeftBgImage />
   
            <td valign="top">
              <title>Partner Status Report</title>
                
              <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                <tbody>
                  <tr>
                    <td>
                      <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                        <tbody>
                          {/* MIDDLE ROW STARTS */}
                          <tr>
                            <td>
                              <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" height="100%">
                                <tbody>
                                  {/* <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
                                    <Tabs style={{ minHeight: '35px' }}>
                                           <NavLink
                                                  to="/distributorpayments"
                                                  onClick={(e) => highlightSelectedLink(e)}
                                                  // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
                                                  className={({ isActive }) => 
                                                    isActive ? 'activeProfilemenu' : `profile_menu 
                                                  ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
                                                  }
                                                ><Tab label={t('b_distributorpaymentsp')} /></NavLink>
                                    </Tabs>
                                  </Box> */}

<JasperTopMenu />

<div className={'mL8 input_boxess'}>
                                  <tr valign="top">
                                    <td width="80%">
                                      {/* body starts */}

                                        <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{ marginTop: '5px' }}>



                                          <Box style={{ display: 'flex', gap: '12px', marginTop: '10px' }}>

                                            <TextField type="text" name="canalID" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {`${t('5597_dis')}`}
                                                </span>} style={{ maxWidth: '250px', width: '150px' }}
                                              onChange={e => setDistributorId(e.target.value)} value={distributorId} size="15" defaultValue=""
                                            />
<LocalizationProvider
  dateAdapter={AdapterDayjs}
  adapterLocale={localeVar === 'en' ? 'en' : 'es'}
>
  <DateTimePicker
    className="datePickerrr"
    value={startDateTime}
    onChange={handleStartDateTimeChange}
    // onChange={(newValue) => setStartDateTime(newValue)}
    ampm={false}
    label={<span>{`${t('25160009')}`}
   <RedAsterisk>*</RedAsterisk>
    </span>}
    format="DD/MM/YYYY HH:mm:ss"
    renderInput={(params) => (
      <TextField
        {...params}
        InputLabelProps={{ shrink: true }}
        placeholder={!startDateTime ? t('80') : ''}
        fullWidth
        variant="outlined"
        sx={{ width: '140px', height: '40px', padding: '20px', marginLeft: '5px' }}
      />
    )}
  />
</LocalizationProvider>

<LocalizationProvider
  dateAdapter={AdapterDayjs}
  adapterLocale={localeVar === 'en' ? 'en' : 'es'}
>
  <DateTimePicker
    className="datePickerrr mt20"
    value={endDateTime}
     onChange={handleEndDateTimeChange}
    // onChange={(newValue) => setEndDateTime(newValue)}
    ampm={false}
    label={<span>{`${t('25160010')}`}<RedAsterisk>*</RedAsterisk></span>}
    format="DD/MM/YYYY HH:mm:ss"
    renderInput={(params) => (
      <TextField
        {...params}
        fullWidth
        variant="outlined"
        sx={{ width: '140px', height: '40px', padding: '20px', marginLeft: '5px', marginTop: '20px' }}
      />
    )}
  />
</LocalizationProvider>




                                            <FormControl className={'selected_formcontrol'} sx={{ minWidth: 120 }} size="small">
                                              <InputLabel
                                                id="demo-select-small-label"
                                                sx={{ backgroundColor: '#fff', padding: '0 5px' }}
                                              >
                                               
                                                {t('25160011')}
                                                  <RedAsterisk>*</RedAsterisk>
                                              </InputLabel>
                                              <Select
                                                className={'bankSelect'}
                                                style={{ maxWidth: '250px', width: '150px' }}
                                                labelId="demo-select-small-label"
                                                id="demo-select-small"
                                                value={hierarchyMode}
                                                label="Select Channel"
                                                onChange={(e) => setHierarchyMode(e.target.value)}
                                              >
                                                <MenuItem value="Y">{t('Y')}</MenuItem>
                                                <MenuItem value="N">{t('N')}</MenuItem>

                                                {/*  Dynamic options from API */}
                                              </Select>
                                            </FormControl>


  <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
    <Button
        style={{ height: '27px' }}
        className={'hoverEffectButton'}
        size="small"
        variant="contained"
        endIcon={<CheckCircleIcon />}
        onClick={handleSubmit}
      >
        {t('25160012')}
      </Button>

                                            <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
                                            onClick={clearData}
                                            >
                                              {t('045')}
                                            </Button>
                                            {/* <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SaveIcon />}
                                            //onClick={clearData}
                                            >
                                              {t('25160013')}
                                              </Button> */}
                          </Box>
               </Box>
{/* </fieldset>
</Box> */}

{/* </Box> */}
           <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
              </Grid>
              <TableContainer component={Paper} className="shadowTable" style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
      <TableHead>
  <TableRow className="darkgray">
    <TableCell align="center" onClick={() => requestSort('c1DistributorId')} style={{ cursor:'pointer' }}>
      {t('5597_dis')}&nbsp;
      {sortConfig.key === 'c1DistributorId' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('distributorName')} style={{ cursor:'pointer' }}>
      {t('251608')}&nbsp;
      {sortConfig.key === 'distributorName' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('level')} style={{ cursor:'pointer' }}>
      {t('25160014')}&nbsp;
      {sortConfig.key === 'level' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('parentName')} style={{ cursor:'pointer' }}>
      {t('25160015')}&nbsp;
      {sortConfig.key === 'parentName' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('mainDitributorName')} style={{ cursor:'pointer' }}>
      {t('25160016')}&nbsp;
      {sortConfig.key === 'mainDitributorName' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('c2AccBlcId')} style={{ cursor:'pointer' }}>
      {t('25160017')}&nbsp;
      {sortConfig.key === 'c2AccBlcId' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('c6PaymentDate')} style={{ cursor:'pointer' }}>
      {t('023')}&nbsp;
      {sortConfig.key === 'c6PaymentDate' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('c4ReferenceNum')} style={{ cursor:'pointer' }}>
      {t('referenceNo')}&nbsp;
      {sortConfig.key === 'c4ReferenceNum' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('c5CreatedBy')} style={{ cursor:'pointer' }}>
      {t('25160018')}&nbsp;
      {sortConfig.key === 'c5CreatedBy' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('c9PayableAmount')} style={{ cursor:'pointer' }}>
      {t('25160019')}&nbsp;
      {sortConfig.key === 'c9PayableAmount' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('currencySymbol')} style={{ cursor:'pointer' }}>
      {t('251620')}&nbsp;
      {sortConfig.key === 'currencySymbol' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('depositAmount')} style={{ cursor:'pointer' }}>
      {t('025')}&nbsp;
      {sortConfig.key === 'depositAmount' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('depositDate')} style={{ cursor:'pointer' }}>
      {t('25160020')}&nbsp;
      {sortConfig.key === 'depositDate' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('bankName')} style={{ cursor:'pointer' }}>
      {t('25160021')}&nbsp;
      {sortConfig.key === 'bankName' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>

    <TableCell align="center" onClick={() => requestSort('bankReferenceNumber')} style={{ cursor:'pointer' }}>
      {t('25160022')}&nbsp;
      {sortConfig.key === 'bankReferenceNumber' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
    </TableCell>
  </TableRow>
</TableHead>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={20} align="center" className="spinnerDiv">
                {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : sortedItems.length > 0 ? (
            sortedItems.map((item, index) => (
             <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
  <TableCell align="center">{item.c1DistributorId || '---'}</TableCell>
  <TableCell align="center">{item.distributorName || '---'}</TableCell>
  <TableCell align="center">{item.level || '---'}</TableCell>
  <TableCell align="center">{item.parentName || '---'}</TableCell>
  <TableCell align="center">{item.mainDitributorName || '---'}</TableCell>
  <TableCell align="center">{item.c2AccBlcId || '---'}</TableCell>
  <TableCell align="center">{item.c6PaymentDate || '---'}</TableCell>
  <TableCell align="center">{item.c4ReferenceNum || '---'}</TableCell>
  <TableCell align="center">{item.c5CreatedBy || '---'}</TableCell>
  <TableCell align="center">
{item.c3PaymentAmount != null
  ? Number(item.c3PaymentAmount).toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })
  : '---'}
  </TableCell>
  <TableCell align="center">{item.currencySymbol || '---'}</TableCell>
  <TableCell align="center">
    {item.depositAmount != null
  ? Number(item.depositAmount).toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })
  : '---'}
  </TableCell>
  <TableCell align="center">{item.depositDate || '---'}</TableCell>
  <TableCell align="center">{item.bankName || '---'}</TableCell>
  <TableCell align="center">{item.bankReferenceNumber || '---'}</TableCell>
</TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={20} align="center" className="redTxt" style={{ color: 'red' }}>
                {submitted
                ? t("2481_061")
                : t("038")}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
                                          <br></br>
<Table>
  <tfoot>
    <Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
      <Box
        sx={{ textAlign: "right", padding: "4px 0px 4px 0 !important" }}
        className={'displayFlex'}
      ></Box>

      {items.length > 0 ? (
        <Pagination
          count={totalPages}
          page={page}
          onChange={handleChangePage}
          showFirstButton
          showLastButton
        />
      ) : null}
    </Box>
    <tr></tr>
  </tfoot>
</Table>

<div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
  {items.length > 0 ? (
    <div onMouseLeave={handleClose}>
      <Button
        className="hoverEffectButton"
        size="small"
        variant="contained"
        endIcon={<CloudDownload />}
        onMouseEnter={handleHover}
      >
        {t('089')}
      </Button>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        MenuListProps={{
          onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
          onMouseLeave: handleClose,
        }}
      >
<MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{localeVar=="en"?"As":"Como"} PDF</MenuItem>
<MenuItem onClick={() => { setAnchorEl(null); handleDownload(); }}>{localeVar=="en"?"As":"Como"} Excel</MenuItem>
<MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{localeVar=="en"?"As":"Como"} CSV</MenuItem>
      </Menu>
    </div>
  ) : null}

  <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  >
    {t('013')}
  </Button>
</div>
<ToastContainer
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />
                                          <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                                        </table>
                                          </td></tr>
                                      </div>
                                  
                                </tbody>
                              </table>
                            </td>
                          </tr>{/* MIDDLE ROW ENDS HERE  */}
                        </tbody>
                      </table>
                    </td></tr>
                </tbody>
              </table>
            </td></tr>
          <tr height="60px"><td colSpan={2}>
            <Footer />
          </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default DistributorPayments
