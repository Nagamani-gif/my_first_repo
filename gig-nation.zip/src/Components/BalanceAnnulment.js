import { Footer, Header, JasperLeftMenu, LeftBgImage, LeftMenu, PaymentManagerHeading, TransactionTopMenu } from './PageComponents';
import TopMenu from './TopMenu';
import { useTranslation } from 'react-i18next';
import {Box, Button, Checkbox, styled, TextField } from '@mui/material';
import {CancelRounded, KeyboardReturn, Search} from '@mui/icons-material';

import { useNavigate } from 'react-router-dom';
import {useRef, useState, useEffect} from 'react';
import { useSelector } from 'react-redux';
import axios from 'axios';
// Importing toastify module
import { ToastContainer, toast } from "react-toastify";
import i18n from './i18n';

function BalanceAnnulment(){
    //sessionStorage.setItem("selectedIndex", 5);
    const {t} = useTranslation();
    sessionStorage.setItem("selectedLink", "e_transactions");
    const exampleData = JSON.parse(localStorage.getItem("userData"))
    console.log(exampleData, "example Data")
    const partnerLoginId = exampleData.LOGIN_ID; //"138242"//
    const userName = process.env.REACT_APP_USERNAME;// "MEXICO";
    const password = process.env.REACT_APP_PASSWORD; //"xius@1234";
    const localeVar = i18n.language;
    const transferReversalFlag = exampleData.TRANSFER_REVERSAL_FLAG_VAL;

    const [distributorId, setDistributorId] = useState('');
    const [transactionPassword, setTransactionPassword] = useState('');
    //const [partnerId, setPartnerId] = useState('');
    const [reverseAmt, setReverseAmt] = useState('');
    const [transId, setTransId] = useState('');
    const [transNumber, setTransNumber] = useState('');
    const [message, setMessage] = useState('');
    const toastId = useRef(null);

    const submitForm = async() => {
        if(document.getElementById("distributorId").value === ""){
            if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('balanceAnnulment1')); 
              }

         //  toast.error("Please enter valid from distributor");
            document.getElementById("distributorId").focus();
            return;
        }
        if(document.getElementById("reverseAmt").value === ""){
            if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('balanceAnnulment2')); 
              }
           //toast.error("Please enter valid annulment amount");
            document.getElementById("reverseAmt").focus();
            return;
        }
        if(document.getElementById("transId").value === ""){
            if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('balanceAnnulment3')); 
              }
           //toast.error("Please enter valid Fund Transfer ID");
            document.getElementById("transId").focus();
            return;
        }
        if(document.getElementById("transId").value === ""){
            if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('balanceAnnulment3')); 
              }
          // toast.error("Please enter valid Fund Transfer ID");
            document.getElementById("transId").focus();
            return;
        }
        if(document.getElementById("transNumber").value === ""){
            if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('balanceAnnulment4')); 
              }
           //toast.error("Please enter valid reference number");
            document.getElementById("transNumber").focus();
            return;
        }
        if(document.getElementById("transNumber").value === ""){
            if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('balanceAnnulment4')); 
              }
          // toast.error("Please enter valid reference number");
            document.getElementById("transNumber").focus();
            return;
        }
        if(document.getElementById("transactionPassword").value === ""){
            if(!toast.isActive(toastId.current) )  {
                toastId.current = toast.error(t('balanceAnnulment5')); 
              }
           //toast.error("Please enter Transaction Password");
            document.getElementById("transactionPassword").focus();
            return;
        }

        let distributorId = document.getElementById("distributorId").value;
        

        let transactionPassword = document.getElementById('transactionPassword').value;
        let isPartial = "N";
        
        if(document.getElementById("pSelect").checked){
            isPartial = "Y";
        }

    
        console.log("partnerId",partnerLoginId)
        console.log("localeVar",localeVar)
        console.log("transactionpassword",transactionPassword)
        console.log("distributedId",distributorId)
        console.log("isPartial",isPartial)
        console.log("transNumber",transNumber)
        console.log("transID",transId)
        console.log("reverseAmt",reverseAmt)
  
            const apiUrl = window.config.apiUrl + process.env.REACT_APP_BAL_ANNULMNT_SEARCH;
            const distributorIdUpper = distributorId.toUpperCase();
            const response = await axios.post(apiUrl, {
                userName,
                password,
                "partnerId": partnerLoginId,
                localeVar,
                "transactionpassword":transactionPassword,
                "distributedId":distributorIdUpper,
                isPartial,
                transNumber,
                "transID":transId,
                reverseAmt
            });
            const data = response.data;
            console.log("response",data);

            setMessage(data.message);

            console.log("message", message);
            
            // if(data.message ==='No Recent Transactions Found '){
            //     setTransId('');
            //     setTransactionPassword('');
            //     //document.getElementById('transactionPassword').value = "";
            // }else
            //  if(data.message){
            //     // if(!toast.isActive(toastId.current) )  {
            //     //     toastId.current = toast.error(data.message); 
            //     //   }
            //     setTransactionPassword('');
            //    // document.getElementById('transactionPassword').value = "";
            // }

            if(response.data.message ===t('2480_029')){
                setTransId('');
                //document.getElementById('transId').value="";
                document.getElementById('transactionPassword').value = "";
            }else if(response.data.message === t('2480_020')){
                document.getElementById('transactionPassword').value = "";
            }

            if( response.data.responseCode === "00"){

            navigate('./../balanceAnnulmentSubmit', 
                {state: {userName, password, partnerLoginId, localeVar, transactionPassword, distributorId, isPartial, transNumber, transId, reverseAmt} }
            )
        } 
        setTransactionPassword('');
    }

    const navigate = useNavigate();

    const handleReturn = () => {
      navigate(-1);
    };

    const numValidate = (e) => {

        const re = /^\d*\.?\d*$/;
        if (!re.test(e.target.value)) {
           return  false;
        }
        setReverseAmt(e.target.value);
        return true;
    }

    const transIdValidate = (e) => {
        const re = /^\d*.?\d*$/;
        if (!re.test(e.target.value)) {
           return  false;
        }
        setTransId(e.target.value);
        return true;
    }

    const transNumberValidate = (e) => {
        const re = /^\d*.?\d*$/;
        if (!re.test(e.target.value)) {
           return  false;
        }
        setTransNumber(e.target.value);
        return true;
    }

    const clear = () => {
        // document.getElementById("distributorId").value ='';
        setDistributorId('')
        setReverseAmt('');
        setTransId('');
        setTransNumber('');
        setMessage('');
        setTransactionPassword('');
        // document.getElementById('transactionPassword').value ='';
    }
    const RedAsterisk = styled("span")({
        color: "red",
      });
      const [isMandate, setIsMandate] = useState(false);
      const [isMandate1, setIsMandate1] = useState(false);
      const [isMandate2, setIsMandate2] = useState(false);
      const [isMandate3, setIsMandate3] = useState(false);
      const [isMandate4, setIsMandate4] = useState(false);
      const handleDistributorBlur = () => {
        if (distributorId.trim() === "") {
          setIsMandate(true);
        } else {
          setIsMandate(false);
        }
      };
      const handleReverseAmtBlur = () => {
        if (reverseAmt.trim() === "") {
          setIsMandate1(true);
        } else {
          setIsMandate1(false);
        }
      };
      const handleTransIdBlur = () => {
        if (transId.trim() === "") {
          setIsMandate2(true);
        } else {
          setIsMandate2(false);
        }
      };

   const handleTransNumber = () => {
        if (transNumber.trim() === "") {
          setIsMandate3(true);
        } else {
          setIsMandate3(false);
        }
      };
      const handleTransactionPwdBlur = () => {
        if (transactionPassword.trim() === "") {
          setIsMandate4(true);
        } else {
          setIsMandate4(false);
        }
      };
      useEffect(() => {
        // Set the browser title
          document.title = t('2472_022');
      }, []);

    return(
        <>
        
<table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <tbody>
                    
                            <Header />
                    <tr height="65px">
                    <PaymentManagerHeading />
                       
                                    <TopMenu />
                    </tr>
                    <tr>
                        {/* <td valign="top" style={{ borderRightStyle: 'solid', borderRightWidth: '1pt', borderColor: 'rgb(51 153 255)',
              maxWidth: '162px'
                         }} nowrap="nowrap">
                        </td> */}
                        <LeftBgImage />
                        <TransactionTopMenu />
<div className={`mL8 input_boxess balAnmulment ${transferReversalFlag !== "Y" ? 'displayFlexCenter': ''} `}>
                        <td valign="top" style={{width:'100%'}}>

                            
                            <table width="100%">
                                <tbody>
                                    {/* <tr>
                                        <td style={{paddingLeft: '10px'}} align='center' width="100%" class="headingText">{t('balanceAnnulment')}</td>
                                    </tr> */}
                                </tbody>
                            </table>
                            {/* <br></br> */}

                            { message !== "" &&
                                <p style={{marginTop:'5px', marginBottom:'5px'}}>
                                    <font color="red" size="2"> {message} </font>
                                </p>
                            }

                            <br></br>

                            {
                                transferReversalFlag !== "Y" 
                                ?
                                    i18n.language == 'en' 
                                    ?
                                    <>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <p className={"headingText"} align={"center"} style={{textAlign:'center'}}>You are not eligible to perform this operation. Please contact your administrator.</p>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <Button className={'hoverEffectButton'} style={{marginTop: '15px', marginBottom:'10px', float:'right'}} size="small" variant="contained" endIcon={<KeyboardReturn />}
                                        onClick={handleReturn}>{t('013')}</Button>
                                    </>
                                    :
                                    <>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <p className={"headingText"} align={"center"} style={{textAlign:'center'}}>Usted no es elegible para realizar esta operación. Por favor contacte a su administrador.</p>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <br></br>
                                        <Button className={'hoverEffectButton'} style={{marginTop: '15px', marginBottom:'10px',float:'right'}} size="small" variant="contained" endIcon={<KeyboardReturn />}
                                        onClick={handleReturn}>{t('013')}</Button>
                                    </>
 
                                :
                            <table align="left" cellspacing="2" cellpadding="2">

                                <tbody>

                                    <tr>
                                        {/* <td class="strongerTxtLable"> <span style={{color: 'red'}} class="redTxt">*&nbsp;</span>{t('fromDistributor')}</td>	 */}
                                            <td><TextField type="text"  label={
                                  <span>
                                    {`${t("fromDistributor")}`}
                                    <RedAsterisk>*</RedAsterisk>
                                  </span>
                                } id="distributorId" name="distributorId"   
                                className={`sampleInput mb5 ${isMandate ? 'mandateField' : ''}`}
                                onBlur={handleDistributorBlur}
                                value={distributorId} onChange={(e) => setDistributorId(e.target.value)} 
                                
                                /></td>
                                    </tr>
                                    
                                    <tr>
                                        {/* <td class="strongerTxtLable">&nbsp;&nbsp;{t('toDistributor')}</td>	 */}
                                        <td><TextField label={
                                  <span>
                                    {`${t("toDistributor")}`}
                                  </span>
                                } type="text" id="partnerId" name="partnerId" value={partnerLoginId} disabled className={"sampleInput mb5"} /></td>
                                    </tr>
                                    
                                    <tr>
                                        {/* <td class="strongerTxtLable"><span style={{color: 'red'}}class="redTxt">*&nbsp;</span>{t('annulmentAmount')}(MXN)</td>	 */}
                                        <td><TextField type="text" id="reverseAmt"  label={
                                  <span>
                                    {`${t("annulmentAmount")} (MXN)`}
                                    <RedAsterisk>*</RedAsterisk>
                                  </span>
                                } name="reverseAmt" value={reverseAmt} onChange={(e) => numValidate(e)}  
                                onBlur={handleReverseAmtBlur}
                                className={`sampleInput mb5 ${isMandate1 ? 'mandateField' : ''}`} /></td>
                                    </tr>
                                    
                                    <tr>
                                        {/* <td class="strongerTxtLable"><span style={{color: 'red'}} class="redTxt">*&nbsp;</span>{t('fundTransferID')}</td> */}
                                        	<td><TextField type="text" id="transId"   label={
                                  <span>
                                    {`${t("fundTransferID")}`}
                                    <RedAsterisk>*</RedAsterisk>
                                  </span>
                                } name="transId" value={transId} onChange={(e) => transIdValidate(e)} 
                                onBlur={handleTransIdBlur}
                                className={`sampleInput mb5 ${isMandate2 ? 'mandateField' : ''}`} /></td>
                                    </tr>                                    
                                    <tr>
                                        {/* <td class="strongerTxtLable"><span style={{color: 'red'}} class="redTxt">*&nbsp;</span>{t('referenceNo')}</td>	 */}
                                        <td><TextField type="text" id="transNumber"  label={
                                  <span>
                                    {`${t("referenceNo")}`}
                                    <RedAsterisk>*</RedAsterisk>
                                  </span>
                                } name="transNumber" value={transNumber} onChange={(e) => transNumberValidate(e)} 
                                onBlur={handleTransNumber}
                                className={`sampleInput mb5 ${isMandate3 ? 'mandateField' : ''}`}  /></td>
                                    </tr>
                                    
                                    <tr>
                                        {/* <td class="strongerTxtLable"><span style={{color: 'red'}} class="redTxt">*&nbsp;</span>{t('transactionPassword')}</td> */}
                                        <td><TextField type="password" style={{marginBottom:'1px'}} label={
                                  <span>
                                    {`${t("transactionPassword")}`}
                                    <RedAsterisk>*</RedAsterisk>
                                  </span>
                                } id="transactionPassword" name="transactionPassword" className={`sampleInput mb5 ${isMandate4 ? 'mandateField' : ''}`} 
                                value={transactionPassword} onChange={(e) => setTransactionPassword(e.target.value)} 
                                onBlur={handleTransactionPwdBlur}
                                autoComplete="new-password" /></td>
                                    </tr>
                                    <tr>
                                        <td class="strongerTxtLable">{t('isPartialReversal')} <Checkbox type="checkbox" id="pSelect" name="pSelect"  /> </td>	
                                        {/* <td></td> */}
                                    </tr>
                                    {/* <tr><td colspan="2">&nbsp;</td></tr> */}

                                    <tr>
                                        <td align="left">
                                           <Box style={{display:'flex', gap:'8px'}}>
                                            <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<Search />} onClick={() => {submitForm('search')}}> {t('043')} </Button>
                                            <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelRounded />} onClick={() => {clear()}}> {t('003')} </Button>
                                           </Box>
                                        </td>
                                    </tr>

                                </tbody>

                            </table>
                            }



                        </td>
                        </div>
                    </tr>

                    <tr height="60px">
                        <td colSpan={2}>
                            <Footer />
                        </td>
                    </tr>
                    <ToastContainer
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
                </tbody>
            </table>
        </>
    );

}

export {BalanceAnnulment}
