import React, { useEffect, useState } from 'react'
import SendIcon from '@mui/icons-material/Send';
import i18n from './i18n';
import {
    Box,
    Button,
    Checkbox,
    FormControl,
    Grid,
    InputLabel,
    MenuItem,
    Paper,
    Select,
    Tab,
    Table,
    TableBody,
    TableContainer,
    TableHead,
    TableRow,
    Tabs,
    TextField,
    Typography,
    TableCell,
    DialogTit,
    DialogTitle,
    Dialog,
    IconButton,
    DialogContent,
    DialogContentText,
  } from "@mui/material";
  import {KeyboardReturn, CancelRounded, ArrowRight } from '@mui/icons-material';
import axios from 'axios';
import { useTheme } from '@mui/material';
import { useSelector } from 'react-redux';
import CloseIcon from "@mui/icons-material/Close";
import { useMediaQuery } from '@mui/material';
import { useTranslation } from 'react-i18next';
import ViewPwdFileContent from './ViewPwdFileContent';



const PasswordRulesPopUp = ( props ) => {
    const {t} = useTranslation();
    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
    const [open, setOpen] = useState(false);
 
    const exampleData = JSON.parse(localStorage.getItem("userData"))
    let localeVar=i18n.language;
    let userName = process.env.REACT_APP_USERNAME;
    let password =  process.env.REACT_APP_PASSWORD;
    const partnerId = exampleData.LOGIN_ID;
    //console.log(partnerId);
    const [check , setCheck ] = useState(""); // State to store ruleArray
    const [rules, setRules] = useState([]); // State to store ruleArray
    const [trnrules, setTrnRules] = useState([]); // State to store ruleArray
    
 
 useEffect(()=>{
  fetchData();
 },[])
 
    const handlePopup = () => {
        setOpen(true);
        fetchData();
    };
    // MODAL CLOSING FUNCTION
    const handleClose = () => {
        setOpen(false);
    };
 
    const fetchData = async() => {
        const apiUrl = window.config.apiUrl + process.env.REACT_APP_PASSWORDRULES_URL;
        const response = await axios.post(apiUrl, {
             userName,
             password,
             localeVar,
            partnerId 
        });
        
        const { responseCode, passwordRules,transactionPasswordRules } = response.data;

      setCheck(responseCode);
      setRules(passwordRules);
      setTrnRules(transactionPasswordRules);
       // const responseData=response.data;
      console.log("responseCode=="+response.data);
    }


 console.log(props.visible, "VISIB:LE ???????????")
 
 
    return(
        <>
        {props.visible ?
        <>
          {/* <img
                                      border={0}
                                      src={require("../images/arrowicons.gif")}
                                      width={7}
                                      height={7}
                                    /> */}
                                    <a  className="underline-link"  onClick={() => {handlePopup()}}><ArrowRight className="animated-arrow" style={{color:'#39f'}} />  <span style={{fontSize:'12px'}}> {t("242402")}</span></a>
        {/* <span onClick={() => {handlePopup()}} className="pageLink1" style={{cursor:'pointer', fontSize:'12px'}}>{t('242402')}
        </span> */}
        </>
        :
       <></>
        
        }
                     {/* MODAL STARTS HERE */}
                     <Dialog
          fullScreen={fullScreen}
          open={open}
          onClose={() => {handleClose()}}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "25px" }}
            className={"headerTxt"}
            align="center"
          >
           
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={() => {handleClose()}}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
            }}
          >
            <CloseIcon />
          </IconButton>
          <DialogContent>
            <DialogContentText>
            <TableContainer component={Paper} className={'shadowTable passwordRulespopup'} style={{ maxHeight: '300px' }}>
            <Table sx={{ minWidth: 500 }} size="small" className={''} stickyHeader aria-label="sticky table">
                  {/* <TableHead > */}
                  {rules.length>0 && (     <TableRow >
  <TableCell className="strongerTxt" align='center'>
  <span style={{ fontWeight: '900', fontSize: '12px', color: '#3399FF' }}>
  {t('242489')}
</span>
      </TableCell>

  </TableRow>)}

{/* 
                    <TableRow className={'darkgray subdistributor_table'}>
                      <TableCell  colSpan={4} align="center" sx={{backgroundColor: "#3399FF", color: "white"}}>
                      {t('242489')}
                      </TableCell>
                    </TableRow> */}
                  {/* </TableHead> */}
                  <TableBody>
                 
                 {rules.length>0 &&
(rules.map((data, index) => (             
  <TableRow key={index}>
    <TableCell className="strongerTxt">
      {console.log("data==="+data)}
      {data.includes('$1') && (
        <span style={{cursor: 'pointer'}}>{index + 1} &nbsp; &nbsp; {t('5160')} <ViewPwdFileContent fileName={data.replace('$1','')}/></span>
      )} { data.includes('$2')&& (
        <span style={{cursor: 'pointer'}}>{index + 1} &nbsp; &nbsp; {t('5161')} <ViewPwdFileContent fileName={data.replace('$2','')}/></span>
      ) }
      {(!(data.includes('$1'))&&!(data.includes('$2')))&&(
       <span>{index + 1} &nbsp; &nbsp; {data}</span>
      )} 
    </TableCell>
  </TableRow>
)))}
{/* :(
  <TableRow>
<TableCell className="strongerTxt" align='center'>
NO DATA FOUND
</TableCell>
</TableRow>
) */}

{trnrules.length>0?(
  <>
<TableRow >
  <TableCell className="strongerTxt" align='center'>
  <span style={{ fontWeight: '900', fontSize: '12px', color: '#3399FF' }}>
  {t('4712')}&nbsp;&nbsp;{t('5742')}
</span>
      </TableCell>

  </TableRow>
  </>
  ):null}



{console.log("trnrules=="+trnrules.length)}
{trnrules.length>0 ?
(trnrules.map((data, index) => (   
  <TableRow key={index}>
    <TableCell className="strongerTxt">
      {console.log("index==="+index)}
     
        <span>{index + 1} &nbsp; &nbsp; {data}</span>
     
    </TableCell>
  </TableRow>
))):null}
                  </TableBody>
                </Table>
              </TableContainer>
              <br></br>
              <div align="center" gap={1}>
                {/* <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}>
                 Submit
                </Button>&nbsp; */}
                <Button className={'hoverEffectButton'} onClick={() => {handleClose()}} size="small" variant="contained" endIcon={<CancelRounded />}>
                {t('6810')}
                </Button>
              </div>
            </DialogContentText>
          </DialogContent>
        </Dialog>
        {/* MODAL ENDS HERE */}
       
        </>
    );
}

export default PasswordRulesPopUp