import React, { useState, useEffect } from 'react';
import TopMenu from './TopMenu';
import { useTranslation } from 'react-i18next';
import { Footer, Header, LeftBgImage,JasperTopMenu, PaymentManagerHeading } from './PageComponents';
import axios from 'axios';
import i18n from './i18n';
import { Box, Grid, Tab, Tabs } from '@mui/material';
import { NavLink, useLocation, useNavigationType } from 'react-router-dom';
import { CalendarMonth, CalendarToday, CallMade, PendingActions, PieChart, Today } from '@mui/icons-material';
import numeral from 'numeral';
import PieChartIcon from '@mui/icons-material/PieChart';


export default function BlankPage() {
   const location = useLocation();
   const selectedMenu = location.state?.selectedLinkNam || null;
console.log("selectedMenu", selectedMenu);
sessionStorage.setItem("selectedLink", selectedMenu);
    const { t } = useTranslation();
    const localVar=i18n.language
    console.log("llll="+i18n)

      useEffect(() => {
        document.title = t('2472_008')+' - '+t('b_distributorpaymentsp');
      }, []);
  //     const navigationType = useNavigationType(); // Detects how navigation happened
  // const [data, setData] = useState(true);

  // useEffect(() => {
  //   if (navigationType === "POP") {
  //     setData(false); // Clear data if navigated back
  //     sessionStorage.setItem("selectedLink", "")
  //   }
  // }, [navigationType]);

    
  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          
                  <Header />
          <tr height="65px">
          <PaymentManagerHeading />
          <TopMenu menuLink= {localVar==='en'?"Home":"Hogar"}/>
          </tr>
          <tr>
          <LeftBgImage />
            {/* <td valign="top" style={{ width:"100px" ,borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)" }}> */}
          {/* <img src={bg} alt="" style={{width:'100%', height:'100%', objectFit:'cover'}} /> */}
            {/* </td> */}
            <td valign="top">
              <meta httpEquiv="Content-Type" content="text/html; charset=ISO-8859-1" />
              <title>homepage</title>
            {/* {data && <JasperTopMenu />}   */}
            <JasperTopMenu />
              {/* <div>
                <h1>Welcome to the Home Page!</h1>
                {data ? (
                  <>
                    <p>Site Language: {data.siteLanguage}</p>
                    <p>Locale: {data.localeValue}</p>
                    <p>Country: {data.countryValue}</p>
                  </>
                ) : (
                  <p>Loading...</p>
                )}
              </div> */}
              
            </td>
          </tr>
          <tr height="55px">
            <td colSpan={2}>
              <link href="/airmanage/networkadmin/stylesheets/abcstyles-new.css" rel="stylesheet" type="text/css" />
               <Footer />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
