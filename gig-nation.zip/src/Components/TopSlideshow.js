import React, { useState, useEffect, useRef } from 'react';
import { Box, Grid } from '@mui/material';
import Person2 from '@mui/icons-material/Person2';
import { t } from 'i18next';
import { useTranslation } from "react-i18next";
import axios from 'axios';

const DistributorBlock = () => {
    const [expanded, setExpanded] = useState(false); // Initially collapsed
    const [contentWidth, setContentWidth] = useState(170); // Default collapsed width
    const contentRef = useRef(null);
    const [accountBalance, setAccountBalance] = useState('');
    const [credit, setCredit] = useState('');
    const [firstTimeExpanded, setFirstTimeExpanded] = useState(false); 
    const exampleData = JSON.parse(localStorage.getItem("userData"));

    const partnerLoginId = exampleData?.LOGIN_ID;
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;

    console.log("exampleData", exampleData);
    useEffect(() => {
        // Automatically expand on page load and collapse after 3 seconds
        setExpanded(true);
        const timer = setTimeout(() => {
            setExpanded(false); // Collapse after 3 seconds
            if (!firstTimeExpanded) {
                setFirstTimeExpanded(true);
            }
        }, 4000); // Adjust the time as needed

        return () => clearTimeout(timer); // Cleanup on component unmount
    }, []);
    useEffect(() => {
        if (contentRef.current) {
            const width = contentRef.current.scrollWidth; // Get content width
            setContentWidth(expanded ? width : 170); // Adjust based on expanded state
        }
    }, [expanded]);
 // Handle hover events
    const handleMouseEnter = () => {
        setExpanded(true);
    };

    const handleMouseLeave = () => {
        setExpanded(false);
    };
  const {t} = useTranslation();
  useEffect(() => {
    const fetchData = async () => {
        try {
            const apiUrl =window.config.apiUrl+process.env.REACT_APP_GET_BALANCE;
            const response = await axios.post(apiUrl, {
                userName,
                password,              
              partnerLoginId
            });
            const data = response.data;
            setAccountBalance(data.accountBalance);
            setCredit(data.creditOrBalance);


            console.log("response top",data);
        } catch (error) {
            // setError(error.message);
        } finally {
        }
    };

    fetchData();
}, []);
    return (
        <>
       
        <div  className="distributor-block"
            style={{
                width: `${firstTimeExpanded ? contentWidth : contentWidth + 50}px`, // Dynamic width based on content size
                transition: 'width 1s ease-in-out',
            }}
            
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}>
                
    <Box ref={contentRef} style={{ display: 'flex', gap: expanded ? '4px' : '0px' }}>
    &nbsp;
           
        {expanded && (
                    <>
        <Box className="additional-info">
         

        <div className="distributor-id"><b>{t('008')}:</b> {exampleData.LOGIN_ID}</div>
        <div><b>{t('7056')}:</b> {exampleData.PARENT_ID ? exampleData.PARENT_ID : '- -'}</div>
        </Box>

        <Box className="additional-info">
            <div className="user-name" style={{textTransform:'capitalize'}}><b>{t('7055')}:</b> {exampleData.FIRST_NAME+ " " +exampleData.LAST_NAME}</div>
            <div style={{textTransform:'capitalize'}}><b>{t('031')}:</b> {exampleData.COMPANY_NAME}</div>
        </Box>
        

        </>
        )}
         <div style={{ textAlign: 'left'}}>
              
              {/* <div><b>{t('009')}:</b> {accountBalance}</div>
              <div><b>{t('010')} {t('011')}:</b> {credit}</div> */}
              <div><b>{t('011')}:</b> <span style={{fontSize:expanded ? '10px' :'12px'}}>{accountBalance}</span></div>
              <div><b>{t('010')} {t('01000')}:</b> <span style={{fontSize:expanded ? '10px' :'12px'}}>{credit}</span></div>
           </div>
           &nbsp;
    </Box>
</div>
<Person2 className="userIconn" style={{color:'#39f', marginTop:'16px'}}  onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave} />
</>
    );
};

export default DistributorBlock;
