/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import {Header, Footer, ProfileMenu, PaymentManagerHeading, LeftBgImage} from './PageComponents'
import TopMenu from './TopMenu';
import React from 'react';
import { useTranslation } from 'react-i18next';
import i18n from './i18n';
import Button from '@mui/material/Button';
import { CancelRounded, KeyboardReturn, RemoveRedEyeRounded } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useState,useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import {
  Box,
  Checkbox,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Pagination,
  Paper,
  Select,
  Tab,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  TextField,
  Typography,
} from "@mui/material";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import { CircularProgress } from '@mui/joy';

function Profile(input={}){
 // sessionStorage.setItem("selectedIndex", 1);
 sessionStorage.setItem("selectedLink", "a_profile");
const localeVar=i18n.language;
const location = useLocation();
const [partnerData , setPartnerData] = useState({});
const [profiles1 , setProfiles1] = useState([]);
const [distributorList1 , setDistributorList1] = useState([]);
const [partnerTypeId , setPartnerTypeId] = useState('');
const [isLoading, setIsLoading] = useState(true);
useEffect(() => {
  setTimeout(()=>{
  setIsLoading(false);
  }, 1000)
  },[])
// const { distId } = location.state || {};
const { distId, toAcctType } = location.state || {};
console.log("toAcctType::::::profile::::::::::",toAcctType);
//const pwdMsg = location.state?.pwdMsg || '';
const {pwdMsg } = location.state || {};
console.log("distId",distId);
console.log("pwdMsg",pwdMsg);


if (!pwdMsg || pwdMsg) {
  window.history.replaceState({}, document.title);

}



  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

  const {t} = useTranslation();

  const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
  console.log("exampleData LOGIN_ID====>"+exampleData.LOGIN_ID);
 
  let partnerLoginId = exampleData.LOGIN_ID;

  const userName = process.env.REACT_APP_USERNAME;
  const password = process.env.REACT_APP_PASSWORD;

  let partnerId = exampleData.LOGIN_ID;
  if (distId !== undefined) {
    partnerId=distId;
  }
  const information = "";
  const methodName = "";
  const activeCurrencyPrecision = exampleData.activeCurrencyPrecision;
  const activeCurrencySymbol = exampleData.activeCurrencySymbol;


  useEffect(() => {
    // Set the browser title
    document.title = "Prepaid Movistar - Channel Distributor Profile";
    document.title = t('2472_007');
  }, []);
  useEffect(() => {

    const fetchDataAsync = async () => {
      try {
        await fetchData(); // Call your existing fetchData function asynchronously
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    }
      fetchDataAsync(); // Fetch data when the component mounts
  }, []); // Empty dependency array ensures this effect runs only once on mount


  const fetchChannels = async (channelList) => {

    //alert(channelList);
    //console.log("channelList=="+channelList)
    //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
    const apiUrl = window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
    console.log(apiUrl);
    const response = await axios.post(apiUrl, {
      userName,
      password,
      localeVar,
      channelTransAl: channelList,
    });
    // const[channels]=response.data;

    localStorage.setItem("channels", JSON.stringify(response.data.channels));
   // alert(response.data.channels);
  };



  const fetchData = async () => {
    try {
      // Fetch data from API
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_VIEWPARTNERDETAILS_URL;
      const response = await axios.post(apiUrl, {
        userName,
        password,
        partnerLoginId,
        partnerId,
        information,
        methodName,
        activeCurrencyPrecision,
        activeCurrencySymbol,
        localeVar

      });
    
      console.log("response.data"+JSON.stringify(response.data));

      setPartnerData(response.data);
      const {profiles,distributorList} = response.data;
      setProfiles1(profiles)
      setDistributorList1(distributorList)
      setPartnerTypeId(response.data.partnerTypeId)
      fetchChannels(response.data.promTopUpList)
    } catch (error) {
      console.error("An error occurred:", error);
      // Handle error, e.g., display error message to the user
    }
  };

 
  console.log("profiles-->"+profiles1);
  let chunkedData=[];
  if(profiles1!=undefined){
   chunkedData = profiles1.reduce((resultArray, item, index) => {
    const chunkIndex = Math.floor(index / 4);

    if (!resultArray[chunkIndex]) {
      resultArray[chunkIndex] = []; // start a new chunk
    }

    resultArray[chunkIndex].push(item);

    return resultArray;
  }, []);
}
 let chunkedData2=[];
  if(distributorList1!=undefined){
   chunkedData2 = distributorList1.reduce((resultArray, item, index) => {
    const chunkIndex = Math.floor(index / 4);

    if (!resultArray[chunkIndex]) {
      resultArray[chunkIndex] = []; // start a new chunk
    }

    resultArray[chunkIndex].push(item);

    return resultArray;
  }, []);
}
  
const distClick =(distId)=>{
  navigate('/modifyProfile', { state: {distId} })
}
    return(
    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
     
    <tbody>
   
    
         <Header/>

      <tr height="65px">
      <PaymentManagerHeading />
      <TopMenu menuLink= {localeVar==='en'?"Profile":"Perfil"}/>
    </tr>
      
      {/* </tr> */}

      <tr>
      <LeftBgImage />

    {/* <table border={0} width="100%" cellSpacing={0} cellPadding={1}>
  <tbody><tr>
      <td width="100%" align="left" style={{paddingLeft: '10px'}} className="headingText">{t('006')}</td>{" "}</tr>{" "}  
</tbody>
</table> */}
    <table border={0} width="100%" className={'profileScreen'} cellSpacing={0} cellPadding={1}>
    {/* <table border={0} width="100%" cellSpacing={0} cellPadding={1}> */}
  <tbody>
    <ProfileMenu/>
    <tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
    </tr>
  </tbody>
  <div  className={'mL8'}>
 <table
    border={0}
    width="100%"
    cellSpacing={0}
    cellPadding={2}
    bordercolor="red"
   
  >
   <tbody>
   {pwdMsg!==undefined&& pwdMsg!=='SUCCESS'?( <tr>
        <td width="59%" align="center" className="redTxt">
        {t('0169')}
        </td>
      </tr>):null}


      {pwdMsg!==undefined && pwdMsg ==='SUCCESS'?( <tr>
        <td width="59%" align="center" className="redTxt">
        {t('24244256')}
        </td>
      </tr>):null}
     
      {/* <tr>
        <td width="59%" align="center" className="strongerTxt">
          {t('251642')}
        </td>
      </tr> */}
      </tbody>
      </table>
      {isLoading && <><br /><div className={'spinnerDiv'}> {t("Processing...")} <CircularProgress size="sm" /></div></>}
    {!isLoading && <>

  <table border={0} width="100%" cellSpacing={0} cellPadding={0} >
    <tbody>
      <tr>
        <td colSpan={8}>
        <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
        <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">  
          
             <TableHead>

             <TableRow>
             {/* <TableCell className="whiteboldtext" style={{    backgroundColor: 'transparent',
    color: '#39f',
    border: '1px solid',
    borderRadius: '8px 8px 0px 0'}} align="center" colSpan={8}>
                  {" "}
                  {/* {t('251642')}{" "} 
                  {partnerTypeId != 6 ? t('distributor') : t('251642') } 
                </TableCell> */}
                </TableRow>
                <TableRow className="darkgray">
                <TableCell align="center" className="whiteboldtext">
                
                {/* {toAcctType === "5" ? t('242435') : t('251601')}   */}
               {partnerData.textTitle}
                </TableCell>
                <TableCell align="center" className="whiteboldtext">
                {partnerTypeId === "5" ? t('251602') : t('054')}
                </TableCell>
                {partnerData.ForPanama === 'true' &&(
                <TableCell align="center" className="whiteboldtext">{t('251603')}</TableCell>
                )}
                {partnerData.postToSCLEnableFlag === 'Y' && (
                <>
                <TableCell align="center" className="whiteboldtext">{t('251603')}</TableCell>
                <TableCell align="center" className="whiteboldtext">{t('251604')}</TableCell>
                </>
                )}
                <TableCell align="center" className="whiteboldtext">{t('251605')}</TableCell>
                {partnerData.partnerParentIdPresent ==='NoParent' && ( 
                <TableCell align="center" className="whiteboldtext">{t('251606')}</TableCell>
                )}
                <TableCell align="center" className="whiteboldtext">{t('251607')}</TableCell>
                <TableCell align="center" className="whiteboldtext">{t('251608')}</TableCell>
                {partnerData.partnerTypeId === 5 && partnerData.creditControlSystem === 'NonMexico' && (
                <TableCell align="center" className="whiteboldtext">{t('3114')}</TableCell>
                )}
                {/* <TD class='whiteboldtext'>Profiles Name</TD> */}
              </TableRow>
             </TableHead>
              <TableBody>
              <TableRow className="lightyellow">
              {partnerData.status !== 'R' && (  <TableCell className="smallerTxt" align="center">
                <span style={{color:"#3399FF", cursor:'pointer'}} onClick={()=>{distClick(partnerData.distributorId)}}> 
                {/*    <a
                    href="javascript:assignPartnerValues();"
                    onmouseover="window.status=''; return true"
                    className="nav"
                     > */}
                   {!partnerData.distributorId?"---":partnerData.distributorId}&nbsp;
                  {/* </a> */}
                  </span>
                </TableCell>)}
                {partnerData.status === 'R' && (<TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.distributorId?"---":partnerData.distributorId}&nbsp;
                </TableCell>)}
                <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.mdn?"---":partnerData.mdn}&nbsp;
                </TableCell>
                {partnerData.ForPanama === 'true' &&(
                  <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.sclUserName?"---":partnerData.sclUserName}&nbsp;
                </TableCell>)}
                {partnerData.postToSCLEnableFlag === 'Y' && (
                <>
                <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.sclUserName?"---":partnerData.sclUserName}&nbsp;
                </TableCell>
                <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.sclClientCode?"---":partnerData.sclClientCode}&nbsp;
                </TableCell>
                </>)}
                <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.discount?"---":partnerData.discount+"%"}&nbsp;
                </TableCell>
                {partnerData.partnerParentIdPresent ==='NoParent' && (  
                  <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.chargeMode?"---":partnerData.chargeMode}&nbsp;
                </TableCell>)}
                <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.company?"---":partnerData.company}&nbsp;
                </TableCell>
                <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.distributorName?"---":partnerData.distributorName}
                </TableCell>
                {partnerData.partnerTypeId === 5 && partnerData.creditControlSystem === 'NonMexico' && (
                <TableCell className="smallerTxt" align="center">
                  &nbsp;{!partnerData.distributorRatingDESC?"---":partnerData.distributorRatingDESC}
                </TableCell>
                )}
                {/* <TD class='smallerTxt' align='center'>Default</TD> */}
              </TableRow>
            </TableBody>
          </Table>
          </TableContainer>
        </td>
      </tr>
      <tr>
        <td>&nbsp;</td>{" "}
      </tr>
      <tr>
        
        <td colSpan={8}>
        <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
        <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">  
        <TableHead>
        <TableRow >
                {/* <TableCell style={{    backgroundColor: 'transparent',
    color: '#39f',
    border: '1px solid',
    borderRadius: '8px 8px 0px 0'}}  className="whiteboldtext" align="center" colSpan={5}>
                  {" "}
                  {t('251609')}{" "}
                </TableCell> */}
              </TableRow>
              <TableRow className="darkgray">
                <TableCell align="center" className="whiteboldtext" width="20%">
                {t('251610')}{" "}
                </TableCell>
                <TableCell align="center"  className="whiteboldtext" width="20%">
                {t('251611')}
                </TableCell>
                <TableCell align="center"  className="whiteboldtext" width="20%">
                {t('251612')}{" "}
                </TableCell>
                <TableCell align="center" className="whiteboldtext" width="20%">
                {t('251613')}{" "}
                </TableCell>
                <TableCell align="center"  className="whiteboldtext" width="20%">
                {t('251614')}
                </TableCell>
              </TableRow>
              </TableHead>
              <TableBody>
              <TableRow className="lightyellow">
                <TableCell className="arlCtrBlk" width="20%">
                {!partnerData.region?"---":partnerData.region}
                </TableCell>
                <TableCell className="arlCtrBlk" width="20%">
                {!partnerData.state?"---":partnerData.state}
                </TableCell>
                <TableCell className="arlCtrBlk" width="20%">
                {!partnerData.municipality?"---":partnerData.municipality}
                </TableCell>
                <TableCell className="arlCtrBlk" width="20%">
                {!partnerData.colony?"---":partnerData.colony}
                </TableCell>
                <TableCell className="arlCtrBlk" width="20%">
                {!partnerData.geoLocation?"---":partnerData.geoLocation}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
          </TableContainer>
        </td>
      </tr>
      <tr>
        <td>&nbsp;</td>{" "}
      </tr>
    </tbody>
  </table>
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">  
  <TableHead>
      <TableRow className="darkgray">
       {partnerData.tmpMultiLevlDesc !== '---' &&(
        <TableCell align="center"  className="whiteboldtext">{t('251615')}</TableCell>
       )}
       {partnerData.tmpMultiLevlRecDesc !== '---' &&(
        <TableCell align="center"  className="whiteboldtext">{t('251616')}</TableCell>
       )}
       {partnerData.tmpMultiLevelDesc !== '---' &&(
        <TableCell align="center"  className="whiteboldtext">{t('251617')}</TableCell>
       )}
       {partnerData.tmpMultiLevelRecDesc !== '---' &&( 
        <TableCell align="center"  className="whiteboldtext">{t('251618')}</TableCell>
       )}
        <TableCell align="center"  className="whiteboldtext">{t('251619')}</TableCell>
        <TableCell align="center"  className="whiteboldtext">{t('251620')}</TableCell>
      </TableRow>
   </TableHead>
      <TableBody>
      <TableRow className="lightyellow">
      {partnerData.tmpMultiLevlDesc !== '---' &&(
        <TableCell className="smallerTxt" align="center">
         {partnerData.multiNetTransEnabled === 'Y' ? t('Y') :
          partnerData.multiNetTransEnabled === 'N' ? t('N') : '---'}
        </TableCell>
      )}
      {partnerData.tmpMultiLevlRecDesc !== '---' &&(
        <TableCell className="smallerTxt" align="center">
        {partnerData.multiNetRecEnabled === 'Y' ? t('Y') : 
         partnerData.multiNetRecEnabled === 'N' ? t('N') : '---'}
        </TableCell>
      )}
      {partnerData.tmpMultiLevelDesc !== '---' &&(
        <TableCell className="smallerTxt" align="center">
        {partnerData.multiLevTransEnable === 'Y' ? t('Y') : 
         partnerData.multiLevTransEnable === 'N' ? t('N') : '---'}
        </TableCell>
      )}
       {partnerData.tmpMultiLevelRecDesc !== '---' &&(
        <TableCell className="smallerTxt" align="center">
        {partnerData.multiLevRecEnable === 'Y' ? t('Y') : 
         partnerData.multiLevRecEnable === 'N' ? t('N') : '---'}
        </TableCell>
       )}
        <TableCell className="smallerTxt" align="center">
        {partnerData.singleFundSourceHierarcy === 'Y' ? t('Y') : 
         partnerData.singleFundSourceHierarcy === 'N' ? t('N') : '---'}
        </TableCell>
        <TableCell className="smallerTxt" align="center">
        {!partnerData.currency?"---":partnerData.currency}
        </TableCell>
      </TableRow>
    </TableBody>
  </Table>
  </TableContainer>
  <br />
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table"> 
  <TableHead>
      <TableRow className="darkgray">
        <TableCell align="center"  className="whiteboldtext">{t('251621')}</TableCell>
        {partnerData.tmpPayString === 'Display' && (
         <>
           {partnerData.tempPayTStr === '3' && (
             <TableCell align="center" className="whiteboldtext">{t('251707')}</TableCell>
           )}
           {partnerData.tempPayTStr === '4' && (
             <TableCell align="center" className="whiteboldtext">{t('251708')}</TableCell>
           )}
           {partnerData.tempPayTStr === '5' && (
             <TableCell align="center" className="whiteboldtext">{t('251709')}</TableCell>
           )}
         </>
       )}
        <TableCell align="center"  className="whiteboldtext">{t('251622')}</TableCell>
        <TableCell align="center"  className="whiteboldtext">{t('251623')}</TableCell>
        {partnerData.tempPartnerParentId === 'Parent' && (<TableCell align="center"  className="whiteboldtext">{t('055')}</TableCell>)}
        {/* <td colSpan={2} style={{ display: "none" }}>
          <table border={0} width="100%" cellSpacing={1} cellPadding={1}>
            <tbody>
              <tr className="darkgray">
                <td className="whiteboldtext" colSpan={3}>
                  Billing Cycle's
                </td>
              </tr>
              <tr className="darkgray">
                <td className="whiteboldtext" align="center">
                  Frequency
                </td>
                <td className="whiteboldtext" align="center" nowrap="">
                  Begin Date
                </td>
                <td className="whiteboldtext" align="center" nowrap="">
                  End Date
                </td>{" "}
              </tr>{" "}
            </tbody>
          </table>
        </td> */}
        {partnerData.flagPmconfigstatus_RechargeRev &&(
        <TableCell align="center"  className="whiteboldtext" >
        {t('251624')}
        </TableCell>
        )}
        {partnerData.flagPmconfigstatus_TransferRev &&(
        <TableCell align="center"  className="whiteboldtext" >
        {t('251625')}
        </TableCell>
        )}
        {partnerData.simEnabled === 'Y' &&(<>
        <TableCell align="center"  className="whiteboldtext">{t('251626')}</TableCell>
        <TableCell align="center"  className="whiteboldtext">{t('251627')} </TableCell>
        <TableCell align="center"  className="whiteboldtext">{t('251628')}</TableCell></>)}
      </TableRow>
      </TableHead>
      <TableBody>
      <TableRow className="lightyellow">
        <TableCell className="smallerTxt" align="center">
          &nbsp;{!partnerData.paymentType?"---":partnerData.paymentType}&nbsp;
        </TableCell>
        {partnerData.tmpPayString === 'Display' &&(<TableCell className="smallerTxt" align="center">
          &nbsp;{!partnerData.part?"---":partnerData.part}&nbsp;
        </TableCell>)}
        <TableCell className="smallerTxt" align="center">
        {partnerData.lateralTransferEnabled === 'Y' ? t('Y') : 
         partnerData.lateralTransferEnabled === 'N' ? t('N') : '---'}
        </TableCell>
        <TableCell className="smallerTxt" align="center">
        {partnerData.useOwnFundsEnabled === 'Y' ? t('Y') : 
         partnerData.useOwnFundsEnabled === 'N' ? t('N') : '---'}
        </TableCell>
        {partnerData.tempPartnerParentId === 'Parent' && ( <TableCell className="smallerTxt" align="center">
        {partnerData.status === 'Y' ? t('057') : 
         partnerData.status === 'R' ? t('R') : t('058')}
        </TableCell>)}
        {/* <td colSpan={2} style={{ display: "none" }}>
          <table border={0} cellSpacing={0} cellPadding={0} width="100%">
            <tbody>
              <tr>
                <td className="smallerTxt" align="center">
                  &nbsp;Daily
                </td>
                <td className="smallerTxt" align="center">
                  &nbsp;---
                </td>
                <td className="smallerTxt" align="center">
                  &nbsp;---
                </td>{" "}
              </tr>{" "}
            </tbody>
          </table>{" "}
        </td> */}
        {partnerData.flagPmconfigstatus_RechargeRev &&(<TableCell className="smallerTxt" align="center">
        {partnerData.rechargeReversalsEnabled === 'Y' ? t('Y') : 
         partnerData.rechargeReversalsEnabled === 'N' ? t('N') : '---'}
        </TableCell>)}
        {partnerData.flagPmconfigstatus_TransferRev &&(<TableCell className="smallerTxt" align="center">
        {partnerData.transferReversalsEnabled === 'Y' ? t('Y') : 
         partnerData.transferReversalsEnabled === 'N' ? t('N') : '---'}
        </TableCell>)}
        {partnerData.simEnabled === 'Y' &&(<> <TableCell className="smallerTxt" align="center">
        {partnerData.salesForceEnabled === 'Y' ? t('Y') : 
         partnerData.salesForceEnabled === 'N' ? t('N') : '---'}
        </TableCell>
        <TableCell className="smallerTxt" align="center">
        {partnerData.simTransactionsEnabled === 'Y' ? t('Y') : 
         partnerData.simTransactionsEnabled === 'N' ? t('N') : '---'}
        </TableCell>
        <TableCell className="smallerTxt" align="center" >
        {!partnerData.simThreshold?"---":partnerData.simThreshold}
        </TableCell></>)}
      </TableRow>
      </TableBody>
  </Table>
  </TableContainer>
  {/* <TD width='2%'>&nbsp;</TD> */}
  &nbsp;
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table"> 

    <TableHead>
      <TableRow className="darkgray">
        <TableCell align="center"  width="10%" className="whiteboldtext">
        {t('251629')}
        </TableCell>
        <TableCell align="center"  width="15%" className="whiteboldtext">
        {t('251630')}
        </TableCell>
        <TableCell align="center"  width="15%" className="whiteboldtext">
        {t('251631')}
        </TableCell>
        <TableCell align="center" width="10%" className="whiteboldtext">
        {t('251632')}
        </TableCell>

        {partnerData.creditControlSystem === 'NonMexico' && (<><TableCell align="center"  width="10%" className="whiteboldtext">
          {t('251710')}
        </TableCell>
        <TableCell align="center"  width="10%" className="whiteboldtext">
        {t('251711')}
        </TableCell></>)}


        <TableCell align="center"  width="10%" className="whiteboldtext">
        {t('251633')}
        </TableCell>
        <TableCell align="center"  width="10%" className="whiteboldtext">
        {t('251634')}
        </TableCell>
        <TableCell align="center"  width="15%" className="whiteboldtext">
        {t('251635')}
        </TableCell>
        {partnerData.tempPartnerParentId === 'NoParent' && (<TableCell align="center"  className="whiteboldtext"> {t('251636')}</TableCell>)}
      </TableRow>
      </TableHead>
      <TableBody>
      <TableRow className="lightyellow">
        <TableCell width="10%" className="arlCtrBlk">
        {!partnerData.distributorType?"---":partnerData.distributorType}
        </TableCell>
        <TableCell className="arlCtrBlk" width="15%">
        {!partnerData.allocatedCreditLimit?"---":partnerData.allocatedCreditLimit}
        </TableCell>
        <TableCell className="arlCtrBlk" width="15%">
        {!partnerData.availableCreditLimit?"---":partnerData.availableCreditLimit}
        </TableCell>
        <TableCell width="10%" className="arlCtrBlk">
        {!partnerData.creditLimitAlarmThreshold?"---":partnerData.creditLimitAlarmThreshold+"%"}
        </TableCell>

        {partnerData.creditControlSystem === 'NonMexico' && (<> <TableCell className="arlCtrBlk" width="10%">
        {!partnerData.creditLmtStartDateTime?"---":partnerData.creditLmtStartDateTime}
        </TableCell>
        <TableCell className="arlCtrBlk" width="10%">
        {!partnerData.creditLmtStartDateTime?"---":partnerData.creditLmtStartDateTime}
        </TableCell></>)}


        <TableCell className="arlCtrBlk" width="10%">
        {!partnerData.accountBalance?"---":partnerData.accountBalance}
        </TableCell>
        <TableCell className="arlCtrBlk" width="10%">
        {!partnerData.accountBalanceAlarmThreshold?"---":partnerData.accountBalanceAlarmThreshold}
        </TableCell>
        <TableCell className="smallerTxt" align="center">
        {!partnerData.billingSystemUserName || partnerData.billingSystemUserName === 'null' ?"---":partnerData.billingSystemUserName}
        </TableCell>
        {partnerData.tempPartnerParentId === 'NoParent' && (<TableCell className="smallerTxt" align="center">
        {!partnerData.creditEnalbed?"---":partnerData.creditEnalbed}
        </TableCell>)}
      </TableRow>
    </TableBody>
  </Table>
  </TableContainer>
  &nbsp;
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table"> 
  <TableHead>
      <TableRow  className="darkgray">
        <TableCell colSpan={4} width="100%" align="center" className="whiteboldtext">
        {t('251637')}
        </TableCell>
      </TableRow>
      </TableHead>
      <TableBody>
      {/* <TableRow className="lightyellow"> */}
        {/* <TableCell width="100%" className="smallerTxt" align="center">
          <table width="100%" border={0} cellSpacing={0} cellPadding={0}>
            
          <tbody> */}
        {chunkedData.length>0&&(chunkedData.map((chunk, rowIndex) => (
          <TableRow  key={rowIndex}>
            {chunk.map((cellData, cellIndex) => (
              <TableCell align='center' className="smallerTxt" width={40}  key={cellIndex}>
                {cellData}
              </TableCell>
            ))}
          </TableRow>
        )))}
      {/* </tbody>
          </table>{" "}
        </TableCell> */}
      {/* </TableRow>{" "} */}
      </TableBody>
  </Table>
  </TableContainer>
  &nbsp;
  {/* <TD width='2%'>&nbsp;</TD> */}
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
    <TableHead>
      <TableRow className="darkgray">
        <TableCell colSpan={4} width="100%" align='center' className="whiteboldtext">
        {t('251638')}{" "}
        </TableCell>
      </TableRow>
      </TableHead>
      <TableBody>
      {/* <TableRow className="lightyellow">
        <TableCell width="100%" className="smallerTxt" align="left">
          <table width="100%" border={0} cellSpacing={0} cellPadding={0}>
         <tbody> */}
        {chunkedData2.length>0&&(chunkedData2.map((chunk, rowIndex) => (
          <TableRow  key={rowIndex}>
            {chunk.map((cellData, cellIndex) => (
              <TableCell  align='center' className="smallerTxt" width={40}  key={cellIndex}>
                {cellData}
              </TableCell>
            ))}
          </TableRow>
        )))}
      {/* </tbody> 
          </table>
        </TableCell>
      </TableRow> */}
      </TableBody>
  </Table>
  </TableContainer>
  &nbsp;
  {/* <TD width='2%'>&nbsp;</TD> */}
  {/* Account Summary */}
  {/* <TR><TD HEIGHT=10>&nbsp;</TD></TR>
<TR><TD width='100%' align='center' colspan='6' class='strongerTxt'>Accounts Summary</TD></TR>
<TR>
 <TD>
    <TABLE border='0' width='100%' cellspacing='1' cellpadding='2'>
	 <TR>
	   <TD colspan='7' class='redTxt'>Note : Total Sales,Current Account Balance and End Account Balance will be updated by the end of the day.</TD>
     </TR>	
     <TR class='darkgray'>
<TD width='15%'  class='whiteboldtext'>Initial Account Balance()</TD>
<TD width='15%'  class='whiteboldtext'>Total Fund Transfer()</TD>
<TD width='15%'  class='whiteboldtext'>Total Sales()</TD>
<TD width='15%'  class='whiteboldtext'>Total Credit()</TD>
<TD width='15%'  class='whiteboldtext'>Current Account Balance()</TD>
<TD width='15%'  class='whiteboldtext'>Available Balance()</TD>
<TD width='15%'  class='whiteboldtext'>End Account Balance()</TD>
<TD width='15%'  class='whiteboldtext'>SCL Client Code</TD>
     </TR>
     <TR class='lightyellow'>
<TD width='15%'  class='smallerTxt' align='center'>&nbsp;0.00</TD>
<TD width='15%'  class='smallerTxt' align='center'>&nbsp;0.00</TD>
<TD width='15%'  class='smallerTxt' align='center'>&nbsp;0.00</TD>
<TD width='15%'  class='smallerTxt' align='center'>&nbsp;110.75</TD>
<TD width='15%'  class='smallerTxt' align='center'>&nbsp;110.75</TD>
<TD width='15%'  class='smallerTxt' align='center'>&nbsp;110.75</TD>
<TD width='15%'  class='smallerTxt' align='center'>&nbsp;110.75</TD>
<TD width='15%'  class='smallerTxt' align='center'>&nbsp;---</TD> </TR> </TABLE> </TD>
</TR> */}
  {/* <TD  width='2%'>&nbsp;</TD> */}
  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table"> 
  <TableHead>
     
      {/* <TableRow>
        <TableCell colSpan={2} className="strongerTxt" align="center">
        {t('251639')}
        </TableCell>
        <TableCell colSpan={2} className="strongerTxt" align="center">
        {t('251640')}
        </TableCell>
      </TableRow> */}
      <TableRow className="darkgray">
        <TableCell colSpan={2} className="whiteboldtext" align="center">
        {t('251639')}
        </TableCell>
        <TableCell colSpan={2} className="whiteboldtext" align="center">
        {t('251640')}
        </TableCell>
        {/* <TD colspan='1' class='whiteboldtext' align='center'>Address</TD>
    <TD colspan='1' class='whiteboldtext' align='center'>Jurisdiction Address</TD> */}
      </TableRow>
      </TableHead>
      <TableBody>
      <TableRow className="lightyellow" >
       <TableCell colSpan={2} className="smallerTxt" align="center" style={{color : partnerData.tempCaddressSer === 'Present' ? '' : 'red'}}>
          <input type="hidden" name="c_addressId" defaultValue={1547967} />
          {/* <A href="javascript:assignCAddressValues();" onMouseOver="window.status='';
   		return true" class='nav'>87,High School Avenue,Cranston,Providence County,Rhode Island,United States,02910 - 02910</A>	</TD> */}{" "}
          
          {partnerData.tempCaddressSer === 'Present' ? <>{!partnerData.contactAddress?"---":partnerData.contactAddress}</> : <>{t('251712')}</>}
          {/* <TD colspan='1' class='smallerTxt' align='center'>---</TD> */}
        </TableCell>


        <TableCell colSpan={2} className="smallerTxt" align="center" style={{color : partnerData.tempBaddressSer === 'Present' ? '' : 'red'}}>
          <input type="hidden" name="c_addressId" defaultValue={1547967} />
          {/* <A href="javascript:assignCAddressValues();" onMouseOver="window.status='';
   		return true" class='nav'>87,High School Avenue,Cranston,Providence County,Rhode Island,United States,02910 - 02910</A>	</TD> */}{" "}
          
          {partnerData.tempBaddressSer === 'Present' ? <>{!partnerData.billingAddress?"---":partnerData.billingAddress}</> : <>{t('251713')}</>}
          {/* <TD colspan='1' class='smallerTxt' align='center'>---</TD> */}
        </TableCell>
        {/* <TD colspan='1' class='smallerTxt' align='center'>---</TD> */}
      </TableRow>
      </TableBody>
  </Table>
  </TableContainer>
  {/* <TD width='2%'>&nbsp;</TD> */}
  {/* Distributor's Sales Targets Start Here */}
  {/* THESE ROWS DISPLAYS THE DISTRIBUTOR REVENUE STATEMENT DATA */}
  &nbsp;
  {/* <TD  width='2%'>&nbsp;</TD> */}
  <table border={0} width="100%" cellSpacing={1} cellPadding={2}>
    <tbody>
      <tr>
        <td align="right">
           <Button onClick={()=>{handleReturn()}}  className={'hoverEffectButton'} size="small" variant="contained" endIcon={<KeyboardReturn />}>
          {t('013')}
          </Button>
        </td>
      </tr>
      <tr>&nbsp;</tr>
    </tbody>
  </table>
  </>}
  </div>
</table>
      </tr>
      <tr height="60px">
        <td colSpan={2}>
            <Footer />
        </td>
      </tr>
    </tbody>
    </table>
  
    );

}  


export default Profile ;


