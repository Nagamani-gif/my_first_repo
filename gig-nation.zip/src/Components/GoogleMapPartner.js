import React, { useState ,useCallback, useRef, useEffect} from 'react';
import { GoogleMap, LoadScript, Marker, InfoWindow } from '@react-google-maps/api';
import {
  DialogTitle,
  Dialog,
  IconButton,
  DialogContent,
  DialogContentText,
  Button
} from "@mui/material";
import { toast } from "react-toastify";
import { useTheme,Box } from '@mui/material';
import CloseIcon from "@mui/icons-material/Close";
import { useMediaQuery } from '@mui/material';
import { useTranslation } from 'react-i18next';
import SendIcon from '@mui/icons-material/Send';
import { FindInPageRounded, CancelRounded, KeyboardReturn, LocationOn } from '@mui/icons-material';
import useLoadScript from './UseLoadScript';
import { useLocation } from 'react-router';
// import { ToastContainer,toast } from 'react-toastify';

const defaultCenter = { lat: 19.432608, lng: -99.133209 }; // Default to Mexico City

const containerStyle = {
  zIndex: 3,
  position: "absolute",
  height: "100%",
  width: "65%",
  padding: "0px",
  borderWidth: "0px",
  margin: "0px",
  left: "0px",
  top: "0px",
  touchAction: "pan-x pan-y"
};

const GoogleMapPartner = ({setMapAddress,mapadd}) => {
  
  const { t } = useTranslation();
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("xl"));
  const [popopen, setPopopen] = useState(false);
  const [map, setMap] = useState(null);
  const [marker, setMarker] = useState(null);
  const [geocoder, setGeocoder] = useState(null);
  let [address, setAddress] = useState('');
  const [street, setStreet] = useState('');
  const [colony, setColony] = useState('');
  const [status, setStatus] = useState('');
  const [municipality, setMunicipality] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [resultAddress, setResultAddress] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [infoWindow, setInfoWindow] = useState({ position: null, content: ''  });
  const toastId = useRef(null);
  const [showError, setShowError] = useState(false);
  const [showError1, setShowError1] = useState(false);
  const [showError2, setShowError2] = useState(false);
  const [showError3, setShowError3] = useState(false);
  const [showError4, setShowError4] = useState(false);
  const [windowPosition, setWindowPosition] = useState(-38);

  let arr=["street_number","route","neighborhood","sublocality","locality","administrative_area_level_2","administrative_area_level_1","country","postal_code"];

  const resultArray=(id)=>{

    var array=arr;
        
    for(var i in array) {
        
        if(id!=undefined && id!=null)
        {	
            if(array[i]==id)
                    return true; 
        }
    }
    }
    

    

    const handleMapClick = async (event) => {
    setShowError(false);
    setShowError1(false);
    setShowError2(false);
    setShowError3(false);
    setShowError4(false);
      let resultAddress="";
      let addressMarker = [];
      const { latLng } = event;
      const lat = latLng.lat();
      const lng = latLng.lng();
   
      setLatitude(lat);
      setLongitude(lng);
  try{
      if (geocoder) {
        setStatus(t('7101'))
        const response =  await geocoder.geocode({ location: { lat, lng } });
        const results=response.results;
        if (results[0]) {
          console.log(response);
   
          //setting
         
          console.log("result",results);
            for(let i =0;i< results[0].address_components.length;i++)
              {
            setStatus(t('7102'))
                  addressMarker.push(
                      <span key={i}>
                       <span style={{fontSize:'12px', fontWeight: 'bold'}}>{results[0].address_components[i].types[0]}</span> - {results[0].address_components[i].long_name}
                        <br />
                      </span>
                    );
   
   
                  if(resultArray(results[0].address_components[i].types[0]))    
                      resultAddress=resultAddress+results[0].address_components[i].long_name+",";
              }
   
          setResultAddress(resultAddress);
         
   
   
          const addressComponents = response.results[0].address_components;
   
          const postalComponent = addressComponents.find(comp => comp.types.includes('postal_code'));
          setPostalCode(postalComponent ? postalComponent.long_name : '');
   
          setInfoWindow({
            position: { lat, lng },
            //content: response.results[0].formatted_address,
            content:addressMarker,
          });
         
        }
      }
   
      setMarker({ lat, lng });
    }catch{
      setStatus(t('7103'))
    }
    };
console.log(infoWindow, "infowindow////////////");
console.log(marker, "marker////////////")
  const handleMapLoad = async (mapInstance)  => {
    setMap(mapInstance);
    setGeocoder(new window.google.maps.Geocoder());

    let resultAddress="";
    let addressMarker = [];
   try{
    if (geocoder) {
      setStatus(t('7101'));
      const response =  await geocoder.geocode({ 'address': mapadd });
      const results=response.results;
      if (results[0]) {
        setStatus(t('7102'));
        console.log(response);

        //setting
        
        const location = results[0].geometry.location;
        console.log("result",results);
          for(let i =0;i< results[0].address_components.length;i++)
            {
               
             
                addressMarker.push(
                    <span key={i}>
                     <span style={{fontSize:'12px', fontWeight: 'bold'}}>{results[0].address_components[i].types[0]}</span> - {results[0].address_components[i].long_name}
                      <br />
                    </span>
                  );
                if(resultArray(results[0].address_components[i].types[0]))     
                    resultAddress=resultAddress+results[0].address_components[i].long_name+",";
            }
        setResultAddress('');
        const addressComponents = response.results[0].address_components;
        const postalComponent = addressComponents.find(comp => comp.types.includes('postal_code'));
        setPostalCode('');

        setInfoWindow({
          
          position: { lat:location.lat(), lng:location.lng()},
          //content: response.results[0].formatted_address,
          content:addressMarker,
        });
        setMarker({ lat:location.lat(), lng:location.lng()});
        
    setLatitude('');
    setLongitude('');
        
      }
    }
  }catch {
    
  }    
  };

  const handleClear = () => {
    setAddress('');
    setStreet('');
    setColony('');
    setMunicipality('');
  };

  const parseAddressComponents = (components) => {
    const addressMarker = [];
    let resultAddress = "";
  
    components.forEach((component, i) => {
      addressMarker.push(
        <span key={i}>
          <span style={{ fontSize: '12px', fontWeight: 'bold' }}>{component.types[0]}</span> - {component.long_name}
          <br />
        </span>
      );
  
      if (resultArray(component.types[0])) {
        resultAddress += component.long_name + ",";
      }
    });
  
    return { addressMarker, resultAddress };
  };


  const handleSearch = async () => {
// debugger;
setShowError(false);
setShowError1(false);
setShowError2(false);
setShowError3(false);
setShowError4(false);
    if (!address) {
      // if (!toast.isActive(toastId.current)) {
      //   toastId.current = toast.error(t('Please enter Address.'));
      // }
      setShowError(true);
      // alert(t('7105'));
      return;
    }
   
    try {
      if (geocoder && address) {
        setStatus(t('7101'));
          
        const response = await geocoder.geocode({ address });
        console.log('response======>', response.status);
       
        if (response.results[0]) {
          setStatus(t('7102'));
          const location = response.results[0].geometry.location;
          const lat = location.lat();
          const lng = location.lng();
  
          setLatitude(lat);
          setLongitude(lng);
  
          const { addressMarker, resultAddress } = parseAddressComponents(response.results[0].address_components);
          setResultAddress(resultAddress);
  
          const postalComponent = response.results[0].address_components.find(comp => comp.types.includes('postal_code'));
          setPostalCode(postalComponent ? postalComponent.long_name : '');
  
          setInfoWindow({
            position: { lat, lng },
            content: addressMarker,
          });
  
          map.panTo({ lat, lng });
          setMarker({ lat, lng });
        }
      }
    } catch (error) {
      console.error("Error in geocode:", error);
     
      // if (!toast.isActive(toastId.current)) {
      //   toastId.current = toast.error(t('7104'));
      // }
     // alert(t('7104'))
      setShowError1(true);
      setTimeout(() => {
        setStatus(t('7103'));
      }, 0);
    }
  };
  


  const handleSearch1 = async () => {
    setShowError(false);
    setShowError1(false);
    setShowError2(false);
    setShowError3(false);
    setShowError4(false);
    const fullAddress = `${street}, ${colony}, ${municipality}`;
    if (!street && !colony && !municipality) {

      // if(!toast.isActive(toastId.current) )  {
      //   toastId.current = toast.error(t('7106'));
      // }
      //alert(t('7106'));
      setShowError2(true);
     
      return;
    }
    try {
      if (geocoder && fullAddress) {
        setStatus(t('7101'));
        const response = await geocoder.geocode({ address: fullAddress });
  
        if (response.results[0]) {
          setStatus(t('7102'));
          const location = response.results[0].geometry.location;
          const lat = location.lat();
          const lng = location.lng();
  
          setLatitude(lat);
          setLongitude(lng);
  
          const { addressMarker, resultAddress } = parseAddressComponents(response.results[0].address_components);
          setResultAddress(resultAddress);
  
          const postalComponent = response.results[0].address_components.find(comp => comp.types.includes('postal_code'));
          setPostalCode(postalComponent ? postalComponent.long_name : '');
  
          setInfoWindow({
            position: { lat, lng },
            content: addressMarker,
          });
  
          map.panTo({ lat, lng });
          setMarker({ lat, lng });
        }
      }
    } catch {
      //  if(!toast.isActive(toastId.current) )  {
      //   toastId.current = toast.error(t('7104'));
      // }
      //alert(t('7104'));
      setShowError3(true);
        setTimeout(() => {
        setStatus(t('7103'));
      }, 0);
    }
  };


  const handleClose = () => {
    setPopopen(false);
    setShowError(false);
    setShowError1(false);
    setShowError2(false);
    setShowError3(false);
    setShowError4(false);
  };

  const handlePopup = () => {
    //alert("hiii"+def)
    
    console.log("mapadd==>",mapadd);
    if(mapadd===''){
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('1247'));
          }  
      //  alert(t('1247'));
         }
    else{
     setPopopen(true);
     setAddress('');
    setStreet('');
    setColony('');
    setMunicipality('');
     handleMapLoad();

    }
   
}



  const handleSubmit = () => {
   // setAddress(resultAddress);
//  debugger;
setShowError(false);
    setShowError1(false);
    setShowError2(false);
    setShowError3(false);
    setShowError4(false);
    const addressData = {
      address: resultAddress,
      latitude,
      longitude,
      postalCode
    };
    const response = JSON.stringify(addressData, null, 2);
    console.log('==================>'+response);

    // Close the modal after submitting

if(resultAddress == '' || latitude == ''|| longitude == '' || postalCode == ''){
   // alert(t('7107'));
    setShowError4(true);
    //toastId.current = toast.error(t('7107'));
}else{
    setMapAddress(resultAddress,latitude,longitude,postalCode);

    handleClose();
    return response;
  }};


  const [mapLoaded, setMapLoaded] = useState(false);
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);

  useEffect(() => {
    if (popopen) {
      setMapLoaded(true);
    } else {
      setMapLoaded(false);
      setMarker(null); // Reset marker when dialog closes
      setInfoWindow({}); // Reset InfoWindow when dialog closes
      
    }
  }, [popopen]);
  useLoadScript(`https://maps.googleapis.com/maps/api/js?key=AIzaSyCpbPErtugyuwLJ73rzoAoZrtcog4FicDk`);
  useEffect(() => {
    if (mapLoaded && mapContainerRef.current && window.google) {
      if (!mapRef.current) {
        mapRef.current = new window.google.maps.Map(mapContainerRef.current, {
          center: { lat: -34.397, lng: 150.644 },
          zoom: 15,
        });
      }

      // Trigger a resize event to fix map rendering issues
      setTimeout(() => {
        window.google.maps.event.trigger(mapRef.current, 'resize');
      }, 100);
    }
  }, [popopen]);

  const handleInfoWindowClose = () => {
    setInfoWindow({position: null, content: '' }); // Reset InfoWindow content when it's closed
    setWindowPosition(-0);
  };
  const location= useLocation();
console.log(location, "location");
  return (
    <>
      {/* <span onClick={handlePopup} className="pageLink1" style={{ color: 'blue', textDecoration: 'underline' }}>{t('5163')}</span> */}
      <span onClick={handlePopup} style={{position: 'absolute',bottom: '16px', cursor: 'pointer'}}>
        {/* <img                                                
  src={require("../images/search.gif")}
  height={18}
    border={0}
   /> */}
   <LocationOn className={location.pathname !== '/modifyProfile' && !resultAddress ? 'locationIcon' : ''} style={{height:'18px', color:"#39f", marginLeft:'-3px'}} />
   
   </span>
      {/* MODAL STARTS HERE */}
      <Dialog
        fullScreen={fullScreen}
        open={popopen}
        onClose={handleClose}
        className={'googlemap_popup'}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogTitle
          id="responsive-dialog-title"
          sx={{ paddingTop: "25px" }}
          className={"headerTxt"}
          align="center"
        >
          {/* Title can be added here if needed */}
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[800],
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
          <DialogContentText>
            <div className="google_container">
              <div className="map-container">
                {/* <LoadScript googleMapsApiKey="AIzaSyCpbPErtugyuwLJ73rzoAoZrtcog4FicDk"> */}
                  {mapLoaded && <GoogleMap
                    mapContainerStyle={containerStyle}
                    center={defaultCenter}
                    zoom={15}
                    onClick={handleMapClick}
                    onLoad={handleMapLoad}
                  >
                    {marker && (
                      <Marker position={{ lat: marker.lat, lng: marker.lng }}>
                        {infoWindow.position && (
                          <InfoWindow position={infoWindow.position}  options={{
                            pixelOffset: new window.google.maps.Size(0, windowPosition),
                            disableAutoPan: false,
                            maxWidth: 250,
                            maxHeight: 300,
                            zIndex: 1,
                          }}
                          onCloseClick={handleInfoWindowClose}>
                            <div >{infoWindow.content}</div>
                          </InfoWindow>
                        )}
                      </Marker>
                    )}
                  </GoogleMap>}
                {/* </LoadScript> */}
              
              </div>

              <div className="sidebar_left">
                <div className="title">{t('24246816')}</div>
                <input
                  type="text"
                  className="input-box"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                />
                <Button
                  style={{ marginLeft: '5px' }}
                  className={'hoverEffectButton'}
                  size="small"
                  onClick={handleSearch}
                  variant="contained"
                  endIcon={<FindInPageRounded />}
                >
                  {t('043')}
                </Button>
<div style={{position: 'relative',textAlign: 'center',}}>
{showError && (
<p style={{color: 'red', fontSize: '11px', textAlign: 'center', position: 'absolute',  }}>
                {t('7105')}
                </p>
                 )}
                 </div>
                 <div style={{position: 'relative',textAlign: 'center',}}>
{showError1 && (
<p style={{color: 'red', fontSize: '11px', textAlign: 'center', position: 'absolute',}}>
                {t('7104')}
                </p>
                 )}
                 </div>
                <div className="title" style={{ marginTop: '30px' }}>{t('24246817')}</div>

                <div className={'displayFlexLeft'}>
                  <span className="blueText">{t('24246818')}</span>
                  <input
                    type="text"
                    className="input-box"
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                  />
                </div>

                <div className={'displayFlexLeft'}>
                  <span className="blueText">{t('24246819')}</span>
                  <input
                    type="text"
                    className="input-box"
                    value={colony}
                    onChange={(e) => setColony(e.target.value)}
                  />
                </div>

                <div className={'displayFlexLeft'}>
                  <span className="blueText">{t('24246820')}</span>
                  <input
                    type="text"
                    className="input-box"
                    value={municipality}
                    onChange={(e) => setMunicipality(e.target.value)}
                  />
                </div>
                <Box style={{display:'flex', gap:'5px',justifyContent: 'center'}}>
                <Button
                  className={'hoverEffectButton'}
                  size="small"
                  variant="contained"
                  endIcon={<CancelRounded />}
                  onClick={handleClear}
                >
                  {t('0164')}
                </Button>

                <Button
                  className={'hoverEffectButton'}
                  size="small"
                  onClick={handleSearch1}
                  variant="contained"
                  endIcon={<FindInPageRounded />}
                >
                  {t('043')}
                </Button>
                </Box>
                <div className={'statusFlexLeft'}>
                  <span className="blueText">{t('24246822')}</span>
                  <input
                    type="text"
                    className="input-box"
                    value={status}
                    readOnly
                  />
                </div>
                <div style={{position: 'relative',textAlign: 'center',}}>
{showError2 && (
<p style={{color: 'red', fontSize: '11px', position: 'absolute',  }}>
                {t('7106')}
                </p>
                 )}
                 </div>
                 <div style={{position: 'relative',textAlign: 'center',}}>
{showError3 && (
<p style={{color: 'red', fontSize: '11px',  position: 'absolute', marginTop: '5px',}}>
                {t('7104')}
                </p>
                 )}
                 </div>
                <div className="title"  style={{ marginTop: '38px' }}>{t('24246823')}</div>
                <div className={'displayFlexLeft'}>
                  <span className="blueText">{t('24246824')}</span>
                  <input
                    type="text"
                    className="input-box"
                    value={latitude}
                    readOnly
                  />
                </div>
                <div className={'displayFlexLeft'}>
                  <span className="blueText">{t('24246825')}</span>
                  <input
                    type="text"
                    className="input-box"
                    value={longitude}
                    readOnly
                  />
                </div>
                <div className="title">{t('24246816')}</div>
                <textarea
                  className="textarea-box"
                  value={resultAddress}
                  readOnly
                />

                <div className="title">{t('24246826')}</div>
                <input
                  type="text"
                  className="input-box"
                  value={postalCode}
                  readOnly
                />

              <Box style={{display:'flex', gap:'5px',justifyContent: 'left'}}>
                  <Button
                    className="hoverEffectButton"
                    size="small"
                    variant="contained"
                    endIcon={<CancelRounded />}
                    onClick={handleClose}
                  >
                    {t('6810')}
                  </Button>
                  <Button
                    className="hoverEffectButton"
                    size="small"
                    variant="contained"
                    endIcon={<SendIcon />}
                    onClick={handleSubmit}
                  >
                    {t('028')}
                  </Button>
               
                 
                </Box>
                <div style={{position: 'relative',textAlign: 'center',}}>
{showError4 && (
<p style={{color: 'red', fontSize: '11px', textAlign: 'center', position: 'absolute', marginTop: '10px',  }}>
                {t('7107')}
                </p>
                 )}
                 </div>
                <br />
              </div>
            </div>
          </DialogContentText>
        </DialogContent>
      </Dialog>
      {/* MODAL ENDS HERE */}
      {/* <ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />  */}

    </>
  );
};

export default GoogleMapPartner;
