/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable no-unused-vars */
import React from 'react'
import { useTranslation } from 'react-i18next';
import i18n from './i18n';
import { useState,useEffect } from 'react';
import { CurrentDate } from './PageComponents';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { logout, logoutUser } from '../reducers/exampleSlice';
import { useLocation, useNavigate } from 'react-router';
import { Box } from '@mui/material';
import { LoginOutlined } from '@mui/icons-material';

export default function Navbar(props) {
const [link, setLink] =useState(false);
const [visitedLink, setVisitedLink] =useState(true);
// const [isChecked, setIsChecked] = useState(i18n.language==='en' ? true : false);
const location = useLocation();
const navigate = useNavigate();

let isLoggedIn = useSelector((state) => state.example.isLoggedIn); // Get isLoggedIn from Redux state

 // Initialize the language state to default to Spanish ('es')

//  const initialCheckedState = () => {
//    if (!isLoggedIn) {
//     //debugger;
//      return sessionStorage.getItem('language') === 'es';
//    } else {
//   const savedLanguage = sessionStorage.getItem('language') || 'es'; // Default to 'es'
//   i18n.changeLanguage(savedLanguage); // Set language for i18n
//   return savedLanguage === 'es'; // Return true if Spanish
//    }
//  };

const initialCheckedState = () => {
  if (location.pathname === "/") {
    i18n.changeLanguage("es"); // Set language to Malaysian for i18n
    sessionStorage.setItem("language", "es"); // Store language in session
    return true; // Toggle isChecked to true for Malaysian
  }

  if (!isLoggedIn) {
    return sessionStorage.getItem("language") === "es";
  } else {
    const savedLanguage = sessionStorage.getItem("language") || "es"; // Default to 'es'
    i18n.changeLanguage(savedLanguage); // Set language for i18n
    return savedLanguage === "es"; // Return true if Malaysian
  }
};
 
 const [isChecked, setIsChecked] = useState(initialCheckedState);


useEffect(() => {
  if(!isLoggedIn){
  const savedLanguage = sessionStorage.getItem('language') || 'es'; // Default to 'es'
  i18n.changeLanguage(savedLanguage); // Change the language for i18n

  // Force set to Malaysian for toggle state regardless of previous selection
  sessionStorage.setItem('language', 'es'); // Always set to Malaysian on refresh
  setIsChecked(true); // Set toggle state to true (Malaysian)
  }
  else{
  // Set the language based on the stored value on initial render
  const savedLanguage = sessionStorage.getItem('language') || 'en';
  i18n.changeLanguage(savedLanguage);
  setIsChecked(savedLanguage === 'es');
  }
}, []);
 
const changeLanguage = (lng) => {
  i18n.changeLanguage(lng);
  setIsChecked(lng === 'es');
  sessionStorage.setItem('language', lng); // Save the selected language to sessionStorage
};
 
const handleToggleChange = () => {
  const newCheckedState = !isChecked;
  const newLanguage = newCheckedState ? 'es' : 'en';
  setIsChecked(newCheckedState);
  changeLanguage(newLanguage);
};
   useTranslation();
     var language = '';






    const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
    //console.log("name====>"+exampleData.FIRST_NAME+exampleData.LAST_NAME);

  // const navigate = useNavigate();
  // const dispatch = useDispatch();
  //   const handleLogout =()=>{
  //     dispatch(logoutUser());
  //     navigate('/');
  //   }
    // const [isChecked, setIsChecked] = useState(true);

    const [languageToggleIsOn, setLanguageToggleIsOn] = useState(false);

    const handleToggle = () => {
      const newToggleState = !languageToggleIsOn;
      setLanguageToggleIsOn(newToggleState);
      changeLanguage(newToggleState ? 'es' : 'en');
    };
  return (
    <nav> 
   {/* bg-body-tertiary */}
   <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={0} width={1000} align="center">
     <tbody>
      {/* <tr height="85px"> */}
      <tr height="auto">
        <td colSpan={2} valign="top" style={{}}>
          <meta httpEquiv="X-UA-Compatible" content="IE=8" />
          <input type="hidden" name="localeHidden" />
          <input type="hidden" name="myDirectory" defaultValue="networkadmin" />
          <table border={0} cellPadding={0} cellSpacing={0} width="100%">
            <tbody>
            {/* <tr height={8}><td width="100%">&nbsp;</td></tr> */}
              <tr>
                {/* <td><img border="0" src="http://10.10.19.189:8180/airmanage/images/logo.PNG" width="143" height="76"></td> */}
                <td><img border={0} style={{width: '20%'}} src={require("../images/logo.PNG")} /></td>
     
    
        <td>
          <table border={0} cellPadding={0} cellSpacing={0} align="right">
     <tbody>

  <tr height={25}>
      <td align="right">
         {/* <a id="langLinkID_en" onClick={() => changeLanguage('en')}className="langLinkVisited"> English</a>
         &nbsp;|&nbsp;
        <a id="langLinkID_es" onClick={() => changeLanguage('es')}  className="langLink"> Español </a>
        &nbsp; */}
        {/* <div className='language_toggle'>
        <a id="langLinkID_en" onClick={() => changeLanguage('en')}  className={visitedLink ? "langLinkVisited" : "langLink"}> English</a>
        <a id="langLinkID_es" onClick={() => changeLanguage('es')}  className={link ? "langLinkVisited" : "langLink"}> Español </a>
        &nbsp;
        </div> */}
        <Box sx={{display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop:'15px'}}>
      <div className="switch">
      <input 
        id="language-toggle" 
        className="check-toggle check-toggle-round-flat" 
        type="checkbox" 
        checked={isChecked} 
        onChange={handleToggleChange} 
      />
      <label htmlFor="language-toggle"></label>
      <span 
        className="on" 
        // onClick={() => { setIsChecked(false); handleChangeLanguage('en'); }}
        onClick={() => changeLanguage('en')} 
      >
        English
      </span>
      <span 
        className="off" 
        // onClick={() => { setIsChecked(true); handleChangeLanguage('ms'); }}
        onClick={() => changeLanguage('es')} 
      >
        Malaysia
      </span>
    </div>

        {/* <a onClick={handleLogout} style={{display: 'flex', cursor: 'pointer'}} className="langLink">Logout <LoginOutlined style={{    width: '15px',
    height: '15px',
    marginLeft: '3px'}} /></a> */}
        </Box>
        {/* <Box sx={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
        <div className="toggle-contents-wrapper">
      <p>English</p>
      <div 
        id="Language-Switch" 
        onClick={handleToggle} 
        className={`toggle-wrapper ${languageToggleIsOn ? 'toggle-is-active' : ''}`}
      >
        <div className="toggle-dot"></div>
      </div>
      <p>Español</p>
    </div>
    <a onClick={handleLogout} style={{display: 'flex', marginLeft: '10px'}} className="langLink">Logout <LoginOutlined style={{    width: '15px',
    height: '15px',
    marginLeft: '3px'}} /></a>
        </Box> */}
      </td>
     </tr>
     <tr>
        {/* <td>{t('greeting')}</td> */}
      </tr>
                      <tr height={25}>
                        <td align="right" nowrap={'true'}> 
                          <CurrentDate />
                        </td>
                      </tr>
                      {/* <tr height={13}><td width="100%">&nbsp;</td></tr> */}
                      </tbody>
                    </table>
                </td>
              </tr>
              <tr>
                {/* <td height={19} colSpan={2} className="lineClassLogin">&nbsp;</td> */}
                <td colSpan={2} style={{fontSize: '1.5px'}} className="lineClass">&nbsp;</td>

              </tr>
              </tbody>
            </table>
        </td>
      </tr>
      </tbody>
      </table>
  </nav>
  )

}
