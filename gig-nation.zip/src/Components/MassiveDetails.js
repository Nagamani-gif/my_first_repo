import React from 'react';
import { Box, Button, Menu,CircularProgress, FormControl,Grid, InputLabel, MenuItem, Pagination, Paper,Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField ,Dialog, DialogTitle, DialogContent, IconButton} from "@mui/material";
import { useTranslation } from 'react-i18next';
import { useState, useEffect, useCallback,useRef } from 'react';
import axios from "axios";
import i18n from "./i18n";
import { CloudDownload } from '@mui/icons-material';
import ExcelJS from 'exceljs';
import jsPDF from 'jspdf';
import 'jspdf-autotable';


const MassiveDetails= ({fileId,inftType,handleClose} ) => {

  const { t } = useTranslation();
     const localeVar = i18n.language;
  const [isLoading, setIsLoading] = useState(false);
 const [items, setItems] = useState([]);
  const [submitted, setSubmitted] = useState(false);

  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
  const [recordsFound, setRecordsFound] = useState(0);
   const [anchorEl, setAnchorEl] = useState(null);






console.log("fileId====>",fileId);
console.log("interFaceType====>",inftType);


useEffect(() => {
  const callFetchData = async () => {
    try {
      await fetchData(); // fetchData already uses axios internally
    } catch (error) {
      console.error('Error calling fetchData:', error);
    }
  };

  callFetchData(); // Trigger the async function

}, []);


const fetchData = async () => {
    setIsLoading(true);
    try {
      const apiUrl = window.config.apiUrlJasper+ '/massiveDetails';
       //const apiUrl = window.config.jasperUrl + process.env.REACT_APP_MASSIVE;
  

      const response = await axios.post(apiUrl, {
        userName,
        password,
        fileId,
        inftType,
        locale:localeVar,
        startPageNo: startRecord,
        endPageNo: endRecord < 10 ? '10' :endRecord
      });

      console.log("response::::::", response.data);
      //alert()
      // if (response.status === 200) {
        // if(response.data.MassiveTranferDetails!==undefined){
         setItems(response.data.data);  // <-- Set items here!
        setTotalRecords(response.data.noOfRecord || 0);
       setRecordsFound(response.data.noOfRecord || 0);
        // }
      // }
    } catch (error) {
      console.error('An error occurred:', error);
      setItems([]);
    } finally {
      setIsLoading(false);
    }
  };


const totalPages = Math.ceil(recordsFound / recordsPerPage);

let startRecord = (page - 1) * perpage + 1;
let endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);


 const handleDownload = async (type) => {
  setAnchorEl(null);
  if (type === 'excel') {
    await exportAsExcel();
  } else if (type === 'pdf') {
    await exportAsPdf();
  } else if (type === 'csv') {
     await exportAsCSV();
  }
};





 const fetchDataDownload = async () => {
    try {
     // const localeVar = 'en';
      const apiUrlDownload = window.config.apiUrlJasper+ '/massiveDetails';

  const response = await axios.post(apiUrlDownload, {
        userName,
        password,
        locale:localeVar,
        fileId,
        inftType,
      });

    if (!Array.isArray(response.data.data)) {
      throw new Error('Invalid API response: Expected array');
    }
     console.log("response.data.data",response.data.data)
     const items = response.data.data;
     items.noOfRecord = response.data.noOfRecord;
     return items;

    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };



 const exportAsExcel = async () => {
    const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Massive_Transfers_Detail_Report');

    const numberOfColumns = 13;
    const headingRow1 = worksheet.addRow([t('2480_0011')]);
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    headingRow1.getCell(1).font = { bold: true };
    headingRow1.getCell(1).alignment = { horizontal: 'center' };
    worksheet.addRow([]);

  
    const columnHeaders = [
      t('File ID'),t('2480_0012'), t('2480_0013'), t('2480_0014'),t('2480_0015'), t('2480_0016'), t('2480_0018'), t('fund_001'), t('Currency'),
      t('fundTransferID'), t('pmResponseCode'), t('pmResponseDescription'),t('2480_0017')
    ];

const totalRecord = totalRecords;

const summaryRow = worksheet.addRow([]);   // start with an empty row


const totalColumns = numberOfColumns;
const oneThird = Math.floor(totalColumns / 3);

const leftStart   = 1;
const middleStart = oneThird + 1;
const rightStart  = (2 * oneThird) + 1;

// Merge cells first
worksheet.mergeCells(summaryRow.number, leftStart, summaryRow.number, middleStart - 1);
worksheet.mergeCells(summaryRow.number, middleStart, summaryRow.number, rightStart - 1);
worksheet.mergeCells(summaryRow.number, rightStart, summaryRow.number, totalColumns);

// Now set values (after merge!)


summaryRow.eachCell(cell => {
  cell.font = { bold: true };
  cell.alignment = { horizontal: 'left' }; // Use 'center' if preferred
});

//const totalRecordsRow = worksheet.addRow([`${t('032')}: ${totalRecords}`]);

const sameLineRow = worksheet.addRow(
  Array(numberOfColumns).fill('') // Fill the entire row with empty cells
);

// Set left-side label (first cell)
const leftCell = sameLineRow.getCell(1);
leftCell.value = `${t('032')}: ${totalRecord}`; // e.g., "Total: 100"
leftCell.font = { bold: true };
leftCell.alignment = { horizontal: 'left' };

// Set right-side label (last cell)
// const rightCell = sameLineRow.getCell(numberOfColumns);
// rightCell.value = `${t('033')}: ${totalRecord}`; // e.g., "Displayed: 100"
// rightCell.font = { bold: true };
// rightCell.alignment = { horizontal: 'right' };


   worksheet.addRow([]);
    const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' }, left: { style: 'thin' },
        bottom: { style: 'thin' }, right: { style: 'thin' },
      };
    });

    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
      item.fileId,
      item.requestId,
      item.fromPartner,
      item.toPartner,
      item.fromMdn,
      item.toMdn,
      item.requestDate,
      !isNaN(parseFloat(item.transferAmt)) ? parseFloat(item.transferAmt).toFixed(2) : '---',
      item.currencySymbol,
      item.fundTransferId,
      item.responseCode,
      item.description,
      item.responseStatus === 'S'
                                                            ? t('Success')
                                                            : item.responseStatus === 'F'
                                                            ? t('fail')
                                                            : item.responseStatus
      //item.responseStatus ==='S'? t('Success') : item.responseStatus
      ]);
       dataRow.eachCell(cell => {
      cell.border = {
        top: { style: 'thin' }, left: { style: 'thin' },
        bottom: { style: 'thin' }, right: { style: 'thin' },
      };
      cell.alignment = { horizontal: 'center' };
    });
  });

  worksheet.addRow([]);
  const endOfReportRow = worksheet.addRow([t('0171')]);
  worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
  const endOfReportCell = endOfReportRow.getCell(1);
  endOfReportCell.font = { italic: true, underline: true, bold: true };
  endOfReportCell.alignment = { horizontal: 'center' };

  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });

  worksheet.protect('yourPassword', {
    selectLockedCells: true,
    selectUnlockedCells: true,
  });

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });

  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'Massive_Transfers_Detail_Report.xls';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};



 
 

const exportAsPdf = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  // Use A2 for wider space to fit all columns
  const doc = new jsPDF({
    orientation: 'landscape',
     format: [500, 1000],
    unit: 'pt'
  });

const totalRecord = totalRecords;
console.log("totalRecord====>",totalRecord);

  // Heading
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text(t('2480_0011'), doc.internal.pageSize.getWidth() / 2, 40, { align: 'center' });


// Data row
doc.setFontSize(10);
doc.setFont(undefined, 'normal');
// col 3  (≈ +100 px)
doc.text(`${t('032')}: ${totalRecord}`, 15, 75); 


  const columnHeaders = [
      t('File ID'),t('2480_0012'), t('2480_0013'), t('2480_0014'),t('2480_0015'), t('2480_0016'), t('2480_0018'), t('fund_001'), t('Currency'),
      t('fundTransferID'), t('pmResponseCode'), t('pmResponseDescription'),t('2480_0017')
  ];


  const rows = downloadItems.map(item => [
      item.fileId,
      item.requestId,
      item.fromPartner,
      item.toPartner,
      item.fromMdn,
      item.toMdn,
      item.requestDate,
      !isNaN(parseFloat(item.transferAmt)) ? parseFloat(item.transferAmt).toFixed(2) : '---',
      item.currencySymbol,
      item.fundTransferId,
      item.responseCode,
      item.description,
           item.responseStatus === 'S'
                                                            ? t('Success')
                                                            : item.responseStatus === 'F'
                                                            ? t('fail')
                                                            : item.responseStatus
     // item.responseStatus ==='S'? t('Success') : item.responseStatus
  ]);

  // AutoTable
  doc.autoTable({
    startY: 80,
    head: [columnHeaders],
    body: rows,
    styles: {
      fontSize: 5,       // Smaller font for more data
      overflow: 'linebreak',
      cellPadding: 1
    },
    headStyles: {
      
      fillColor: [41, 128, 185],
      halign: 'center',
      fontSize: 6
    },
    theme: 'grid',
    margin: { top: 70, left: 10, right: 10 }
  });

  // Footer
  doc.setFontSize(10);
  doc.setFont(undefined, 'italic');
  doc.text(t('0171'), doc.internal.pageSize.getWidth() / 2, doc.lastAutoTable.finalY + 20, { align: 'center' });

  doc.save('Massive_Transfers_Detail_Report.pdf');
};



  
  const formatAmount = (value) => {
  if (value === null || value === undefined || value === '') return '0.00';
  const num = Number(value);
  if (Number.isNaN(num)) return '0.00';
  return `="${num.toFixed(2)}"`; // Excel will show exactly 10.00
  };



  const formatDate = (value) => {
    if (!value) return "---";
    const date = new Date(value);
    if (isNaN(date.getTime())) return value;
    const pad = (n) => (n < 10 ? '0' + n : n);
    return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };
 


const exportAsCSV = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

    const numberOfColumns = 13;
  const columnHeaders = [
   t('File ID'),t('2480_0012'), t('2480_0013'), t('2480_0014'),t('2480_0015'), t('2480_0016'), t('2480_0018'), t('fund_001'), t('Currency'),
      t('fundTransferID'), t('pmResponseCode'), t('pmResponseDescription'),t('2480_0017')
  ];

  const totalRecord = totalRecords;

  // CSV Rows
  const rows = [];

  // Add title
  //rows.push([t('2480_0011')]);

 const title = t('2480_0011');
 const leftPadding = Math.floor((numberOfColumns - 1) / 2);
  const titleRow = Array(leftPadding).fill('').concat(title).concat(Array(numberOfColumns - leftPadding - 1).fill(''));
rows.push(titleRow);

  rows.push([]);
  rows.push([]);
  // Add total records
  rows.push([`${t('032')}: ${totalRecord}`]);
  rows.push([]);

  // Add headers
  rows.push(columnHeaders);

  // Add data rows
  downloadItems.forEach(item => {
    rows.push([
      item.fileId,
      item.requestId,
      item.fromPartner,
      item.toPartner,
      item.fromMdn,
      item.toMdn,
      formatDate(item.requestDate),
      // formatAmount(item.transferAmt),
      item.transferAmt != null ? Number(item.transferAmt).toFixed(2) : "---",
      // !isNaN(parseFloat(item.transferAmt)) ? parseFloat(item.transferAmt).toFixed(2) : '---',
      item.currencySymbol,
      item.fundTransferId,
      item.responseCode,
      item.description,
      item.responseStatus === 'S'
                                                            ? t('Success')
                                                            : item.responseStatus === 'F'
                                                            ? t('fail')
                                                            : item.responseStatus
                                                   
      // item.responseStatus ==='S'? t('Success') : item.responseStatus
     
    ]);
  });

  // Add end-of-report
  rows.push([]);

const escapeCSV = value => {
      if (value == null) return '';
    const strVal = String(value).trim().replace(/"/g, '""');

    if (/^\d+\.\d{2}$/.test(strVal)) {
      return `="${strVal}"`;
    } else if (/^\d{2}\/\d{2}\/\d{4}/.test(strVal)) {
      return `="${strVal}"`;
    } else {
      return `"${strVal}"`;
    }
    };

const csvLines = [];


  const endRep = t('0171');
  const endleftPadding = Math.floor((numberOfColumns - 1) / 2);
  const endtitleRow = Array(endleftPadding).fill('').concat(endRep).concat(Array(numberOfColumns - endleftPadding - 1).fill(''));
  rows.push(endtitleRow);
  // rows.push([t('0171')]);

  // Convert to CSV string

    rows.forEach(row => {
      csvLines.push(row.map(escapeCSV).join(','));
    });


let csvContent = csvLines.join('\n');

//  const csvContent = rows
//   .map(row => row.map(val => `"${val != null ? val : ''}"`).join(','))
//   .join('\n');

  // Download as .csv
const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;

const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
const url = URL.createObjectURL(blob);
const link = document.createElement("a");
link.setAttribute("href", url);
link.setAttribute("download", "Massive_Transfers_Detail_Report.csv");
document.body.appendChild(link);
link.click();
document.body.removeChild(link);


};







const handleChangePage =(event, newPage) => {
    event.preventDefault();
    setPage(newPage);
  };

useEffect(() => {
  fetchData();           // runs every time `page` changes
}, [page]);





  return (
 <div align='center' className={"redTextBold"}>
   {t('2480_0011')}


                                         <Grid
                                               container
                                               spacing={2}
                                               sx={{ width: 1 }}
                                               className={""}
                                               style={{
                                                 justifyContent: "center",
                                                 marginTop: "5px",
                                                 marginBottom: '0px',
                                                 marginLeft: "0px",
                                                 borderBottom: "1px solid #fff",
                                                 paddingInline: "0px",
                                               }}
                                             >
                                               <Grid
                                                 item
                                                 xs={3}
                                                 sx={{ textAlign: "left", padding: "0 !important" }}
                                               >
                                               </Grid>
                                               <Grid
                                                 item
                                                 xs={3}
                                                 sx={{ textAlign: "center", padding: "0 !important" }}
                                               ></Grid>
                                               <Grid
                                                 item
                                                 xs={6}
                                                 sx={{ textAlign: "right", padding: "0 !important" }}>
                                                 {totalRecords > 0 ?
                                                   <><span className={"TxtLable"}>
                                                     {t('032')} : {totalRecords}
                                                   </span><span className={"TxtLable"}>
                                                       &nbsp; / &nbsp;
                                                       {t('033')} : {startRecord} - {endRecord}
                                                     </span></> :
                                                   <></>}
                                               </Grid>
                                             </Grid>   
<TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                                            <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
                                              <TableHead>
                                                <TableRow className="darkgray">
                                                  <TableCell align="center">{t('File ID')} </TableCell>
                                                  <TableCell align="center">{t('2480_0012')} </TableCell>
                                                  <TableCell align="center">{t('2480_0013')} </TableCell>
                                                  <TableCell align="center">{t('2480_0014')} </TableCell>
                                                  <TableCell align="center">{t('2480_0015')} </TableCell>
                                                  <TableCell align="center">{t('2480_0016')} </TableCell>
                                                  <TableCell align="center">{t('2480_0018')} </TableCell>
                                                  <TableCell align="center">{t('fund_001')} </TableCell>
                                                  <TableCell align="center">{t('Currency')} </TableCell>
                                                  <TableCell align="center">{t('2480_0020')} </TableCell>
                                                  <TableCell align="center">{t('pmResponseCode')} </TableCell>
                                                  <TableCell align="center">{t('pmResponseDescription')} </TableCell>
                                                  <TableCell align="center">{t('2480_0017')} </TableCell>

                                                </TableRow>
                                              </TableHead>
                                              <TableBody>
                                                {isLoading ? (
                                                  // Show loading spinner while data is being fetched
                                                  <TableRow>
                                                    <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
                                                      {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
                                                    </TableCell>
                                                  </TableRow>
                                                ) : items.length > 0 ? (
                                                  // Show table rows when data is available
                                                  items.map((item, index) => (
                                                    <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>


                                                     {/* <TableCell align="center"style={{color:"#3399FF", cursor:'pointer'}} 
                                                       onClick={() => handleOpen(item.fileID,item.interfaceType)}>{item.fileID}</TableCell> */}
                                                      <TableCell align="center">&nbsp;{item.fileId}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.requestId}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.fromPartner}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.toPartner}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.fromMdn}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.toMdn}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.requestDate}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{Number(item.transferAmt).toFixed(2)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.currencySymbol}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.fundTransferId}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.responseCode}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.description}&nbsp;</TableCell>
                                                     <TableCell align="center">
                                                          &nbsp;
                                                          {item.responseStatus === 'S'
                                                            ? t('Success')
                                                            : item.responseStatus === 'F'
                                                            ? t('fail')
                                                            : item.responseStatus}
                                                          &nbsp;
                                                        </TableCell>
                                                    </TableRow>
                                                  ))
                                                ) : (
                                                  // Show 'No data found' message if no items are found after loading
                                                  <TableRow>
                                                    <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                                                    {submitted ? t("2481_061") : t("038")}
                                                    </TableCell>
                                                  </TableRow>
                                                )}

                                          </TableBody>
                                            </Table>
                                          </TableContainer>

<br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?                                                 <Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>       



<div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
  {items.length > 0 && (
    <div
      onMouseEnter={(e) => setAnchorEl(e.currentTarget)}
      onMouseLeave={(e) => setAnchorEl(null)}
      style={{ display: 'inline-block' }}
    >
      <Button
        className="hoverEffectButton"
        size="small"
        variant="contained"
        endIcon={<CloudDownload />}
        type="button"
        onClick={(e) => setAnchorEl(e.currentTarget)}
        aria-controls={Boolean(anchorEl) ? 'download-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={Boolean(anchorEl) ? 'true' : undefined}
      >
        {t('089')}
      </Button>

      <Menu
        id="download-menu"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        MenuListProps={{
          onMouseEnter: () => {}, // don't reset anchorEl here
          onMouseLeave: () => setAnchorEl(null),
          style: { minWidth: 85 },
        }}
        PaperProps={{
          sx: { minWidth: 70, mt: 0.1 },
        }}
      >
        <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('pdf'); }}>{t('2480_080')}</MenuItem>
        <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('excel'); }}>{t('2480_081')}</MenuItem>
        <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('csv'); }}>{t('2480_082')}</MenuItem>
      </Menu>
    </div>
  )}
</div>


   {/* <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap:'8px' }}>
      {items.length>0?
    
        <div
          onMouseEnter={(e) => setAnchorEl(e.currentTarget)}
          onMouseLeave={() => setAnchorEl(null)}
          style={{ display: 'inline-block' }}
        >
          <Button
            className="hoverEffectButton"
            size="small"
            variant="contained"
            endIcon={<CloudDownload />}
            type="button"
            onClick={(e) => setAnchorEl(e.currentTarget)}
            aria-controls={Boolean(anchorEl) ? 'download-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={Boolean(anchorEl) ? 'true' : undefined}
          >
            {t('089')}
          </Button>

          <Menu
            id="download-menu"
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={() => setAnchorEl(null)}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            transformOrigin={{ vertical: 'top', horizontal: 'left' }}
            MenuListProps={{
              onMouseEnter: (e) => setAnchorEl(e.currentTarget),
              onMouseLeave: () => setAnchorEl(null),
              style: { minWidth: 85 },
            }}
            PaperProps={{
              sx: { minWidth: 85, mt: 1.5 },
            }}
          >
            <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('pdf'); }}>{t('2480_080')}</MenuItem>
            <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('excel'); }}>{t('2480_081')}</MenuItem>
            <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('csv'); }}>{t('2480_082')}</MenuItem>
          </Menu>
        </div>

       :<></>}
</div> */}



    </div>



  )
}


export default MassiveDetails;
