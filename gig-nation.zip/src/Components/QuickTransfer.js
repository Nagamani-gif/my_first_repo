import {Header, Footer, PaymentManagerHeading, JasperLeftMenu, TransactionTopMenu, LeftBgImage} from './PageComponents';
import TopMenu from './TopMenu';
import axios from 'axios';
import {useRef, useState, useEffect} from 'react';
import { useTranslation } from 'react-i18next';
import { amountValidation } from './AmountValidation';
import i18n from './i18n';
import { ToastContainer, toast } from "react-toastify";


import { Box, Button, TextField} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';

import { CancelRounded } from '@mui/icons-material';


function QuickTransfer(){
   // sessionStorage.setItem("selectedIndex", 5);
    let localeVar=i18n.language;
    sessionStorage.setItem("selectedLink", "e_transactions");

    const {t} = useTranslation();

    const exampleData = JSON.parse(localStorage.getItem("userData"))
    const singleFundSource = exampleData.SINGLE_FUND_SOURCE_FLAG_VAL;
    console.log("singleFundSource="+singleFundSource);
    
    useEffect(() => {
        // Set the browser title
          document.title = t('2472_023');
      }, []);


    return (
        <>
            <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <tbody>
                    
                            <Header />
                    <tr height="65px">
                    <PaymentManagerHeading />
                     <TopMenu menuLink= {localeVar==='en'?"Transactions":"Transacciones"}/>
                    </tr>
                    <tr>
                       <LeftBgImage />
{/* <div className={'mL8'}> */}
                        <td valign="top">
                        <TransactionTopMenu />
                            {   singleFundSource === "N" ? 
                                <QuickTransferContent /> 
                            : 
                                <>

                                    {/* <table width="100%">
                                        <tbody>
                                        <tr><td width="100%" class="headingText" style={{paddingLeft: '8px'}}>{t('046')}Quick Transfer</td></tr>
                                        </tbody>
                                    </table> */}

                                    <br></br>
                                    <br></br>

                                    <table align="center" border='0' cellPadding='0' cellSpacing='1' width='100%'>
                                        
                                        <tr>
                                            <td class='redTxt' align="center" colspan='4'>
                                                {t('047')}
                                                {/*The Fund Transfer Options are not available for Single Fund Source Hierarchy*/}
                                            </td>
                                        </tr>
                                    </table>
                                </>
                            }
                        </td>
                        {/* </div> */}
                        <ToastContainer 
                        position="top-right"
                        autoClose={2000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
                    </tr>

                    <tr height="60px">
                        <td colSpan={2}>
                            <Footer />
                        </td>
                    </tr>

                </tbody>
            </table>
        </>
    );
}

function QuickTransferContent(){

    const {t} = useTranslation();
    let localeVar=i18n.language;
    const exampleData = JSON.parse(localStorage.getItem("userData"))
    const partnerLoginId = exampleData.LOGIN_ID;

    const [amountVal, setAmountVal] = useState('');
    const [mdn, setMdn] = useState('');
    const [msg, setMsg] = useState('');
    const toastId = useRef(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showError, setShowError] = useState(false);
    //const msg = '';

    const numValidate = (e) => {
        const re = /^[0-9\b]+$/;
    //     if (!re.test(e.target.value)) {
    //        return  false;
    //     }
    //     setAmountVal(e.target.value);
    //     return true;
    // }
 
    if (re.test(e.target.value)) {
 
        return  false;

        setAmountVal(e.target.value);

     }
    }
    const mdnValidate = (e) => {
        const value = e.target.value.trim(); 
        console.log("value is::::",value);
    
        // If clearing the field and not submitting, just update the state
        if (value === '' && !isSubmitting) {
            setMdn(value);
            setMsg('');
            return;
        }
        
        // Validate the MDN only if we are submitting the form
        if (isSubmitting && value === '') {
            if (!toast.isActive(toastId.current)) {
                toastId.current = toast.error(t('2472_001')); // Error message for empty MDN
            }
            setMsg(t('2472_001'));
            return;
        }
    
        // Validate if the value is numeric
            const re = /^[0-9\b]+$/;
            if (!re.test(value)) {
            // if (!toast.isActive(toastId.current)) {
            //     toastId.current = toast.error("MDN must be numeric"); // Error message for non-numeric MDN
            // }
            setMsg('');
            return;
        }
    
        // Set valid MDN and clear any previous messages
        setMdn(value);
        // setMsg(''); 
    };
    

    const validateAmount = (value,setValue) => {
        amountValidation(value,setValue, 15, 2);
    }

    const clearSearch = () => {
        setMdn('');
        setAmountVal('');
    }

  
    const submit = async() => {
         setShowError(false);
        setIsSubmitting(true); // Indicate submission in progress
    
        // Perform MDN validation
        if (!mdn || mdn.trim() === '') {
            // toast.error("Please enter Destination MDN");
            if (!toast.isActive(toastId.current)) {
                toastId.current = toast.error(t('2472_001')); // Error message for empty MDN
        }
            document.getElementById("destinationMDN").focus();
            setIsSubmitting(false); // Reset submitting state
            return;
        }

        // Perform amount validation
        if (!amountVal || amountVal.trim() === '') {
            if (!toast.isActive(toastId.current)) {
                toastId.current = toast.error(t('2472_002'),{
                    onClose: () => {
                        setAmountVal("0.00");
                        document.getElementById("depositamount").focus();
                        setIsSubmitting(false); // Reset submitting state
                    }
                })
         }
            return;
        }
    
        const formattedAmountVal = parseFloat(amountVal).toFixed(2);// Output: "9999.00"
        const apiUrl = window.config.apiUrl + process.env.REACT_APP_QUICKTRANSFER;
        let userName = process.env.REACT_APP_USERNAME;
        let password = process.env.REACT_APP_PASSWORD;
    
        try {
        const response = await axios.post(apiUrl, {
                                            userName,
                                            password,
                                            destinationMDN: mdn,
                                            partnerLoginId,
                                            amountVal: formattedAmountVal,
                                            localeVar
                                        });

        const data = response.data;
        if(response.data.responseDescription==="SUCESS"){
            setMdn('');
            setAmountVal('');
        }else{
            console.log(response.data.msg,"data.msg--------------")
            if(response.data.msg)
            {
        //       if (!toast.isActive(toastId.current)) {
        //           toastId.current = toast.error(data.msg); // Error message for empty MDN
        //   }
          setShowError(response.data.msg);
          setMdn('')
          setAmountVal('')
            }
      }// console.log("data=",response.data);
        // setMsg(data.msg);
        // console.log("msg="+data.msg);


        } catch (error) {
            console.error("Error during form submission:", error);
        } finally {
            setIsSubmitting(false); // Reset submitting state
        }
    };


    // const handleBlur = (value, setValue) => {
    //     const parsedValue = parseFloat(value);
    //     console.log("Parsed value:", parsedValue); // Debug line
    //     if (isNaN(parsedValue) || parsedValue < 0) {
    //       setAmountVal("0.00");
    //     } else {
    //       setAmountVal(parsedValue.toFixed(2));
    //     }
    //     validateAmount(value, setValue);
    //   };
    const handleBlur = (value, setValue) => {
        console.log("Before Validation:", value); // Debugging purpose
        validateAmount(value, setValue);
    };
    return(
        <>
            <div className={'mL8 distAccnt'}>
            {/* <table width="100%">
                <tbody>
                    <tr><td width="100%" class="headingText">{t('046')}{/*Quick Transfer*</td></tr>
                    <tr>&nbsp;</tr>
                </tbody>
            </table> */}

            <table align="left" width="50%">
                <tbody>
                    <tr><td style={{padding:'0'}}>&nbsp;</td></tr>


                    <div style={{position: 'relative',textAlign: 'center',}}>
{showError && (
<p style={{color: 'red', fontSize: '11px', textAlign: 'center', position: 'absolute', marginTop:'-7px', }}>
                {showError}
                </p>
                 )}
                 </div>

                    <br/>
                    {/* <tr>
                        <td colspan="2" align="left" class='redTxt'>
                            {msg !== '' ? msg : ''}
                        </td>
                    </tr> */}
                    {msg !== '' ? <tr>&nbsp;</tr>: <></>}
                    <tr>
                        {/* <td style={{width: '100px', textAlign: 'left'}} class="strongerTxtLable">{t('048')}Destination MDN</td> */}
                        <td style={{padding:'0'}}><TextField label={
                                  <span>
                                    {`${t("048")}`}
                                  </span>
                                } 
                      type="text" 
                      name="destinationMDN" 
                      id="destinationMDN" 
                      value={mdn} 
                      maxlength="25" 
                      size="20" 
                      onChange={(e) => mdnValidate(e)}  
                      onInput={(e) => {
                        // Allow only digits and limit to 30 characters
                        e.target.value = e.target.value.replace(/[^0-9]/g, '').slice(0, 50);
                      }}
                      onBlur={() => {
                        // Only validate on blur if the field is not empty or if we are submitting
                        if (mdn.trim() !== '' || isSubmitting) {
                            mdnValidate({ target: { value: mdn } });
                        }
                    }}
                      className={'sampleInput mb5'} /></td>
                        {/* <td style={{transform: 'translate(5px, 0px)'}}><input type="text" name="destinationMDN" id="destinationMDN" maxlength="25" size="20" onChange={(e) => mdnValidate(e)} value={mdn} className={'textBoxSmall'} /></td> */}
                    </tr>

                    <tr>
                        {/* <td style={{width: '100px', textAlign: 'left'}} class="strongerTxtLable">{t('049')}Amount (MXN)</td> */}
                        <td style={{padding:'0'}}><TextField  label={
                                  <span>
                                    {`${t("049")}`} (MXN)
                                  </span>
                                } 
                                 type="text" 
                                 name="totFundAmt" 
                                 id="depositamount"
                                 value={amountVal}  
                                 size="18" 
//                               onChange={(e) => {
//                               setAmountVal(e.target.value);
//                               numValidate(e);
// }}
onChange={(e) =>
    setAmountVal(
      e.target.value
    )
  }
onBlur={() =>
    handleBlur(
        amountVal,
        setAmountVal
    )
    }
          className={'sampleInput mb5'} /></td>
                        {/* <td style={{transform: 'translate(5px, 0px)'}}><input type="text" name="totFundAmt" id="depositamount" size="18" onChange={(e) => numValidate(e)} onBlur={() => validateAmount()} value={amountVal} className={'textBoxSmall'} /></td> */}
                    </tr>

                    {/* <tr><td colspan="2">&nbsp;</td></tr> */}

                    <tr>
                        <td>


                        <Box style={{display: 'flex', gap: '8px'}}>
	<Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />} onClick={() => submit()} >{t('028')}</Button>
	
  <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelRounded />} onClick={() => clearSearch()}  >{t('003')}</Button>		
  </Box>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
        </>
    );
}

export {QuickTransfer};
