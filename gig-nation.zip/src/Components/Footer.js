import React, { Component } from 'react'

export class Footer extends Component {
  render() {
    return (
      <div>
         
    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={0} width={1000} align="center">
      <tbody>
    {/* <link href="http://10.10.19.189:8180/airmanage/networkadmin/stylesheets/abcstyles-new.css" rel="stylesheet" type="text/css" /> */}
    <tr height="60px">
        <td colSpan={2}>
       
          {/* <INPUT type='hidden' name='OWASP_CSRFTOKEN'  value='7WpIX_Ebt2PvMOPATNuVDx9G9q5WKY0yxsE4okLcrVg=' > */}
          <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="60px" bgcolor="#E5E5E5">
            <tbody><tr height="60px"><td align="left" width={'100%'}>
                  <a href="javascript:showTermsConditions();" className="nav">
                    <font face="Arial" style={{fontSize: '8.5pt'}}><u>Terms &amp; Conditions</u></font></a><font face="Arial" style={{fontSize: '8.5pt'}}>
                  </font></td>
                <td align={'right'} nowrap={'true'}><a target="xius_website" href="http://www.xius.com" className="nav"><u>Powered by</u></a></td>
                <td align={'right'} width={1}><img border={0} src={require("../images/bott_logo.jpg")} width={72} height={35} /></td>
              </tr></tbody></table>
        </td>
      </tr>
      </tbody>
     </table>
      </div>
    )
  }
}

export default Footer
