/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, LeftBgImage, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, Menu,CircularProgress, FormControl, FormControlLabel, FormLabel, Grid, InputLabel, MenuItem, Pagination, Paper, Radio, RadioGroup, Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, TableSortLabel } from "@mui/material";
import React, { useState, useEffect, useCallback } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CloudDownload, KeyboardReturn,DoneAllRounded,RestartAltRounded, SaveRounded } from '@mui/icons-material';
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
 import ExcelJS from 'exceljs';
 import { useRef } from "react";
import SendIcon from '@mui/icons-material/Send';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { DatePicker, DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import 'dayjs/locale/es'; // Spanish locale
import 'dayjs/locale/en'; // English locale (optional, dayjs default is English)
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';


function ReversalTrasactionReport(){sessionStorage.setItem("selectedLink", "e_transactions");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
  //const [partnerLoginId ,setPartnerLoginId]= useState('');
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
    const toastId = useRef(null);
     const [anchorEl, setAnchorEl] = useState();
      const closeTimeoutRef = useRef(null);


    const [subscriberCellularNumber, setSubscriberCellularNumber] = useState('');
    const now = dayjs();
  const midnightToday = dayjs().startOf('day');
  const [startDateTime, setStartDateTime] = useState(midnightToday);
  const [startDate, setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
  const [endDateTime, setEndDateTime] = useState(now);
  const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));
    const [status, setStatus] = useState(' ');
    const [transactionType, setTransactionType] = useState('---');
    const [hierarchyMode, setHierarchyMode] = useState('N');
    const [transactionNumber, setTransactionNumber] = useState(''); 
    const [sequnceIso, setSequnceIso] = useState('');
    const [authorizationId, setAuthorizationId] = useState('');
    const [canalId, setCanalId] = useState('');
    const [terminalId, setTerminalId] = useState('');
    const [sucursalId, setSucursalId] = useState('');
    const[replenishment ,setReplenishment ] = useState('---');
    const[referenceId, setReferenceId] = useState('');
    const[statusId, setStatusId] = useState('F');
    const[isAdmin, setIsAdmin] = useState('');
    const[levelFlag, setLevelFlag] = useState('N');
    const[carrierId, setCarrierId] = useState('');
    const[download, setDownload] = useState('N');
  const navigate = useNavigate();
   const [order, setOrder] = useState('asc');
  const [orderBy, setOrderBy] = useState('transactionDate');
  const [amount, setAmount] = useState('');
  console.log("totalRecords++++++++++++",totalRecords)

let reportDays = process.env.REACT_APP_ReportDays;
const transIdRef = useRef(null);
    const [apply,setApply] =useState(false);
 
  const [replenishmentOptions, setReplenishmentOptions] = useState([]);
  const [transactionApiOptions, setTransactionApiOptions] = useState([]);

     console.log("totalRecords++++++++++++", totalRecords)
  let startRecord=0;
  let endRecord =10;


const handleChangePage = async (event, newPage) => {
  event.preventDefault();

const isValid = validateDateRange({
             startDateTime,
             endDateTime,
             reportDays,
             toast,
             toastId,
             t
           });
       
        if (!isValid) {
        return;
      }
    
    if(!apply){
    
    if (!toast.isActive(toastId.current)) {
          toastId.current = toast.error(t('apply_validation'));
        //  setSubmitted(false);
        }
    return false;
    
    }

  setPage(newPage);
  await fetchData(newPage); // fetch data for the selected page
  
};

const RedAsterisk = styled('span')({
    color: 'red',
  });




  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);


  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
 
   const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };
  

//date validation 
const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
   
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      

    }
    return false;
  }

  return true;
};

  const handleEndDateTimeChange = (newValue) => {
    setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };
  const handleStartDateTimeChange = (newValue) => {
    setApply(false);
    setStartDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setStartDate(formattedDateTime);
    console.log("startDate::::::", newValue)
    console.log("startDate::::::", formattedDateTime)
  };


  const handleSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };



const handlePdfDownload = () => {
    console.log('Downloading as PDF...');
    // Your logic here
  };
 
  const handleCsvDownload = () => {
    console.log('Downloading as CSV...');
    // Your logic here
  };
 
  const handleExcelDownload = () => {
    console.log('Downloading as Excel...');
    // Your logic here
  };

  // Get current date and time
    const currentDate = new Date();
    const formattedDate = currentDate.toLocaleDateString('en-US', {
      weekday: 'short', 
      year: 'numeric', 
      month: 'numeric', 
      day: 'numeric'
    });
    const formattedTime = currentDate.toLocaleTimeString('en-US', {
      hour: 'numeric', 
      minute: 'numeric'
    });
const doReset1 = () => {
  // Add your reset logic here
  console.log("Reset clicked");
  // For example, reset state variables
};

   const doReset = async () => {
  setSubscriberCellularNumber('');
  setTransactionNumber('');
  setSequnceIso('');
  setAuthorizationId('');
  setCanalId('');
  setTerminalId('');
  setSucursalId('');
  setTransactionType('---');
  setReplenishment('---');
  setStartDateTime(dayjs().startOf('day'));
  setEndDateTime(dayjs());
  setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'))
  setEndDate(now.format('DD/MM/YYYY HH:mm:ss'))
  setStatus(' ');
  setLevelFlag('N');
 
  setPage(1);
  setPerPage(10);
  setStatusId('F');
};


  


useEffect(() => {
  fetchReplenishmentDropdown();
  fetchTransactionAPIDropdown();
  }, []);

  

  const fetchReplenishmentDropdown = async () => {
    try {
      //const localeVar = 'en_US';

      const apiUrl = window.config.apiUrlJasper+ '/replenishmentChannels';
      // OR use window.config if it's defined:
      // const apiUrl = window.config.apiUrl + '/jasper/replenishmentChannels';

      const response = await axios.post(apiUrl, {
        userName,
        password,
        localeVar,
      });

      const options = response.data;
      setReplenishmentOptions(options);
      console.log("options========>",options);
    } catch (error) {
      console.error('Error fetching replenishment channels:', error);
    }
  };





const fetchTransactionAPIDropdown = async () => {
  try {
    const apiUrl = window.config.apiUrlJasper+ '/getTransactionAPI';
    const response = await axios.post(apiUrl, {
      userName,
      password,
    });
    
    const options1 = response.data.summaryConfigArray;
    setTransactionApiOptions(options1); 
    console.log("Transaction API Options:", options1);
  } catch (error) {
    console.error('Error fetching transaction API dropdown:', error);
  }
};



 
const fetchData = async (pageNumber = 1) => {
  const startRecord = (pageNumber - 1) * perpage + 1;
  const endRecord = startRecord + perpage - 1;

    setIsLoading(true);

    
    try {


  //      if (authorizationId.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(authorizationId)) {
  //   toast.error(`${t('alrt_01')} in ${t('2480_033')}.`);
  //   return;
  //  }

 const toastId = 'error';
 
if (authorizationId.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(authorizationId)) {
  if (!toast.isActive(toastId)) {
    toast.error(`${t('alrt_01')} in ${t('2480_033')}.`, {
      toastId: toastId
    });
  }
  transIdRef.current?.focus();
  return;
}

  const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t
    });

if (!isValid){
  setApply(false);
  return;
}   




     setStatusId('N');
      console.log("replenishment====>",replenishment);
      const apiUrl = window.config.apiUrlJasper+ '/getreversaltransactions';
      const response = await axios.post(apiUrl, {          
        userName,
        password,
        partnerLoginId,
        subscriberCellularNumber,
        transactionNumber,
        amount,
        referenceId,
        statusId,
        startDateTime:startDate,
        endDateTime:endDate,
        levelFlag,
        carrierId,
        transactionType,
        sequnceIso,
        replenishment,
        authorizationId,
        canalId,
        terminalId,
        sucursalId,
        download,
        beginingRecordNum: startRecord,
        endingRecordNum: endRecord,
        localeVar
      });
      console.log("response::::::",response);
      if (response.status === 200) {
        setItems(response?.data?.summaryConfigArray || []);
        setTotalRecords(response.data.totalRecords || 0);
      }
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

     const sortedItems = [...items].sort((a, b) => {
    const valA = a[orderBy] || '';
    const valB = b[orderBy] || '';
    if (valA < valB) return order === 'asc' ? -1 : 1;
    if (valA > valB) return order === 'asc' ? 1 : -1;
    return 0;
  });



  const fetchDataDownload = async () => {

 const isValid = validateDateRange({
           startDateTime,
           endDateTime,
           reportDays,
           toast,
           toastId,
           t
         });
     
      if (!isValid) {
      // setSubmitted(false);  // reset submit flag
      return;
    }
    
    if(!apply){
    
    if (!toast.isActive(toastId.current)) {
          toastId.current = toast.error(t('apply_validation'));
        //  setSubmitted(false);
        }
    return false;
    
    }


    try {
    
        const apiUrlDownload = window.config.apiUrlJasper+ '/getreversaltransactions';
        console.log('API URL:', apiUrlDownload);
        console.log('Partner Login ID:', partnerLoginId);
        setDownload('Y');
         const response = await axios.post(apiUrlDownload, {      
        userName,
        password,    
        partnerLoginId,
        subscriberCellularNumber,
        transactionNumber,
        sequnceIso,
        authorizationId,
        canalId,
        terminalId,
        sucursalId,
        transactionType,
        replenishment,
        startDateTime:startDate,
        endDateTime:endDate,
        download,
        localeVar
            });

        console.log('Response:', response.data.summaryConfigArray);

        if (!response.data || !response.data.summaryConfigArray) {
            throw new Error('Invalid API response');
        }
          const safeNumber = (val) => {
    const num = parseFloat(val);
    return isNaN(num) ? 0.00 : parseFloat(num.toFixed(2));
  };
        const downloadData = response.data.summaryConfigArray.map(item => ({
       	c1: item.c1|| '---',
        c2: item.c2|| '---',
        c3: item.c3|| '---',
        c4: item.c4|| '---',
        c5: item.c5||'---',
        c6: item.c6|| '---',
        c7:item.c7 || '---',
        c8: item.c8|| '---',
        c9: item.c9 || '---',
        c15: item.c15|| '---',
        c16: item.c16 ||'---',
        c17: item.c17 ||'---',
        c18:  item.c18||'---',
        c19: item.c19 ||'---',
       currencySymbol:item.currencySymbol || '---',
	     parentName:  item.parent_name|| '---', 
		    mainDistName: item.mainDistName|| '---',
		    levl: item.levl|| '---',
		    authorizationId:item.authorizationId || '----', 
		    recAuthorizationId: item.recAuthorizationId || '----',
        transactionCode: item.transactionCode|| '---',
        canalId:item.canalId|| '---', 
        terminalId: item.terminalId|| '---',
        sucursalId:  item.sucursalId|| '---', 
        transactionCategory: item.transactionCategory || '---',
        queueProcessingTime:item.queueProcessingTime|| '---',
        PromotionPlanName: item.PromotionPlanName || '---',
        altamiraPlan:item.altamiraPlan || '---'
             
   
      }));


        console.log('Download Data:', downloadData);

        return downloadData;
    } catch (error) {
        console.error('Error fetching data:', error);
        return [];
    }
};



const handleDownloadPdf = async () => {
  const downloadItems = await fetchDataDownload(); // same data as Excel
    if (!downloadItems || downloadItems.length === 0) return;
  const tableBody = [];

  // Table Headers (first row)
  const headers = [
   t('2481_047'),t('023') ,t('2481_048'),t('2481_012'),t('2481_049'),t('2481_050'),t('2481_022'),t('2481_023'),t('2481_020'),
t('2481_93')  ,   t('phone_name') ,   t('2481_90')  ,  t('2481_016'),t('2481_017'),t('2481_051'),t('251620') , t('2481_052'),t('rtr_055'),
t('2481_004'),t('2481_003'),t('2481_005'),t('2481_015'),t('2481_053'),t('2481_054'),t('2481_018'),t('2481_055'),t('2481_056')
  ];
  tableBody.push(headers.map(header => ({ text: header, style: 'tableHeader' })));

  // Table Rows
  downloadItems.forEach(item => {
    const row = [
          
        item.c1|| '---',
       item.c2|| '---',
       item.c3|| '---',
       item.c4|| '---',
	   item.recAuthorizationId|| '---',
	   item.authorizationId || '----',
	   item.parentName|| '---', 
	   item.mainDistName|| '---',
	   item.levl|| '---',
	    item.c15|| '---',
       item.c5||'---',
       item.c6|| '---',
	   item.PromotionPlanName || '---',
	   item.altamiraPlan || '---',
      Number(item.c7 || 0).toFixed(2) || '---',
	   item.currencySymbol || '---',
       item.c8|| '---',
       item.c9 || '---',
	   item.terminalId|| '---',
	   item.canalId|| '---',
	   item.sucursalId|| '---',
       item.queueProcessingTime|| '---',	   
        item.c17 ||'---',
        item.c16 ||'---',
        item.transactionCategory|| '---',
         item.c18||'---',
        item.c19 ||'---'
		


      ];
    tableBody.push(row);
    
  });

  // Content Structure
  const content = [
    {
      text: localeVar === 'en' ? "ReversalTrasactionReport" : "Reporte de Transaccionesde Reversa",
      style: 'title',
      alignment: 'center',
      margin: [0, 0, 0, 10]
    },
   {
  columns: [
    {
      text: `${t('032')} : ${totalRecords}`,
      alignment: 'left',
      fontSize: 8
    },
    // {
    //   text: `${t('033')} : ${startRecord} - ${endRecord}`,
    //   alignment: 'right',
    //   fontSize: 8
    // }
  ],
  margin: [0, 0, 0, 5]
},
    {
      style: 'tableExample',
      table: {
        headerRows: 1,
        widths: [
          20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
          20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
          20, 20, 20, 20, 20, 20, 20, 20, 20
        ],
        body: tableBody
      },
      layout: {
        fillColor: function (rowIndex) {
          return rowIndex === 0 ? '#3399FF' : null;
        }
      }
    },
    {
      text: t('0171'),
      style: 'endText',
      alignment: 'center',
      margin: [0, 10, 0, 0]
    }
  ];

  // PDF Definition
  const docDefinition = {
    content: content,
    styles: {
      title: { fontSize: 16, bold: true },
      subheader: { fontSize: 10, bold: true },
      tableExample: { margin: [0, 5, 0, 15] },
      tableHeader: { bold: true, fontSize: 8, color: '#fff' },
      endText: { italics: true, bold: true, decoration: 'underline', fontSize: 10 }
    },
    pageOrientation: 'landscape',
    defaultStyle: {
      fontSize: 8
    }
  };

  pdfMake.createPdf(docDefinition).download('ReversalTransactions.pdf');
};




const handleDownloadCsv = async () => {
  const downloadItems = await fetchDataDownload(); // same as in PDF
    if (!downloadItems || downloadItems.length === 0) return;
  
  
  const formatAmount = (value) => {
  if (value === null || value === undefined || value === '') return '0.00';
  const num = Number(value);
  if (Number.isNaN(num)) return '0.00';
  return `="${num.toFixed(2)}"`; // Excel will show exactly 10.00
  };


  const formatDateTime = (value) => {
    if (!value) return "---";
    const date = new Date(value);
    if (isNaN(date.getTime())) return value;
    const pad = (n) => (n < 10 ? '0' + n : n);
    return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };
  const headers = [
    t('2481_047'), t('023'), t('2481_048'), t('2481_012'), t('2481_049'), t('2481_050'), t('2481_022'),
    t('2481_023'), t('2481_020'), t('2481_93'), t('phone_name'), t('2481_90'), t('2481_016'), t('2481_017'),
    t('2481_051'), t('251620'), t('2481_052'), t('rtr_055'), t('2481_004'), t('2481_003'),
    t('2481_005'), t('2481_015'), t('2481_053'), t('2481_054'), t('2481_018'), t('2481_055'), t('2481_056')
  ];

  const title = localeVar === 'en'
    ? 'ReversalTransactionsReport'
    : 'Reporte de Transaccionesde Reversa';

  const summaryLeft = `${t('032')} : ${totalRecords}`;
  const summaryRight = ``;

  // Title centered visually in 27 columns (middle is around column 14)
  const paddedTitleRow = `${Array(13).fill('').join(',')}${title}\n`;

  // Summary: left in column 1, right in column 27
  const paddedSummaryRow = `${summaryLeft},${Array(25).fill('').join(',')},${summaryRight}\n`;

  // Build CSV content
  let csvContent = '';
  csvContent += paddedTitleRow;
  csvContent += paddedSummaryRow;
  csvContent += '\n'; // empty row for spacing
  csvContent += headers.join(',') + '\n';

  downloadItems.forEach(item => {
    const row = [
      item.c1|| '---',
       item.c2|| '---',
       item.c3|| '---',
       item.c4|| '---',
	   item.recAuthorizationId|| '---',
	   item.authorizationId || '----',
	   item.parentName|| '---', 
	   item.mainDistName|| '---',
	   item.levl|| '---',
	    item.c15|| '---',
       item.c5||'---',
       item.c6|| '---',
	   item.PromotionPlanName || '---',
	   item.altamiraPlan || '---',
    //  item.c7,
     formatAmount(item.c7),
    //  item.c7 != null ? Number(item.c7).toFixed(2) : '---',

	   item.currencySymbol || '---',
       item.c8|| '---',
       item.c9 || '---',
	   item.terminalId|| '---',
	   item.canalId|| '---',
	   item.sucursalId|| '---',
       item.queueProcessingTime|| '---',	   
        item.c17 ||'---',
        item.c16 ||'---',
        item.transactionCategory|| '---',
         item.c18||'---',
        item.c19 ||'---'
    ];

    const csvRow = row
      .map(field =>
        typeof field === 'string' && field.includes(',') ? `"${field}"` : field
      )
      .join(',');
    csvContent += csvRow + '\n';
  });
  

  const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;


  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', 'ReversalTransactionsReport.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


  const totalPages = Math.ceil(totalRecords / recordsPerPage);
 startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);

  const handleDownload = async () => {
   const downloadItems = await fetchDataDownload();
     if (!downloadItems || downloadItems.length === 0) return;
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('ReversalTransactionReport');
    const headingRow1 = worksheet.addRow([t('k_reversaltransactionreport')]);
    const numberOfColumns = 8; // Adjust this to match the number of columns in your table
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    const headingCell = headingRow1.getCell(1);
    headingCell.font = { bold: true };
    headingCell.alignment = { horizontal: 'center' };
    worksheet.addRow([]); // Empty row
    const headingRow2 = worksheet.addRow();
    worksheet.mergeCells(headingRow2.number, 1, headingRow2.number, numberOfColumns);
    const headingCell2 = headingRow2.getCell(1);
   

const summaryRow = worksheet.addRow([]);
summaryRow.getCell(1).value = `${t('032')} : ${totalRecords}`; // Total records
summaryRow.getCell(5).value = ``; // Displayed range + pages

summaryRow.getCell(1).alignment = { horizontal: 'left' };
summaryRow.getCell(5).alignment = { horizontal: 'right' };

// Merge cells for alignment
worksheet.mergeCells(summaryRow.number, 1, summaryRow.number, 4); // Left half
worksheet.mergeCells(summaryRow.number, 5, summaryRow.number, 8); // Right half

// Spacer Row before headers
worksheet.addRow([]);



   // worksheet.addRow([]); // Empty row
    
    const columnHeaders = [
    t('2481_047'),t('023') ,t('2481_048'),t('2481_012'),t('2481_049'),t('2481_050'),t('2481_022'),t('2481_023'),t('2481_020'),
t('2481_93')  ,   t('phone_name') ,   t('2481_90')  ,  t('2481_016'),t('2481_017'),t('2481_051'),t('251620') , t('2481_052'),t('rtr_055'),
t('2481_004'),t('2481_003'),t('2481_005'),t('2481_015'),t('2481_053'),t('2481_054'),t('2481_018'),t('2481_055'),t('2481_056')
    ];
    const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
        cell.font = { bold: true };
        cell.alignment = { horizontal: 'center' };
        cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
        };
    });
    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
   
        item.c1|| '---',
       item.c2|| '---',
       item.c3|| '---',
       item.c4|| '---',
	   item.recAuthorizationId|| '---',
	   item.authorizationId || '----',
	   item.parentName|| '---', 
	   item.mainDistName|| '---',
	   item.levl|| '---',
	    item.c15|| '---',
       item.c5||'---',
       item.c6|| '---',
	   item.PromotionPlanName || '---',
	   item.altamiraPlan || '---',
       Number(item.c7 || 0).toFixed(2)|| '---',
	   item.currencySymbol || '---',
       item.c8|| '---',
       item.c9 || '---',
	   item.terminalId|| '---',
	   item.canalId|| '---',
	   item.sucursalId|| '---',
       item.queueProcessingTime|| '---',	   
        item.c17 ||'---',
        item.c16 ||'---',
        item.transactionCategory|| '---',
         item.c18||'---',
        item.c19 ||'---'
	

      ]);
        dataRow.eachCell(cell => {
            cell.border = {
                top: { style: 'thin' },
                left: { style: 'thin' },
                bottom: { style: 'thin' },
                right: { style: 'thin' }
            };
            cell.alignment = { horizontal: 'center' }; // Center-align the cell content
        });
    });
      worksheet.addRow([]);

    const emptyRow3 = worksheet.addRow([]);
    emptyRow3.hidden = true; // Hide the empty row
    const endOfReportText = t('0171'); // Replace with your translated text
    const endOfReportRow = worksheet.addRow([endOfReportText]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
      // Style the "End of Report" cell
      const endOfReportCell = endOfReportRow.getCell(1);
      endOfReportCell.font = { italic: true, underline: true, bold: true };
      endOfReportCell.alignment = { horizontal: 'center' };
      
  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });

    // Protect the worksheet to make it read-only
    worksheet.protect('yourPassword', {
        selectLockedCells: true,
        selectUnlockedCells: true,
        formatCells: false,
        formatColumns: false,
        formatRows: false,
        insertColumns: false,
        insertRows: false,
        insertHyperlinks: false,
        deleteColumns: false,
        deleteRows: false,
        sort: false,
        autoFilter: false,
        pivotTables: false
    });

    // Generate and download the Excel file
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'ReversalTransactionReport.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

// const goToViewSubDistributors = useCallback(async (partnerId) => {
//   setPartnerLoginId(partnerId);
//   setPage(1);
// }, []);

// const handleSubGroupNavigation = (distId) => {
//   navigate('/profile', { state: { distId } });
//   setPartnerLoginId(distId);
//   setPage(1);
// };



const handleSubmit1 = async (e) => {
  e.preventDefault();
  const firstPage = 1;
  setPage(firstPage);
  await fetchData(firstPage); // fetch data for page 1
   setApply(true);
  
};



const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}


var fromDate='';
if(startDateTime != null){
  var d = new Date(startDateTime);
  var month= d.getMonth()+1;

  var day = d.getDate();
  var year = d.getFullYear();
  var hours = d.getHours();
  var minutes = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;

  // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
  fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
  console.log("StartDate = "+ day + "/" + month + "/" + year + " " + hours + ":" + minutes);
}

var toDate='';
if(endDateTime != null){
  var d = new Date(endDateTime);
  var month2= d.getMonth()+1;
  var hours1 = d.getHours();
  var minutes1 = d.getMinutes();


  // Ensure that hours and minutes are always two digits
  hours1 = hours1 < 10 ? '0' + hours1 : hours1;
  minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;


  toDate =  d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1;
  console.log("EndDate = "+ d.getDate() + "/" +month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1);
}
const formatSpanishNumbers = (date) => {
    return new Intl.DateTimeFormat('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  
  


return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Packet Sales Report":"Informe de Ventas de Paquetes de paquetes"}/>
  </tr>

  <tr>
  
<div style={{ display: 'flex' }}> 
    <LeftBgImage1 />
</div>
<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
   <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
       {/* <NavLink
            to="/reversaltrasactionreport"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${"menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab label={'ReversalTrasactionReport'} /></NavLink> */}


       <NavLink
            to="/reversaltrasactionreport"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${"menuHighlight" ? 'addingDynClass' : ''}`
                      }><Tab label={t('k_reversaltransactionreport')} /></NavLink>
   </Tabs>
  </Box>

    <div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="80%">
            {/* body starts */}
          

    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>


          
               <Box style={{display:'flex', gap:'12px',marginTop:'10px'}}> 
                
              {/* <TextField
  type="text"
  name="salesId"
  className="sampleInput mb5"
  label={
    <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
      {t('2481_014')}
    </Box>
  }
  style={{ maxWidth: '250px', width: '210px' }}
  value={subscriberCellularNumber}
  onChange={(e) => {
    const input = e.target.value;
    if (/^\d{0,10}$/.test(input)) {
      setSubscriberCellularNumber(input);
    }
  }}
  inputProps={{
    maxLength: 10,
    inputMode: 'numeric',
    pattern: '[0-9]*',
  }}
  size="small"
/> */}

{/* <TextField
  type="text"
  name="salesId"
  className="sampleInput mb5"
  label={<span>{`${t('2481_014')}`}</span>}
  style={{ maxWidth: '250px', width: '210px' }}
  value={subscriberCellularNumber}
  onChange={(e) => {
    const input = e.target.value;
    // Allow only digits and limit to 10
    if (/^\d{0,10}$/.test(input)) {
      setSubscriberCellularNumber(input);
    }
  }}
  inputProps={{ maxLength: 10 }}
/> */}

 <TextField
                    label={t('2481_014')}
                    size="15"
                    className={"sampleInput mb5"}
                    style={{ maxWidth: '250px', width: '210px' }}
                    onChange={e => setSubscriberCellularNumber(e.target.value)}
                     name="salesId"
                    value={subscriberCellularNumber}
                    type="text"
                    autoComplete="off"
/>


                    <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                     {`${t('2481_047')}`} 
                     
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setTransactionNumber(e.target.value)} value={transactionNumber} size="15" defaultValue=""
               />
      
              
      
          <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('rtr_055')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setSequnceIso(e.target.value)} value={sequnceIso} size="15" defaultValue=""
               />

                   <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_002')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setAuthorizationId(e.target.value)} value={authorizationId} inputRef={transIdRef} size="15" defaultValue=""
               />


                 

               
                 

</Box>
<Box style={{display:'flex', gap:'12px'}}> 
                   <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_003')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setCanalId(e.target.value)} value={canalId} size="15" defaultValue=""
               />
               
                   <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_004')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setTerminalId(e.target.value)} value={terminalId} size="15" defaultValue=""
               />            
              <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_005')}`} 
                        </span>} style={{maxWidth:'250px',width:'210px'}}
               onChange={e => setSucursalId(e.target.value)} value={sucursalId} size="15" defaultValue=""
               />
               <FormControl className={'selected_formcontrol'} sx={{  minWidth: 210 }}size="small">
            <InputLabel id="demo-select-small-label">
             {t('2481_046')} 
            </InputLabel>
      
            <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
            label="Transaction Type"
            value={transactionType} 
            onChange={e => setTransactionType(e.target.value)}>
              
          <MenuItem value="---">{"---"}</MenuItem>

    {transactionApiOptions.map((option1) => (
      <MenuItem key={option1.apiId} value={option1.apiId}>
        {option1.apiName}
      </MenuItem>
  ))}


            
            </Select>
          </FormControl>



</Box>


   <Box style={{display:'flex',gap:'12px'}}>
               
            



 <FormControl className={'selected_formcontrol'} sx={{  minWidth: 200 }}size="small">
            <InputLabel id="demo-select-small-label">
             {t('2481_90')} 
            </InputLabel>
      
              <Select
  className={'bankSelect'}
  style={{ maxWidth: '250px', width: '210px' }}
  labelId="demo-select-small-label"
  id="demo-select-small"
  label="Replenishment Channel"
  value={replenishment}
  onChange={e => setReplenishment(e.target.value)}
>
  <MenuItem value="---">{"---"}</MenuItem>
{replenishmentOptions.map((option) => (
    <MenuItem key={option.value} value={option.value}>
      {option.label}
    </MenuItem>
  ))}
</Select>


          </FormControl> 


          {/* <FormControl className="selected_formcontrol" sx={{ minWidth: 200 }} size="small">
      <InputLabel id="replenishment-label">{t('6814')}</InputLabel>
      
      <Select
  className="bankSelect"
  style={{ maxWidth: '250px', width: '210px' }}
  labelId="replenishment-label"
  id="replenishment-select"
  value={replenishment}
  label={t('6814')}
  onChange={(e) => setReplenishment(e.target.value)}
>
   <MenuItem value="---">{"---"}</MenuItem>

  {replenishmentOptions.map((option) => (
    <MenuItem key={option.value} value={option.label}>
      {option.label}
    </MenuItem>
  ))}
</Select>



    </FormControl> */}


   <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                
                  className={'datePickerrrjasper'}
                  // label="Select Date and Time"
                  value={startDateTime}
                  onChange={handleStartDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
                  // label={t('80')} // This serves as the floating label
                  label={
                    <span>
                    {`${t('80')}`}<RedAsterisk>*</RedAsterisk>
                    </span>}
                      format="DD/MM/YYYY HH:mm:ss" 
                  inputFormat=" " // Keeps the input field empty unless a date is selected
                  renderInput={(params) => <TextField
                    {...params}
                    InputLabelProps={{
                      shrink: true, // Always shrink the label to allow for a floating effect
                    }}
                    placeholder={!startDateTime ? t('2481_91') : ''} // Show the placeholder only if no date is selected
                    fullWidth
                    variant="outlined"
                    sx={{ width: "200px", height: "40px", padding: '20px' }}
                  />}
                />
                
              </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                
               className={'datePickerrrjasper'}
               label={
                <span>
                {`${t('81')}`} <RedAsterisk>*</RedAsterisk>
                </span>}
                    format="DD/MM/YYYY HH:mm:ss" // 
                  value={endDateTime}
                  onChange={handleEndDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
               renderInput={(params) => <TextField {...params} />} />

              </LocalizationProvider>
			  
			

  {/* <FormControl className={'selected_formcontrol'} sx={{  minWidth: 200 }}size="small">
            <InputLabel id="demo-select-small-label">
             {t('2481_025')}<RedAsterisk>*</RedAsterisk> 
            </InputLabel> 
 
 
                      <Select className={'bankSelect'} 
                      labelId="demo-select-small-label" id="demo-select-small"
                      label="hierarchyMode"value={levelFlag} onChange={e => setLevelFlag(e.target.value)}>
                        <MenuItem value="Y">{t('Y')}</MenuItem>
                        <MenuItem value="N">{t('N')}</MenuItem>
                      </Select>
                    </FormControl>  */}

                   <FormControl className={'selected_formcontrol'} sx={{ minWidth: 120 }} size="small">
                                                                <InputLabel
                                                                  id="demo-select-small-label"
                                                                  sx={{ backgroundColor: '#fff', padding: '0 5px' }}
                                                                >
                                                                  {`${t('hierarchyMode')}`}<RedAsterisk>*</RedAsterisk>
                                                                </InputLabel>
                                                                <Select
                                                                  className={'bankSelect'}
                                                                  style={{ maxWidth: '210px', width: '210px' }}
                                                                  labelId="demo-select-small-label"
                                                                  id="demo-select-small"
                                                                  value={levelFlag}
                                                                  label="Select Channel"
                                                                  onChange={(e) => setLevelFlag(e.target.value)}
                                                                >
                                                                  <MenuItem value="N">{t('N')}</MenuItem>
                                                                  <MenuItem value="Y">{t('Y')}</MenuItem>


                                                                </Select>
                                                              </FormControl>


          <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
           {/*  <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<DoneAllRounded />}
              onClick={handleSubmit1} disabled={isLoading}
            >
               {t('2481_026')} 
              </Button>*/} 
     <Button
        style={{ height: '27px' }}
        className={'hoverEffectButton'}
        size="small"
        variant="contained"
        endIcon={<CheckCircleIcon />}
        onClick={handleSubmit1}
      >
        {t('2481_026')}
      </Button>
           
            {/* <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
            onClick={clearData}
            >
               {t('2481_027')}
            </Button> */}
               <Button className={'hoverEffectButton'} style={{marginTop:'3px'}} size="small" variant="contained" onClick={() => doReset()} endIcon={<RestartAltRounded/>}>{t('603')}</Button>

              
              
               </Box>
            </Box>

           <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               {/* <Grid
                  item
                  xs={11.5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {
                 
                 
                totalRecords >0 &&(
               
                <Box display="flex" justifyContent="space-between" alignItems="center">
                     <span className="strongerTxtLable">
                       {t('032')} : {totalRecords}
                     </span>
                
                     <span className="strongerTxtLable">
                       {t('033')} : {startRecord} - {endRecord}
                     </span>
                   </Box>
                      
                      
                      )}
                </Grid> */}
                <Grid
                                  item
                                  xs={5}
                                  sx={{ textAlign: "right", padding: "0 !important" }}>
                                 {totalRecords >0 ?
                                    <><span className={"strongerTxtLable"}>
                                                              {t('032')} : {totalRecords}
                                                            </span><span className={"strongerTxtLable"}>
                                                                &nbsp; / &nbsp;
                                                                {t('033')} : {startRecord} - {endRecord}
                                                              </span></>   :
                                      <></>}
                                </Grid>
              </Grid>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
        <TableRow className="darkgray">
            <TableCell align="center">{t('2481_047')} </TableCell>
       <TableCell align="center" sortDirection={orderBy === 'c2' ? order : false} >
       
          <TableSortLabel
  active={orderBy === 'c2'}          // ✅ Mark it active so arrow appears
  direction={orderBy === 'c2' ? order : 'asc'}
  onClick={() => handleSort('c2')}
  sx={{
    color: 'white',
    '& .MuiTableSortLabel-icon': {
      opacity: 1, // ✅ Force visibility
      color: 'white !important', // ✅ Ensure correct color
    },
  }}
>
  {t('023')}
</TableSortLabel>

            
              </TableCell>
      
        <TableCell align="center">{t('2481_048')} </TableCell>
        <TableCell align="center">{t('2481_012')} </TableCell>
        <TableCell align="center">{t('2481_049')} </TableCell>
        <TableCell align="center">{t('2481_050')} </TableCell>
        <TableCell align="center">{t('2481_022')} </TableCell>
        <TableCell align="center">{t('2481_023')} </TableCell>
        <TableCell align="center">{t('2481_020')} </TableCell>
        <TableCell align="center">{t('2481_93')} </TableCell>
        <TableCell align="center">{t('phone_name')} </TableCell>
        <TableCell align="center">{t('2481_90')} </TableCell>
        <TableCell align="center">{t('2481_016')} </TableCell>
        <TableCell align="center">{t('2481_017')} </TableCell>
        <TableCell align="center">{t('2481_051')} </TableCell>
        <TableCell align="center">{t('251620')} </TableCell>
        <TableCell align="center">{t('2481_052')} </TableCell>
        <TableCell align="center">{t('rtr_055')} </TableCell>
        <TableCell align="center">{t('2481_004')} </TableCell>
      <TableCell align="center">{t('2481_003')} </TableCell>
       <TableCell align="center">{t('2481_005')} </TableCell>
      <TableCell align="center">{t('2481_015')} </TableCell>
      <TableCell align="center">{t('2481_053')} </TableCell>
      <TableCell align="center">{t('2481_054')} </TableCell>
     <TableCell align="center">{t('2481_018')} </TableCell>
      <TableCell align="center">{t('2481_055')} </TableCell>
      <TableCell align="center">{t('2481_056')} </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
            <TableRow>
              <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
              {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : sortedItems.length > 0 ? (
            // Show table rows when data is available
            sortedItems.map((item, index) => (
              <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
             
                <TableCell align="center">&nbsp;{item.c1|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c2|| '---'}&nbsp;</TableCell>
                <TableCell align="center">{item.c3|| '---'}</TableCell>
                <TableCell align="center">{item.c4|| '---'}</TableCell>
                 <TableCell align="center">&nbsp;{item.recAuthorizationId|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.authorizationId || '----'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.parentName|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.mainDistName|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.levl|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c15|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c5||'---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c6|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.PromotionPlanName|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.altamiraPlan|| '---'}&nbsp;</TableCell>
                 {/* <TableCell align="center">&nbsp;{item.c7|| '---'}&nbsp;</TableCell> */}
                   <TableCell align="center"> &nbsp;{!isNaN(item.c7) ? parseFloat(item.c7).toFixed(2) : "---"}&nbsp;</TableCell>
                {/* <TableCell align="center">&nbsp;{Number(item.c7 || 0).toFixed(2)}&nbsp;</TableCell>  */}
                <TableCell align="center">&nbsp;{item.currencySymbol|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c8|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c9 || '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.terminalId || '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.canalId|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.sucursalId|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.queueProcessingTime || '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c17 ||'---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c16 ||'---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.transactionCategory || '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c18||'---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.c19 ||'---'}&nbsp;</TableCell>
             
                </TableRow>
            ))
          ) : (
            // Show 'No data found' message if no items are found after loading
            statusId === 'F' ? <TableRow>
<TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                        {t("038")} {/* No data found for the given search criteria */}
</TableCell>
</TableRow> :
<TableRow>
<TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                        {t("2481_061")} {/* No data found  */}
</TableCell>
</TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
  <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                            {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,
                                                 }}
                                               >
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{t('pdf')}</MenuItem>
                                                  <MenuItem onClick={() => { setAnchorEl(null); handleDownload(); }}>{t('excel')}</MenuItem>
                                                   <MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{t('csv')}</MenuItem>
                                               </Menu>
                                             </div>
                                              : <></>}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</td></tr>
</div>
</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>
<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                    style={{
    width: "auto",           // Let width grow with message
    fontSize: "18px",        // Optional: keep font size
    padding: "8px",          // Optional: spacing inside
    wordBreak: "break-word", // Ensure long words/wrapped text don't overflow
  }}
                      />
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  );
}

export default ReversalTrasactionReport;
