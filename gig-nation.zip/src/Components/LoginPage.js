import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../App.css';
import { useNavigate } from 'react-router';
import Navbar from './Navbar';
import { Footer } from './PageComponents';
import { useTranslation } from 'react-i18next';
import { useDispatch } from 'react-redux';
import { setUserSession } from '../reducers/exampleSlice';
import { CancelRounded, LoginOutlined } from '@mui/icons-material';
import { Box, Button, Grid } from '@mui/material';
import CircularProgress from '@mui/joy/CircularProgress';
import SendIcon from '@mui/icons-material/Send';
import i18n from './i18n';
import { ToastContainer, toast } from "react-toastify";
import { useSelector } from 'react-redux';
import { logoutUser } from '../reducers/exampleSlice';
import { Link } from 'react-router-dom';
import loginbg from '../images/login1.webp'
 
function LoginPage({gettingdata}) {
 
    const dispatch = useDispatch();
    const [partnerId, setPartnerId] = useState('');
    const [partnerPassword, setPartnerPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [logoutHide, setLogoutHide] = useState(false);
    // let localeVar=i18n.language;
    let localeVar = i18n.language === "es" ? "es" : "en";
    console.log("localeVar:::::::",localeVar);
   const exampleData = JSON.parse(localStorage.getItem("userData"))
    const [tempChkVar, setTempChkVar] = useState('firstTime'); // Initialize as 'firstTime'
    // const [userName, setUserName] = useState(process.env.REACT_APP_USERNAME);
    // const [password, setPassword] = useState(process.env.REACT_APP_PASSWORD);
    const browser = navigator.userAgent;
 
    console.log('Browser==='+browser)
 
    const toastId = useRef(null);
    const {t} = useTranslation();

    //sessionStorage.setItem("selectedIndex", 0);
    sessionStorage.setItem("selectedSubLinkIndex", 0);
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
 
 
    const navigator1=useNavigate();
 
 
    useEffect(() => {
      i18n.changeLanguage('es');
      sessionStorage.setItem('language', 'es');
        // Check if a session ID exists in localStorage
        const existingSessionId = localStorage.getItem('sessionId');
        console.log("existingSessionId:::::",existingSessionId);
        if (existingSessionId) {
            setTempChkVar(existingSessionId);
        }
       
    }, []);

    useEffect(() => {
        const fetchIp = async() => {
        try {
            const response = await axios.get('https://api.ipify.org?format=json');
            localStorage.setItem("clientNetworkIp",response.data.ip);
            console.log("clientNetworkIp", localStorage.getItem("clientNetworkIp"));
          } catch (error) {
            console.error('Error fetching the IP address', error);
          }
        }
    

        fetchIp();

    }, [])
 
   const handleLogin = (event) => {
        event.preventDefault();

        // Basic validations: username and password must not be empty
        if (partnerId.trim() === '') {
          if (!toast.isActive(toastId.current)) {
            toastId.current = toast.error(t('2480_001')); // username required
          }
          return;
        }

        if (partnerPassword === '') {
          if (!toast.isActive(toastId.current)) {
            toastId.current = toast.error(t('2480_002')); // password required
          }
          return;
        }

        // Bypass API call: accept any non-empty credentials and go to home
        const sessionId = `local-session-${Date.now()}`;
        const userData = {
          FIRST_NAME: partnerId || 'User',
          LAST_NAME: '',
          passwordStatus: 'Active',
        };

        localStorage.setItem('sessionId', sessionId);
        localStorage.setItem('firstName', userData.FIRST_NAME);
        localStorage.setItem('secondName', userData.LAST_NAME);

        dispatch(setUserSession({ user: userData, sessionId }));
        if (gettingdata) {
          gettingdata(userData);
        }

        setIsLoading(false);
        navigator1('/home');
    };
 
   
      const handleClear = () => {
        setPartnerId('');
        setPartnerPassword('');
      };
 
 
 
      const navigate = useNavigate();
    //   const dispatch = useDispatch();
        const handleLogout =()=>{
          dispatch(logoutUser());
          setLogoutHide(true);
          navigate('/logout');
        }
   

// // CSRF ATTACK CODE STARTS
// //const navigate = useNavigate();
// const [clickTimestamps, setClickTimestamps] = useState([]);
// const timeWindow = 5000; // 5 seconds time window
// const maxClicks = 5; // Maximum clicks allowed within the time window

// useEffect(() => {
//   const handleClick = (event) => {
//     const now = Date.now();
//     const updatedClickTimestamps = clickTimestamps.filter(timestamp => now - timestamp < timeWindow);
//     updatedClickTimestamps.push(now);
//     setClickTimestamps(updatedClickTimestamps);

//     if (updatedClickTimestamps.length >= maxClicks) {
//       navigate('/csrf');
//     }
//   };
//  console.log(clickTimestamps, "CLICK TIME STAMPS/////////////////////////////")
//   document.addEventListener('click', handleClick);

//   return () => {
//     document.removeEventListener('click', handleClick);
//   };
// }, [clickTimestamps, navigate]);
// // CSRF ATTACK CODE ENDS



        console.log(exampleData,"eeeeeeeeeeeeeeee")
 
        let firstName=localStorage.getItem( "firstName");
        let lastName =localStorage.getItem("secondName");
        let tempSession =localStorage.getItem("sessionId")


  const timerRef = useRef(null);
  useEffect(() => {
    document.title = t('2472_027');
    // Function to reset the idle timer
    const resetTimer = () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        handleLogout(); // Perform any session cleanup
        navigate("/"); // Redirect to /log after 30 seconds of inactivity
      }, 600000); // 30 seconds idle time
    };

    // Set up event listeners for detecting user activity
    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keypress', resetTimer);
    window.addEventListener('click', resetTimer);

    // Initialize the timer on mount
    resetTimer();

    // Clean up event listeners and timer on unmount
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keypress', resetTimer);
      window.removeEventListener('click', resetTimer);
    };
  }, [handleLogout, navigate]);



  return (
 
      <div className={'login_sec'} style={{display:'flex',justifyContent:'center',  flexDirection:'column'}}>
    <Navbar/>
    {(tempSession!=null && !logoutHide) ?
      (<Box style={{width: '100%'}} className={'displayFlex'}>
      <font color="#808080" face="Arial" style={{fontSize: '8pt'}}>
                        {t('welcome')}            
                       {/* | */}
                     </font><b className="loginTextSmall">
                     &nbsp; {firstName} {lastName}
                       {/* TODO <LoginName />*/}</b>
                       &nbsp;|&nbsp;
     <span style={{display: 'flex', cursor: 'pointer', textDecoration: 'none'}} className="langLink logoutButton" onClick={handleLogout} >{t("logout")} <LoginOutlined style={{    width: '15px',
     height: '15px',
     marginLeft: '3px'}} /></span>
     </Box>): ''
    }
 
   
      <table border={0} cellPadding={0} cellSpacing={0} style={{ borderCollapse: "collapse", margin: '0px auto' }} width="100%" height="auto" align="center">
        <tbody>
          <tr>
             <Grid container
                sx={{ width: 1 }}
                spacing={2}
                style={{
                  justifyContent: "flex-start",
                  marginTop: "0px",
                  marginLeft: "0",
                }}>
              <Grid xs={7} item style={{padding:'0',paddingTop:'3px'}}>
                <img src={loginbg} alt="" style={{width:'100%',height:'100%',}} />
              </Grid>
              <Grid xs={5} item style={{display:'flex', justifyContent:'center', alignItems:'center', paddingTop:'6px'}}>
              <td width={500} style={{height:'400px'}} align="center" className={'loginBg'} valign="top">
                  <table>
                    <tbody>
                      <tr style={{height:'75px'}} className={'loginTr'}><td width="100%">&nbsp;</td></tr>
                      <tr><td width="100%" align="left" className="loginTextBig">&nbsp;PAYMENT<b>
                          <font face="Arial" size={4} color="#808080"> &nbsp;</font>
                          <font face="Arial" color="#808080" size={5}>MANAGER</font></b></td></tr>
                      <tr height="6px"><td width="100%">&nbsp;</td></tr>
                      </tbody>
                  </table>
                  {/* <tr><td colSpan={2} width="100%" height={30} align="center" className="loginTextSmall">
                      <p><b>{t('001')}</b></p>
                  </td></tr> */}
                {/* <tr>
                  <td  align="center" className="loginTextSmall">
                  {error && <div>{error}</div>}
                  </td>
                </tr> */}
                <table>
                    <tbody>
                  <tr>
                      <td width="100%" height={25} align="left">
                          <font face="Arial" style={{ fontSize: "8.5pt" }}>
                              {/* User ID: */}
                              {t('userName')}
                          </font>
                      </td>
                  </tr>
                  <tr>
                      <td>
                           <input type="text" className="textBoxSmall" id="username" value={partnerId} maxLength={30}
                              onChange={e => setPartnerId(e.target.value)} />
                      </td></tr>
 
                  <div>&nbsp;</div>
                  <tr>
                      <td width="100%" height={25} align="left">
                          <font face="Arial" style={{ fontSize: "8.5pt" }}>
                              {/* Password: */}
                              {t('password')}
                          </font>
                      </td>
                  </tr>
                  <tr>
                      <td>
                          <input type="password"className="textBoxSmall" id="password" value={partnerPassword} maxLength={30}
                              onChange={e => setPartnerPassword(e.target.value)} />
                      </td>
                  </tr>
                  </tbody>
                  </table>
                  &nbsp;&nbsp;&nbsp;&nbsp;
                  <tr>
                      <td align="left">
                          {/* <button type="button" className="inputButton" onClick={handleLogin}>{t('002')}</button> */}
                          <Button className={'hoverEffectButton'} onClick={handleLogin} size="small" variant="contained" endIcon={<SendIcon />}>{t('002')}</Button>
                      </td>
                      &nbsp;&nbsp;&nbsp;
                      <td align="right">
                      <Button className={'hoverEffectButton'} size="small" onClick={handleClear} variant="contained" endIcon={<CancelRounded />}>
                      {t('003')}
                      </Button>
     
                          {/* <button type="button" className="inputButton" onClick={handleClear}>{t('003')}</button> */}
                      </td>
                  </tr>
      {isLoading && <><br /><div className={'spinnerDiv'}> {t("Processing...")}  <CircularProgress size="sm" /></div></>}
 
              </td>
              <tr><td colSpan="2">&nbsp;</td></tr>
            </Grid>
             </Grid>
          </tr>
          </tbody>
      </table>
      <ToastContainer
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={0} width={1000} align="center">
     <tbody>
      <Footer/>
      </tbody>
      </table>
     </div>
 
  );
}
export default LoginPage;