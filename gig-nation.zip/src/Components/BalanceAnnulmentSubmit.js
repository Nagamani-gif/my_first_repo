import { Footer, Header, JasperLeftMenu, JasperTopMenu, LeftBgImage, LeftMenu, PaymentManagerHeading, TransactionTopMenu } from './PageComponents';
import TopMenu from './TopMenu';
import { useTranslation } from 'react-i18next';
import {Button ,Box} from '@mui/material';
import {CancelOutlined, KeyboardReturn} from '@mui/icons-material';
import SendIcon from '@mui/icons-material/Send';
import { useNavigate } from 'react-router-dom';
import {useState} from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';

function BalanceAnnulmentSubmit(){
    //sessionStorage.setItem("selectedIndex", 5);
    const {t} = useTranslation();

    const location = useLocation();
    const {partnerLoginId, localeVar, transactionPassword, distributorId, isPartial, transNumber, transId, reverseAmt} = location.state || {};
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
    const [message, setMessage] = useState('');
    const [responseCode, setResponseCode] = useState('');

    console.log("******** in balance annulment submit ********")
    console.log("partnerId",partnerLoginId)
    console.log("localeVar",localeVar)
    console.log("transactionpassword",transactionPassword)
    console.log("distributedId",distributorId)
    console.log("isPartial",isPartial)
    console.log("transNumber",transNumber)
    console.log("transID",transId)
    console.log("reverseAmt",reverseAmt)

    const submit = async() => {

        console.log("*********** in submit in balance annulment submit ************")
    
        console.log("partnerId",partnerLoginId)
        console.log("localeVar",localeVar)
        console.log("transactionpassword",transactionPassword)
        console.log("distributedId",distributorId)
        console.log("isPartial",isPartial)
        console.log("transNumber",transNumber)
        console.log("transID",transId)
        console.log("reverseAmt",reverseAmt)
  
            const apiUrl = window.config.apiUrl + process.env.REACT_APP_BAL_ANNULMNT_SUBMIT;
            const distributorIdUpper = distributorId.toUpperCase();
            const response = await axios.post(apiUrl, {
                userName,
                password,
                "partnerId": partnerLoginId,
                localeVar,
                "transactionpassword":transactionPassword,
                "distributedId":distributorIdUpper,
                isPartial,
                transNumber,
                "transID":transId,
                reverseAmt
            });
            const data = response.data;
            console.log("response",data);

            setMessage(data.message);
            setResponseCode(data.responseCode);

            console.log("message", message);
    }

    const navigate = useNavigate();

    const cancel = () => {
      navigate(-1);
    };

    return(
        <>
<table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <tbody>
                    <Header />
                    <tr height="65px">
                    <PaymentManagerHeading />
                    <TopMenu />
                    </tr>
                    <tr>
                        {/* <td valign="top" style={{ borderRightStyle: 'solid', borderRightWidth: '1pt', borderColor: 'rgb(51 153 255)' }} nowrap="nowrap">
                       
                        </td> */}
                       <LeftBgImage />
                        <td valign="top">
                        <TransactionTopMenu menu="menuHighlighttt"/>
                        
                            <br></br>
                            {/* <table width="100%">
                                <tbody>
                                    <tr>
                                        <td width="100%" class="headingText">{t('balanceAnnulment')}</td>
                                    </tr>
                                </tbody>
                            </table> */}
                            {/* <br></br> */}

                            { message !== "" &&
                                <center>
                                    <font color="red" size="2"> {message} </font>
                                </center>
                            }

                           

                            <table
  align="left"
  cellSpacing="5"
  cellPadding="5"
  style={{ marginLeft: '15px' }}
>

                                <tbody>

                                    <tr>
                                        <td class="strongerTxtLable">{t('fromDistributor')}</td>	<td style={{fontWeight: "bold", paddingLeft: "10px" }}>{distributorId}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="strongerTxtLable">{t('toDistributor')}</td>	<td style={{fontWeight: "bold", paddingLeft: "10px"}}>{partnerLoginId}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="strongerTxtLable">{t('annulmentAmount')}(MXN)</td>	<td style={{fontWeight: "bold", paddingLeft: "10px"}}>{reverseAmt}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="strongerTxtLable">{t('fundTransferID')}</td>	<td style={{fontWeight: "bold", paddingLeft: "10px"}}>{transId}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="strongerTxtLable">{t('isPartialReversal')}</td>	<td style={{fontWeight: "bold", paddingLeft: "10px"}}>{ isPartial === "Y" ? t('yes') : t('no') }</td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="strongerTxtLable">{t('referenceNo')}</td>	<td style={{fontWeight: "bold", paddingLeft: "10px"}}>{transNumber}</td>
                                    </tr>
                                    
                                    <tr><td colspan="2">&nbsp;</td></tr>

                                    { responseCode === "00" ?
                                        
                                        <tr>
                                            <td align="right">
                                                {/* <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />} onClick={() => {submit()}}> {t('028')} </Button> */}
                                            </td>
                                            <td>
                                                <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<KeyboardReturn />} onClick={() => {cancel()}}> {t('013')} </Button>
                                            </td>
                                        </tr>
                                    
                                    : 


                                        // <tr>
                                        //     <td align="right">
                                        //         <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />} onClick={() => {submit()}}> {t('028')} </Button>
                                        //     </td>
                                        //     <td>
                                        //         <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelOutlined />} onClick={() => {cancel()}}> {t('cancel')} </Button>
                                        //     </td>
                                        // </tr>
                            

                                        <Box style={{display: 'flex', gap: '8px'}}>
                                        <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />} onClick={() => submit()} >{t('028')}</Button>
                                        
                                      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelOutlined />} onClick={() => {cancel()}}> {t('cancel')} </Button>		
                                      </Box>
                                    }

                                </tbody>

                            </table>

                        </td>
                    </tr>

                    <tr height="60px">
                        <td colSpan={2}>
                            <Footer />
                        </td>
                    </tr>

                </tbody>
            </table>
        </>
    );

}

export {BalanceAnnulmentSubmit}
