/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, LeftBgImage, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, Menu,CircularProgress, FormControl, FormControlLabel, FormLabel, Grid, InputLabel, MenuItem, Pagination, Paper, Radio, RadioGroup, Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, TableSortLabel } from "@mui/material";
import React, { useState, useEffect, useCallback } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CloudDownload, KeyboardReturn,DoneAllRounded,RestartAltRounded, SaveRounded } from '@mui/icons-material';
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
 import ExcelJS from 'exceljs';
 import { useRef } from "react";
import SendIcon from '@mui/icons-material/Send';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { DatePicker, DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import 'dayjs/locale/es'; // Spanish locale
import 'dayjs/locale/en'; // English locale (optional, dayjs default is English)
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';


function Packetsales(){
  sessionStorage.setItem("selectedLink", "e_transactions");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  let reportDays = process.env.REACT_APP_ReportDays;
  const toastId = useRef(null);
  const [anchorEl, setAnchorEl] = useState();
  const closeTimeoutRef = useRef(null);
   const [totalRecords, setTotalRecords] = useState(0);
   const [recordsPerPage] = useState(10);
    const [page, setPage] = useState(1);
    const [perpage, setPerPage] = useState(10);

    const [subscriberCellularNumber, setSubscriberCellularNumber] = useState('');
  const now = dayjs();  
  const midnightToday = dayjs().startOf('day');

  const [startDateTime, setStartDateTime] = useState(midnightToday);
  const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
  const [endDateTime, setEndDateTime] = useState(now);
  const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));

    const [status, setStatus] = useState(' ');
    const [transactionType, setTransactionType] = useState('REC');
    const [packetCode, setPacketCode] = useState(''); 
    const [amount, setAmount] = useState('');
    const [authorizationId, setAuthorizationId] = useState('');
    const [canalId, setCanalId] = useState('');
    const [terminalId, setTerminalId] = useState('');
    const [sucursalId, setSucursalId] = useState('');
    const[packetType, setPacketType] = useState('');
    const[referenceId, setReferenceId] = useState('');
    const[statusId, setStatusId] = useState('F');
    const[isAdmin, setIsAdmin] = useState('');
    const[levelFlag, setLevelFlag] = useState('N');
    const[carrierId, setCarrierId] = useState('');
    const[download, setDownload] = useState('N');
  const navigate = useNavigate();
   const [order, setOrder] = useState('desc');
  const [orderBy, setOrderBy] = useState('transactionDate');
  const [showParentOrderId, setShowParentOrderId] = useState(false);
  const [sortingApplied, setSortingApplied] = useState(false);
 const[enableButton, setEnableButton] = useState(false);

  console.log("totalRecords++++++++++++",totalRecords)
  let startRecord=0;
  let endRecord =10;


const handleChangePage = async (event, newPage) => {
  event.preventDefault();
    const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t
    });
    if(!isValid) return;
  setPage(newPage);
  await fetchData(newPage); // fetch data for the selected page
};

  useEffect(() => {
    if (partnerLoginId) {
     // fetchData();
    }
  }, [partnerLoginId, page]);


   const RedAsterisk = styled('span')({
      color: 'red',
    });

  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);


  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
 
   const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };
  
   const handleStartDateTimeChange = (newValue) => {
       setStartDateTime(newValue); 
     const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
     setStartDate(formattedDateTime);
     setEnableButton(true);
      console.log("startDate::::::",newValue)
       console.log("startDate::::::",formattedDateTime)
    };
	
    const handleEndDateTimeChange = (newValue) => {
    setEndDateTime(newValue);
    setEnableButton(true);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };


  const handleSort = (property) => {
    const isAsc = orderBy === property && order === 'desc';
    setOrder(isAsc ? 'asc' : 'desc');
    setOrderBy(property);
    setSortingApplied(true);
  };




    const clearData = () => {
    setSubscriberCellularNumber('');
    setPacketCode('');
	  setAmount('');
	  setAuthorizationId('');
	  setCanalId('');
	  setTerminalId('');
  	setSucursalId('');
	  setTransactionType('REC');
	  resetDateTime();
    setStatus(' ');	
    setLevelFlag('N');
    // setItems([]);
    setPage(1);
    setPerPage(10);
   // setTotalRecords(0);
      setStatusId('F');

	}

  
  const resetDateTime = () => {
    const now = dayjs();
   setStartDateTime(now.startOf('day'));
   setEndDateTime(dayjs());
   setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
   setEndDate(now.format('DD/MM/YYYY HH:mm:ss'));
    console.log("Reset:", now.format());
  };
  
  const handleSubmit1 = async (e) => {
  e.preventDefault();
  // Set column visibility
  setShowParentOrderId(transactionType === 'REV');
  const firstPage = 1;
  setPage(firstPage);
  
  await fetchData(firstPage); // fetch data for page 1
};


const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24;

  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
    }
    return false;
  }

  return true;
};


  const fetchData = async (pageNumber = 1) => {
  const startRecord = (pageNumber - 1) * perpage + 1;
  const endRecord = startRecord + perpage - 1;
  setIsLoading(true);

    
    try {
        
        // Validation logic
             // Validation logic
       const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t
    });

      if (amount.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(amount)) {
    toast.error(`${t('alrt_01')} in ${t('049')}.`);
    return;
   }
     if (authorizationId.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(authorizationId)) {
    toast.error(`${t('alrt_01')} in ${t('2481_002')}.`);
    return;
   }
    if (!isValid) return;
     setStatusId('N');
      setEnableButton(false);
      const apiUrl = window.config.apiUrlJasper+ '/packetSaleReport';
      const response = await axios.post(apiUrl, {          
       userName,
        password,
        partnerLoginId,
        subscriberCellularNumber,
        packetCode,
        packetType,
        amount,
        referenceId,
        status,
        isAdmin: 'N',
        fromDate:startDate,
        toDate:endDate,
        levelFlag,
        carrierId,
        transactionType,
        authorizationId,
        canalId,
        terminalId,
        sucursalId,
        download : 'N',
        beginingRecordNum: startRecord,
        endingRecordNum: endRecord,
        localeVar
      });
      console.log("response::::::",response);
      if (response.status === 200) {
        setItems(response.data.summaryConfigArray);
        setTotalRecords(response.data.totalRecords);
      }
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

  const amountFormatter = new Intl.NumberFormat('en-IN', { 
  minimumFractionDigits: 2, 
  maximumFractionDigits: 2 
});



  //  const sortedItems = [...items].sort((a, b) => {
  //   const valA = a[orderBy] || '';
  //   const valB = b[orderBy] || '';
  //   if (valA < valB) return order === 'asc' ? -1 : 1;
  //   if (valA > valB) return order === 'asc' ? 1 : -1;
  //   return 0;
  // });


  const sortedItems = sortingApplied
    ? [...items].sort((a, b) => {
        const valA = a[orderBy] || '';
        const valB = b[orderBy] || '';
        if (valA < valB) return order === 'asc' ? -1 : 1;
        if (valA > valB) return order === 'asc' ? 1 : -1;
        return 0;
      })
    : items; 


  


  const fetchDataDownload = async () => {

    const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t
    });

    if(!isValid) return false;

     
    if(enableButton) {
             toast.error(`${t('apply_validation')}`);
           return;
       }

    try {
      let userName = process.env.REACT_APP_USERNAME;
      let password = process.env.REACT_APP_PASSWORD;
        const apiUrlDownload = window.config.apiUrlJasper+ '/packetSaleReport';
        console.log('API URL:', apiUrlDownload);
        console.log('Partner Login ID:', partnerLoginId);
        setDownload('Y');
        setEnableButton(false);
         const response = await axios.post(apiUrlDownload, {          
        userName,
        password,
        partnerLoginId,
        subscriberCellularNumber,
        packetCode,
        packetType,
        amount,
        referenceId,
        status,
        isAdmin : 'N',
        fromDate:startDate,
        toDate:endDate,
        levelFlag,
        carrierId,
        transactionType,
        authorizationId,
        canalId,
        terminalId,
        sucursalId,
        download,
        localeVar
      });

        console.log('Response:', response.data.summaryConfigArray);

        if (!response.data || !response.data.summaryConfigArray) {
            throw new Error('Invalid API response');
        }
        

        const downloadData = response.data.summaryConfigArray.map(item => ({
    transactionDate:  item.transactionDate  ,
    authrizationId:      item.authrizationId ,
    orderId:      item.orderId,
    parenetOrderId:      item.parenetOrderId  ,
    partnerCompanyName:      item.partnerCompanyName  ,
    partnerId:      item.partnerId ,
    partnerParent:      item.partnerParent ,
    mainPartner : item.mainPartner,
     subscriberMdn:     item.subscriberMdn ,
    NORequeAccepted:      item.NORequeAccepted ,
    queueProcessingTime:      item.queueProcessingTime ,
    promationPlan:      item.promationPlan ,
     altramiraPlanName:     item.altramiraPlanName ,
    terminalId:      item.terminalId ,
    canalId:      item.canalId ,
    sucursalId:      item.sucursalId ,
    packetCode:      item.packetCode ,
    level :item.level,
     bankReferenceId:         item.bankReferenceId,
    parentName:        item.parentName,
     mainDistributorName:             item.mainDistributorName,
     transactionCategory : item.transactionCategory,
      
  paymentAmount: item.paymentAmount != null && !isNaN(item.paymentAmount)
    ? amountFormatter.format(Number(item.paymentAmount))
    : '---',
     statusCode : item.statusCode,
errorreason : item.errorreason,
planName : item.planName,
bonus : item.bonus,      
   
      }));


        console.log('Download Data:', downloadData);

        return downloadData;
    } catch (error) {
        console.error('Error fetching data:', error);
        return [];
    }
};

const formatDateForCSV = (d) => {
  if (!d) return "";

  const [datePart, timePart] = d.split(" ");
  const [day, month, year] = datePart.split("/").map(Number);
  const [hours, minutes, seconds] = timePart.split(":").map(Number);

 const formatted =
  String(day).padStart(2, "0") + "/" +
  String(month).padStart(2, "0") + "/" +
  year + " " +
  String(hours).padStart(2, "0") + ":" +
  String(minutes).padStart(2, "0") + ":" +
  String(seconds).padStart(2, "0");

// Force Excel to treat as text
return `="${formatted}"`;

};



const handleDownloadPdf = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;
  const totalRecords = downloadItems.length;
  const startRecord = 1;
  const endRecord = totalRecords;

  const tableBody = [];

  // === 2) Column Headers ===
  const headers = [];
headers.push(t('023'));
headers.push(t('2481_002'));
headers.push(t('2481_012'));
if (transactionType === 'REV') {
 headers.push(t('2481_065'));
} 
headers.push(t('1146'));
headers.push(t('2481_013'));
headers.push(t('partnerstatusreport2'));
headers.push(t('2421456'));
headers.push(t('subscriberCellularNumber'));
headers.push(t('2481_024'));
headers.push(t('2481_015'));
headers.push(t('2481_016'));
headers.push(t('2481_017'));
headers.push(t('2481_004'));
headers.push(t('2481_003'));
headers.push(t('2481_005'));
headers.push(t('1245'));
headers.push(t('2481_018'));
headers.push(t('049'));
headers.push(t('055'));
headers.push(t('errordesp'));
headers.push(t('2481_019'));
headers.push(t('2481_020'));
headers.push(t('2481_021'));
headers.push(t('2481_022'));
headers.push(t('2481_023'));


  tableBody.push(
  headers.map(function(header) {
    return { text: header, style: 'tableHeader' };
  })
);

console.log("transactionType 456" , transactionType)
  // === 3) Table Rows ===
  downloadItems.forEach(item => {
  const row = [];

  row.push(item.transactionDate || '---');
  row.push(item.authrizationId || '---');
  row.push(item.orderId || '---');
  if (transactionType === 'REV') {
  row.push(item.parenetOrderId || '---');
  }
  row.push(item.partnerCompanyName || '---');
  row.push(item.partnerId || '---');
  row.push(item.partnerParent || '---');
  row.push(item.mainPartner || '---');
  row.push(item.subscriberMdn || '---');
  row.push(item.NORequeAccepted || '---');
  row.push(item.queueProcessingTime || '---');
  row.push(item.promationPlan || '---');
  row.push(item.altramiraPlanName || '---');
  row.push(item.terminalId || '---');
  row.push(item.canalId || '---');
  row.push(item.sucursalId || '---');
  row.push(item.packetCode || '---');
  row.push(item.transactionCategory || '---');
  row.push(item.paymentAmount != null ? Number(item.paymentAmount).toFixed(2) : '---');
  row.push(item.statusCode || '---');
  row.push(item.errorreason || '---');
  row.push(item.bonus || '---');
  row.push(item.level || '---');
  row.push(item.bankReferenceId || '---');
  row.push(item.parentName || '---');
  row.push(item.mainDistributorName || '---');

  // Ensure row has exactly 26 items
 while (row.length < headers.length) row.push('---');

  tableBody.push(row.map(function(val) {
    return { text: val, fontSize: 5,alignment: 'center' };
  }));
  
});



  // === 4) PDF Definition ===
  const docDefinition = {
    content: [
    {
      text: localeVar === 'en' ? "Packet Sales Report" : "Informe de Ventas de Paquetes",
      style: 'title',
      alignment: 'center',
      margin: [0, 0, 0, 10]
    },
      {
        columns: [
          {
            text: `${t('032')} : ${totalRecords}`,
            alignment: 'left',
            fontSize: 8
          },
          {
       //     text: `${t('033')} : ${startRecord} - ${totalRecords < 10 ? totalRecords :endRecord}`,
       //     alignment: 'right',
       //     fontSize: 8
          }
        ],
        margin: [0, 0, 0, 5]
      },
    {
      style: 'tableExample',
      table: {
          headerRows: 2,
          widths: new Array(headers.length).fill('*'),
        body: tableBody
      },
      layout: {
         fillColor: (rowIndex) => (rowIndex === 0 ? '#004080' : null)
      }
    },
    {
      text: t('0171'),
      style: 'endText',
      alignment: 'center',
      margin: [0, 10, 0, 0]
    }
    ],
    styles: {
      title: { fontSize: 12, bold: true },
      tableExample: { margin: [0, 5, 0, 10] },
      mainHeader: { bold: true, fontSize: 6, color: '#000' },
      tableHeader: { bold: true, fontSize: 5, color: '#fff', alignment: 'center', fillColor: '#004080' },
      endText: { italics: true, bold: true, decoration: 'underline', fontSize: 8 }
    },
    pageOrientation: 'landscape',
    pageSize: 'A2',
    pageMargins: [10, 10, 10, 10],
    defaultStyle: { fontSize: 5 }
  };

  pdfMake.createPdf(docDefinition).download('PacketSalesReport.pdf');
};



const handleDownloadCsv = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;
  const totalRecords = downloadItems.length;
  const startRecord = 1;
  const endRecord = downloadItems.length;

  const title =` ${t('w_packetsalesreportp')} `;

  const summaryText1 = `${t('032')} : ${totalRecords}`; // Goes to column A
const summaryText2 = `${t('033')} : ${startRecord} - ${(totalRecords < 10 ? totalRecords : endRecord)}`; // Goes to column Z

   const headers = [];
headers.push(t('023'));
headers.push(t('2481_002'));
headers.push(t('2481_012'));
if (transactionType === 'REV') {
 headers.push(t('2481_065'));
}
headers.push(t('1146'));
headers.push(t('2481_013'));
headers.push(t('partnerstatusreport2'));
headers.push(t('2421456'));
headers.push(t('subscriberCellularNumber'));
headers.push(t('2481_024'));
headers.push(t('2481_015'));
headers.push(t('2481_016'));
headers.push(t('2481_017'));
headers.push(t('2481_004'));
headers.push(t('2481_003'));
headers.push(t('2481_005'));
headers.push(t('1245'));
headers.push(t('2481_018'));
headers.push(t('049'));
headers.push(t('055'));
headers.push(t('errordesp'));
headers.push(t('2481_019'));
headers.push(t('2481_020'));
headers.push(t('2481_021'));
headers.push(t('2481_022'));
headers.push(t('2481_023'));
/*
  const rows = downloadItems.map(item => [
          item.transactionDate ||    '---',
          item.authrizationId||    '---',
          item.orderId||    '---',
             item.parenetOrderId||    '---',
          item.partnerCompanyName ||    '---',
          item.partnerId ||    '---',
          item.partnerParent ||     '---',
          item.mainPartner ||      '---',
          item.subscriberMdn  ||      '---',
          item.NORequeAccepted||    '---',
          item.queueProcessingTime||    '---',
          item.promationPlan || '----',
          item.altramiraPlanName||    '---',
          item.terminalId||    '---',
          item.canalId||    '---',
          item.sucursalId||    '---',
          item.packetCode||    '---',
          item.transactionCategory||    '---',
         Number(item.paymentAmount).toFixed(2)||    '---',
          item.statusCode||    '---',
          item.errorreason||    '---',
          item.bonus||    '---',
          item.level||    '---',
          item.bankReferenceId||    '---',
          item.parentName||    '---',
            item.mainDistributorName||    '---'
  ]);
*/

const tableBody = [];

downloadItems.forEach(item => {
  const row = [];

row.push(formatDateForCSV(item.transactionDate));
  row.push(item.authrizationId || '---');
  row.push(item.orderId || '---');
  if (transactionType === 'REV') {
    row.push(item.parenetOrderId || '---');
  }
  row.push(item.partnerCompanyName || '---');
  row.push(item.partnerId || '---');
  row.push(item.partnerParent || '---');
  row.push(item.mainPartner || '---');
  row.push(item.subscriberMdn || '---');
  row.push(item.NORequeAccepted || '---');
  row.push(item.queueProcessingTime || '---');
  row.push(item.promationPlan || '---');
  row.push(item.altramiraPlanName || '---');
  row.push(item.terminalId || '---');
  row.push(item.canalId || '---');
  row.push(item.sucursalId || '---');
  row.push(item.packetCode || '---');
  row.push(item.transactionCategory || '---');
row.push(
  item.paymentAmount != null && !isNaN(item.paymentAmount)
    ? `="${Number(item.paymentAmount).toFixed(2)}"`  // Always 2 decimal places
    : '---'
);
  row.push(item.statusCode || '---');
  row.push(item.errorreason || '---');
  row.push(item.bonus || '---');
  row.push(item.level || '---');
  row.push(item.bankReferenceId || '---');
  row.push(item.parentName || '---');
  row.push(item.mainDistributorName || '---');


  // Ensure row has exactly 26 columns
  console.log('row.length  123' , row.length );


  // Format each cell
  tableBody.push(row);
});

  
  const escapeCSV = value => {
    if (value == null) return '';
    const stringValue = String(value).replace(/"/g, '""');
    return `"${stringValue}"`;
  };

  const csvLines = [];

  // === Line 1: Title


 const totalColumns = headers.length;        // total number of columns
const centerIndex = Math.floor(totalColumns / 2); // middle column index
const titleRow = Array(totalColumns).fill('');
titleRow[centerIndex] = title;
csvLines.push(titleRow.map(val => `"${val}"`).join(','));
  
//  csvLines.push(`"${title}"`);

  // === Line 2: Summary text
  // Create a line with value in column A and Z
const emptyCells = Array(24).fill('""').join(','); // 24 empty cells for columns B to Y
const summaryLine = `"${summaryText1}"`;

csvLines.push(summaryLine);
  // === Line 3: Group Headers


  // === Line 4: Column Headers
  csvLines.push(headers.map(escapeCSV).join(','));


// === Data Rows
tableBody.forEach(row => {
  csvLines.push(row.map(escapeCSV).join(','));
});
const endOfReportText = t('0171');
  // === Final Line: End of Report
const endRow = Array(26).fill('""');

// Put the text only in column M (index 12)
endRow[12] = `"${endOfReportText}"`;

// Add the line to the CSV
csvLines.push(endRow.join(','));
 const BOM = '\uFEFF';
  const csvContent = BOM  + csvLines.join('\n');

  

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const fileName = 'PacketSalesReport.csv';

  if (navigator.msSaveBlob) {
    navigator.msSaveBlob(blob, fileName);
  } else {
  const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  }
};




  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);

const DownloadXL = async () => {
   const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;
    const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('PacketSalesReport' , {
    pageSetup: { paperSize: 9, orientation: 'landscape' }
  });

  // === Set 30 columns width
  worksheet.columns = new Array(30).fill({ width: 30 });
  const endOfReportText = t('0171');

  // === Insert Title Row (Row 1)
  worksheet.insertRow(1, [
    localeVar === 'en' ? 'Packet Sales Report' : 'Informe de Ventas de Paquetes'
  ]);
  worksheet.mergeCells('A1:AD1');
  worksheet.getCell('A1').font = { bold: true, size: 14 };
  worksheet.getCell('A1').alignment = { horizontal: 'center' };

  // === Insert Summary Row (Row 2) with left and right alignment
  const summaryRow = worksheet.insertRow(2, new Array(30).fill(''));

  summaryRow.getCell(1).value = `${t('032')} : ${downloadItems.length}`;
  summaryRow.getCell(1).alignment = { horizontal: 'left' };

 // summaryRow.getCell(24).value = `${t('033')} : 1 - ${downloadItems.length}`;
//  summaryRow.getCell(24).alignment = { horizontal: 'right' };

//summaryRow.font = { italic: true, size: 10 };



    
  // === Column Headers (Row 4)
   /* const columnHeaders = [
    t('023'), t('2481_002'), t('2481_012'),t('2481_065'), t('1146'), t('2481_013'), 
    t('partnerstatusreport2'), t('2421456'), t('subscriberCellularNumber'), t('2481_024'), t('2481_015'),
     t('2481_016'), t('2481_017'), t('2481_004'), t('2481_003'), t('2481_005'),
      t('1245'), t('2481_018'), t('049'), t('055'), t('errordesp'), t('2481_019'), 
      t('2481_020'), t('2481_021'), t('2481_022'), t('2481_023')   
    ]; */

    
   const headers = [];
headers.push(t('023'));
headers.push(t('2481_002'));
headers.push(t('2481_012'));
if (transactionType === 'REV') {
 headers.push(t('2481_065'));
}
headers.push(t('1146'));
headers.push(t('2481_013'));
headers.push(t('partnerstatusreport2'));
headers.push(t('2421456'));
headers.push(t('subscriberCellularNumber'));
headers.push(t('2481_024'));
headers.push(t('2481_015'));
headers.push(t('2481_016'));
headers.push(t('2481_017'));
headers.push(t('2481_004'));
headers.push(t('2481_003'));
headers.push(t('2481_005'));
headers.push(t('1245'));
headers.push(t('2481_018'));
headers.push(t('049'));
headers.push(t('055'));
headers.push(t('errordesp'));
headers.push(t('2481_019'));
headers.push(t('2481_020'));
headers.push(t('2481_021'));
headers.push(t('2481_022'));
headers.push(t('2481_023'));
  const headerRow2 = worksheet.addRow(headers);

  headerRow2.eachCell(cell => {
     cell.font = { bold: true};
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFFFFFFF' }
      // fgColor: { argb: '3399FF' }
    };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
        cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
        };
    });

  // === Add Data Rows (Starting from Row 5)
  
downloadItems.forEach(item => {
  const row = [];

  row.push(item.transactionDate || '---');
  row.push(item.authrizationId || '---');
  row.push(item.orderId || '---');
  if (transactionType === 'REV') {
    row.push(item.parenetOrderId || '---');
  }
  row.push(item.partnerCompanyName || '---');
  row.push(item.partnerId || '---');
  row.push(item.partnerParent || '---');
  row.push(item.mainPartner || '---');
  row.push(item.subscriberMdn || '---');
  row.push(item.NORequeAccepted || '---');
  row.push(item.queueProcessingTime || '---');
  row.push(item.promationPlan || '---');
  row.push(item.altramiraPlanName || '---');
  row.push(item.terminalId || '---');
  row.push(item.canalId || '---');
  row.push(item.sucursalId || '---');
  row.push(item.packetCode || '---');
  row.push(item.transactionCategory || '---');
  row.push(item.paymentAmount != null ? Number(item.paymentAmount).toFixed(2) : '---');
  row.push(item.statusCode || '---');
  row.push(item.errorreason || '---');
  row.push(item.bonus || '---');
  row.push(item.level || '---');
  row.push(item.bankReferenceId || '---');
  row.push(item.parentName || '---');
  row.push(item.mainDistributorName || '---');


    worksheet.addRow(row);
    });

  // === End of Report Message
    const endOfReportRow = worksheet.addRow([endOfReportText]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, headers.length);
  endOfReportRow.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
  endOfReportRow.getCell(1).font = { bold: true };
        
  // === Generate Excel File
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
  saveAs(blob, 'PacketSalesReport.xlsx');
};


const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}


var fromDate='';
if(startDateTime != null){
  var d = new Date(startDateTime);
  var month= d.getMonth()+1;

  var day = d.getDate();
  var year = d.getFullYear();
  var hours = d.getHours();
  var minutes = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;

  // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
  fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
  console.log("StartDate = "+ day + "/" + month + "/" + year + " " + hours + ":" + minutes);
}

var toDate='';
if(endDateTime != null){
  var d = new Date(endDateTime);
  var month2= d.getMonth()+1;
  var hours1 = d.getHours();
  var minutes1 = d.getMinutes();


  // Ensure that hours and minutes are always two digits
  hours1 = hours1 < 10 ? '0' + hours1 : hours1;
  minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;


  toDate =  d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1;
  console.log("EndDate = "+ d.getDate() + "/" +month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1);
}
const formatSpanishNumbers = (date) => {
    return new Intl.DateTimeFormat('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  
  


return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Packet Sales Report":"Informe de Ventas de Paquetes de paquetes"}/>
  </tr>

  <tr>
  
  
  <div style={{ display: 'flex' }}> 
    <LeftBgImage1 />
</div>

<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
   <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
       <NavLink
            to="/packetsalesreportp"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab label={t('2481_059')} /></NavLink>
   </Tabs>
  </Box>
<div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="80%">
            {/* body starts */}
          

    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>


          
          <Box style={{display:'flex', gap:'12px',marginTop:'10px'}}> 
                  <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       { `${t('subscriberCellularNumber')}`} 
                       
                        </span>} style={{maxWidth:'250px',width:'175px'}}
               onChange={e => setSubscriberCellularNumber(e.target.value)} value={subscriberCellularNumber} size="15" defaultValue=""
               />

                    <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                     {`${t('2481_001')}`} 
                     
                        </span>} style={{maxWidth:'250px',width:'175px'}}
               onChange={e => setPacketCode(e.target.value)} value={packetCode} size="15" defaultValue=""
               />
      
              
      
          <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('049')}`} 
                        </span>} style={{maxWidth:'250px',width:'175px'}}
               onChange={e => setAmount(e.target.value)} value={amount} size="15" defaultValue=""
               />

                   <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_002')}`} 
                        </span>} style={{maxWidth:'250px',width:'175px'}}
               onChange={e => setAuthorizationId(e.target.value)} value={authorizationId} size="15" defaultValue=""
               />


                   <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_003')}`} 
                        </span>} style={{maxWidth:'250px',width:'175px'}}
               onChange={e => setCanalId(e.target.value)} value={canalId} size="15" defaultValue=""
               />

               
                   <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_004')}`} 
                        </span>} style={{maxWidth:'250px',width:'175px'}}
               onChange={e => setTerminalId(e.target.value)} value={terminalId} size="15" defaultValue=""
               />

                  
           

         
         
</Box>


   <Box style={{display:'flex',gap:'12px'}}>
               
                <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={
                     <span>
                       {`${t('2481_005')}`} 
                        </span>} style={{maxWidth:'200px',width:'175px'}}
               onChange={e => setSucursalId(e.target.value)} value={sucursalId} size="15" defaultValue=""
               />

<FormControl className={'selected_formcontrol'} sx={{  minWidth: 150 }}size="small">
            <InputLabel id="demo-select-small-label">
             {t('2472_58')} <RedAsterisk>*</RedAsterisk>
            </InputLabel>
      
            <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
            label={t('2472_58')}
            value={transactionType} 
            onChange={e => setTransactionType(e.target.value)}>
              
              <MenuItem value="REC">{t('2481_006')}</MenuItem>
              <MenuItem value="REV">{t('2481_007')}</MenuItem>
            </Select>
          </FormControl>

   <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}  >
                <DateTimePicker
                  style={{ maxWidth: '175px' }}
                  className={'datePickerrr'}
                  // label="Select Date and Time"
                  value={startDateTime}
                  onChange={handleStartDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
                  // label={t('80')} // This serves as the floating label
                  label={
                    <span>
                      {`${t('80')}`} <RedAsterisk>*</RedAsterisk>
                    </span>}
                    format="DD/MM/YYYY HH:mm:ss"
                  inputFormat=" " // Keeps the input field empty unless a date is selected
                  renderInput={(params) => <TextField
                    {...params}
                    InputLabelProps={{
                      shrink: true, // Always shrink the label to allow for a floating effect
                    }}
                    placeholder={!startDateTime ? t('80') : ''} // Show the placeholder only if no date is selected
                    fullWidth
                    variant="outlined"
                    sx={{ width: "140px", height: "40px", padding: '20px' }}
                  />}
                />
                
              </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}   adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                  style={{ marginTop: '20px', maxWidth: '175px' }}
               className={'datePickerrr mt20'}
               label={
                <span>
                  {`${t('81')}`}<RedAsterisk>*</RedAsterisk>
                </span>}
                format="DD/MM/YYYY HH:mm:ss"
                  value={endDateTime}
                  onChange={handleEndDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
               renderInput={(params) => <TextField {...params} />} />

              </LocalizationProvider>
			  
			  

        <FormControl className={'selected_formcontrol'} sx={{  minWidth: 110 }} size="small">
            <InputLabel id="demo-select-small-label">{t('055')}</InputLabel>
            <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
            label={t('055')}   value={status} 
              onChange={e =>setStatus(e.target.value)}>
                <MenuItem value=' '>----</MenuItem>
              <MenuItem value="9">{t('2481_009')}</MenuItem>
              <MenuItem value="11">{t('2481_010')}</MenuItem>
              <MenuItem value="12">{t('2481_011')}</MenuItem>
            </Select>
        </FormControl>

 <FormControl className={'selected_formcontrol'} sx={{  minWidth: 110 }} size="small">
                       <InputLabel id="demo-select-small-label">{t('2481_025')}<RedAsterisk>*</RedAsterisk></InputLabel>
 
                      <Select className={'bankSelect'} style={{ maxWidth: '150px', width: '130px' }} labelId="demo-select-small-label" id="demo-select-small"
                    label={t('2481_025')}    value={levelFlag} onChange={e => setLevelFlag(e.target.value)}>
                        <MenuItem value="Y">{t('Y')}</MenuItem>
                        <MenuItem value="N">{t('N')}</MenuItem>
                      </Select>
                    </FormControl>




           <Box style={{display: 'flex', alignItems: 'center', gap:'4px', justifyContent :'flex-end', marginTop:'-16px'}}>
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
            onClick={handleSubmit1}
            >
              {t('2616028')} 
              </Button>
           
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
            onClick={clearData}
            >
              {t('2481_027')}
            </Button>
               {/* <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SaveIcon />}
            //onClick={clearData}
            >
              {t('2616030')}
            </Button> */}
               </Box>
       
            </Box>

           <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {totalRecords < 10 ? totalRecords :endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
              </Grid>
<TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
        <TableRow className="darkgray">


       <TableCell align="center" sortDirection={orderBy === 'transactionDate' ? order : false} >
            <TableSortLabel   style={{ color: 'white' }} // correct camelCase
              active={orderBy === 'transactionDate'}
              direction={orderBy === 'transactionDate' ? order : 'asc'}
              onClick={() => handleSort('transactionDate')}
               className="largeSortLabel"
               hideSortIcon={false} 
            >
              {t('023')}
            </TableSortLabel>  
        </TableCell>
        <TableCell align="center">{t('2481_002')} </TableCell>
        <TableCell align="center">{t('2481_012')} </TableCell>
        {showParentOrderId && (<TableCell align="center">{t('2481_065')} </TableCell>)}
        <TableCell align="center">{t('2481_066')} </TableCell>
        <TableCell align="center">{t('2481_013')} </TableCell>
        <TableCell align="center">{t('partnerstatusreport2')} </TableCell>
        <TableCell align="center">{t('2421456')} </TableCell>
        <TableCell align="center">{t('subscriberCellularNumber')} </TableCell>
        <TableCell align="center">{t('2481_024')} </TableCell>
        <TableCell align="center">{t('2481_015')} </TableCell>
        <TableCell align="center">{t('2481_016')} </TableCell>
        <TableCell align="center">{t('2481_017')} </TableCell>
        <TableCell align="center">{t('2481_004')} </TableCell>
        <TableCell align="center">{t('2481_003')} </TableCell>
        <TableCell align="center">{t('2481_005')} </TableCell>
        <TableCell align="center">{t('1245')} </TableCell>
        <TableCell align="center">{t('2481_018')} </TableCell>
        <TableCell align="center">{t('049')} </TableCell>
        <TableCell align="center">{t('055')} </TableCell>
        <TableCell align="center">{t('errordesp')} </TableCell>
        <TableCell align="center">{t('2481_019')} </TableCell>
        <TableCell align="center">{t('2481_020')} </TableCell>
        <TableCell align="center">{t('2481_021')} </TableCell>
        <TableCell align="center">{t('2481_022')} </TableCell>
        <TableCell align="center">{t('2481_023')} </TableCell>

      
          
           
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
            <TableRow>
              <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
              {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : sortedItems.length > 0 ? (
            // Show table rows when data is available
            sortedItems.map((item, index) => (
              <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
            
                <TableCell align="center">&nbsp;{item.transactionDate|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.authrizationId|| '---'}&nbsp;</TableCell>
                <TableCell align="center">{item.orderId|| '---'}</TableCell>
                    {showParentOrderId && (
                 <TableCell align="center">{item.parenetOrderId|| '---'}</TableCell>)}
                <TableCell align="center">{item.partnerCompanyName|| '---'}</TableCell>
                 <TableCell align="center">&nbsp;{item.partnerId|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.partnerParent || '----'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.mainPartner|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.subscriberMdn|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.NORequeAccepted|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.queueProcessingTime|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.promationPlan|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.altramiraPlanName|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.terminalId|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.canalId|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.sucursalId|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.packetCode|| '---'}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.transactionCategory|| '---'}&nbsp;</TableCell>
                 <TableCell align="center">&nbsp;{Number(item.paymentAmount).toFixed(2)}&nbsp;</TableCell>
                <TableCell align="center">{item.statusCode|| '---'}</TableCell>
                <TableCell align="center">{item.errorreason|| '---'}</TableCell>
                <TableCell align="center">{item.bonus || '---'}</TableCell>
                <TableCell align="center">{item.level|| '---'}</TableCell>
                <TableCell align="center">{item.bankReferenceId|| '---'}</TableCell>
                <TableCell align="center">{item.parentName|| '---'}</TableCell>
                   <TableCell align="center">{item.mainDistributorName|| '---'}</TableCell>
             
                </TableRow>
            ))
          ) : (
            // Show 'No data found' message if no items are found after loading

           statusId === 'F' ? <TableRow>
              <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                {t("038")} {/* No data found for the given search criteria */}
              </TableCell>
            </TableRow> :
            <TableRow>
              <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                {t("2481_061")} {/* No data found for the given search criteria */}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
  <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                            {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,
                                                 }}
                                               >
                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{t('2481_062')}</MenuItem>
                                                                                       <MenuItem onClick={() => { setAnchorEl(null); DownloadXL(); }}>{t('2481_064')}</MenuItem>
                                                                                        <MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{t('2481_063')}</MenuItem>
                                                                                                                                                                                   </Menu>
                                             </div>
                                              : <></>}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</td></tr>
</div>
</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>
<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
    width: "auto",           // Let width grow with message
    fontSize: "18px",        // Optional: keep font size
    padding: "8px",          // Optional: spacing inside
    wordBreak: "break-word", // Ensure long words/wrapped text don't overflow
                        }}
                      />
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  );
}

export default Packetsales;
