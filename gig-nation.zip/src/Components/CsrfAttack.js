import React, { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { CurrentDate, Footer, Header, PaymentManagerHeading } from './PageComponents';
import TopMenu from './TopMenu';
import i18n from './i18n';
import SendIcon from '@mui/icons-material/Send';
import { Button } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { useDispatch } from 'react-redux';
import { logoutUser } from '../reducers/exampleSlice';


const CsrfAttack = () => {
  const dispatch = useDispatch();

    const navigate = useNavigate();
    const localVar=i18n.language;
    const {t} = useTranslation();

    // BROWSER BACK BUTTON WILL NOT WORK FOR THIS PAGE
    useEffect(() => {
      // Push a new state to history to prevent back navigation
      window.history.pushState(null, document.title, window.location.href);
  
      const handlePopState = (event) => {
        // Prevent navigating back to the previous page
        window.history.pushState(null, document.title, window.location.href);
      };
  
      window.addEventListener('popstate', handlePopState);
  
      return () => {
        window.removeEventListener('popstate', handlePopState);
      };
    }, []);
    useEffect(() => {
      const handleBeforeUnload = (event) => {
          // Set a flag indicating that the page has been visited
          sessionStorage.setItem('csrfPageVisited', 'true');
          
          // Prevent the default behavior and show a confirmation dialog
          event.preventDefault();
          event.returnValue = ''; // Standard way to trigger a confirmation dialog
      };
  
      const csrfPageVisited = sessionStorage.getItem('csrfPageVisited');
  
      if (csrfPageVisited) {
          // If the page is being refreshed, navigate to the login page
          sessionStorage.removeItem('csrfPageVisited');
          dispatch(logoutUser());
          localStorage.removeItem('sessionId');
          navigate('/');
      } else {
          // Add event listener to prevent page refresh or navigation away
          window.addEventListener('beforeunload', handleBeforeUnload);
  
          // Cleanup event listener on component unmount
          return () => {
              window.removeEventListener('beforeunload', handleBeforeUnload);
          };
      }
  }, [navigate, dispatch]);
  
  
  const handleLoginAgain = () => {
    dispatch(logoutUser());
    localStorage.removeItem('sessionId');
    navigate('/');
  };

  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          <tr height="85px">
            <td colSpan={2} valign="top" style={{ }}>
              <meta httpEquiv="X-UA-Compatible" content="IE=8" />
              <input type="hidden" name="localeHidden" />
              <input type="hidden" name="myDirectory" defaultValue="networkadmin" />
              <table border={0} cellPadding={0} cellSpacing={0} width="100%">
                <tbody>
                <table border={0} cellPadding={0} cellSpacing={0} width="100%">
              <tbody><tr height={13}><td width="100%">&nbsp;</td></tr>
                <tr>
                  {/* <td><img border="0" src="http://10.10.19.189:8180/airmanage/images/logo.PNG" width="143" height="76"></td> */}
                  <td><img border={0} style={{width: '20%'}} src={require("../images/logo.PNG")} /></td>
                  <td>
                    <table border={0} cellPadding={0} cellSpacing={0} align="right">
                      <tbody><tr height={25}>
                          <td align="right">
                          </td>
                        </tr>
                        <tr height={25}>
                          <td align="right" nowrap={'true'}> 
                            <CurrentDate />
                          </td>
                        </tr>
                        <tr height={13}><td width="100%">&nbsp;</td></tr>
                      </tbody></table>
                  </td>
                </tr>
                <tr height={10}>
                  <td height={10} colSpan={2} className="lineClass">&nbsp;</td>
                </tr>
               
              </tbody></table>
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
          
            <td valign="top">
              <meta httpEquiv="Content-Type" content="text/html; charset=ISO-8859-1" />
              <title>cs</title>

              {/* <div>
                <h1>Welcome to the Home Page!</h1>
                {data ? (
                  <>
                    <p>Site Language: {data.siteLanguage}</p>
                    <p>Locale: {data.localeValue}</p>
                    <p>Country: {data.countryValue}</p>
                  </>
                ) : (
                  <p>Loading...</p>
                )}
              </div> */}
             
                <table width="100%" height="100%" cellSpacing={20} cellPadding={150} border={0} align="center">
                  <tbody>
                    <tr valign="top">
                      <td align="center" className="headerTxt">
                      <p>Possible CSRF attack determined or Refreshing the page is forbidden for security reasons.</p>
                          <Button className={'hoverEffectButton'} onClick={handleLoginAgain} size="small" variant="contained" endIcon={<SendIcon />}>{t('6817')}</Button>
                      </td>
                    </tr>
                  </tbody>
                </table>
            </td>
          </tr>
          <tr height="60px">
            <td colSpan={2}>
              <link href="/airmanage/networkadmin/stylesheets/abcstyles-new.css" rel="stylesheet" type="text/css" />
               <Footer />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
export default CsrfAttack;
