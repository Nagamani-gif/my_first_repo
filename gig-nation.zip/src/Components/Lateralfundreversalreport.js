
/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import { Header, Footer, PaymentManagerHeading, LeftBgImage, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, CircularProgress, FormControl, Menu,FormControlLabel, FormLabel, Grid, InputLabel, MenuItem, Pagination, Paper, Radio, RadioGroup, Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField } from "@mui/material";
import React, { useState, useEffect, useCallback ,useRef} from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { ArrowDownward, ArrowUpward, CancelRounded, CloudDownload, KeyboardReturn, UnfoldMore } from "@mui/icons-material";
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import ExcelJS from 'exceljs';
import SendIcon from '@mui/icons-material/Send';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { ToastContainer, toast } from "react-toastify";
import dayjs from "dayjs";


function Lateralfundreversalreport() {
  sessionStorage.setItem("selectedLink", "e_transactions");

  const { t } = useTranslation();
  const localeVar = i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData"))
  const [partnerLoginId, setPartnerLoginId] = useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
//  const [startDateTime, setStartDateTime] = useState(dayjs().startOf('day'));
//    const [endDateTime, setEndDateTime] = useState(dayjs());
  const [hierarchyMode, setHierarchyMode] = useState('N');
  const [TransactionNumber, setTransactionNumber] = useState('');
  const [SourceSalesPersonIdentity, setSourceSalesPersonIdentity] = useState('');
  const [SourceCellularNumber, setSourceCellularNumber] = useState('');
  const [DestinationCellularNumber, setDestinationCellularNumber] = useState('');
  const [AuthorizationID, setAuthorizationID] = useState('');

  const [anchorEl, setAnchorEl] = useState();
  const closeTimeoutRef = useRef(null);
  const [sortConfig, setSortConfig] = useState({ key: '', direction: 'asc' });
  const [submitted, setSubmitted] = useState(false);
  

    const now = dayjs();  
    const midnightToday = dayjs().startOf('day');
  
    const [startDateTime, setStartDateTime] = useState(midnightToday);
    const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
    const [endDateTime, setEndDateTime] = useState(now);
    const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));

  const [apply,setApply] =useState(false);


     const toastId = useRef(null);
      let reportDays = process.env.REACT_APP_ReportDays;

      const [sortedItems1, setSortedItems1] = useState([]);
      const [sortDirection, setSortDirection] = useState(null);

 
        const [recordsFound, setRecordsFound] = useState(0);
        // let startRecord=0;
        // let endRecord =10;



  const navigate = useNavigate();

  console.log("totalRecords++++++++++++", totalRecords)
  const handleChangePage = (event, newPage) => {

 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       submitted
     });
 
  if (!isValid) {
  setSubmitted(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmitted(false);
    }
return false;

}


    setPage(newPage);
  };

  useEffect(() => {
    if (!submitted) return;
      fetchData();
  }, [submitted, page]);


  const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
  
  const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
   
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      

    }
    return false;
  }

  return true;
};

  const clearData = () => {
      setStartDateTime(midnightToday)
      setEndDateTime(now)
      setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
      setEndDate(now.format('DD/MM/YYYY HH:mm:ss'));
      setTransactionNumber('')
      setSourceSalesPersonIdentity('')
      setSourceCellularNumber('')
      setDestinationCellularNumber('')
      setAuthorizationID('')
      setHierarchyMode('N')
    };


 const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  

     const sortedItems = React.useMemo(() => {
    const sorted = [...items];
    if (sortConfig.key) {
      sorted.sort((a, b) => {
        const aVal = a[sortConfig.key];
        const bVal = b[sortConfig.key];
  
        if (!aVal) return -1;
        if (!bVal) return 1;
  
        if (sortConfig.direction === 'asc') {
          return aVal > bVal ? 1 : -1;
        } else {
          return aVal < bVal ? 1 : -1;
        }
      });
    }
    return sorted;
  }, [items, sortConfig]);


  

 const  AuthorizationIDRef = useRef(null);

  const handleSubmit = () => {


 if (AuthorizationID.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(AuthorizationID)) {
      if (!toast.isActive(toastId.current)) {
  
     toastId.current = toast.error(`${t('alrt_01')} in ${t('2480_033')}.`, {
      onClose: () => {
       AuthorizationIDRef.current?.focus();  // Focus after toast closes
      }
    });
  }
    return;
   }



const isValid = validateDateRange({
              startDateTime,
              endDateTime,
              reportDays,
              toast,
              toastId,
              t
            });
        
   if (!isValid){
  setApply(false);
  return;
} 
     
    startRecord=0;
    endRecord=10;
    fetchData(); // Assuming fetchData is an async function 
    setPage(1);
    setSubmitted(true);  
    setApply(true);

  };

  useEffect(() => {
    // Set the browser title
    document.title = t('2472_018');
  }, []);



  var fromDate = '';
  if (startDateTime != null) {
      var d = new Date(startDateTime);
      var month = d.getMonth() + 1;

      var day = d.getDate();
      var year = d.getFullYear();
      var hours = d.getHours();
      var minutes = d.getMinutes();

      // Ensure that hours and minutes are always two digits
      hours = hours < 10 ? '0' + hours : hours;
      minutes = minutes < 10 ? '0' + minutes : minutes;

      // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
      fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
      console.log("StartDate = " + day + "/" + month + "/" + year + " " + hours + ":" + minutes);
  }

  var toDate = '';
  if (endDateTime != null) {
      var d = new Date(endDateTime);
      var month2 = d.getMonth() + 1;
      var hours1 = d.getHours();
      var minutes1 = d.getMinutes();

      // Ensure that hours and minutes are always two digits
      hours1 = hours1 < 10 ? '0' + hours1 : hours1;
      minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;

      toDate = d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1 + ":" + minutes1;
      console.log("EndDate = " + d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1 + ":" + minutes1);
  }





 const handleEndDateTimeChange = (newValue) => {
    setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };
    const handleStartDateTimeChange = (newValue) => {
        setApply(false);
      setStartDateTime(newValue); 
     const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
     setStartDate(formattedDateTime);
      console.log("startDate::::::",newValue)
       console.log("startDate::::::",formattedDateTime)
    };



  const fetchData = async () => {
    localStorage.removeItem('channels');
    setIsLoading(true);
    try {

      const apiUrl =  window.config.apiUrlJasper + '/getLateralFundReport';
      const response = await axios.post(apiUrl, {
        userName,
        password,
        transactionId: TransactionNumber ? TransactionNumber.trim() : '',
        salesPersonId:SourceSalesPersonIdentity,
        fromMDn:SourceCellularNumber,
        toMdn:DestinationCellularNumber,
        authorizationId:AuthorizationID,
        fromDate:startDate,
        todate: endDate,
        levelFlag: hierarchyMode,
        fromDistributer:'',
        toDistributer:'',
        transferType:'',
        transcationType:'LATERALREVTRANS',
        toDistStatus:'',
        todistType:'',
        partnerId:partnerLoginId,
        piBegRecNo: startRecord,
        EndRecNo:(endRecord < 10 ? '10' : endRecord),
        piDownload:'N'
        
      });



if (response?.data?.data && response.data.data.length > 0) {
  setItems(response.data.data);
  setTotalRecords(response.data.data[0]?.noRows || 0);
  setRecordsFound(response.data.data[0]?.noRows || 0);
} else {
  setItems([]);
  setTotalRecords(0);
  setRecordsFound(0);
}
      // console.log("response::::::", response.data);
      // // if (response.status === 200) {
      //   if(response.data.data!==undefined){
      //   setItems(response.data.data);  // <-- Set items here!
      //   setTotalRecords(response.data.data[0].noRows || 0);
      //   setRecordsFound(response.data.data[0].noRows  || 0);
      //   }
      // // }
      // if(items===undefined){
      //   setItems([])
      // }
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };



  const fetchDataDownload = async () => {

 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       submitted
     });
 
  if (!isValid) {
  setSubmitted(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmitted(false);
    }
return false;

}
    //alert("hi")
    try {
     
     const apiUrl = window.config.apiUrlJasper +'/getLateralFundReport';
   //  const apiUrl = window.config.jasperUrl + process.env.REACT_APP_LATERALRPT;
      console.log('API URL:', apiUrl);
      console.log('Partner Login ID:', partnerLoginId);
      const responseDownload = await axios.post(apiUrl, {
        userName,
        password,
        transactionId:TransactionNumber,
        salesPersonId:SourceSalesPersonIdentity,
        fromMDn:SourceCellularNumber,
        toMdn:DestinationCellularNumber,
        authorizationId:AuthorizationID,
        fromDate:startDate,
        todate:endDate,
        levelFlag: hierarchyMode,
        fromDistributer:'',
        toDistributer:'',
        transferType:'',
        transcationType:'LATERALREVTRANS',
        toDistStatus:'',
        todistType:'',
        partnerId:partnerLoginId,
        piBegRecNo:0,
        EndRecNo:0,
        piDownload:'N'
        
      });

      console.log('Response download:', responseDownload);
     // alert("sss"+responseDownload.data.MassiveTranferDetails)

      if (!responseDownload.data.data || !responseDownload.data.data) {
        throw new Error('Invalid API response');
      }


      const downloadData = responseDownload.data.data.map(dto => ({
        fundTransferId: dto.fundTransferId,
        fundTransferDate: dto.fundTransferDate,
        authorizationId: dto.authorizationId,
        parentTransId: dto.parentTransId,
        fundTransferAmt: dto.fundTransferAmt,
        currencysymbol: dto.currencysymbol,
        fromAccount: dto.fromAccount,
        fromSalespersonMdn: dto.fromSalespersonMdn,
        fromPartnerCompanyName: dto.fromPartnerCompanyName,
        frmParentDistComp: dto.frmParentDistComp,
        fromAccountPreBalance: dto.fromAccountPreBalance,
        fromAccountPostBalance: dto.fromAccountPostBalance,
        toAccount:dto.toAccount,
        toSalespersonMdn: dto.toSalespersonMdn,
        toPartnerCompanyName: dto.toPartnerCompanyName,
        toParentDistComp: dto.toParentDistComp,
        toAccountPreBalance: dto.toAccountPreBalance,
        toAccountPostBalance: dto.toAccountPostBalance,
        transferedBy: dto.transferedBy,
        channel: dto.channel,
        levl: dto.levl,
        bankReferenceId: dto.bankReferenceId
      }));


      console.log('Download Data:', downloadData);

      return downloadData;
    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };
  
 


  
  const handleReturn = () => {
    navigate(-1);
  };


  const formatter = new Intl.NumberFormat('en-US', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});
 
 //excel
 
 const handleDownload = async () => {
  const downloadItems = await fetchDataDownload();
   if (!downloadItems || downloadItems.length === 0) return;
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('LateralFundReversalReport');

  const numberOfColumns = 22; // total columns
  const groupSpan = 6; // merge group width

  // Title Row: "Massive Transfers"
  const titleRow = worksheet.addRow([localeVar === 'en' ? "Lateral Fund Reversal Report" : "Reporte de Reversas de Fondos Laterales"]);
  worksheet.mergeCells(titleRow.number, 1, titleRow.number, numberOfColumns);
  const titleCell = titleRow.getCell(1);
  titleCell.font = { bold: true, size: 14 };
  titleCell.alignment = { horizontal: 'center' };


const summaryRow = worksheet.addRow([]);
summaryRow.getCell(1).value = `${t('032')} : ${totalRecords}`; // Total records
summaryRow.getCell(5).value = ``; // Displayed range + pages

summaryRow.getCell(1).alignment = { horizontal: 'left' };
summaryRow.getCell(5).alignment = { horizontal: 'right' };

// Merge cells for alignment
worksheet.mergeCells(summaryRow.number, 1, summaryRow.number, 4); // Left half
worksheet.mergeCells(summaryRow.number, 5, summaryRow.number, 8); // Right half

  // Empty row
  worksheet.addRow([]);

  // Sub-heading row with merged sections (6 each)
  const sectionHeadingRow = worksheet.addRow([]);
  worksheet.mergeCells(sectionHeadingRow.number, 1, sectionHeadingRow.number, groupSpan);
  worksheet.mergeCells(sectionHeadingRow.number, 7, sectionHeadingRow.number, groupSpan * 2);
  worksheet.mergeCells(sectionHeadingRow.number, 13, sectionHeadingRow.number, groupSpan * 3);

  sectionHeadingRow.getCell(1).value = '';
  sectionHeadingRow.getCell(7).value = t('Source Account');
  sectionHeadingRow.getCell(13).value = t('Destination Account');

  sectionHeadingRow.getCell(7).font = sectionHeadingRow.getCell(13).font = { bold: true };
  sectionHeadingRow.getCell(7).alignment = sectionHeadingRow.getCell(13).alignment = { horizontal: 'center' };

  // Headers
  const columnHeaders = [
    t('Transaction Number'), t('Transaction Date'), t('AuthorizationID'), t('FundTransferID'),
    t('TransferAmount'), t('Currency'),
    t('ID'), t('Cellular Number'), t('Company Name'), t('Parent Company Name'), t('Previous Balance'), t('Post Balance'),
    t('ID'), t('Cellular Number'), t('Company Name'), t('Parent Company Name'), t('Previous Balance'), t('Post Balance'),
    t('Entered By'), t('Channel'), t('Level'), t('Bank Reference Number')
  ];

  const headerRow = worksheet.addRow(columnHeaders);
  headerRow.eachCell(cell => {
    cell.font = { bold: true };
    cell.alignment = { horizontal: 'center' };
    cell.border = {
      top: { style: 'thin' },
      left: { style: 'thin' },
      bottom: { style: 'thin' },
      right: { style: 'thin' }
    };
  });

  // Data rows
  downloadItems.forEach(item => {
    const dataRow = worksheet.addRow([
      item.fundTransferId,
      item.fundTransferDate,
      item.authorizationId, 
      item.parentTransId,
      !isNaN(parseFloat(item.fundTransferAmt)) ? parseFloat(item.fundTransferAmt).toFixed(2) : '---',
      item.currencysymbol,
      item.fromAccount,
      item.toSalespersonMdn, 
      item.fromPartnerCompanyName,
      item.frmParentDistComp, 
      formatter.format(item.fromAccountPreBalance),
      formatter.format(item.fromAccountPostBalance),
      item.toAccount, item.fromSalespersonMdn,item.toPartnerCompanyName, item.toParentDistComp, 
      formatter.format(item.toAccountPreBalance),
      formatter.format(item.toAccountPostBalance),
      item.transferedBy,
      item.channel==="---"?"---":t('REP'+item.channel),
      item.levl, item.bankReferenceId
    ]);

    dataRow.eachCell(cell => {
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });
  });

  // Footer
  worksheet.addRow([]);
  const endOfReportRow = worksheet.addRow([t('0171')]);
  worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, numberOfColumns);
  const endCell = endOfReportRow.getCell(1);
  endCell.font = { italic: true, underline: true, bold: true };
  endCell.alignment = { horizontal: 'center' };

  // Set column widths (you can adjust this as needed)

  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });


  // Optional protection
  worksheet.protect('yourPassword', {
    selectLockedCells: true,
    selectUnlockedCells: true
  });

  // Export
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'LateralFundReversalReport.xlsx';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


//for pdf
const handleDownloadPdf = async () => {
  const downloadItems = await fetchDataDownload();
   if (!downloadItems || downloadItems.length === 0) return;
  const tableBody = [];

  // Grouped Headers: Empty | Source | Destination
  const groupedHeaderRow = [];
  groupedHeaderRow.push({ text: '', colSpan: 6 });
  for (let i = 1; i < 6; i++) groupedHeaderRow.push({ text: '' });

  groupedHeaderRow.push({ text: t('Source Account'), colSpan: 6, style: 'subGroup', alignment: 'center' });
  for (let i = 1; i < 6; i++) groupedHeaderRow.push({ text: '' });

  groupedHeaderRow.push({ text: t('Destination Account'), colSpan: 6, style: 'subGroup', alignment: 'center' });
  for (let i = 1; i < 6; i++) groupedHeaderRow.push({ text: '' });

  for (let i = 0; i < 4; i++) groupedHeaderRow.push({ text: '' });
  tableBody.push(groupedHeaderRow);

  // Column Headers
  const headers = [
    t('Transaction Number'), t('Transaction Date'), t('AuthorizationID'), t('FundTransferID'),
    t('TransferAmount'), t('Currency'),
    t('ID'), t('Cellular Number'), t('Company Name'), t('Parent Company Name'), t('Previous Balance'), t('Post Balance'),
    t('ID'), t('Cellular Number'), t('Company Name'), t('Parent Company Name'), t('Previous Balance'), t('Post Balance'),
    t('Entered By'), t('Channel'), t('Level'), t('Bank Reference Number')
  ];
  tableBody.push(headers.map(header => ({ text: header, style: 'tableHeader' })));

  // Data Rows
  downloadItems.forEach(item => {
    const row = [
      item.fundTransferId,
      item.fundTransferDate,
      item.authorizationId, 
      item.parentTransId,
     !isNaN(parseFloat(item.fundTransferAmt)) ? parseFloat(item.fundTransferAmt).toFixed(2) : '---',
      item.currencysymbol,
      item.fromAccount,
      item.toSalespersonMdn, 
      item.fromPartnerCompanyName,
      item.frmParentDistComp, 
      formatter.format(item.fromAccountPreBalance),
      formatter.format(item.fromAccountPostBalance),
      item.toAccount,
      item.fromSalespersonMdn,
      item.toPartnerCompanyName,
      item.toParentDistComp,
      formatter.format(item.toAccountPreBalance),
      formatter.format(item.toAccountPostBalance),
      item.transferedBy,
      item.channel==="---"?"---":t('REP'+item.channel),
      item.levl,
      item.bankReferenceId
    ];
    tableBody.push(row.map(val => ({ text: val != null ? String(val) : '' })));
  });

  // Final Content
  const content = [
        {
      text: localeVar === 'en'
        ? "Lateral Fund Reversal Report"
        : "Reporte de Reversas de Fondos Laterales",
      style: 'title',
      alignment: 'center',
      margin: [0, 0, 0, 10]
    },
    {
  columns: [
    {
      text: `${t('032')} : ${totalRecords}`,
      alignment: 'left',
      fontSize: 8
        }
  ],
  margin: [0, 0, 0, 5]
},
    {
      style: 'tableExample',
      table: {
        headerRows: 2, // now only grouped headers + column headers
        widths: [
          24, 24, 24, 24, 24, 24,     // General Info
          24, 24, 24, 24, 24, 24,     // Source Account
          24, 24, 24, 24, 24, 24,     // Destination Account
          24, 24, 24, 24              // Misc
        ],
        body: tableBody
      },
      layout: {
        fillColor: function (rowIndex) {
          return rowIndex === 1 ? '#3399FF' : null; // rowIndex adjusted since title removed
        }
      }
    },
    {
      text: t('0171'), // "End of Report"
      style: 'endText',
      alignment: 'center',
      margin: [0, 10, 0, 0]
    }
  ];

  // PDF Definition
  const docDefinition = {
    content,
    styles: {
      title: { fontSize: 16, bold: true },
      subGroup: { fontSize: 10, bold: true },
      tableExample: { margin: [0, 5, 0, 15] },
      tableHeader: { bold: true, fontSize: 8, color: '#fff' },
      endText: { italics: true, bold: true, decoration: 'underline', fontSize: 10 }
    },
    pageOrientation: 'landscape',
    pageSize: 'A4',
    defaultStyle: {
      fontSize: 7.5
    }
  };

  pdfMake.createPdf(docDefinition).download('LateralFundReversalReport.pdf');
};




const formatDateTime = (val) => {
    if (!val || val.trim() === "") return "";

  const parts = val.split(" ");
  if (parts.length < 2) return val;

  const [day, month, year] = parts[0].split("/");
  const [hh = "00", mm = "00", ss = "00"] = parts[1].split(":");

  const dd = day.padStart(2, "0");
  const mmn = month.padStart(2, "0");
  const yyyy = year;
  const hh24 = hh.padStart(2, "0");
  const min = mm.padStart(2, "0");
  const sec = ss.padStart(2, "0");
  return `="${dd}/${mmn}/${yyyy} ${hh24}:${min}:${sec}"`;
};



const handleDownloadCsv = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  // Headers
  const headers = [
    t('Transaction Number'), t('Transaction Date'), t('AuthorizationID'), t('FundTransferID'),
    t('TransferAmount'), t('Currency'),
    t('ID'), t('Cellular Number'), t('Company Name'), t('Parent Company Name'), t('Previous Balance'), t('Post Balance'), // Source Account
    t('ID'), t('Cellular Number'), t('Company Name'), t('Parent Company Name'), t('Previous Balance'), t('Post Balance'), // Destination Account
    t('Entered By'), t('Channel'), t('Level'), t('Bank Reference Number')
  ];

  // Escape function for CSV
  const escapeCSV = value => {
    if (value == null) return '';
    const strVal = String(value).trim().replace(/"/g, '""');
    return /^\d+\.\d{2}$/.test(strVal) || /^\d{2}\/\d{2}\/\d{4}/.test(strVal)
      ? `="${strVal}"`
      : `"${strVal}"`;
  };

  // Total columns
  const numberOfColumns = headers.length;

  // Function to create padded/centered row
  const createPaddedRow = (text, totalColumns) => {
    const leftPadding = Math.floor((totalColumns - 1) / 2);
    const rightPadding = totalColumns - leftPadding - 1;
    return [...Array(leftPadding).fill(''), text, ...Array(rightPadding).fill('')].join(',');
  };

  // Title and summary
  const title = localeVar === 'en' ? "Lateral Fund Reversal Report" : "Reporte de Reversas de Fondos Laterales";
  const paddedTitleRow = createPaddedRow(title, numberOfColumns);
  const summaryLeft = `${t('032')} : ${downloadItems.length}`;
  const summaryRight = ''; // Optional right text
  const paddedSummaryRow = `${summaryLeft},${Array(numberOfColumns - 2).fill('').join(',')},${summaryRight}`;

  // CSV content
  let csvContent = '';
  csvContent += paddedTitleRow + '\n';
  csvContent += paddedSummaryRow + '\n';
  csvContent += '\n'; // empty row for spacing


  // Optional: group headers (Source / Destination Account)
  const groupRow = [
    '', '', '', '', '', '', // first 6 empty
    t('Source Account'), ...Array(5).fill(''),
    t('Destination Account'), ...Array(5).fill(''),
    '', '', '', '' // last 4 empty columns
  ];
  csvContent += groupRow.join(',') + '\n';

    // Column headers
  csvContent += headers.map(escapeCSV).join(',') + '\n';

  // Data rows
  downloadItems.forEach(item => {
    const row = [
      item.fundTransferId,
      formatDateTime(item.fundTransferDate),
      item.authorizationId, 
      item.parentTransId,
      formatter.format(item.fundTransferAmt),
      item.currencysymbol,
      item.fromAccount,
      item.toSalespersonMdn, 
      item.fromPartnerCompanyName,
      item.frmParentDistComp, 
      formatter.format(item.fromAccountPreBalance),
      formatter.format(item.fromAccountPostBalance),
      item.toAccount,
      item.fromSalespersonMdn,
      item.toPartnerCompanyName,
      item.toParentDistComp, 
      formatter.format(item.toAccountPreBalance),
      formatter.format(item.toAccountPostBalance),
      item.transferedBy,
      item.channel === "---" ? "---" : t('REP' + item.channel),
      item.levl,
      item.bankReferenceId
    ];

    csvContent += row.map(escapeCSV).join(',') + '\n';
  });

  // End of report
//  csvContent += `\n${t('0171')}\n`;

const endRep = t('0171');  
const endLeftPadding = Math.floor((numberOfColumns - 1) / 2);

// Create an array for the row: left padding, message, right padding
const endTitleRow = [
  ...Array(endLeftPadding).fill(''),
  endRep,
  ...Array(numberOfColumns - endLeftPadding - 1).fill('')
];

// Add to CSV
csvContent += endTitleRow.join(',') + '\n';



const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;
  // Trigger download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', 'LateralFundReversalReport.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


// const handleDownloadCsv = async () => {
//   const downloadItems = await fetchDataDownload();
//    if (!downloadItems || downloadItems.length === 0) return;

//   // Actual headers
//   const headers = [
//     t('Transaction Number'), t('Transaction Date'), t('AuthorizationID'), t('FundTransferID'),
//     t('TransferAmount'), t('Currency'),
//     t('ID'), t('Cellular Number'), t('Company Name'), t('Parent Company Name'), t('Previous Balance'), t('Post Balance'), // Source Account
//     t('ID'), t('Cellular Number'), t('Company Name'), t('Parent Company Name'), t('Previous Balance'), t('Post Balance'), // Destination Account
//     t('Entered By'), t('Channel'), t('Level'), t('Bank Reference Number')
//   ];

//   let csvContent = '';

//   // Add main title row (merged visually; CSV does not support real merging)
//   const title = localeVar === 'en' ? "Lateral Fund Reversal Report" : "Reporte de Reversas de Fondos Laterales";
//   csvContent += `${title}\n\n`;

// const summaryLeft = `${t('032')} : ${totalRecords}`;
//   const summaryRight = ``;

//   // Title centered visually in 27 columns (middle is around column 14)
//   const paddedTitleRow = `${Array(5).fill('').join(',')}${title}\n`;

//   // Summary: left in column 1, right in column 27
//   const paddedSummaryRow = `${summaryLeft},${Array(5).fill('').join(',')},${summaryRight}\n`;

//   // // Build CSV content
//   csvContent = '';
//   csvContent += paddedTitleRow;
//   csvContent += paddedSummaryRow;
//   csvContent += '\n'; // empty row for spacing
//   csvContent += headers.join(',') + '\n';








//   // Add group headers (visually mimicking merged cells)
//   const sourceGroup = Array(6).fill('');
//   const sourceLabel = t('Source Account');
//   sourceGroup[0] = sourceLabel;

//   const destinationGroup = Array(6).fill('');
//   const destinationLabel = t('Destination Account');
//   destinationGroup[0] = destinationLabel;

//   const groupRow = [
//     '', '', '', '', '', '', // First 6 empty
//     ...sourceGroup,
//     ...destinationGroup,
//     '', '', '', '', // Last 4 columns
//   ];
//   csvContent += groupRow.join(',') + '\n';

//   // Add data rows
//   downloadItems.forEach(item => {
//     const row = [
//       item.fundTransferId,
//       formatDateTime(item.fundTransferDate),
//       item.authorizationId, 
//       item.parentTransId,
//       formatter.format(item.fundTransferAmt),
//       item.currencysymbol,
//       item.fromAccount,
//       item.toSalespersonMdn, 
//       item.fromPartnerCompanyName,
//       item.frmParentDistComp, 
//       formatter.format(item.fromAccountPreBalance),
//       formatter.format(item.fromAccountPostBalance),
//       item.toAccount, item.fromSalespersonMdn,item.toPartnerCompanyName, item.toParentDistComp, 
//       formatter.format(item.toAccountPreBalance),
//       formatter.format(item.toAccountPostBalance),
//       item.transferedBy,
//       item.channel==="---"?"---":t('REP'+item.channel),
//       item.levl, item.bankReferenceId
//     ];

//     const csvRow = row.map(field => {
//       if (field == null) return '';
//       const str = String(field);
//       return str.includes(',') || str.includes('"') ? `"${str.replace(/"/g, '""')}"` : str;
//     }).join(',');

//     csvContent += csvRow + '\n';
//   });

//   // End of report message
//   csvContent += `\n${t('0171')}\n`;

//   // Trigger download
//   const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
//   const link = document.createElement('a');
//   link.href = URL.createObjectURL(blob);
//   link.setAttribute('download', 'LateralFundReversalReport.csv');
//   document.body.appendChild(link);
//   link.click();
//   document.body.removeChild(link);
// };



  const RedAsterisk = styled('span')({
    color: 'red',
  });

  // let startRecord = (page - 1) * perpage + 1;
  // let endRecord = totalRecords > 0
  //   ? Math.min(startRecord + perpage - 1, totalRecords)
  //   : (page === 1 ? 10 : page * perpage);
  const totalPages = Math.ceil(recordsFound / recordsPerPage);

let startRecord = (page - 1) * perpage + 1;
let endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);


  const highlightSelectedLink = (e) => {
    var x = document.querySelector(".subLinkVisited");
    if (x !== null) {
      x.classList.replace("subLinkVisited", "subLink");
    }
    e.target.classList.replace("subLink", "subLinkVisited");
  }


const parseDate = (dateStr) => {
  // Expected format: DD/MM/YYYY HH:mm:ss
  const [datePart, timePart] = dateStr.split(' ');
  const [day, month, year] = datePart.split('/');
  return new Date(`${year}-${month}-${day}T${timePart}`);
};


const handleSortByDate = () => {
  const newDirection = sortDirection === 'asc' ? 'desc' : 'asc';

  const sorted = [...sortedItems].sort((a, b) => {
    const dateA = parseDate(a.fundTransferDate);
    const dateB = parseDate(b.fundTransferDate);
    return newDirection === 'asc' ? dateA - dateB : dateB - dateA;
  });

  setSortedItems(sorted);
  setSortDirection(newDirection);
};



  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          <Header />
          <tr height="65px">
            <PaymentManagerHeading />
            <TopMenu menuLink={localeVar === 'en' ? "MVNE Report" : "MVNE Soporte"} />
          </tr>

          <tr>
            {/* <td valign="top"style={{ borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)"}}nowrap="nowrap">

    </td> */}
            <div style={{ display: 'flex' }}>
              <LeftBgImage1 />
            </div>
            <td valign="top">
              <title>Lateralfundreversalreport</title>
              <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                <tbody>
                  <tr>
                    <td>
                      <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                        <tbody>
                          {/* MIDDLE ROW STARTS */}
                          <tr>
                            <td>
                              <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" height="100%">
                                <tbody>
                                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
                                    <Tabs style={{ minHeight: '35px' }}>
                                      <NavLink
                                        to="/lateralfundreversalreport"
                                        onClick={(e) => highlightSelectedLink(e)}
                                        // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
                                        className={({ isActive }) =>
                                          isActive ? 'activeProfilemenu' : `profile_menu 
                                       ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
                                        }
                                      ><Tab label={t('b_lateralfundreversalreport')} /></NavLink>
                                    </Tabs>
                                  </Box>

               <div className={'mL8 input_boxess'}>
                                  <tr valign="top">
                                    <td width="80%">
                                      {/* body starts */}

                                    
                                        <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{ marginTop: '5px' }}>

                                          {/* 
      <Box className={"distributor_fund_transfer_sec mL8 input_boxess rehargePreview"}sx={{ flexGrow: 1 }}>                        
              <Box className={'to_bloc'} style={{marginTop:'20px'}}>
        <fieldset  className={'distributor_fieldset'}>*/}

                                          <Box style={{ display: 'flex', gap: '12px', marginTop: '10px' }}>


                                            <TextField type="text" name="TransactionNumber" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {/* {`${t('053')}`} */}
                                                  {`${t('Transaction Number')}`}
                                                </span>} style={{ maxWidth: '250px', width: '160px' }}
                                              onChange={e => setTransactionNumber(e.target.value)} value={TransactionNumber} size="15" defaultValue=""
                                            />

                                      



                                            <TextField type="text" name="SourceCellularNumber" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {/* {`${t('053')}`} */}
                                                  {`${t('Source Cellular Number')}`}
                                                </span>} style={{ maxWidth: '250px', width: '160px' }}
                                              onChange={e => setSourceCellularNumber(e.target.value)} value={SourceCellularNumber} size="15" defaultValue=""
                                            />

                                            <TextField type="text" name="AuthorizationID" className={'sampleInput mb5'} inputRef={ AuthorizationIDRef}
                                              label={
                                                <span>
                                                  {/* {`${t('053')}`} */}
                                                  {`${t('AuthorizationID')}`}
                                                </span>} style={{ maxWidth: '250px', width: '160px' }}
                                              onChange={e => setAuthorizationID(e.target.value)} value={AuthorizationID} size="15" defaultValue=""
                                            />

                                            <TextField type="text" name="DestinationCellularNumber" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {/* {`${t('053')}`} */}
                                                  {`${t('Destination Cellular Number')}`}
                                                </span>} style={{ maxWidth: '250px', width: '180px' }}
                                              onChange={e => setDestinationCellularNumber(e.target.value)} value={DestinationCellularNumber} size="15" defaultValue=""
                                            />

                                        <TextField type="text" name="SourceSalesPersonIdentity" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {/* {`${t('053')}`} */}
                                                  {`${t('Source Sales Person Identity')}`}
                                                </span>} style={{ maxWidth: '250px', width: '217px' }}
                                              onChange={e => setSourceSalesPersonIdentity(e.target.value)} value={SourceSalesPersonIdentity} size="15" defaultValue=""
                                            />


                                          </Box>

<Box style={{ display: 'flex', gap: '12px'}}>
 <LocalizationProvider
  dateAdapter={AdapterDayjs}
  adapterLocale={localeVar === 'en' ? 'en' : 'es'}
>
  <DateTimePicker
    className="datePickerrr"
    value={startDateTime}
    onChange={handleStartDateTimeChange}
    ampm={false}
    label={<span>{`${t('80')}`}  <RedAsterisk>*</RedAsterisk></span>}
    format="DD/MM/YYYY HH:mm:ss"
    renderInput={(params) => (
      <TextField
        {...params}
        InputLabelProps={{ shrink: true }}
        placeholder={!startDateTime ? t('80') : ''}
        fullWidth
        variant="outlined"
        sx={{ width: '140px', height: '40px', padding: '20px', marginLeft: '5px' }}
      />
    )}
  />
</LocalizationProvider>

<LocalizationProvider
  dateAdapter={AdapterDayjs}
  adapterLocale={localeVar === 'en' ? 'en' : 'es'}
>
  <DateTimePicker
    className="datePickerrr mt20"
    value={endDateTime}
    onChange={handleEndDateTimeChange}
    ampm={false}
    label={<span>{`${t('81')}`} <RedAsterisk>*</RedAsterisk></span>}
    format="DD/MM/YYYY HH:mm:ss"
    renderInput={(params) => (
      <TextField
        {...params}
        fullWidth
        variant="outlined"
        sx={{ width: '140px', height: '40px', padding: '20px', marginLeft: '5px', marginTop: '20px' }}
      />
    )}
  />
</LocalizationProvider>
                                            <FormControl className={'selected_formcontrol'} sx={{ minWidth: 120 }} size="small">
                                              <InputLabel
                                                id="demo-select-small-label"
                                                sx={{ backgroundColor: '#fff', padding: '0 5px' }}
                                              >
                                                {`${t('hierarchyMode')}`} <RedAsterisk>*</RedAsterisk>
                                              </InputLabel>
                                              <Select
                                                className={'bankSelect'}
                                                style={{ maxWidth: '250px', width: '150px' }}
                                                labelId="demo-select-small-label"
                                                id="demo-select-small"
                                                value={hierarchyMode}
                                                label="Modo de jerarquia"
                                                onChange={(e) => setHierarchyMode(e.target.value)}
                                              >
                                                <MenuItem value="N">{t('N')}</MenuItem>
                                                <MenuItem value="Y">{t('Y')}</MenuItem>
                                              </Select>
                                            </FormControl>


                                            {/* </Box>
<Box style={{display:'flex', gap:'20px'}}> */}


                                            <Box style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'flex-end', marginTop: '-16px' }}>
                                              <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
                                                onClick={handleSubmit}
                                              >
                                                {/* {t('028')} */}{t('Apply')}
                                              </Button>

                                              <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
                                              onClick={clearData}
                                              >
                                                {/* {t('003')} */} {t('Reset')}
                                              </Button>
                           
                                            </Box>
                                          </Box>

                                          <Grid
                                            container
                                            spacing={2}
                                            sx={{ width: 1 }}
                                            className={""}
                                            style={{
                                              justifyContent: "center",
                                              marginTop: "5px",
                                              marginBottom: '0px',
                                              marginLeft: "0px",
                                              borderBottom: "1px solid #fff",
                                              paddingInline: "0px",
                                            }}
                                          >
                                            <Grid
                                              item
                                              xs={4}
                                              sx={{ textAlign: "left", padding: "0 !important" }}
                                            >
                                            </Grid>
                                            <Grid
                                              item
                                              xs={3}
                                              sx={{ textAlign: "center", padding: "0 !important" }}
                                            ></Grid>
                                            <Grid
                                              item
                                              xs={5}
                                              sx={{ textAlign: "right", padding: "0 !important" }}>
                                              {totalRecords > 0 ?
                                                <><span className={"strongerTxtLable"}>
                                                  {t('032')} : {totalRecords}
                                                </span><span className={"strongerTxtLable"}>
                                                    &nbsp; / &nbsp;
                                                    {t('033')} : {startRecord} - {endRecord}
                                                  </span></> :
                                                <></>}
                                            </Grid>
                                          </Grid>
                                          <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                                          <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
                                                                                    <TableHead>
                                                                                      <TableRow className="darkgray" style={{
                                                                                        position: 'sticky',
                                                                                        top: 0,
                                                                                        backgroundColor: '#d3d3d3',
                                                                                        zIndex: 2,
                                                                                      }}>
                                                
                                                  <TableCell align="center" colSpan={6}></TableCell>
                                                  <TableCell align="center" colSpan={6}>{t('Source Account')}</TableCell>
                                                  <TableCell align="center" colSpan={6}>{t('Destination Account')}</TableCell>
                                                  <TableCell align="center" colSpan={4}></TableCell>
                                                  </TableRow>
                                                  <TableRow className="darkgray" style={{
                                                                                                position: 'sticky',
                                                                                                top: 27, // Adjust based on height of previous sticky row (usually ~48px)
                                                                                                backgroundColor: '#f5f5f5',
                                                                                                zIndex: 2,
                                                                                              }} >
                                                  <TableCell align="center">{t('Transaction Number')}</TableCell>

                                                
                                                    {/* <TableCell align="center" onClick={() => requestSort('fundTransferDate')} style={{ cursor:'pointer' }}>
                                                 {t('Transaction Number')}&nbsp;
                                                 {sortConfig.key === 'fundTransferDate' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
                                                 </TableCell> */}
                                                 <TableCell
                                                   className="whiteboldtext"
                                                   align="center"
                                                   onClick={handleSortByDate}
                                                   style={{ cursor: 'pointer', userSelect: 'none', display: 'flex-center', justifyContent: 'center', alignItems: 'center' }}
                                                 >
                                                   {t('023')}&nbsp;
                                                   {sortDirection === 'asc' ? (
                                                     <ArrowUpward fontSize="small" />
                                                   ) : sortDirection === 'desc' ? (
                                                     <ArrowDownward fontSize="small" />
                                                   ) : (
                                                     <UnfoldMore fontSize="small" />
                                                   )}
                                                 </TableCell>


                                                 
                                                  <TableCell align="center">{t('AuthorizationID')}</TableCell>

                                                   <TableCell align="center" onClick={() => requestSort('parentTransId')} style={{ cursor:'pointer' }}>
                                                 {t('FundTransferID')}&nbsp;
                                                 {sortConfig.key === 'parentTransId' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                  
                                                    <TableCell align="center" onClick={() => requestSort('fundTransferAmt')} style={{ cursor:'pointer' }}>
                                                 {t('TransferAmount')}&nbsp;
                                                 {sortConfig.key === 'fundTransferAmt' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                    <TableCell align="center" onClick={() => requestSort('currencysymbol')} style={{ cursor:'pointer' }}>
                                                 {t('Currency')}&nbsp;
                                                 {sortConfig.key === 'currencysymbol' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                 
                                                 


                                                  <TableCell align="center">{t('ID')}</TableCell>
                                                  <TableCell align="center" onClick={() => requestSort('toSalespersonMdn')} style={{ cursor:'pointer' }}>
                                                 {t('Cellular Number')}&nbsp;
                                                 {sortConfig.key === 'toSalespersonMdn' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>


                                                 <TableCell align="center" onClick={() => requestSort('fromPartnerCompanyName')} style={{ cursor:'pointer' }}>
                                                 {t('Company Name')}&nbsp;
                                                 {sortConfig.key === 'fromPartnerCompanyName' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                 <TableCell align="center" onClick={() => requestSort('frmParentDistComp')} style={{ cursor:'pointer' }}>
                                                 {t('Parent Company Name')}&nbsp;
                                                 {sortConfig.key === 'frmParentDistComp' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                
                                              
                                                 <TableCell align="center" onClick={() => requestSort('fromAccountPreBalance')} style={{ cursor:'pointer' }}>
                                                 {t('Previous Balance')}&nbsp;
                                                 {sortConfig.key === 'fromAccountPreBalance' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                  <TableCell align="center" onClick={() => requestSort('fromAccountPostBalance')} style={{ cursor:'pointer' }}>
                                                 {t('Post Balance')}&nbsp;
                                                 {sortConfig.key === 'fromAccountPostBalance' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                  <TableCell align="center">{t('ID')}</TableCell>

                                                   <TableCell align="center" onClick={() => requestSort('fromSalespersonMdn')} style={{ cursor:'pointer' }}>
                                                 {t('Cellular Number')}&nbsp;
                                                 {sortConfig.key === 'fromSalespersonMdn' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>


                                                 <TableCell align="center" onClick={() => requestSort('toPartnerCompanyName')} style={{ cursor:'pointer' }}>
                                                 {t('Company Name')}&nbsp;
                                                 {sortConfig.key === 'toPartnerCompanyName' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                 <TableCell align="center" onClick={() => requestSort('toParentDistComp')} style={{ cursor:'pointer' }}>
                                                 {t('Parent Company Name')}&nbsp;
                                                 {sortConfig.key === 'toParentDistComp' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                
                                              
                                                 <TableCell align="center" onClick={() => requestSort('toAccountPreBalance')} style={{ cursor:'pointer' }}>
                                                 {t('Previous Balance')}&nbsp;
                                                 {sortConfig.key === 'toAccountPreBalance' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                  <TableCell align="center" onClick={() => requestSort('toAccountPostBalance')} style={{ cursor:'pointer' }}>
                                                 {t('Post Balance')}&nbsp;
                                                 {sortConfig.key === 'toAccountPostBalance' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                                  <TableCell align="center">{t('Entered By')}</TableCell>
                                                  <TableCell align="center">{t('Channel')}</TableCell>
                                                
                                                  <TableCell align="center" onClick={() => requestSort('levl')} style={{ cursor:'pointer' }}>
                                                 {t('Level')}&nbsp;
                                                 {sortConfig.key === 'levl' && (sortConfig.direction === 'asc' ? '▲' : '▼')}</TableCell>

                                               
                                                  <TableCell align="center">{t('Bank Reference Number')}</TableCell>

                                                </TableRow>
                                              </TableHead>
                                              <TableBody>
                                                {isLoading ? (
                                                  // Show loading spinner while data is being fetched
                                                  <TableRow>
                                                    <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
                                                      {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
                                                    </TableCell>
                                                  </TableRow>
                                                ) : sortedItems.length > 0 ? (
                                                  // Show table rows when data is available
                                                  sortedItems.map((item, index) => (
                                                    <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
                                                      <TableCell align="center">&nbsp;{item.fundTransferId}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.fundTransferDate}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.authorizationId}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.parentTransId}&nbsp;</TableCell>
                                                     
                                                      <TableCell align="center">&nbsp; {formatter.format(item.fundTransferAmt)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.currencysymbol}&nbsp;</TableCell>

                                                      
                                                      <TableCell align="center">&nbsp;{item.fromAccount}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.toSalespersonMdn}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.fromPartnerCompanyName}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.frmParentDistComp}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{formatter.format(item.fromAccountPreBalance)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{formatter.format(item.fromAccountPostBalance)}&nbsp;</TableCell>

                                                      
                                                      <TableCell align="center">&nbsp;{item.toAccount}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.fromSalespersonMdn}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.toPartnerCompanyName}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.toParentDistComp}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{formatter.format(item.toAccountPreBalance)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{formatter.format(item.toAccountPostBalance)}&nbsp;</TableCell>
                                                      

                                                      <TableCell align="center">&nbsp;{item.transferedBy}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.channel==="---"?"---":t('REP'+item.channel)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.levl}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.bankReferenceId}&nbsp;</TableCell>


                                                    </TableRow>
                                                  ))
                                                ) : (
                                                  // Show 'No data found' message if no items are found after loading
                                                  <TableRow>
                                                    <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                                                  {submitted ? t("2481_061") : t("038")}
                                                    </TableCell>
                                                  </TableRow>
                                                )}
                                              </TableBody>
                                            </Table>
                                          </TableContainer>
                                          <br></br>
                                         <Table>
  <tfoot>
    <Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
      <Box
        sx={{ textAlign: "right", padding: "4px 0px 4px 0 !important" }}
        className={'displayFlex'}
      ></Box>

{items.length>0?                                                 <Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
    </Box>
    <tr></tr>
  </tfoot>
</Table>
 <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
  {items.length > 0 ? (
    <div onMouseLeave={handleClose}>
      <Button
        className="hoverEffectButton"
        size="small"
        variant="contained"
        endIcon={<CloudDownload />}
        onMouseEnter={handleHover}
      >
        {t('089')}
      </Button>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        MenuListProps={{
          onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
          onMouseLeave: handleClose,
        }}
      >
<MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{localeVar=="en"?"As":"Como"} PDF</MenuItem>
<MenuItem onClick={() => { setAnchorEl(null); handleDownload(); }}>{localeVar=="en"?"As":"Como"} Excel</MenuItem>
<MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{localeVar=="en"?"As":"Como"} CSV</MenuItem>

      </Menu>
    </div>
  ) : null}

                                            <Button
                                              className={"hoverEffectButton"}
                                              size="small"
                                              variant="contained"
                                              onClick={handleReturn}
                                              endIcon={<KeyboardReturn />}
                                            > {t('013')}</Button>
                                          </div>
                                          <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                                        </table>
                                        </td></tr>
                                      </div>
                                    
                                </tbody>
                              </table>
                            </td>
                          </tr>{/* MIDDLE ROW ENDS HERE  */}
                        </tbody>
                      </table>
                    </td></tr>
                </tbody>
              </table>
            </td></tr>

<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />

          <tr height="60px"><td colSpan={2}>
            <Footer />
          </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default Lateralfundreversalreport;

