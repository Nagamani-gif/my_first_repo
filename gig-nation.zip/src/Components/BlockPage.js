
import React from 'react';
import { Footer } from './PageComponents'
import { Link } from 'react-router-dom';
import Button from '@mui/material/Button';
import SendIcon from '@mui/icons-material/Send';
import { useTranslation } from 'react-i18next';
import { CancelRounded } from '@mui/icons-material';
import Navbar from './Navbar';

const BlockPage = () => {
  const { t } = useTranslation();
  sessionStorage.setItem('fromExpSoon','fromExpSoon');

  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          <table border={0} cellPadding={0} cellSpacing={0} width="100%">
            <tbody>

              <Navbar />
             
              <tr > <td height="176" font-weight="bold" > </td></tr>
              
              <tr >
                <td height="22" class="redTxt" align="center" >
                  <b>		{t('1')} </b>
                </td></tr>
              <tr>
                <td height="22" class="redTxt" align="center"><b>
                  {t('2')} <font color="#000000">{t('changepassword')}</font> {t('6')}.</b>
                </td>
              </tr>
              <tr>
                <td height="22" class="redTxt" align="center" ><b>

                  {t('3')} <font color="#000000">{t('cancel')}</font> {t('7')}<font color="#000000"></font></b>
                </td>

              </tr>
             
            </tbody>
          </table>




          <center><br />
            <Link to={"/changepasswordpage"}>
              <Button style={{ marginRight: '10px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}>{t('242401')}</Button><td></td>
            </Link>

            <Link to={"/logout"}>
              <Button style={{ marginRight: '10px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelRounded />}>{t('8')}</Button>
            </Link>
            <br></br>
          </center>

          <tr height="60px"><td colSpan={2}>
            <Footer />
          </td>
          </tr>
        </tbody>
      </table>
    </div>
  )
};

export default BlockPage;




