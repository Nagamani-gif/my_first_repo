/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect, useRef } from "react";
import TopMenu from "./TopMenu";
import { useTranslation } from "react-i18next";
import {
  Footer,
  Header,
  JasperLeftMenu,
  JasperTopMenu,
  LeftBgImage,
  PaymentManagerHeading,
  ProfileMenu,
} from "./PageComponents";
import axios from "axios";
import {
  CancelRounded,
  KeyboardReturn,
  RemoveRedEyeRounded,
  AddCardRounded,
  FlashAutoRounded,
  ArrowRight,
} from "@mui/icons-material";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import Button from "@mui/material/Button";
import { AccordionDetails, AccordionSummary, Checkbox, TextareaAutosize } from "@mui/material";
import { useNavigate } from "react-router-dom";
import SalesPersonPopup from "./SalesPersonPopup";
import i18n from "./i18n";
import { LocationPopUp } from "./LocationPopUp";
import DenominationsAssociationPopUp from "./DenominationsAssociationPopUp";
import { ToastContainer, toast } from "react-toastify";
import ConfigurationNotificationPopup from "./ConfigurationNotificationPopup";
import NavigationIcon from "@mui/icons-material/Navigation";
import { resetData } from "../reducers/exampleSlice";
import GoogleMapPartner from "./GoogleMapPartner";
import { LoadScript } from "@react-google-maps/api";
import numeral from "numeral";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
  Box,
  Grid,
  TextField,
  Typography,
  TableContainer,
  TableCell,
  Paper,
  TableRow,
  TableHead,
  Table,
  TableBody,
} from "@mui/material";
import ThumbUpAltIcon from "@mui/icons-material/ThumbUpAlt";
import SendIcon from "@mui/icons-material/Send";
import { useLocation } from "react-router-dom";
import Accordion from '@mui/material/Accordion';
import { CircularProgress } from "@mui/joy";

function ModifyProfile() {
  
  const [data, setData] = useState(() => {
    // Try to get initial state from sessionStorage
    const savedData = sessionStorage.getItem("homePageData");
    return savedData ? JSON.parse(savedData) : null;
  });
  //sessionStorage.setItem("selectedIndex", 1);
  sessionStorage.setItem("selectedLink", "a_profile");

 
  const localVar = i18n.language;
  const localeVar = i18n.language;
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const appLocation = useLocation();
  let componentRef = useRef();

  const exampleData = JSON.parse(localStorage.getItem("userData")); // Select the data from the Redux store
  console.log("exampleData LOGIN_ID====>" + exampleData.LOGIN_ID);
  const sfsCheck = exampleData.SINGLE_FUND_SOURCE_FLAG_VAL;
  const sfsCheckvalue = sfsCheck === "N" ? "Yes" : "No";
  let isSelf = false;
  const { distId } = appLocation.state || {};

  if (distId != undefined) {
    if (exampleData.LOGIN_ID === distId) {
      // alert(distId);
      isSelf = true;
    }
  }

  let id = "";

  if (isSelf) {
    id = exampleData.LOGIN_ID;
  } else {
    id = distId;
  }
  //alert("distIddistIddistId=="+isSelf)
  const [usertypes, setUsertypes] = useState([]);
  const [bankRefernceNumber, setBankRefernceNumber] = useState("");
  const [salesData, setsalesData] = useState([]);
  const [channelTransAl, setChannelTransAl] = useState([]);
  const [ChannelcheckFlag, setChannelcheckFlag] = useState("");

  const [addrComprisionChk, setAddrComprisionChk] = useState("");
  const [geoReferencingEnable, setGeoReferencingEnable] = useState("");
  const [geoReferencingMapValue, setGeoReferencingMapValue] = useState("");

  const navigate = useNavigate();
  const handleReturn = () => {
     // navigate(-1);
   navigate("/profile", { state: { distId} });
  };

  const { t } = useTranslation();
  const labelsArray = [
    t('251610'),
    t('251611'),
    t('251612'),
    t('251613'),
    t('251650')
  ];
  const checkboxChange = (bool) => {
    return !bool;
  };

  const [parentLaternalFlagVal, setParentLaternalFlagVal] = useState("");
  const [parentMultiLevlFlagVal, setParentMultiLevlFlagVal] = useState("");
  const [parentMultiLevlRecFlagVal, setParentMultiLevlRecFlagVal] =
    useState("");
  const [parentIsSingleSrcFlagVal, setParentIsSingleSrcFlagVal] = useState("");
  const [partnerTypeId, setPartnerTypeId] = useState("");
  const [partnerEffTime, setPartnerEffTime] = useState("");
  const [partnerBgnDt, setPartnerBgnDt] = useState("");
  const [partnerEndDt, setPartnerEndDt] = useState("");
  const [addressId, setAddressId] = useState("");
  const [location, setLocation] = useState("");
  const [status, setStatus] = useState("");
  const [commission, setCommission] = useState("");
  const [distRatings, setDistRatings] = useState("");
  const [rateDesc, setRateDesc] = useState("");
  const [ratingId, setRatingId] = useState("");
  const [maxFundLimit, setMaxFundLimit] = useState("0.00");
  const [isMasterDistributorStr, setIsMasterDistributorStr] = useState("");
  const [accountBal, setAccountBal] = useState("");
  const [isLatEnabled, setIsLatEnabled] = useState("");
  const [latTransHierFlag, setLatTransHierFlag] = useState("");
  const [isMultiNetEnabled, setIsMultiNetEnabled] = useState("");
  const [mulNetTransHierFlag, setMulNetTransHierFlag] = useState("");
  const [isMultiLevlEnabled, setIsMultiLevlEnabled] = useState("");
  const [isMultiNetRecEnabled, setIsMultiNetRecEnabled] = useState("");
  const [mulNetRecHierFlag, setMulNetRecHierFlag] = useState("");
  const [isMultiLevlRecEnabled, setIsMultiLevlRecEnabled] = useState("");
  const [isMultiLevelTransEnabled, setIsMultiLevelTransEnabled] = useState("");
  const [mulLvlTransHierFlag, setMulLvlTransHierFlag] = useState("");
  const [isMultiLevlTransEnabled, setIsMultiLevlTransEnabled] = useState("");
  const [isMultiLevelRecEnabled, setIsMultiLevelRecEnabled] = useState("");
  const [mulLvlRecHierFlag, setMulLvlRecHierFlag] = useState("");
  const [isMultiLevlReceiveEnabled, setIsMultiLevlReceiveEnabled] =
    useState("");
  const [profName, setProfName] = useState("");
  const [profId, setProfId] = useState("");
  const [profTypeId, setProfTypeId] = useState("");
  const [addresschecking, setAddresschecking] = useState("");
  const [province, setProvince] = useState("");
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [addressStr, setAddressStr] = useState("");
  const [mapCity, setMapCity] = useState("");
  const [mapCounty, setMapCounty] = useState("");
  const [mapProvince, setMapProvince] = useState("");
  const [mapAddrChngeFlg, setMapAddrChngeFlg] = useState("");
  const [addDistNChannel, setAddDistNChannel] = useState("");
  const [profileTypeId, setProfileTypeId] = useState("");
  const [parentCurrencyId, setParentCurrencyId] = useState("");
  const [geoMarketName, setGeoMarketName] = useState("");
  const [geoRegionName, setGeoRegionName] = useState("");
  const [geoProvinceName, setGeoProvinceName] = useState("");
  const [geoCityName, setGeoCityName] = useState("");
  const [geoLocationName, setGeoLocationName] = useState("");
  const [commissionFlag, setCommissionFlag] = useState("");
  const [commissionTemplet, setCommissionTemplet] = useState("");
  const [isPrePaid, setIsPrePaid] = useState("");
  const [creditStDate, setCreditStDate] = useState("");
  const [creditEdDate, setCreditEdDate] = useState("");
  const [isSingleSrcFlagChanged, setIsSingleSrcFlagChanged] = useState("");

  const [eventIDAl, setEventIDAl] = useState([]);
  const [otherDistributionListAl, setOtherDistributionListAl] = useState([]);
  const [childAlertSubscriptionAl, setChildAlertSubscriptionAl] = useState([]);
  const [selfAlertAl, setSelfAlertAl] = useState([]);
  const [deliveryMethodAl, setDeliveryMethodAl] = useState([]);
  const [statusAl, setStatusAl] = useState([]);
  const [jobFlag, setJobFlag] = useState("");
  const [jobFlagAL, setJobFlagAL] = useState([]);
  const [denomTypeAL, setdenomTypeAL] = useState([]);
  const [denomIdAL, setDenomIdAL] = useState([]);

  const [selectedGeographicalLoc, setSelectedGeographicalLoc] = useState("");
  const [locationArray, setLocationArray] = useState([]);
  const [selectedGeographicalObj, setSelectedGeographicalLocObj] = useState({});
  const [mapInAdd, setMapInAdd] = useState("");
  const [channelsSelectFlag, setChannelsSelectFlag] = useState(false);
  const [notificationObj, setNotificationObj] = useState([]);
  const [preview, setPreview] = useState(false);
  const [notifSub, setNotifSub] = useState(false);
  const [denomFlag, setDenomFlag] = useState(true);
  const [channelList, setChannelList] = useState("");
  const [channelDesp, setChannelDesp] = useState("");
  const [LocationId, setLocationId] = useState("");
  const [postalcheck, setPostalCheck] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const [partnerId, setPartnerId] = useState("");
  const [salesMDN, setSalesMDN] = useState("");
  const [partnerParentId, setPartnerParentId] = useState("");
  const [partnerCompanyName, setPartnerCompanyName] = useState("");
  const [isPrepaidDistributor, setIsPrepaidDistributor] = useState("");
  const [partnerTypeDesc, setPartnerTypeDesc] = useState("");
  const [isCredit, setIsCredit] = useState("");
  const [rucNo, setRucNo] = useState("");
  const [sclCode, setSclCode] = useState("");
  const [sclUserName, setSclUserName] = useState("");
  const [chargeMode, setChargeMode] = useState("");
  const [discountValue, setDiscountValue] = useState("");
  const [locationDesc, setLocationDesc] = useState("");
  const [contaddress1, setContaddress1] = useState("");
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [contzipcode, setContzipcode] = useState("");
  const [billaddress1, setBilladdress1] = useState("");
  const [billzipcode, setBillzipcode] = useState("");
  const [partnerFirstName, setPartnerFirstName] = useState("");
  const [partnerLastName, setPartnerLastName] = useState("");
  const [emailID, setEmailID] = useState("");
  const [paymentType, setPaymentType] = useState({});
  const [creditLmt, setCreditLmt] = useState("");
  const [creditAlloted, setCreditAlloted] = useState("");
  const [creditThreshold, setCreditThreshold] = useState("");
  const [acctBalThresold, setAcctBalThresold] = useState("");
  const [gl_code, setGl_code] = useState("");
  const [currencyId, setCurrencyId] = useState("");
  const [isLateralEnabled, setIsLateralEnabled] = useState("");
  const [isSingleSrcEnabled, setIsSingleSrcEnabled] = useState("");
  // const [isMultiLevlEnabled, setIsMultiLevlEnabled] = useState("No");
  // const [isMultiLevlRecEnabled, setIsMultiLevlRecEnabled] = useState("No");
  // const [isMultiLevlTransEnabled, setIsMultiLevlTransEnabled] = useState("No");
  // const [isMultiLevlReceiveEnabled, setIsMultiLevlReceiveEnabled] = useState("No");
  const [isRechargeReversal, setIsRechargeReversal] = useState("");
  const [isTransferReversal, setIsTransferReversal] = useState("");
  const [updateComment, setUpdateComment] = useState("");
  const [bankReferenceNum, setBankReferenceNum] = useState("");
  const [billingSysUserName, setBillingSysUserName] = useState("");
  const [saleforenable, setSaleforenable] = useState("");
  const [simtransenable, setSimtransenable] = useState("");
  const [partnerSimThreshold, setPartnerSimThreshold] = useState("");
  const [negativeTransfers, setNegativeTransfers] = useState("");
  const [feeSet, setFeeSet] = useState("");
  const [feeFundSource, setFeeFundSource] = useState("");
  const [isChecked, setIsChecked] = useState(false);

  const [mulitNetTransEnabled, setMultiNetTransEnabled] = useState("");
  const [mulitNetRecEnabled, setMultiNetRecEnabled] = useState("");
  const [mulitLevelTransEnabled, setMultiLevelTransEnabled] = useState("");
  const [mulitLevelRecEnabled, setMultiLevelRecEnabled] = useState("");

  const [paymentTypeValue, setPaymentTypeValue] = useState("1");
  const [promTopUpList, setPromTopUpList] = useState("");
  const [promTopUpDesc, setPromTopUpDesc] = useState("");

  const [feeSetList, setFeeSetList] = useState([]);
  const [locationVal, setLocationVal] = useState("");
  const [remoteAddress, setRemoteAddress] = useState("");
  const [partnerUserTypeDesc, setPartnerUserTypeDesc] = useState("");
  const [currecyChanged, setCurrecyChanged] = useState("");
  const [denomAssociationFlag, setDenomAssociationFlag] = useState("");
  const [fundReversalFlag, setFundReversalFlag] = useState(false);
  const [userTypeId, setUserTypeId] = useState(false);

  const [andPartnerParentIdPresent, setAndPartnerParentIdPresent] =
    useState("");
  const [transferFlagStatus, setTransferFlagStatus] = useState("");
  const [pmConfigStatusOut, setPmConfigStatusOut] = useState("");
  const [pmConfigMultiStatus, setPmConfigMultiStatus] = useState("");
  const [transferFlag, setTransferFlag] = useState("");
  const [partnerParentIdType, setPartnerParentIdType] = useState("");
  const [partnerIdPmConfigStatus, setPartnerIdPmConfigStatus] = useState("");
  const [isSalesEnb, setIsSalesEnb] = useState(true);
  const [pmConfigMultiLevelStatus, setPmConfigMultiLevelStatus] = useState("");
  const [flagPmconfigstatus_RechargeRev, setFlagPmconfigstatus_RechargeRev] =
    useState(true);
  const [flagPmconfigstatus_TransferRev, setFlagPmconfigstatus_TransferRev] =
    useState(true);
  const [postToSCLEnableFlag, setPostToSCLEnableFlag] = useState("");
  const [partnerParentIdPresent, setPartnerParentIdPresent] = useState("");
  const [creditThresholdFlag, setCreditThresholdFlag] = useState("");
  const [isSimMgmtEnable, setIsSimMgmtEnable] = useState("");
  const [str, setStr] = useState([]);
  const [parentBankRefNumber, setParentBankRefNumber] = useState("");
  const [promGeoLocId, setPromGeoLocId] = useState("");
  const [triggerFetch, setTriggerFetch] = useState(false);
  const [isFirstTime, setIsFirstTime] = useState("");
  const toastId = useRef(null); // Use a ref to track the toast ID
  const [tempChargeMode, setTempChargeMode] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  let check=false;
  const [toastShown, setToastShown] = useState(false);
  const [clear, setClear] = useState(false);

  const [configId,setConfigId]=useState(id);
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    setTimeout(()=>{
    setIsLoading(false);
    }, 1000)
    },[])
  const setClearReset=(check)=>{
    setClear(check);
  }
  const activeCurrencyPrecision = exampleData.activeCurrencyPrecision;

  const doReverseFunds = () => {
    if (fundReversalFlag) {
      // eslint-disable-next-line no-restricted-globals
      const userConfirmed = confirm(t("49492424"));
      if (userConfirmed) {
        setFundReversalFlag(false);
      } else {
        setFundReversalFlag(true);
      }
    } else {
      // eslint-disable-next-line no-restricted-globals
      const userConfirmed = confirm(t("49482424"));
      if (userConfirmed) {
        setFundReversalFlag(true);
      } else {
        setFundReversalFlag(false);
      }
    }
  };

  const fetchUsers = async () => {
    try {
      const apiUrl =
        window.config.apiUrl + process.env.REACT_APP_GET_USER_TYPES;
      console.log(apiUrl);
      const response = await axios.post(apiUrl, {
        userName,
        password,
        partnerId: id,
        localeVar,
      });
      setUsertypes(response.data.userTypes);
      setBankRefernceNumber(response.data.parentBankRefId);
      console.log("usertypes", usertypes);
      console.log("bankRefernceNumber", bankRefernceNumber);
    } catch (error) {
      console.error("Error fetching the IP address", error);
    }
  };

  console.log("activeCurrencyPrecision-->" + activeCurrencyPrecision);
  // useEffect(
  //   () => async () => {
  //     //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
  //     const apiUrl = window.config.apiUrl +  process.env.REACT_APP_GET_CHANNELS;
  //     console.log(apiUrl);
  //     const response = await axios.post(apiUrl, {
  //       userName,
  //       password,
  //       localeVar,
  //       channelTransAl: "",
  //     });
  //     // const[channels]=response.data;

  //     localStorage.setItem("channels", JSON.stringify(response.data.channels));
  //     //console.log(JSON.stringify(response.data.channels));
  //     //  setsalesData(JSON.stringify(response.data.channels));
  //   },
  //   []
  // );

  //parent also Included based on that we can decide this Default Value
  const [useOwnFunds, setUseOwnFunds] = useState("Y");

  // useEffect(
  //   () => async () => {
  //     //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
  //     const apiUrl = process.env.REACT_APP_GET_CHANNELS;
  //     console.log(apiUrl);
  //     const response = await axios.post(apiUrl, {
  //       userName,
  //       password,
  //       localeVar,
  //       channelTransAl: "",
  //     });
  //     // const[channels]=response.data;

  //     localStorage.setItem("channels", JSON.stringify(response.data.channels));
  //     //console.log(JSON.stringify(response.data.channels));
  //     //  setsalesData(JSON.stringify(response.data.channels));
  //   },
  //   []
  // );

  const fetchChannels = async (channelList) => {
    //alert(channelList);
    //console.log("channelList=="+channelList)
    //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
    const apiUrl = window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
    console.log(apiUrl);
    const response = await axios.post(apiUrl, {
      userName,
      password,
      localeVar,
      channelTransAl: channelList,
    });
    // const[channels]=response.data;

    localStorage.setItem("channels", JSON.stringify(response.data.channels));
    const selectedRowsData = response.data.channels.filter(
      (sales) => sales.checkVal === "checked"
    );
    setChannelTransAl(selectedRowsData);

  //  let arr=channelList.split('_-_');
  //  let channelslength=arr.length-1;
    console.log("checked channels length===" + selectedRowsData.length);
    console.log("checked channels length===" + response.data.channels.length);
  //  console.log("Arrr channels length===" + channelslength);
    if (selectedRowsData.length == response.data.channels.length) {
      setChannelsSelectFlag(true);
      check=true;
    }
  };

  // useEffect(()=>{
  //   const fetdenominatons = async () => {
  //     const apiUrl = window.config.apiUrl + process.env.REACT_APP_DENOMINATIONS_ASSOCIATION;
  //     console.log(apiUrl);
  //     const response = await axios.post(apiUrl, {
  //       userName,
  //       password,
  //       partnerId: partnerParentId,
  //       localeVar,
  //     });
  //     // const[channels]=response.data;

  //     localStorage.setItem("denominations", JSON.stringify(response.data));
  //     //alert(JSON.stringify(response.data));
  //     //console.log(JSON.stringify(response.data.channels));
  //     //  setsalesData(JSON.stringify(response.data.channels));
  //   }
  //   fetdenominatons();

  //   },
  //   []
  // );

  console.log("activeCurrencyPrecision-->" + activeCurrencyPrecision);
  const [activeCurrencySymbol, setActiveCurrencySymbol] = useState(
    exampleData.systemCurrencySymbol
  );

  useEffect(() => {
    console.log("Updated prom List: " + promTopUpList);
  }, [promTopUpList]);

  const handleUseOwnFundsChange = (event) => {
    setUseOwnFunds(event.target.value);
  };

  const setChannelsAssociation = (obj, checkFlag) => {
    let channels=promTopUpList;
    console.log("objjj====", obj);
    console.log("chekflag====", checkFlag);
    if (obj.length > 0) {

      // setChannelList(obj.map((channel) => channel.topUpId).join("_-_"));
       channels = obj.map((channel) => channel.topUpId).join('_-_');
      // setChannelDesp(obj.map((channel) => channel.topupTypeDesc).join("_-_"));
       channels=channels+"_-_";
     //  alert(channels);
       setPromTopUpList(channels);
       
     }

    setChannelsSelectFlag(checkFlag);
    setChannelTransAl(obj);
    if (checkFlag)
      setAddDistNChannel("channel");
     else
     setAddDistNChannel("");
    console.log("Channel List: " + channels);
    console.log("prom List: " + promTopUpList);

  };


  const setnotificationListObj = (notificationobj, notif) => {
    // alert(t("2616023"));
    console.log("notificationobj==========", notificationobj);

    const eventIdArray = notificationobj.map((item) => item.eventId);
    const deliveryMethodArray = notificationobj.map(
      (item) => item.deliveryMethod
    );
    const selfAlertArray = notificationobj.map((item) =>
      item.selfAlert ? "Y" : "N"
    );
    const otherDistributionListArray = notificationobj.map(
      (item) => item.otherDistributionList
    );
    const childAlertSubscriptionArray = notificationobj.map(
      (item) => item.childAlertSubscription
    );
    const statusArray = notificationobj.map((item) => item.status);

    console.log("Event IDs:", eventIdArray);
    console.log("Delivery Methods:", deliveryMethodArray);
    console.log("Self Alerts:", selfAlertArray);
    console.log("Other Distribution Lists:", otherDistributionListArray);
    console.log("Child Alert Subscriptions:", childAlertSubscriptionArray);
    console.log("Statuses:", statusArray);

    setNotificationObj(notificationobj);
    setNotifSub(notif);

    setEventIDAl(eventIdArray);
    setOtherDistributionListAl(otherDistributionListArray);
    setChildAlertSubscriptionAl(childAlertSubscriptionArray);
    setSelfAlertAl(selfAlertArray);
    setDeliveryMethodAl(deliveryMethodArray);
    setStatusAl(statusArray);
    if (notif) setJobFlag("I");
  };

  const handleSelectedGeographicalLoc = (obj, loc, mapIn, locId) => {
    setSelectedGeographicalLoc(loc);
    setLocationVal(loc);
    setLocationArray(loc.split('-->'));
    console.log(loc.split('-->'), "Location Array from Modify");
    setSelectedGeographicalLocObj(obj);
    setMapInAdd(mapIn);
    setLocationId(locId + "_-_");
    setPromGeoLocId(locId + "_");
    setPostalCheck(obj.selectedZipCode);
  };

  const setMapAddress = (address, long, lati, postal) => {
    console.log("Hiii" + address);
    setContaddress1(address);
    setLatitude(lati);
    setLongitude(long);
    setContzipcode(postal);
    setPostalCheck(postal);
    console.log(postal, "Postal....")
  };

  const chunkedData = channelTransAl.reduce((resultArray, item, index) => {
    const chunkIndex = Math.floor(index / 4);

    if (!resultArray[chunkIndex]) {
      resultArray[chunkIndex] = []; // start a new chunk
    }

    resultArray[chunkIndex].push(item);

    return resultArray;
  }, []);

  const [selectedAddress, setSelectedAddress] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    fetchUsers();

    let url =
      window.config.apiUrl + process.env.REACT_APP_VIEWPARTNERDETAILS_URL;
    let response = await axios.post(url, {
      userName,
      password,
      partnerId: id,
      partnerLoginId: exampleData.LOGIN_ID,
      information: "",
      methodName: "",
      activeCurrencyPrecision: activeCurrencyPrecision,
      activeCurrencySymbol: exampleData.systemCurrencySymbol,
      localeVar: i18n.language,
    });

    let data = response.data;

    console.log("data user===" + data);
    setConfigId(data.distributorId);
    setPartnerId(data.distributorId);
    setSalesMDN(data.mdn);
    setPartnerCompanyName(data.company);
    setSclCode(data.sclClientCode);
    setSclUserName(data.sclUserName);
    setChargeMode(data.chargeMode);
    setDiscountValue(data.discount);

    setContaddress1(data.cadrLine1);
    if (data.addressChecked == "Y") setBilladdress1(data.cadrLine1);
    else setBilladdress1(data.cbAddressSer);

    setCreditLmt(data.availableCreditLimit);
    setCreditAlloted(data.allocatedCreditLimit);
    setCreditThreshold(data.creditLimitAlarmThreshold);
    setAcctBalThresold(data.accountBalanceAlarmThreshold);
    setCurrencyId(data.currency);
    setIsLateralEnabled(data.lateralTransferEnabled);
    setIsSingleSrcEnabled(exampleData.SINGLE_FUND_SOURCE_FLAG_VAL);
    setIsRechargeReversal(data.rechargeReversalsEnabled);
    setIsTransferReversal(data.transferReversalsEnabled);
    setFeeSet(data.feeSet);
    setFeeFundSource(data.feeFundSource);
    setBillingSysUserName(data.billingSystemUserName);
    setSaleforenable(data.salesForceEnabled);
    setSimtransenable(data.simTransactionsEnabled);
    setPartnerSimThreshold(data.simThreshold);

    setMultiNetTransEnabled(data.multiNetTransEnabled);
    setIsMultiNetEnabled(data.multiNetTransEnabled);
    setMultiNetRecEnabled(data.multiNetRecEnabled);
    setMultiLevelTransEnabled(data.multiLevTransEnable);
    setMultiLevelRecEnabled(data.multiLevRecEnable);

    setIsPrepaidDistributor(data.isPrePaidDistributor);
    setPartnerTypeDesc(data.userIdType);
    setStr(data.userIdType.split("#"));

    setIsCredit(data.isCreditEnabled);
    setRucNo(data.rucNumber);
    setSclCode(data.sclClientCode);
    setSclUserName(data.sclUserName);
    setChargeMode(data.chargeMode);
    setDiscountValue(data.discount);
    setPartnerFirstName(data.partnerFirstName);
    setPartnerLastName(data.partnerLastName);
    setEmailID(data.partnerEmailId);
    setPaymentType(data.formOfPayment);
    setCreditLmt(data.availableCreditLimit);
    setCreditAlloted(data.allocatedCreditLimit);
    setCreditThreshold(data.creditLimitAlarmThreshold);
    setAcctBalThresold(data.accountBalanceAlarmThreshold);
    setIsLateralEnabled(data.lateralTransferEnabled);
    setIsLatEnabled(data.lateralTransferEnabled);
  //  setIsSingleSrcEnabled(data.singleFundSourceHierarcy);
    setMultiNetTransEnabled(data.multiNetTransEnabled);
    setMultiNetRecEnabled(data.multiNetRecEnabled);
    setIsMultiNetRecEnabled(data.multiNetRecEnabled);
    setMultiLevelTransEnabled(data.multiLevTransEnable);
    setIsMultiLevelTransEnabled(data.multiLevTransEnable);
    setMultiLevelRecEnabled(data.multiLevRecEnable);
    setIsMultiLevelRecEnabled(data.multiLevRecEnable);
    setIsRechargeReversal(data.rechargeReversalsEnabled);
    setIsTransferReversal(data.transferReversalsEnabled);
    setPromTopUpList(data.promTopUpList);
    setBankReferenceNum(data.bankReferenceNumber);
    setBillingSysUserName(data.billingSystemUserName);
    setSaleforenable(data.salesForceEnabled);
    setSimtransenable(data.simTransactionsEnabled);
    setPartnerSimThreshold(data.simThreshold);
    setFeeSetList(data.feeSetList);
    setNegativeTransfers(data.negativeTransfers);
    setPartnerTypeId(data.partnerTypeId);
    setPartnerParentId(data.partnerParentId);
    setSelectedGeographicalLoc(
      data.region +
        "-->" +
        data.state +
        "-->" +
        data.municipality +
        "-->" +
        data.colony +
        "-->" +
        data.geoLocation
    );
    setLocationArray([data.region, data.state, data.municipality, data.colony, data.geoLocation ]);
    setContzipcode(data.czipCode);
    setLatitude(data.latitude);
    setLongitude(data.longitude);
    setIsChecked(data.addressChecked);
    setStatus(data.status);
    setLocationId(data.contAddressId + "_-_");
    setGl_code(data.gl_code);
    if (data.addressChecked == "Y") setBillzipcode(data.czipCode);
    else setBillzipcode(data.bzipCode);

    setPostalCheck(data.bzipCode);

    setMapInAdd(data.state + " " + data.municipality + " " + data.colony);
    //badrLine1
    //bzipCode
    //status

    console.log("feeSetList", data.feeSetList);

    console.log("response.data", response.data);
    let desc = data.userType;
    // alert("data.userType=="+data.userType);
    //alert(desc);
    setAndPartnerParentIdPresent(data.andPartnerParentIdPresent);
    setTransferFlagStatus(data.transferFlagStatus);
    setPmConfigStatusOut(data.pmConfigStatusOut);
    setPmConfigMultiStatus(data.pmConfigMultiStatus);
    setTransferFlag(data.transferFlag);
    setPartnerParentIdType(data.partnerParentIdType);
    setPartnerIdPmConfigStatus(data.partnerIdPmConfigStatus);
    setIsSalesEnb(data.isSalesEnb);
    setPmConfigMultiLevelStatus(data.pmConfigMultiLevelStatus);
    setFlagPmconfigstatus_RechargeRev(data.flagPmconfigstatus_RechargeRev);
    setFlagPmconfigstatus_TransferRev(data.flagPmconfigstatus_TransferRev);
    setPostToSCLEnableFlag(data.postToSCLEnableFlag);
    setPartnerParentIdPresent(data.partnerParentIdPresent);
    setUpdateComment(data.updateComment);
    setCreditThresholdFlag(data.creditThresholdFlag);
    setIsSimMgmtEnable(data.isSimMgmtEnable);
    setParentBankRefNumber(data.parentBankRefNumber);
    setProfileTypeId(data.profileTypeId);
    setPromGeoLocId(data.promGeoLocId + "_");
    setTempChargeMode(data.tempChargeMode);
    setIsMasterDistributorStr(data.isMasterDistributor);
    fetchChannels(data.promTopUpList);  //Channels Call
    setMaxFundLimit(data.maxFundLimit);
    if (data.addressChecked == "Y"){
      setIsChecked(true);}
      if(data.useOwnFundsEnabled == 'N')
      {
        setUseOwnFunds('N')
      }
  };

  const FinalSubmitSubmit = async () => {
    setIsProcessing(true);
    setRemoteAddress(exampleData.remoteAddress);
    const apiUrl1 = window.config.apiUrl + process.env.REACT_APP_MODIFY_API_URL;
    console.log(apiUrl1);
    const response1 = await axios.post(apiUrl1, {
      partnerType: partnerTypeId,
      userName,
      password,
      activeCurrencyPrecision,
      activeCurrencySymbol,
      localeVar,
      partnerId,
      parentLaternalFlagVal,
      parentMultiLevlFlagVal,
      parentMultiLevlRecFlagVal,
      parentIsSingleSrcFlagVal,
      rucNo,
      salesMDN,
      partnerCompanyName,
      partnerFirstName,
      partnerLastName,
      paymentType: "1",
      partnerTypeId,
      partnerParentId,
      partnerEffTime,
      partnerBgnDt,
      partnerEndDt,
      emailID,
      updateComment,
      addressId,
      location,
      locationDesc,
      isCredit,
      status,
      gl_code,
      commission,
      distRatings,
      rateDesc,
      creditLmt,
      creditAlloted,
      ratingId,
      maxFundLimit,
      saleforenable,
      simtransenable,
      partnerSimThreshold,
      sclCode,
      sclUserName,
      discountValue,
      chargeMode: tempChargeMode,
      isMasterDistributorStr,
      accountBal,
      promTopUpDesc,
      promTopUpList,
      isLateralEnabled,
      isLatEnabled,
      isRechargeReversal,
      isTransferReversal,
      isMultiNetEnabled,
      mulNetTransHierFlag,
      isMultiLevlEnabled:isMultiNetEnabled,
      isMultiNetRecEnabled,
      mulNetRecHierFlag,
      isMultiLevlRecEnabled:isMultiNetRecEnabled,
      isMultiLevlTransEnabled:isMultiLevelTransEnabled,
      isMultiLevelTransEnabled,
      mulLvlTransHierFlag,
      isMultiLevelRecEnabled,
      mulLvlRecHierFlag,
      isMultiLevlReceiveEnabled:isMultiLevelRecEnabled,
      negativeTransfers,
      feeSet,
      feeFundSource,
      isSingleSrcEnabled,
      useOwnFunds,
      profName,
      profId,
      profTypeId,
      partnerTypeDesc,
      partnerUserTypeDesc,
      creditThreshold,
      acctBalThresold,
      bankReferenceNum,
      billingSysUserName,
      billaddress1,
      contaddress1,
      billzipcode,
      contzipcode,
      addresschecking,
      province,
      city,
      postalCode,
      addressStr,
      latitude,
      longitude,
      mapCity,
      mapCounty,
      mapProvince,
      mapAddrChngeFlg,
      updateComment,
      addDistNChannel,
      profileTypeId,
      currencyId,
      parentCurrencyId,
      geoMarketName,
      geoRegionName,
      geoProvinceName,
      geoCityName,
      geoLocationName,
      commissionFlag,
      commissionTemplet,
      isPrePaid:isPrepaidDistributor,
      creditStDate,
      creditEdDate,
      latTransHierFlag,
      isSingleSrcFlagChanged,
      mulNetTransHierFlag,
      mulNetRecHierFlag,
      mulLvlTransHierFlag,
      mulLvlRecHierFlag,
      currecyChanged,
      notifSub,
      eventIDAl,
      otherDistributionListAl,
      childAlertSubscriptionAl,
      selfAlertAl,
      deliveryMethodAl,
      statusAl,
      jobFlag,
      jobFlagAL,
      denomTypeAL,
      denomIdAL,
      denomAssociationFlag,
      remoteAddress,
      fundReversalFlag,
      promGeoLocId,
      isFirstTime,
      creditLmt,
      creditAlloted,
      partnerLoginId: exampleData.LOGIN_ID,
    });
    console.log("Api Response===" + JSON.stringify(response1.data));
    if (response1.data.responseCode === "00") {
      localStorage.removeItem('channels');
      //localStorage.removeItem('denominations');
      setIsProcessing(false);
      let distId = partnerId;
      let pwdMsg = response1.data.responseDescription;
      navigate("/profile", { state: { distId, pwdMsg } });
    } else {
      setErrorMsg(response1.data.responseDescription);
      setPreview(false);
    }
  };

  const numvalidate = (e) => {
    const allowedKeys = [
      "Backspace",
      "ArrowLeft",
      "ArrowRight",
      "Tab",
      "Delete",
      "Enter",
      ".",
    ];
    const isNumberKey = (key) => /^[0-9]$/.test(key);
    const isDotKey = (key) => key === ".";
    const isControlKey = (e) => e.ctrlKey || e.metaKey;

    if (isControlKey(e)) return; // Allow ctrl+key combinations like ctrl+v

    if (allowedKeys.includes(e.key) || isNumberKey(e.key)) {
      // Allow numeric keys and the dot key
      return;
    } else {
      e.preventDefault(); // Prevent other keys
    }
  };

  function isCharsInBag(s, bag) {
    //alert("s-->"+s+"bag-->"+bag)
    var i;
    var c = "";

    for (i = 0; i < s.length; i++) {
      c = s.charAt(i);
      if (bag.indexOf(c) === -1) return 0;
    }
    return 1;
  }

  const handleCheckboxChange = (event) => {
    setIsChecked(event.target.checked);
    if (event.target.checked) {
      setBilladdress1(contaddress1);
      setBillzipcode(contzipcode);
    } else {
      setBilladdress1("");
      setBillzipcode("");
    }
  };

  // It Romoves White spaces at both ends of a given String
  function trim(value) {
    //alert("value-->"+value)
    var len = value.length;

    var i = 0;

    //Removes White spaces at Front end of the string

    for (i = 0; i < len; i++) {
      var c = value.charAt(i);

      if (c === " ") {
        value = value.substring(i + 1, len);

        i--;
      } else break;
    }

    var len2 = value.length;

    //Removes White spaces at Rear end of the string

    for (i = len2 - 1; i >= 0; i--) {
      var c2 = value.charAt(i);

      if (value.charAt(i) === " ") {
        value = value.substring(0, i);
      } else break;
    }
    return value;
  }

  /*
	function compareGeoStrings(loc1,loc2)
	{
		//var cBag='ABCDEFGHIJKLMNOPQRSTUVWXYZ'+'abcdefghijklmnopqrstuvwxyz'+' 0123456789';//here space also necissary for string comparisons
		//var cityHypenChk ='<bean:message bundle="pb" key="geo.cityPattern.hypenChk" />';
		loc1=trim(loc1.toUpperCase())+",";
		loc2=trim(loc2.toUpperCase())+",";
		//alert("loc1-->"+loc1+"\nloc2-->"+loc2);
	    var checkFlag = false;
	   /* var patt=/-/g;
	    if('Y'==trim(cityHypenChk).toUpperCase())
		{	
			if(patt.test(loc2))
			{
				if(loc2.indexOf(loc1)==-1)
					checkFlag=true;

				return checkFlag;
			}
		}
	if(loc1.length == loc2.length)
	 {
		for(i=0;i<loc1.length;i++)
		{
			if(cBag.indexOf(loc1.charAt(i)) == -1 || cBag.indexOf(loc2.charAt(i)) == -1 )
			{
				continue;

			}
			if(loc1.charAt(i) != loc2.charAt(i))
			{
				checkFlag=true;
				break;
			}
		}
	 }
	 else
	    checkFlag=true;*/
  /*    if(loc1.indexOf(loc2)==-1)
        checkFlag=true;
        
      return checkFlag;
    }
*/

  /*

	function googleMapGeoLocValidation()
	{
		if(document.forms[0].postalCode.value!=document.forms[0].contzipcode.value)
		{
			alert("<bean:message bundle="tb" key="6462" />");
			return 0;
		}
	}

  */

  function googleMapGeoLocValidation() {
    // alert("=====postalcheck==== "+postalcheck+"========contzipcode======"+contzipcode+"==============")
    if (postalcheck !== contzipcode) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("24246462"), {
            onClose: () => setToastShown(false)
        });
    }
      // alert(t("24246462"));
      return 0;
    }
      return 1;
  }

  function removeCharContains(amount, charToBeRemove) {
    let tempAmount = "";
    for (let index = 0; index < amount.length; index++) {
      const c = amount.charAt(index);
      if (c !== charToBeRemove) {
        tempAmount += c;
      }
    }
    return tempAmount;
  }

  const notescheckCount = (event, maxLimit) => {
    const value = event.target.value;
    if (value.length > maxLimit) {
      // Truncate the value to maxLimit
      event.target.value = value.substring(0, maxLimit);
      setContaddress1(event.target.value); // Update state with truncated value
    }
  };

  function checkingMail() {
    var mail = emailID;

    if (emailID === null || emailID.trim() === "") {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251683"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (
      isCharsInBag(
        mail,
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789@.,-"
      ) === 0
    ) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.indexOf("@") === -1) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.lastIndexOf("@") > mail.lastIndexOf(".") + 1) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.lastIndexOf("@") !== mail.indexOf("@")) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.indexOf(".") === -1) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.lastIndexOf(".") === mail.length - 1) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.indexOf("@") === mail.length - 1) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (
      mail.indexOf("@") === mail.indexOf(".") - 1 ||
      mail.indexOf(".") === mail.indexOf("@") - 1
    ) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else if (
      mail.indexOf("@") === 0 ||
      mail.indexOf(".") === 0 ||
      mail.indexOf(" ") > 0
    ) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251674"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].emailID.focus();
      return 0;
    } else {
      return 1;
    }
  }

  function onlyAlphaNumericValidate(event) {
    // Allow only alphanumeric characters, Enter, and Backspace key
    const allowedKeys = /^[a-zA-Z0-9]$/;
    const isAlphanumeric = allowedKeys.test(event.key);
    const isEnterKey = event.key === "Enter";
    const isBackspaceKey = event.key === "Backspace";

    if (!isAlphanumeric && !isEnterKey && !isBackspaceKey) {
      event.preventDefault(); // Prevent the key press if it's not allowed
    }
  }

  const handleBlur = (value, setValue) => {
    if (!amountValidation(value, setValue, 17, activeCurrencyPrecision)) {
      toast.error("Validation error");
    }
  };

  const amountValidation = (amount, setAmount, maxIntPart, maxDeciPart) => {
    if (amount == null || amount.length <= 0) {
      setAmount(formatDecimal("0", true, maxDeciPart));
      return true;
    } else if (isNaN(removeCharContains(amount, ","))) {
      setAmount(formatDecimal("0", true, maxDeciPart));
      return true;
    } else if (isCharsInBagValid(amount, " ") === 1) {
      setAmount("");
      // If you need to focus the input, you'll need to handle this separately in React
      return false;
    } else if (isCharsInBagValid(amount, "-0123456789 .,") === 0) {
      setAmount("");
      // If you need to focus the input, you'll need to handle this separately in React
      return false;
    } else if (!isCharsInBagValid(amount, "0.") === 0) {
      setAmount(formatDecimal("0", true, maxDeciPart));
      return true;
    } else {
      let tempAmount = "";
      let retAmt = "";

      tempAmount = removeCharContains(amount, ",");
      tempAmount = removeCharContains(tempAmount, " ");

      retAmt = formatDecimal(tempAmount, true, maxDeciPart);
      retAmt = retAmt + "";

      let inclValue;
      let decmlValue;
      let indexxx = retAmt.indexOf(".");
      if (indexxx !== -1) {
        inclValue = retAmt.substring(0, indexxx);
        decmlValue = retAmt.substring(indexxx + 1, retAmt.length);

        inclValue = setCommas(inclValue);

        setAmount(inclValue + "." + decmlValue);
      } else {
        inclValue = setCommas(retAmt);
        setAmount(inclValue);
      }

      return true;
    }
  };

  function setCommas(stringAmt) {
    let tempAmt = stringAmt;
    let commaAmt = tempAmt.substring(tempAmt.length - 3, tempAmt.length);

    let commaIndex = 3;
    for (let index = tempAmt.length - 4; index >= 0; index--) {
      const c = tempAmt.charAt(index);

      if (commaIndex === 3 && c !== "-") {
        commaAmt = c + "," + commaAmt;
        commaIndex = 1;
      } else {
        commaAmt = c + commaAmt;
        commaIndex++;
      }
    }

    if (commaAmt.charAt(0) === ",") {
      commaAmt = commaAmt.substring(1, commaAmt.length);
    }

    return commaAmt;
  }

  function formatDecimal(argvalue, addzero, decimaln) {
    const numOfDecimal = decimaln == null ? 2 : decimaln;

    if (argvalue.indexOf(".") !== -1)
      argvalue = decimalRound(argvalue, decimaln);

    argvalue = "" + argvalue;

    if (argvalue.indexOf(".") === 0) argvalue = "0" + argvalue;

    if (addzero === true) {
      if (argvalue.indexOf(".") === -1 && decimaln !== 0)
        argvalue = argvalue + ".";

      while (argvalue.indexOf(".") + 1 > argvalue.length - numOfDecimal)
        argvalue = argvalue + "0";
    }
    return argvalue;
  }

  function isCharsInBagValid(s, bag) {
    for (let i = 0; i < s.length; i++) {
      const c = s.charAt(i);
      if (bag.indexOf(c) === -1) return 0;
    }
    return 1;
  }

  function decimalRound(input, pre) {
    var number = 1;
    var output = "";

    number = Math.pow(10, pre);
    output = Math.round(parseFloat(input) * number) / number;

    return output;
  }

  const onlyNumberValidate = (e) => {
    // Allow only numeric keys, backspace, delete, tab, arrow keys, and enter key
    const allowedKeys = [
      "Backspace",
      "Tab",
      "ArrowLeft",
      "ArrowRight",
      "ArrowUp",
      "ArrowDown",
      "Delete",
      "Enter",
      "Home",
      "End",
    ];
    if (allowedKeys.indexOf(e.key) !== -1) {
      return; // Allow the keypress
    }
    // Prevent non-numeric key presses
    if (!/^\d$/.test(e.key)) {
      e.preventDefault();
    }
  };

  const modifyPartner = (e) => {
    //trimValues();
    var creditAlloted = "";
    var creditLmt = "";

    var bag =
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ. _$*@�";
    var alphaNumaric_bag =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.- '0123456789";
    var num_bag = "0123456789";
    var msgEntered = document.getElementById("updateComment").value;
    var trimmed = msgEntered.replace(/^\s+|\s+$/g, "");
    var pname_bags =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    e.preventDefault();

    if (validations()) {
      if (salesMDN !== null && isCharsInBag(salesMDN, num_bag) === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251666"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].salesMDN.focus();
        return false;
      }
      if (salesMDN.length > 0 && salesMDN.length < 10) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251695"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].salesMDN.focus();
        return;
      }

      if (creditAlloted.type === "text") {
        // creditAlloted = document.forms[0].creditAlloted.value;
        creditAlloted = removeCharContains(creditAlloted, ",");
        // creditLmt     = document.forms[0].creditLmt.value;
        creditLmt = parseFloat(creditLmt) + 0.0;
        creditAlloted = parseFloat(creditAlloted) + 0.0;
      }

      if (rucNo.trim().length < 1) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251696"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].rucNo.focus();
        return false;
      } else if (isCharsInBag(rucNo.trim(), pname_bags) === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251697"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].rucNo.focus();
        return false;
      }

      if (contaddress1.trim().length === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251667"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].contaddress1.focus();
        return false;
      } else if (contzipcode.trim().length === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251669"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].contzipcode.focus();
        return false;
      } else if (billaddress1.trim().length === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251670"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].billaddress1.focus();
        return false;
      } else if (billzipcode.trim().length === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251671"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].billzipcode.focus();
        return false;
      } else if (partnerFirstName.trim().length < 1) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251698"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].partnerFirstName.focus();
        return;
      } else if (partnerFirstName.trim().length === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251699"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].partnerFirstName.focus();
        //document.forms[0].partnerFirstName.value="";
        return;
      } else if (partnerLastName.trim().length < 1) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251700"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].partnerLastName.focus();
        return;
      } else if (partnerLastName.trim().length === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251701"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].partnerLastName.focus();
        document.forms[0].partnerLastName.value = "";
        return;
      } else if (trimmed === "") {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251702"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].updateComment.focus();
      } else if (checkingMail() === 0) {
        //do-nothing
      } else if (
        creditAlloted.type === "text" &&
        creditAlloted.trim().length === 0
      ) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251703"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].creditAlloted.focus();
        return;
      } else if (
        creditThreshold.trim() !== null &&
        creditThreshold.trim() !== null &&
        creditThreshold.trim() > 100
      ) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251704"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].creditThreshold.focus();
        return;
      } else if (updateComment.trim().length === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251705"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].updateComment.focus();
        return;
      } else if (updateComment.trim().length > 100) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251706"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].updateComment.focus();
        return;
      }

      // else  if(document.forms[0].promTopUpDesc.value.length == 0)
      // {
      //   alert("Select atleast one Replenishment Channels.");
      //   document.forms[0].promTopUpListChk.focus();
      //   return ;

      // }
      else if (
        sclCode.trim() !== null &&
        isCharsInBag(sclCode.trim(), num_bag) === 0
      ) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251666"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        document.forms[0].sclCode.focus();
        return;
      } else if (contaddress1.trim().length === 0) {
        if (!toastShown) {
          setToastShown(true);
          toast.error(t("251667"), {
              onClose: () => setToastShown(false) // Reset the state when the toast closes
          });
        }
        //document.forms[0].contaddress1.focus();
        //return ;
      }
     else if(channelTransAl.length<=0)
        {
          if (!toast.isActive(toastId.current))
            {    
              toastId.current =toast.error(t('24246079'));
           }
        }
         else {
        //  alert("Modify.......Page");
        FinalSubmitSubmit();

        // document.forms[0].pageAction.value='Modify';
        // document.forms[0].method="post";
        // //document.forms[0].action="alterPartner.jsp";
        // document.forms[0].action="/partner/profile.do?method=modifyProfile";
        // document.forms[0].submit();
      }
    }
  };

  function validations() {
    var mapAddrModifyChk = "yes"; //"<bean:message bundle="pb" key="geoRef.addrComprisionChk" />";
    var geoReferencingEnable = "YES"; //AttributeReader.getValue("appConfig","georeferencing.feature.enabled");
    //var geoReferencingMapValue="<bean:write name='geoReferencingMapValue'/>";
    var dummyPartnerParentId = partnerParentId; //document.forms[0].dummyPartnerParentId.value;
    var alphaNumaric_bag =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    if (contaddress1.trim().length === 0) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251667"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].contaddress1.focus();
      return false;
    } else if (contzipcode.trim().length === 0) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251669"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].contzipcode.focus();
      return false;
    } else if (billaddress1.trim().length === 0) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251670"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].billaddress1.focus();
      return false;
    } else if (billzipcode.trim().length === 0) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251671"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].billzipcode.focus();
      return false;
    } else if (
      dummyPartnerParentId.trim() === "No Parent" &&
      bankReferenceNum.trim().length === 0
    ) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251692"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].bankReferenceNum.focus();
      return false;
    } else if (
      dummyPartnerParentId.trim() === "No Parent" &&
      bankReferenceNum.trim().length !== 0 &&
      (bankReferenceNum.trim().length < 8 ||
        bankReferenceNum.trim().length > 18)
    ) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251693"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].bankReferenceNum.focus();
      return false;
    } else if (dummyPartnerParentId.trim() === "No Parent") {
      if (bankReferenceNum !== null) {
        var tempBSVal = bankReferenceNum.trim();
        if (isCharsInBag(tempBSVal, alphaNumaric_bag) === 0) {
          if (!toastShown) {
            setToastShown(true);
            toast.error(t("251692"), {
                onClose: () => setToastShown(false) // Reset the state when the toast closes
            });
          }
          document.forms[0].bankReferenceNum.focus();
          return false;
        }
      }
    }
    // else
    if (
      dummyPartnerParentId.trim() === "No Parent" &&
      isCharsInBag(billingSysUserName.trim(), alphaNumaric_bag) === 0
    ) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251694"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      document.forms[0].billingSysUserName.focus();
      return false;
    } else if (
      billaddress1.trim() !== contaddress1.trim() ||
      billzipcode.trim() !== contzipcode.trim()
    ) {
      if (!toastShown) {
        setToastShown(true);
        toast.error(t("251672"), {
            onClose: () => setToastShown(false) // Reset the state when the toast closes
        });
      }
      setIsChecked(false);
      return false;
    } else if (googleMapGeoLocValidation() == 0) {
      //need to change
      return false;
    } else return true;

    /*
    if(geoReferencingMapValue == 'NMAPS' || geoReferencingMapValue == 'LOCATIONWORLD')
      {
  
          if(geoReferencingEnable=='YES' && (document.forms[0].latitude.value.length == 0 || document.forms[0].longitude.value.length == 0))
          {  
            alert("<bean:message bundle="tb" key="6617" />");
            document.forms[0].latitude.focus();
        return false;
      }
        
        else if('YES'==trim(geoReferencingEnable).toUpperCase()&& 'YES'==trim(mapAddrModifyChk).toUpperCase())
      {
        var mapCounty=document.forms[0].mapCounty.value==null?"":document.forms[0].mapCounty.value;
  
        if('YES'==trim(document.forms[0].mapAddrChngeFlg.value).toUpperCase())
          {	//if((document.forms[0].mapCity.value==null || document.forms[0].mapCity.value.length == 0) && (document.forms[0].mapCounty.value==null || document.forms[0].mapCounty.value.length == 0) )
            if(document.forms[0].mapCity.value==null || document.forms[0].mapCity.value.length == 0) 
            {
              if((document.forms[0].mapProvince.value==null || document.forms[0].mapProvince.value.length == 0) && (document.forms[0].mapCounty.value==null || document.forms[0].mapCounty.value.length == 0))
              {
                  alert("<bean:message bundle="tb" key="6619" />");
                return false;
              }
              else
              {
                  alert("<bean:message bundle="tb" key="6605" />");
                return false;
              }
            }
            else if(document.forms[0].mapProvince.value==null || document.forms[0].mapProvince.value.length == 0)
            {
                alert("<bean:message bundle="tb" key="6625" />");							
              return false;
            }
            else if(compareGeoStrings(document.forms[0].province.value,document.forms[0].mapProvince.value))
            {
              if(compareGeoStrings(document.forms[0].city.value,document.forms[0].mapCity.value))
              {
                  alert("<bean:message bundle="tb" key="6620" />");								
                return false;
              }
              else
              {
                  alert("<bean:message bundle="tb" key="6622" />");								
                return false;
              }
            }
            else if(compareGeoStrings(document.forms[0].city.value,document.forms[0].mapCity.value))
            {
                alert("<bean:message bundle="tb" key="6621" />");
              return false;
            }					
            else
              return true;
        }
        else
          return true;
      }
      }else if( geoReferencingEnable=='YES' && geoReferencingMapValue=='GOOGLEMAPS' && googleMapGeoLocValidation()==0)	//need to change	
      {	
        
          return  false;
      }

*/
  }

  const getPaymentTypes = () => {
    for (let key in paymentType)
      return (
        <>
          <MenuItem value={key}>{paymentType[key]}</MenuItem>
        </>
      );
  };
  const [isHovered, setIsHovered] = useState(false);

  return (
    <table
      border={0}
      cellPadding={0}
      cellSpacing={0}
      id="inSideLayoutTable"
      height={600}
      width={1000}
      align="center"
    >
      <tbody>
        <Header />
        <tr height="65px">
          <PaymentManagerHeading />
          <TopMenu menuLink={localVar === "en" ? "Profile" : "Perfil"} />
        </tr>

        {/* </tr> */}

        <tr>
     <LeftBgImage />

          <td valign="top">
              <ToastContainer
                containerId="GlobalApplicationToast"
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                style={{
                  width: "fit-content",
                  minWidth: "300px",
                  minHeight: "100px",
                  fontSize: "18px",
                }}
              />
          <ProfileMenu menu="profileHighlight" />
          {isLoading && <><br /><div className={'spinnerDiv'}> {t("Processing...")}  <CircularProgress size="sm" /></div></>}

          {!isLoading && <>  <form onSubmit={modifyPartner} className={'accordion_sec distAccnt input_boxess rehargePreview '}>
              <table
                border={0}
                cellPadding={0}
                cellSpacing={0}
                style={{width:'100%'}}
                className="accordion_bloc"
              >
                <tbody>
                  <tr>
                    <td>
                      <table
                        border={0}
                        cellPadding={0}
                        cellSpacing={0}
                        width="100%"
                        height="100%"
                        align="center"
                        onload="keepFormFocussed()"
                      >
                        {/* MIDDLE ROW STARTS */}
                        <tbody>
                          {errorMsg != undefined && errorMsg.length > 0 ? (
                            <>
                              {errorMsg == "E-CL001" ? (
                                <>
                                  <tr>
                                    <td>&nbsp;</td>
                                  </tr>
                                  <tr>
                                    <td class="redTxt" align="center">
                                      {t("50342424")}
                                    </td>
                                  </tr>
                                </>
                              ) : (
                                <>
                                  {errorMsg == "NOTMODIFIED" ? (
                                    <>
                                      <tr>
                                        <td>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td class="redTxt" align="center">
                                          Failed to update {t("251643")}
                                        </td>
                                      </tr>
                                    </>
                                  ) : (
                                    <>
                                      {errorMsg == "E-CL002" ? (
                                        <>
                                          <tr>
                                            <td>&nbsp;</td>
                                          </tr>
                                          <tr>
                                            <td class="redTxt" align="center">
                                              {t("50352424")}
                                            </td>
                                          </tr>
                                        </>
                                      ) : (
                                        <>
                                          {errorMsg == "E-CL003" ? (
                                            <>
                                              <tr>
                                                <td>&nbsp;</td>
                                              </tr>
                                              <tr>
                                                <td
                                                  class="redTxt"
                                                  align="center"
                                                >
                                                  {t("50422424")}
                                                </td>
                                              </tr>
                                            </>
                                          ) : (
                                            <>
                                              {errorMsg == "RUC-" ? (
                                                <>
                                                  <tr>
                                                    <td>&nbsp;</td>
                                                  </tr>
                                                  <tr>
                                                    <td
                                                      class="redTxt"
                                                      align="center"
                                                    >
                                                      {errorMsg}
                                                    </td>
                                                  </tr>
                                                </>
                                              ) : (
                                                <></>
                                              )}
                                            </>
                                          )}
                                        </>
                                      )}
                                    </>
                                  )}
                                </>
                              )}
                            </>
                          ) : null}
                             <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel1-content"
                      id="panel1-header"
                    >
                      {t("1250")}
                    </AccordionSummary>
                    <AccordionDetails className={'general_accordion'}>
                      <Grid container>
                       <Grid xs={3} item>
                       <TextField
                            label={
                              <span>
                                {`${t('069')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!partnerId ? "---" : partnerId}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                       </Grid>
                       <Grid xs={3} item>
                       <TextField
                                                type="text"
                                                className="sampleInput mb5"
                                                size="12"
                                                label={
                                                  <span>
                                                    {`${t("251602")}`}
                                                  </span>
                                                }
                                                inputProps={{ maxLength: 10 }}
                                                name="salesMDN"
                                                onKeyDown={numvalidate}
                                                defaultValue=""
                                                value={salesMDN}
                                                onChange={(e) =>
                                                  setSalesMDN(e.target.value)
                                                }
                                              />
                        </Grid>
                        {isSelf === false ? (
                                                <>
                                                  <Grid xs={3} item>
                                                    <TextField
                                                      size="12"
                                                      type="text"
                                                      label={
                                                        <span>
                                                          {`${t("082")}`}
                                                        </span>
                                                      }
                                                      inputProps={{ maxLength: 65 }}
                                                      name="partnerCompanyName"
                                                      //defaultValue="sega"Parent company name
                                                      className="sampleInput mb5"
                                                      value={partnerCompanyName}
                                                      onChange={(e) =>
                                                        setPartnerCompanyName(
                                                          e.target.value
                                                        )
                                                      }
                                                    />
                                                  </Grid>
                                                </>
                                              ) : (
                                                <Grid xs={3} item>
                                                <TextField
                                                label={
                                                  <span>
                                                    {`${t('082')}`}
                                                  </span>
                                                }
                                                disabled
                                                InputLabelProps={{
                                                  shrink: true, // This will prevent label and value from overlapping
                                                }}
                                                size="15"
                                                className={"sampleInput mb5"}
                                                value={partnerCompanyName}
                                                type="text"
                                                autocomplete="off"
                                                id=""
                                              />
                                              </Grid>
                                              
                                              )}
                                               <Grid xs={3} item>
                        <TextField
                                                type="text"
                                                label={
                                                  <span>
                                                    {`${t("251646")}`}
                                                  </span>
                                                }
                                                className="sampleInput mb5"
                                                inputProps={{ maxLength: 25 }}
                                                name="rucNo"
                                                defaultValue=""
                                                onKeyDown={
                                                  onlyAlphaNumericValidate
                                                }
                                                value={rucNo}
                                                onChange={(e) =>
                                                  setRucNo(e.target.value)
                                                }
                                              />
                        </Grid>
                        <Grid xs={3} item>
                        <TextField
                                                type="text"
                                                label={
                                                  <span>
                                                    {partnerTypeId === "6"
                                                ? `${t("55212424")}`
                                                : `${t("251652")}`}
                                                  </span>
                                                }
                                                name="partnerFirstName"
                                                size="25"
                                                inputProps={{ maxLength: 90 }}
                                                defaultValue=""
                                                className="sampleInput mb5"
                                                value={partnerFirstName}
                                                onChange={(e) =>
                                                  setPartnerFirstName(
                                                    e.target.value
                                                  )
                                                }
                                              />
                        </Grid>
                        <Grid xs={3} item>
                        <TextField
                                                type="text"
                                                label={
                                                  <span>
                                                    {partnerTypeId === "6"
                                                ? `${t("55222424")}`
                                                : `${t("251653")}`}
                                                  </span>
                                                }
                                                name="partnerLastName"
                                                size="25"
                                                inputProps={{ maxLength: 90 }}
                                                defaultValue=""
                                                className="sampleInput mb5"
                                                value={partnerLastName}
                                                onChange={(e) =>
                                                  setPartnerLastName(
                                                    e.target.value
                                                  )
                                                }
                                              />
                        </Grid>
                        <Grid xs={3} item>
                        <TextField
                                                type="text"
                                                label={
                                                  <span>
                                                    {`${t('037')}`}
                                                  </span>
                                                }
                                                name="emailID"
                                                size="25"
                                                inputProps={{ maxLength: 99 }}
                                                defaultValue=""
                                                className="sampleInput mb5"
                                                value={emailID}
                                                onChange={(e) =>
                                                  setEmailID(e.target.value)
                                                }
                                              />
                        </Grid>
                        <Grid xs={3} item>
                                          <TextField
                            label={
                              <span>
                                {`${t('251655')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!gl_code.length>0 || gl_code=='0.00' ? "---" : gl_code}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                          </Grid>
                                       
                                                <Grid xs={3} item>
                                                {isSelf === false ? (
                                                <>
                                                    <FormControl
                                                     className={'selected_formcontrol'}
                                                      size="small"
                                                    >
                                                      <InputLabel id="demo-select-small-label">
                                                        {t('251645')}
                                                      </InputLabel>
                                                      <Select
                                                       
                                                        labelId="demo-select-small-label"
                                                        id="demo-select-small"
                                                        label={t("251645")}
                                                        name="partnerTypeDesc"
                                                        value={partnerTypeDesc}
                                                        onChange={(e) =>
                                                          setPartnerTypeDesc(
                                                            e.target.value
                                                          )
                                                        }
                                                        className="selected_dropdown"
                                                      >
                                                        {usertypes != undefined
                                                          ? usertypes.map(
                                                              (usertype) => (
                                                                <MenuItem
                                                                  key={
                                                                    usertype.id +
                                                                    "#" +
                                                                    usertype.value
                                                                  }
                                                                  value={
                                                                    usertype.id +
                                                                    "#" +
                                                                    usertype.value
                                                                  }
                                                                >
                                                                  {
                                                                    usertype.value
                                                                  }
                                                                </MenuItem>
                                                              )
                                                            )
                                                          : null}
                                                      </Select>
                                                    </FormControl>
                                                </>
                                              ) : (
                                                
                                                <TextField
                            label={
                              <span>
                                {`${t('251645')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={str[1]}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                              )}
                        </Grid>
                        <Grid xs={3} item>
                        <FormControl
                                                size="small"
                                                className={
                                                  "selected_formcontrol"
                                                }
                                              >
                                                <InputLabel id="demo-select-small-label">
                                                  {t('251654')}
                                                </InputLabel>
                                                <Select
                                                  labelId="demo-select-small-label"
                                                  id="demo-select-small"
                                                  label={t('251654')}
                                                  name="paymentType"
                                                  value={paymentTypeValue}
                                                  onChange={(e) =>
                                                    setPaymentTypeValue(
                                                      e.target.value
                                                    )
                                                  }
                                                  className={
                                                    "selected_dropdown"
                                                  }
                                                >
                                                  <MenuItem></MenuItem>
                                                  <MenuItem value="1">
                                                    {" "}
                                                    {t("111")}
                                                  </MenuItem>
                                                  {console.log(
                                                    "paymentType in select",
                                                    paymentType
                                                  )}
                                                  {/* {getPaymentTypes()} */}

                                                  {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                </Select>
                                              </FormControl>
                        </Grid>
                        <Grid xs={3} item>
                        <TextField
                            label={
                              <span>
                                {`${t('051')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={partnerParentId == "No Parent"
                              ? "---"
                              : partnerParentId}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                        </Grid>
                        
                       
                       
                        {postToSCLEnableFlag == "Y" && (
                                            <>
                                             
                                             <Grid xs={3} item>    
                                                  <TextField
                            label={
                              <span>
                                {`${t('063')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!sclCode ? "---" : sclCode}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                          </Grid>
                                            </>
                                          )}
                                           <Grid xs={3} item>
                                           <TextField
                            label={
                              <span>
                                {`${t('251620')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={currencyId}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                          </Grid>
                          {partnerParentIdPresent ==
                                            "NoParent" && (
                                            <>
                                              <Grid xs={3} item>
                                                  <TextField
                                                  
                            label={
                              <span>
                                {`${t('251660')}`}
                              </span>
                            }
                                                    type="text"
                                                    name="bankReferenceNum"
                                                    size="20"
                                                    inputProps={{ maxLength: 18 }}
                                                    className="sampleInput mb5"
                                                    defaultValue=""
                                                    value={bankReferenceNum}
                                                    onChange={(e) =>
                                                      setBankReferenceNum(
                                                        e.target.value
                                                      )
                                                    }
                                                  />
                                               </Grid>
                                            </>
                                          )}
{partnerParentIdPresent !=
                                            "NoParent" && (
                                            <>
                                              <Grid xs={3} item>
                                                  <TextField
                            label={
                              <span>
                                {`${t('251660')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={parentBankRefNumber}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                              </Grid>
                                            </>
                                          )}
                                          {partnerParentIdPresent !=
                                            "NoParent" && (
                                            <>
                                              <Grid xs={3} item>
                                                  <TextField
                            label={
                              <span>
                                {`${t('251635')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={billingSysUserName}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                                </Grid>
                                            </>
                                          )}
                          {partnerParentIdPresent ==
                                            "NoParent" && (
                                            <>
                                              <Grid xs={3} item>
                                                  <TextField
                                                    type="text"
                                                    
                            label={
                              <span>
                                {`${t('251635')}`}
                              </span>
                            }
                                                    name="billingSysUserName"
                                                    size="20"
                                                    inputProps={{ maxLength: 12 }}
                                                    className="sampleInput mb5"
                                                    defaultValue=" "
                                                    value={billingSysUserName}
                                                    onChange={(e) =>
                                                      setBillingSysUserName(
                                                        e.target.value
                                                      )
                                                    }
                                                  />
                                               </Grid>
                                            </>
                                          )}
                        {isSelf && (
                                            <>
                                           

                                              {postToSCLEnableFlag == "Y" && (
                                                <>
                                                  {partnerParentIdPresent ==
                                                    "NoParent" && (
                                                    <>
                                                  
                                                  <Grid xs={3} item>
                                                             <TextField
                            label={
                              <span>
                                {`${t('251603')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!sclUserName
                              ? "---"
                              : sclUserName}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                          </Grid>
                                                    </>
                                                  )}
                                                </>
                                              )}
                                              {partnerParentIdPresent ==
                                                "NoParent" && (
                                                <>
                                                  <Grid xs={3} item>
                                                       <TextField
                            label={
                              <span>
                                {`${t('251606')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!chargeMode
                              ? "---"
                              : chargeMode}
                            type="text"
                            autocomplete="off"
                            id=""
                          /></Grid>
                                                     
                                                </>
                                              )}
                                            </>
                                          )}
                       <Grid item xs={3}>
                       <TextField
                            label={
                              <span>
                                {`${t('251605')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!discountValue
                              ? "---"
                              : discountValue +'%'}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                       </Grid>
                        {partnerParentIdPresent ==
                                                    "NoParent" && (
                                            <>
                                             <Grid xs={3} item>
                                                  <TextField
                            label={
                              <span>
                                {`${t('251644')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={isPrepaidDistributor == "Y"
                              ? t("Y")
                              : isPrepaidDistributor ==
                                "N"
                              ? t("N")
                              : "---"}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                                  
                                                  </Grid>
                                            </>
                                          )}
                      
                        
                       
                       
                        
                        {andPartnerParentIdPresent=='NoParent'&&(<>
{isCredit=='Y'&&(<>

  <Grid xs={3} item>
                                               <TextField
                            label={
                              <span>
                                {`${t('251631')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={creditLmt}
                            type="text"
                            autocomplete="off"
                            id=""
                          /></Grid>
                          <Grid xs={3} item>
                                              <TextField
                            label={
                              <span>
                                {`${t('251630')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={creditAlloted}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                          </Grid>
                                          </>)}	
</>)}	
                      

                                          {partnerIdPmConfigStatus ==
                                            "Present" && (
                                            <>
                                              <input
                                                type="hidden"
                                                name="creditLmt"
                                                defaultValue={100.0}
                                              />
                                              <input
                                                type="hidden"
                                                name="creditAlloted"
                                                defaultValue={100}
                                              />
                                              <input
                                                type="hidden"
                                                name="creditThreshold"
                                                defaultValue={100}
                                              />
                                            </>
                                          )}
                                          {!isSelf && (
                                            <>
                                              {andPartnerParentIdPresent ==
                                                "Parent" && (
                                                <>
                                                  <Grid xs={3} item>
                                                      <FormControl
                                                        size="small"
                                                        className={
                                                          "selected_formcontrol"
                                                        }
                                                      >
                                                        <InputLabel id="demo-select-small-label">
                                                          {t('242457')}
                                                        </InputLabel>
                                                        <Select
                                                          labelId="demo-select-small-label"
                                                          id="demo-select-small"
                                                          label={t("242457")}
                                                          name="status"
                                                          value={status}
                                                          onChange={(e) =>
                                                            setStatus(
                                                              e.target.value
                                                            )
                                                          }
                                                          className={
                                                            "selected_dropdown"
                                                          }
                                                        >
                                                          <MenuItem value="Y">
                                                            {" "}
                                                            {t("242478")}
                                                          </MenuItem>
                                                          <MenuItem value="N">
                                                            {" "}
                                                            {t("242479")}
                                                          </MenuItem>

                                                          {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                        </Select>
                                                      </FormControl>
                                                    </Grid>
                                                    <Grid xs={3} item>
                                                  {status == "Y" && (
                                                    <>
                                                     
                                                          <Checkbox  
                                                            type="checkbox"
                                                            name="fundReversalFlag"
                                                            checked={
                                                              fundReversalFlag
                                                            }
                                                            onChange={() => {
                                                              doReverseFunds();
                                                            }} />
                                                          {t("49472424")}
                                                        
                                                    </>
                                                  )}
                                                  </Grid>
                                                </>
                                              )}
                                            </>
                                          )}
                                         
                      </Grid>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                    >
                                            {t("1248")}

                    </AccordionSummary>
                    <AccordionDetails className={'address_accordion'}>
                      <Grid container>
                    <Grid xs={3} item>
                    <LocationPopUp
                                                  handleSelectedGeographicalLoc={
                                                    handleSelectedGeographicalLoc
                                                  }
                                                />
                    </Grid>
                    <Grid item xs={12}>
                          
                          {/* <div style={{ display: 'block', color: 'black', padding: '0px' }}> */}
                          {selectedGeographicalLoc.length >
                              0 ?( <>
                                <span className={'labelText'} style={{ color: '#39f' }}> {t("242447")}</span> : <br/><br/>
  {locationArray.map((part, index) => (
       <TextField
       label={
         <span>
           {labelsArray[index] || `${t('default_label')}`} {/* Fallback label */}
         </span>
       }
       style={{ width: `${part.length + 10}ch`, marginRight: '5px' }} // Adjust width based on text length
       disabled
       InputLabelProps={{
         shrink: true, // Prevent label and value from overlapping
       }}
       size="15"
       className={"sampleInput mb5"}
       value={part}
       type="text"
       autoComplete="off"
       id=""
     />
  ))}</>)
  : <b style={{marginLeft:'30px'}}>---</b> }

                        </Grid>
                        </Grid>
                        <p className={'labelText'} style={{ color: '#39f', margin: "10px 0px 1px 0px", fontWeight:'bold', fontSize:'12px' }}> {t("242448")}</p>
                      <p className={'labelText'} style={{ color: '#39f', margin: "1px 0" }}> {t("242449")}</p>
                      <Grid container>
                      <Grid xs={3} item style={{ position: 'relative' }}>
                      <textarea
                            name="contaddress1"
                            className="textAreaSmall sampleInput mb5"
                            id="idContaddress1"
                            rows={4}
                            cols={40}
                            // maxLength={512}
                            inputProps={{ maxLength: 512 }}
                            maxrows={15}
                            maxcols={40}
                            onKeyDown={(e) =>
                              notescheckCount(
                                e,
                                512
                              )
                            }
                            onKeyUp={(e) =>
                              notescheckCount(
                                e,
                                512
                              )
                            }
                            defaultValue={""}
                            value={contaddress1}
                            onChange={(e) =>
                              setContaddress1(
                                e.target.value
                              )
                            }
                            nowrap
                          />
                          <GoogleMapPartner
                            setMapAddress={
                              setMapAddress
                            }
                            mapadd={mapInAdd}
                          />
                   </Grid>
                   <Grid item xs={9}>
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("2424501")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="latitude"
                            className="sampleInput  mb5"
                            defaultValue=""
                            id="cLatitude"
                            readOnly="true"
                            style={{ width: `${latitude.length + 150}px`, marginRight: '5px' }}
                            // maxLength={20}
                            inputProps={{ maxLength: 20 }}
                            value={latitude}
                            onChange={(e) =>
                              setLatitude(
                                e.target.value
                              )
                            }
                          />
                        {/* </Grid>
                        <Grid item xs={3}> */}
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("2424502")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="longitude"
                            className="sampleInput mb5"
                            defaultValue=""
                            id="cLongitude"
                            readOnly="true"
                            style={{ width: `${longitude.length + 150}px`, marginRight: '5px' }}
                            // maxLength={20}
                            inputProps={{ maxLength: 20 }}
                            value={longitude}
                            onChange={(e) =>
                              setLongitude(
                                e.target.value
                              )
                            }
                          />
                        {/* </Grid>
                        <Grid item xs={3}> */}
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("242451")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="contzipcode"
                            className="sampleInput mb5"
                            defaultValue=""
                            readOnly="true"
                            style={{ width: `${contzipcode.length + 100}px`, marginRight: '5px' }}
                            // maxLength={9}
                            inputProps={{ maxLength: 9 }}
                            id="idContzipcode"
                            value={contzipcode}
                            onChange={(e) =>
                              setContzipcode(
                                e.target.value
                              )
                            }
                          />
                        </Grid>
                        <Grid item xs={5} style={{ display: 'flex', alignItems: 'center',marginTop: '-7px', marginBottom:'12px' }}>
                          <span
                            width="40%"
                            className="labelText"
                            style={{fontSize:'10px'}}
                          >
                            {t("242452")}{" "}
                          </span>
                          <span
                            width="60%"
                            colSpan={2}
                            className="labelText"
                          >
                            {/* <input
                                                        type="checkbox"
                                                        name="addresschecking"
                                                        checked={isChecked}
                                                        onChange={
                                                          handleCheckboxChange
                                                        }
                                                      /> */}
                            <Checkbox name="addresschecking"
                              checked={isChecked}
                              onChange={
                                handleCheckboxChange
                              } />
                          </span>
                        </Grid>
                      </Grid>
                      <p className={'labelText'} style={{ color: '#39f', margin: '1px 0',  fontWeight:'bold', fontSize:'12px' }}> {t("242453")}</p>
                      <p className={'labelText'} style={{ color: '#39f', margin: "1px 0" }}> {t("242449")}</p>
                      <Grid container>
                        <Grid item xs={3}>
                     
                          <textarea
                            name="billaddress1"
                            className="textAreaSmall sampleInput  mb5 mb10"
                            id="idBilladdress1"
                            rows={4}
                            cols={40}
                            // maxLength={512}
                            inputProps={{ maxLength: 512 }}
                            maxrows={15}
                            maxcols={40}
                            onKeyDown={(e) =>
                              notescheckCount(
                                e,
                                512
                              )
                            }
                            onKeyUp={(e) =>
                              notescheckCount(
                                e,
                                512
                              )
                            }
                            defaultValue={""}
                            value={billaddress1}
                            onChange={(e) =>
                              setBilladdress1(
                                e.target.value
                              )
                            }
                          />
                          <font color="red">*</font>
                        </Grid>
                        <Grid item xs={3}>
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("242451")}`}
                              </span>
                            }
                            className="sampleInput mb5 mb10"
                            name="billzipcode"
                            defaultValue=""
                            // maxLength={9}
                            inputProps={{ maxLength: 9 }}
                            value={billzipcode}
                            onChange={(e) =>
                              setBillzipcode(
                                e.target.value
                              )
                            }
                          />
                        </Grid>
                       
                      </Grid>
                      
                    </AccordionDetails>
                  </Accordion>
                  <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel3-content"
                      id="panel3-header"
                    >
                    {t("1249")}

                    </AccordionSummary>
                    <AccordionDetails>
                      <Grid container>
                      {partnerParentIdPresent ===
                                          "NoParent" ? (
                                            <>
                                              <Grid xs={3} item>
                                                  <FormControl
                                                    size="small"
                                                    className={
                                                      "selected_formcontrol"
                                                    }
                                                  >
                                                    <InputLabel id="demo-select-small-label">
                                                      {t('251662')}
                                                    </InputLabel>
                                                    <Select
                                                      
                                                      labelId="demo-select-small-label"
                                                      id="demo-select-small"
                                                      label={t('251662')}
                                                      name="feeSet"
                                                      value={feeSet}
                                                      onChange={(e) =>
                                                        setFeeSet(
                                                          e.target.value
                                                        )
                                                      }
                                                      className={
                                                        "selected_dropdown"
                                                      }
                                                    >
                                                      {feeSetList.length > 0 &&
                                                        feeSetList.map(
                                                          (item) => {
                                                            return (
                                                              <MenuItem
                                                                value={
                                                                  item.feeSetId
                                                                }
                                                              >
                                                                {
                                                                  item.feeSetName
                                                                }
                                                              </MenuItem>
                                                            );
                                                          }
                                                        )}
                                                    </Select>
                                                  </FormControl>
                                                </Grid>
                                                <Grid xs={3} item>
                                                  <FormControl
                                                    size="small"
                                                    className={
                                                      "selected_formcontrol"
                                                    }
                                                  >
                                                    <InputLabel id="demo-select-small-label">
                                                      {t('251663')}
                                                    </InputLabel>
                                                    <Select
                                                     
                                                      labelId="demo-select-small-label"
                                                      id="demo-select-small"
                                                      label={t('251663')}
                                                      name="feeFundSource"
                                                      value={feeFundSource}
                                                      onChange={(e) =>
                                                        setFeeFundSource(
                                                          e.target.value
                                                        )
                                                      }
                                                      className={
                                                        "selected_dropdown"
                                                      }
                                                    >
                                                      <MenuItem value="S">
                                                        {t("2421455")}
                                                      </MenuItem>
                                                      <MenuItem value="M">
                                                        {t("2421456")}
                                                      </MenuItem>
                                                      {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                    </Select>
                                                  </FormControl>
                                               </Grid>
                                            </>
                                          ) : null}
                      
                      {!isSelf && (
                                            <>
                                              {isSingleSrcEnabled === "N" ? (
                                                <>
                                          <Grid xs={3} item>
                                                 
                                                       <FormControl

size="small"
className={
  "selected_formcontrol"
}
>
<InputLabel id="demo-select-small-label">
  {t('24246840')}
</InputLabel>
<Select
  labelId="demo-select-small-label"
  id="demo-select-small"
  label={t("24246840")}
  name="isLateralEnabled"
  value={
    useOwnFunds
  }
  onChange={handleUseOwnFundsChange}
  className={
    "selected_dropdown"
  }
>

  <MenuItem value="Y">
    {t('Y')}
  </MenuItem>
  <MenuItem value="N">
    {t('N')}
  </MenuItem>

  {/* <MenuItem value={30}>Thirty</MenuItem> */}
</Select>
</FormControl>
                                                 </Grid>
                                                </>
                                              ) : null}
                                            </>
                                          )}
                                          
                                          
                                            {isSimMgmtEnable == "Y" && (
                                            <>
                                              

                                                {isSelf ? (
                                                  <>
                                                    <Grid xs={3} item>
                                                      <TextField
                            label={
                              <span>
                                {`${t('251626')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={
                              saleforenable == "Y"
                                ? t("Y")
                                : t("N")
                            }
                            onChange={(e) =>
                              setSaleforenable(
                                e.target.value
                              )
                            }
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                                    </Grid>
                                                  </>
                                                ) : (
                                                  <Grid xs={3} item>
                                                    <FormControl
                                                      size="small"
                                                      className={
                                                        "selected_formcontrol"
                                                      }
                                                    >
                                                      <InputLabel id="demo-select-small-label">
                                                        {t('251626')}
                                                      </InputLabel>
                                                      <Select
                                                        
                                                        labelId="demo-select-small-label"
                                                        id="demo-select-small"
                                                        label={t("251626")}
                                                        name="negativeTransfers"
                                                        value={saleforenable}
                                                        onChange={(e) =>
                                                          setSaleforenable(
                                                            e.target.value
                                                          )
                                                        }
                                                        className={
                                                          "selected_dropdown"
                                                        }
                                                      >
                                                        <MenuItem value="Y">
                                                          {t("Y")}
                                                        </MenuItem>
                                                        <MenuItem value="N">
                                                          {t("N")}
                                                        </MenuItem>

                                                        {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                      </Select>
                                                    </FormControl>
                                                  </Grid>
                                                )}
                                              
                                            </>
                                          )}
                                         


                                            {partnerParentIdPresent ==
                                                    "NoParent"  && (
                                            <>
                                              <Grid xs={3} item>
                                                  <TextField
                            label={
                              <span>
                                {`${t('251636')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={isCredit == "Y"
                              ? t("Y")
                              : t("N")}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                                  
                                                  </Grid> 
                                            </>
                                          )}
                                            {andPartnerParentIdPresent ==
                                            "Parent" && (
                                            <>
                          <Grid xs={3} item>
                                            
                                                  <TextField
                                                    type="text"
                                                    label={
                                                      <span>
                                                        {`${t('242443')}`}
                                                      </span>
                                                    }
                                                    name="maxFundLimit"
                                                    size="10"
                                                    inputProps={{ maxLength: 10 }}
                                                    className="sampleInput mb5"
                                                    defaultValue=""
                                                    onBlur={() =>
                                                      handleBlur(
                                                        maxFundLimit,
                                                        setMaxFundLimit
                                                      )
                                                    }
                                                    onKeyDown={numvalidate}
                                                    value={numeral(maxFundLimit).format('0.00')}
                                                    onChange={(e) =>
                                                      setMaxFundLimit(
                                                        e.target.value
                                                      )
                                                    }
                                                  />
                                               </Grid>
                                            </>
                                          )}
                                          {partnerParentIdType != "Present" && (
                                            <>
                                              {creditThresholdFlag ==
                                                "Present" && (
                                                <>
                          <Grid xs={3} item>

                                                      <TextField
                                                         label={
                                                          <span>
                                                            {`${t('251632')}`}
                                                          </span>
                                                        }
                                                        type="text"
                                                        name="creditThreshold"
                                                        size="5"
                                                        inputProps={{ maxLength: 3 }}
                                                        className="sampleInput mb5"
                                                        defaultValue=""
                                                        value={creditThreshold}
                                                        onChange={(e) =>
                                                          setCreditThreshold(
                                                            e.target.value
                                                          )
                                                        }
                                                      />
                                                      </Grid>
                                                </>
                                              )}
                                            </>
                                          )}
                                          
                                         
                                            
                                            
                                            <Grid xs={3} item>
                                          <FormControl
                                                size="small"
                                                className={
                                                  "selected_formcontrol"
                                                }
                                              >
                                                <InputLabel id="demo-select-small-label">
                                                  {t('251661')}
                                                </InputLabel>
                                                <Select
                                                  
                                                  labelId="demo-select-small-label"
                                                  id="demo-select-small"
                                                  label={t('251661')}
                                                  name="negativeTransfers"
                                                  value={negativeTransfers}
                                                  onChange={(e) =>
                                                    setNegativeTransfers(
                                                      e.target.value
                                                    )
                                                  }
                                                  className={
                                                    "selected_dropdown"
                                                  }
                                                >
                                                  <MenuItem value="Y">
                                                    {t("Y")}
                                                  </MenuItem>
                                                  <MenuItem value="N">
                                                    {t("N")}
                                                  </MenuItem>

                                                  {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                </Select>
                                              </FormControl>
                                          </Grid>
                                            
                                          {isSimMgmtEnable == "Y" && (
                                            <>
                                              
                                                {isSelf ? (
                                                  <>
                                                     <Grid xs={3} item>
                                                      <TextField
                                                      disabled
                                                        type="text"
                                                        label={
                                                          <span>
                                                            {`${t('251627')}`}
                                                          </span>
                                                        }
                                                        defaultValue=""
                                                        readOnly="true"
                                                        value={
                                                          simtransenable == "Y"
                                                            ? t("Y")
                                                            : t("N")
                                                        }
                                                        onChange={(e) =>
                                                          setSimtransenable(
                                                            e.target.value
                                                          )
                                                        }
                                                        className="sampleInput mb5"
                                                      />
                                                    </Grid>
                                                  </>
                                                ) : (
                                                  <Grid xs={3} item>
                                                    <FormControl
                                                      size="small"
                                                      className={
                                                        "selected_formcontrol"
                                                      }
                                                    >
                                                      <InputLabel id="demo-select-small-label">
                                                        {t('251627')}
                                                      </InputLabel>
                                                      <Select
                                                        labelId="demo-select-small-label"
                                                        id="demo-select-small"
                                                        label={t("251627")}
                                                        name="negativeTransfers"
                                                        value={simtransenable}
                                                        onChange={(e) =>
                                                          setSimtransenable(
                                                            e.target.value
                                                          )
                                                        }
                                                        className={
                                                          "selected_dropdown"
                                                        }
                                                      >
                                                        <MenuItem value="Y">
                                                          {t("Y")}
                                                        </MenuItem>
                                                        <MenuItem value="N">
                                                          {t("N")}
                                                        </MenuItem>

                                                        {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                      </Select>
                                                    </FormControl>
                                                  </Grid>
                                                )}
                                             
                                            </>
                                          )}
                                          
                                          <Grid xs={3} item>
                                          <TextField
                                                label={
                                                  <span>
                                                    {`${t('251634')}`}
                                                  </span>
                                                }
                                                type="text"
                                                name="acctBalThresold"
                                                size="20"
                                                inputProps={{ maxLength: 15 }}
                                                className="sampleInput mb5"
                                                defaultValue=""
                                                onBlur={() =>
                                                  handleBlur(
                                                    acctBalThresold,
                                                    setAcctBalThresold
                                                  )
                                                }
                                                onKeyDown={numvalidate}
                                                value={acctBalThresold}
                                                onChange={(e) =>
                                                  setAcctBalThresold(
                                                    e.target.value
                                                  )
                                                }
                                              />
                                          </Grid>
                                          
{isSimMgmtEnable == "Y" && (
                                            <>
                                               <Grid xs={3} item>
                                                  <TextField
                                                  
                            label={
                              <span>
                                {`${t('251628')}`}
                              </span>
                            }
                                                    type="text"
                                                    className="sampleInput mb5"
                                                    inputProps={{ maxLength: 25 }}
                                                    name="partnerSimThreshold"
                                                    defaultValue=""
                                                    onKeyDown={
                                                      onlyNumberValidate
                                                    }
                                                    value={partnerSimThreshold}
                                                    onChange={(e) =>
                                                      setPartnerSimThreshold(
                                                        e.target.value
                                                      )
                                                    }
                                                  />
                                               </Grid>
                                            </>
                                          )}


                                          {pmConfigStatusOut == "True" && (
                                            <>
                                           <Grid xs={3} item>
                                                 
                                                     <TextField
                            label={
                              <span>
                                {`${t('251619')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value= {isSingleSrcEnabled == "Y"
                              ? t("Y")
                              : t("N")}
                            type="text"
                            autocomplete="off"
                            id=""
                          /></Grid>
                                            </>
                                          )}
                                          {flagPmconfigstatus_RechargeRev && (
                                            <>
                                              <Grid xs={3} item>
                                                  
                                                     <TextField
                            label={
                              <span>
                                {`${t('251624')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={isRechargeReversal == "Y"
                              ? t("Y")
                              : t("N")}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                                 </Grid>
                                            </>
                                          )}
{flagPmconfigstatus_TransferRev && (
                                            <>
                                              <Grid xs={3} item>
                                                  
                                                     <TextField
                            label={
                              <span>
                                {`${t('251625')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={isTransferReversal == "Y"
                              ? t("Y")
                              : t("N")}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                                 </Grid>
                                            </>
                                          )}
                                          </Grid>
                                          <Grid container>
                                          
                                          {isSelf ? (
                                             <Grid xs={3} item>
                                                
                                                   <TextField
                            label={
                              <span>
                                {`${t('251615')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={isMultiNetEnabled == "Y"
                              ? t("Y")
                              : t("N")}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                              </Grid>
                                            ) : (
                                              <>
                                                {transferFlagStatus == "Y" && (
                                                  <>
                                                    <Grid xs={3} item>
                                                    <div className={partnerTypeId === "5" ? "multiLevel" : "multilevel20"}>
                                                      <FormControl
                                                        size="small"
                                                        className={
                                                          "selected_formcontrol"
                                                        }
                                                        style={{marginBottom:'0'}}
                                                      >
                                                        <InputLabel id="demo-select-small-label">
                                                          {t('251615')}
                                                        </InputLabel>
                                                        <Select
                                                        
                                                          labelId="demo-select-small-label"
                                                          id="demo-select-small"
                                                          label={t("251615")}
                                                          name="negativeTransfers"
                                                          value={
                                                            isMultiNetEnabled
                                                          }
                                                          onChange={(e) =>
                                                            setIsMultiNetEnabled(
                                                              e.target.value
                                                            )
                                                          }
                                                          className={
                                                            "selected_dropdown"
                                                          }
                                                        >
                                                          <MenuItem value="Y">
                                                            {t("Y")}
                                                          </MenuItem>
                                                          <MenuItem value="N">
                                                            {t("N")}
                                                          </MenuItem>

                                                          {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                        </Select>
                                                      </FormControl>
                                                    <br></br>
                                                      {partnerTypeId === "5" ? (
                                                        <div>
                                                          <Checkbox
                                                            type="checkbox"
                                                            checked={
                                                              mulNetTransHierFlag
                                                            }
                                                            style={{padding:'5px'}}
                                                            onChange={() => {
                                                              setMulNetTransHierFlag(
                                                                checkboxChange(
                                                                  mulNetTransHierFlag
                                                                )
                                                              );
                                                            }}
                                                          />
                                                          <font color="#39f"
                                                          >
                                                            {t("56372424")}
                                                          </font>{" "}
                                                        </div>
                                                      ) : null}
                                                      </div>
                                                   </Grid>
                                                  </>
                                                )}
                                              </>
                                            )}
{isSelf ? (
                                            <Grid xs={3} item>
                                                   <TextField
                            label={
                              <span>
                                {`${t('251616')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={isMultiNetRecEnabled == "Y"
                              ? t("Y")
                              : t("N")}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                              </Grid>
                                            ) : (
                                              <>
                                                {transferFlagStatus == "Y" && (
                                                  <>
                                                    <Grid xs={3} item>
                                                    <div className={partnerTypeId === "5" ? "multiLevel" : "multilevel20"}>
                                                      <FormControl
                                                        size="small"
                                                        className={
                                                          "selected_formcontrol"
                                                        }
                                                        style={{marginBottom:'0px'}}
                                                      >
                                                        <InputLabel id="demo-select-small-label">
                                                          {t('251616')}
                                                        </InputLabel>
                                                        <Select
                                                          labelId="demo-select-small-label"
                                                          id="demo-select-small"
                                                          label={t("251616")}
                                                          name="negativeTransfers"
                                                          value={
                                                            isMultiNetRecEnabled
                                                          }
                                                          onChange={(e) =>
                                                            setIsMultiNetRecEnabled(
                                                              e.target.value
                                                            )
                                                          }
                                                          className={
                                                            "selected_dropdown"
                                                          }
                                                        >
                                                          <MenuItem value="Y">
                                                            {t("Y")}
                                                          </MenuItem>
                                                          <MenuItem value="N">
                                                            {t("N")}
                                                          </MenuItem>

                                                          {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                        </Select>
                                                      </FormControl>
                                                     <br/>
                                                      {partnerTypeId === "5" ? (
                                                         <div>
                                                          <Checkbox
                                                            type="checkbox"
                                                            checked={
                                                              mulNetRecHierFlag
                                                            }
                                                            style={{padding:'5px'}}
                                                            onChange={() => {
                                                              setMulNetRecHierFlag(
                                                                checkboxChange(
                                                                  mulNetRecHierFlag
                                                                )
                                                              );
                                                            }}
                                                          />
                                                          <font color="#39f">
                                                            {t("56372424")}
                                                          </font>{" "}
                                                        </div>
                                                      ) : null}
                                                      </div>
                                                    </Grid>
                                                  </>
                                                )}
                                              </>
                                            )}
{isSelf ? (
                                              
                                              <Grid xs={3} item>
                                                    
                                                     <TextField
                                label={
                                  <span>
                                    {`${t('251622')}`}
                                  </span>
                                }
                                disabled
                                InputLabelProps={{
                                  shrink: true, // This will prevent label and value from overlapping
                                }}
                                size="15"
                                className={"sampleInput mb5"}
                                value={isLatEnabled == "Y"
                                  ? t("Y")
                                  : t("N")}
                                type="text"
                                autocomplete="off"
                                id=""
                              />
                                                  </Grid>
                                                ) : (
                                                  <>
                                                    {transferFlagStatus == "Y" && (
                                                      <>
                                                       <Grid xs={3} item>
                                                      <div className={partnerTypeId === "5" ? "multiLevel" : "multilevel20"}>
                                                          <FormControl
                                                            size="small"
                                                            className={
                                                              "selected_formcontrol"
                                                            }
                                                            style={{marginBottom:'0px'}}
                                                          >
                                                            <InputLabel id="demo-select-small-label">
                                                              {t('251622')}
                                                            </InputLabel>
                                                            <Select
                                                              labelId="demo-select-small-label"
                                                              id="demo-select-small"
                                                              label={t("251622")}
                                                              name="negativeTransfers"
                                                              value={isLatEnabled}
                                                              onChange={(e) =>
                                                                setIsLatEnabled(
                                                                  e.target.value
                                                                )
                                                              }
                                                              className={
                                                                "selected_dropdown"
                                                              }
                                                            >
                                                              <MenuItem value="Y">
                                                                {t("Y")}
                                                              </MenuItem>
                                                              <MenuItem value="N">
                                                                {t("N")}
                                                              </MenuItem>
    
                                                              {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                            </Select>
                                                          </FormControl><br/>
                                                          {partnerTypeId === "5" ? (
                                                            <div>
                                                       
    
                                                              <Checkbox
                                                                type="checkbox"
                                                                checked={
                                                                  latTransHierFlag
                                                                }
                                                                style={{padding:'5px'}}
                                                                onChange={() => {
                                                                  setLatTransHierFlag(
                                                                    checkboxChange(
                                                                      latTransHierFlag
                                                                    )
                                                                  );
                                                                }}
                                                              />
                                                              <font color="#39f"
                                                              >
                                                                {t("56372424")}
                                                              </font>
                                                            </div>
                                                          ) : null}
                                                          </div>
                                                          </Grid>
                                                      </>
                                                    )}
                                                  </>
                                                )}
{isSelf ? (
                                              <Grid xs={3} item>
                                                
                                                   <TextField
                            label={
                              <span>
                                {`${t('251617')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={isMultiLevelTransEnabled == "Y"
                              ? t("Y")
                              : t("N")}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                              </Grid>
                                            ) : (
                                              <>
                                                {transferFlagStatus == "Y" && (
                                                  <>
                                                   <Grid xs={3} item>
                                                   <div className={partnerTypeId === "5" ? "multiLevel" : "multilevel20"}>
                                                      <FormControl
                                                        size="small"
                                                        className={
                                                          "selected_formcontrol"
                                                        }
                                                        style={{marginBottom:'0px'}}
                                                      >
                                                        <InputLabel id="demo-select-small-label">
                                                          {t('251617')}
                                                        </InputLabel>
                                                        <Select
                                        
                                                          labelId="demo-select-small-label"
                                                          id="demo-select-small"
                                                          label={t("251617")}
                                                          name="negativeTransfers"
                                                          value={
                                                            isMultiLevelTransEnabled
                                                          }
                                                          onChange={(e) =>
                                                            setIsMultiLevelTransEnabled(
                                                              e.target.value
                                                            )
                                                          }
                                                          className={
                                                            "selected_dropdown"
                                                          }
                                                        >
                                                          <MenuItem value="Y">
                                                            {t("Y")}
                                                          </MenuItem>
                                                          <MenuItem value="N">
                                                            {t("N")}
                                                          </MenuItem>

                                                          {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                        </Select>
                                                      </FormControl>
                                                      <br />
                                                      {partnerTypeId === "5" ? (
                                                         <div>
                                                          <Checkbox
                                                            type="checkbox"
                                                            checked={
                                                              mulLvlTransHierFlag
                                                            }
                                                            style={{padding:'5px'}}
                                                            onChange={() => {
                                                              setMulLvlTransHierFlag(
                                                                checkboxChange(
                                                                  mulLvlTransHierFlag
                                                                )
                                                              );
                                                            }}
                                                          />
                                                          <font color="#39f">
                                                            {t("56372424")}
                                                          </font>{" "}
                                                        </div>
                                                      ) : null}
                                                      </div>
                                                    </Grid>
                                                  </>
                                                )}
                                              </>
                                            )}
{isSelf ? (
                                              <Grid xs={3} item>
                                                
                                                   <TextField
                            label={
                              <span>
                                {`${t('251618')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={isMultiLevelRecEnabled == "Y"
                              ? t("Y")
                              : t("N")}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
                                                </Grid>
                                            ) : (
                                              <>
                                                {transferFlagStatus == "Y" && (
                                                  <>
                                                    <Grid xs={3} item>
                                                      <div className={partnerTypeId === "5" ? "multiLevel" : "multilevel20"}>
                                                      <FormControl
                                                        size="small"
                                                       className={
                                                          "selected_formcontrol"}
                                                          style={{marginBottom:'0px'}}
                                                      >
                                                        <InputLabel id="demo-select-small-label">
                                                          {t('251618')}
                                                        </InputLabel>
                                                        <Select
                                                         
                                                          labelId="demo-select-small-label"
                                                          id="demo-select-small"
                                                          label={t("251618")}
                                                          name="negativeTransfers"
                                                          value={
                                                            isMultiLevelRecEnabled
                                                          }
                                                          onChange={(e) =>
                                                            setIsMultiLevelRecEnabled(
                                                              e.target.value
                                                            )
                                                          }
                                                          className={
                                                            "selected_dropdown"
                                                          }
                                                        >
                                                          <MenuItem value="Y">
                                                            {t("Y")}
                                                          </MenuItem>
                                                          <MenuItem value="N">
                                                            {t("N")}
                                                          </MenuItem>

                                                          {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                        </Select>
                                                      </FormControl>
                                                     <br />
                                                      {partnerTypeId === "5" ? (
                                                         <div>
                                                          <Checkbox
                                                            type="checkbox"
                                                            checked={
                                                              mulLvlRecHierFlag
                                                            }
                                                            style={{padding:'5px'}}
                                                            onChange={() => {
                                                              setMulLvlRecHierFlag(
                                                                checkboxChange(
                                                                  mulLvlRecHierFlag
                                                                )
                                                              );
                                                            }}
                                                          />
                                                          <font color="#39f">
                                                            {t("56372424")}
                                                          </font>{" "}
                                                        </div>
                                                      ) : null}
                                                      </div>
                                                    </Grid>
                                                  </>
                                                )}
                                              </>
                                            )}
                                         
                                          
                                           
                                          </Grid>
                                          <p className={'labelText'} style={{ color: '#39f', margin: "1px 0" }}> {t("251659")}</p>

                                          <Grid container>
                                          
                                         
                                          
                                           <Grid xs={3} item style={{marginBottom:'20px'}}>

                                          <textarea
                                                className="textAreaSmall sampleInput"
                                                id="updateComment"
                                                maxLength={99}
                                                name="updateComment"
                                                size={30}
                                                rows={5}
                                                cols={25}
                                                maxrows={25}
                                                maxcols={25}
                                                onkeypress="return ismaxlength(this)"
                                                defaultValue=""
                                                value={updateComment}
                                                onChange={(e) =>
                                                  setUpdateComment(
                                                    e.target.value
                                                  )
                                                }
                                                // style={{width:'220px'}}
                                              />
                                              <br />
                                              <font color="red">
                                                {t("121212121")}
                                              </font>
                                          </Grid>
                                         
                                           {!isSelf && (
                                            <>
                                              <Grid xs={3} item>

                                                <SalesPersonPopup
                                                  setChannelsAssociation={
                                                    setChannelsAssociation
                                                  }
                                                />
                                               
                                                    <div
      className="parent-div"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{ marginBottom: '10px' }}
    >
      <span
        style={{ color: "#000", cursor: "pointer" }}
       
      >
        <ArrowRight className="animated-arrow" style={{ color: "#39f" }} /> 
        {t("1253")}
      </span>
      <div className={`scroll-list ${isHovered ? 'show' : ''}`} 
      // style={{ maxHeight: isHovered ? channelTransAl.length * 30 + 'px' : '0', transition: 'max-height 0.5s ease-in-out', overflow: 'hidden' }}
      style={{
        maxHeight: channelTransAl.length > 10
          ? '450px'  // Set a fixed max height for scrolling
          : isHovered 
          ? channelTransAl.length * 30 + 'px' 
          : '0',
        transition: 'max-height 0.5s ease-in-out',
        overflow: channelTransAl.length > 10 ? 'auto' : 'hidden'
      }}
      >
      {channelsSelectFlag ? (
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0' }}>
      <li className="smallerTxt"
        style={{
          color: "#000",
          fontFamily: "Arial, helvetica, sans-serif",
          fontSize: "12px",
          padding: '10px'
        }}>
        {t("245678")}
      </li>
    </ul>
  ) : channelTransAl.length > 0 ? (
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0' }}>
      {chunkedData.map((chunk, rowIndex) =>
        chunk.map((cellData, cellIndex) => (
          <li className="smallerTxt" key={cellIndex}>
            {cellData.topupTypeDesc + " - " + cellData.transCategory}
          </li>
        ))
      )}
    </ul>
  ) : (
    // Fallback for when channelsSelectFlag is false and no data in channelTransAl
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0', marginTop: '-18px' }}>
    <li className="smallerTxt"
      style={{
        color: "#000",
        fontFamily: "Arial, helvetica, sans-serif",
        fontSize: "12px",
        padding: '10px'
      }}>
      {t("1251")}
    </li>
    </ul>
  )}
      </div>
    </div>
                                              </Grid>
                                            </>
                                          )}
                                          {isSelf && (
                                            <>
                                             <Grid xs={3} item>
                                                  
                                                    <div
      className="parent-div"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{ marginBottom: '10px' }}
    >
      <span
        style={{ color: "#000", cursor: "pointer" }}
       
      >
        <ArrowRight className="animated-arrow" style={{ color: "#39f" }} /> 
       {t("1253")}
      </span>
      <div className={`scroll-list ${isHovered ? 'show' : ''}`} 
      // style={{ maxHeight: isHovered ? channelTransAl.length * 30 + 'px' : '0', transition: 'max-height 0.5s ease-in-out', overflow: 'hidden' }}
      style={{
        maxHeight: channelTransAl.length > 10
          ? '450px'  // Set a fixed max height for scrolling
          : isHovered 
          ? channelTransAl.length * 30 + 'px' 
          : '0',
        transition: 'max-height 0.5s ease-in-out',
        overflow: channelTransAl.length > 10 ? 'auto' : 'hidden'
      }}
      >
      {channelsSelectFlag ? (
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0' }}>
      <li className="smallerTxt"
        style={{
          color: "#000",
          fontFamily: "Arial, helvetica, sans-serif",
          fontSize: "12px",
          padding: '10px'
        }}>
        {t("245678")}
      </li>
    </ul>
  ) : channelTransAl.length > 0 ? (
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0' }}>
      {chunkedData.map((chunk, rowIndex) =>
        chunk.map((cellData, cellIndex) => (
          <li className="smallerTxt" key={cellIndex}>
            {cellData.topupTypeDesc + " - " + cellData.transCategory}
          </li>
        ))
      )}
    </ul>
  ) : (
    // Fallback for when channelsSelectFlag is false and no data in channelTransAl
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0', marginTop: '-18px' }}>
    <li className="smallerTxt"
      style={{
        color: "#000",
        fontFamily: "Arial, helvetica, sans-serif",
        fontSize: "12px",
        padding: '10px'
      }}>
      {t("1251")}
    </li>
    </ul>
  )}
      </div>
    </div>
                                               </Grid>
                                            </>
                                          )}
                                          <Grid xs={3} item>
                                          <DenominationsAssociationPopUp />
                                          </Grid>
                                          <Grid xs={3} item>
                                          <ConfigurationNotificationPopup
                                                setnotificationListObj={
                                                  setnotificationListObj
                                                }
                                                configId={configId}
                                                triggerFetch={true}
                                              />
                                          </Grid>
                      </Grid>
                    </AccordionDetails>
                  </Accordion>
                  <div className={'displayFlexCenter'} style={{ marginBottom: '10px', gap:'8px' }}>
                  {!isProcessing ? (
                                                <>
                                                  <Button
                                                    type="submit"
                                                    id="submitImg"
                                                    className={
                                                      "hoverEffectButton"
                                                    }
                                                    size="small"
                                                    variant="contained"
                                                    endIcon={<AddCardRounded />}
                                                  >
                                                    {t("11")}
                                                  </Button>
                                                </>
                                              ) : (
                                                <>
                                                  <Button
                                                    className={
                                                      "hoverEffectButton"
                                                    }
                                                    size="small"
                                                    variant="contained"
                                                  >
                                                    {t("2424444")}
                                                  </Button>
                                                </>
                                              )}
                                              <Button
                                                onClick={() => {
                                                  handleReturn();
                                                }}
                                                className={"hoverEffectButton"}
                                                size="small"
                                                variant="contained"
                                                endIcon={<KeyboardReturn />}
                                              >
                                                {t("013")}
                                              </Button>
                                              </div>
                        
                          {/* MIDDLE ROW ENDS */}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
              <input
                type="hidden"
                name="OWASP_CSRFTOKEN"
                defaultValue="PmON1qWUZe7XztBUMmkuLA2TF8kxvbkfYQ6kQsC9dic="
              />
            </form></>}
          </td>
        </tr>
        <tr height="60px">
          <td colSpan={2}>
            <Footer />
          </td>
        </tr>
      </tbody>
    </table>
  );
}

export default ModifyProfile;
