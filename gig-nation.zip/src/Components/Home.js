import React, { useState, useEffect } from 'react';
import TopMenu from './TopMenu';
import { useTranslation } from 'react-i18next';
import { Footer, Header, LeftBgImage, PaymentManagerHeading } from './PageComponents';
import i18n from './i18n';
import { Box, Grid, Tab, Tabs } from '@mui/material';
import { NavLink,Navigate } from 'react-router-dom';
import { CalendarMonth, CalendarToday, CallMade, PendingActions, PieChart, Today } from '@mui/icons-material';
import numeral from 'numeral';
import PieChartIcon from '@mui/icons-material/PieChart';


export default function Home() {
  const [summaryData, setSummaryData]=useState([]);
  const [summaryDay, setSummaryDay]=useState("");
  const [summaryWeek, setSummaryWeek]=useState("");
  const [summaryMonth, setSummaryMonth]=useState("");
  const [summaryQuater, setSummaryQuater]=useState("");
  const [transactionData, setTransactionData]=useState([]);
  const [transactionType, setTransactionType] = useState("R");
const [summaryType, setSummaryType] = useState("N");

  sessionStorage.setItem("selectedIndex", 0);
  sessionStorage.setItem("selectedLink", "a_homepage");
  const { t } = useTranslation();
  const localVar = i18n.language;
  console.log("llll=" + i18n);
  const [data, setData] = useState(() => {
    // Try to get initial state from sessionStorage
    const savedData = sessionStorage.getItem('homePageData');
    return savedData ? JSON.parse(savedData) : null;
  });


  // useEffect(() => {
  //   // Set the browser title
  //   // document.title = "HomePage";
  //   document.title = t('2472_005');
  // }, []);

  useEffect(() => {
    document.title = t('2472_005');
  }, [t]);

  // Populate summary data locally instead of via API
  useEffect(() => {
    // Example static summary data for demo/offline mode
    const summaryConfigArray = [
      { PERIOD: t('Today'), AMOUNT: '100.00' },
      { PERIOD: t('Yesterday'), AMOUNT: '80.00' },
      { PERIOD: t('This Week'), AMOUNT: '500.00' },
      { PERIOD: t('Last Week'), AMOUNT: '450.00' },
      { PERIOD: t('This Month'), AMOUNT: '2000.00' },
      { PERIOD: t('Last Month'), AMOUNT: '1800.00' },
      { PERIOD: t('This Quarter'), AMOUNT: '6000.00' },
      { PERIOD: t('Last Quarter'), AMOUNT: '5500.00' },
    ];

    setSummaryData(summaryConfigArray);
    setSummaryDay([summaryConfigArray?.[0] || {}, summaryConfigArray?.[1] || {}]);
    setSummaryWeek([summaryConfigArray?.[2] || {}, summaryConfigArray?.[3] || {}]);
    setSummaryMonth([summaryConfigArray?.[4] || {}, summaryConfigArray?.[5] || {}]);
    setSummaryQuater([summaryConfigArray?.[6] || {}, summaryConfigArray?.[7] || {}]);
  }, [summaryType, t]);

  // Populate transaction data locally instead of via API
  useEffect(() => {
    if (transactionType === 'R') {
      setTransactionData([
        {
          c_transaction_date: '2025-12-01 10:15',
          c_mdn: '9999999999',
          c_trans_type: 'TOPUP',
          c_packet_code: 'PKT100',
          c_transaction_type: 'DEBIT',
          c_amount: 10.0,
        },
        {
          c_transaction_date: '2025-12-01 09:45',
          c_mdn: '8888888888',
          c_trans_type: 'TOPUP',
          c_packet_code: 'PKT50',
          c_transaction_type: 'CREDIT',
          c_amount: 5.0,
        },
      ]);
    } else {
      // Fund transfer sample data
      setTransactionData([
        {
          c_transaction_date: '2025-12-01 11:00',
          c_partner_name: 'Subdistributor A',
          c_trans_type: 'DEBIT',
          c_amount: 100.0,
        },
        {
          c_transaction_date: '2025-12-01 08:30',
          c_partner_name: 'Subdistributor B',
          c_trans_type: 'CREDIT',
          c_amount: 150.0,
        },
      ]);
    }
  }, [transactionType]);

  
  const exampleData = JSON.parse(localStorage.getItem("userData")); // Select the data from the Redux store

// if (!exampleData?.LOGIN_ID) {
//   // redirect to logout page
//     window.location.href = '/gig-nation/logout';
//     return null;
//    //return <Navigate to="/logout" replace />;
// }



  console.log(summaryDay, "summaryDay");
  console.log(summaryMonth, "summaryMonth");
  console.log(summaryQuater, "summaryQuater");
  console.log(summaryWeek, "summaryWeek");
// Function to render dynamic key-value pairs
const renderKeyValues = (summary) => {
  return Object.entries(summary).map(([key, value]) => (
    <span key={key}>
      {key.replace(/([A-Z])/g, ' $1')} : {value}
    </span>
  ));
};

console.log(summaryData);
const handleSummaryChange = (event, newValue) => {
  setSummaryType(newValue);
  // toast.error(newValue);
};
const handleTransactionChange = (event, newValue) => {
  setTransactionType(newValue);
  // toast.error(newValue);
};


if (!exampleData) {
  return <Navigate to="/logout" replace />;
}


  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          
                  <Header />
          <tr height="65px">
          <PaymentManagerHeading />
          <TopMenu menuLink= {localVar==='en'?"Home":"Rumah"}/>
          </tr>
          <tr>
          <LeftBgImage />
            {/* <td valign="top" style={{ width:"100px" ,borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)" }}> */}
          {/* <img src={bg} alt="" style={{width:'100%', height:'100%', objectFit:'cover'}} /> */}
            {/* </td> */}
            <td valign="top">
              <meta httpEquiv="Content-Type" content="text/html; charset=ISO-8859-1" />
              <title>homepage</title>

              {/* <div>
                <h1>Welcome to the Home Page!</h1>
                {data ? (
                  <>
                    <p>Site Language: {data.siteLanguage}</p>
                    <p>Locale: {data.localeValue}</p>
                    <p>Country: {data.countryValue}</p>
                  </>
                ) : (
                  <p>Loading...</p>
                )}
              </div> */}
              <form action="/partner/login.do?method=loginHomePage" method="post">
                <table width="100%" height="100%" cellSpacing={0} cellPadding={0} border={0} align="center">
                  <tbody>
                    <tr valign="top">
                      <td align="center" className="">
                       {/* <p style={{fontSize:'15px', paddingTop:'10px', marginBottom:'0'}}> {t('005')}</p> */}
                        {/* {t('greeting')} */}
                        <Grid container style={{padding:'10px', paddingInline: '30px'}}>
                          
                          {/* <Grid item xs={1}></Grid> */}
                          
                        </Grid>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <input type="hidden" name="OWASP_CSRFTOKEN" defaultValue="Hh3W2bgRUUuaNuy9JwA1M612nXRUN21uAGkz3oiCGFw=" />
              </form>
            </td>
          </tr>
          <tr height="55px">
            <td colSpan={2}>
              <link href="/airmanage/networkadmin/stylesheets/abcstyles-new.css" rel="stylesheet" type="text/css" />
               <Footer />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
