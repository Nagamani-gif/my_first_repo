import TopMenu from "./TopMenu";
import { LeftMenu, Header, Footer, PaymentManagerHeading, JasperLeftMenu, TransactionTopMenu, LeftBgImage } from "./PageComponents";
import {
  Box,
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  Grid,
  InputLabel,
  MenuItem,
  Pagination,
  Paper,
  Radio,
  Select,
  Tab,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  TextField,
  Typography,
} from "@mui/material";
import RadioGroup from '@mui/material/RadioGroup';

import CircularProgress from '@mui/joy/CircularProgress';
import React, { useEffect, useRef, useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import numeral from "numeral";
import { v4 as uuidv4 } from "uuid";
// Importing toastify module
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import { styled } from "@mui/material/styles";
import {
  FindInPageRounded,
  KeyboardReturn,
  KeyboardReturnRounded,
  RemoveRedEyeRounded,
} from "@mui/icons-material";
import SendIcon from '@mui/icons-material/Send';
import i18n from "./i18n";
import { useTranslation } from "react-i18next";
import axios from 'axios';
import { useNavigate } from 'react-router';

function DistributorFundTransferSample() {

  sessionStorage.setItem("selectedLink", "e_transactions");


  const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
  const partnerId = exampleData.LOGIN_ID;
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const singleFundSource = exampleData.SINGLE_FUND_SOURCE_FLAG_VAL;
  const MULTI_LEVEL_TRANSFER_FLAG_VAL=exampleData.MULTI_LEVEL_TRANSFER_FLAG_VAL;
  const MULTI_LEVEL_TRANSFER_FLG_VALUE=exampleData.MULTI_LEVEL_TRANSFER_FLG_VALUE;
  const hasFunctionBeenCalled = useRef(false);

  // const storedData = localStorage.getItem("subDistributorList");

  // if(storedData){}else 
  const toastId = useRef(null);
  const [open, setOpen] = useState(false);
  const [distributorIdentity, setDistributorIdentity] = useState();
  const [maxLimit, setMaxLimit] = useState();
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
  const [headerCheckbox, setHeaderCheckbox] = useState(false);
  const [checkedRows, setCheckedRows] = useState([]);
  const [totalTransferAmount, setTotalTransferAmount] = useState("0.00");
  const [selectedRowDataList, setSelectedRowDataList] = useState([]);
  // let selectedRowDataList = [];
    // PAGINATION
    const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(25);
  const [transactionpassword, setTransactionpassword] = useState("");
  const [changeFundValue, setChangeFundValue] = useState("");

  const [toAcctType, setToAcctType] = useState(exampleData.USER_TYPE_ID)
  const [salesperson, setSalesperson] = useState(false);
  const inputRef = useRef(null); 
  const {t} = useTranslation();
  const [selTransfer, setSelTransfer] = useState(t('096'));
  const localeVar=i18n.language;
  const [isLoading, setIsLoading]=useState(false);
  const navigate = useNavigate();
const [accountBal, setAccountBal]=useState('');
const [creditBal, setCreditBal]=useState('');
const [errorMsg,setErrorMsg] = useState('');



  // FOR INPUT FIELDS
  const [subDistributorId, setSubDistributorId]=useState('');
  const [subDistributorFirstName, setSubDistributorFirstName]=useState('');
  const [subDistributorLastName, setSubDistributorLastName]=useState('');
  const [companyName, setCompanyName]=useState('');

  const [mxn, setMxn]=useState("0.00");
  const [thresholdAmount, setThresholdAmount]=useState("0.00");
  const [noOftimes, setNoOftimes]=useState('');

  const [mdn, setMdn]=useState('');
  const [location, setLocation]=useState('');
  const [totalRecordsSatisfied, setTotalRecordsSatisfied] = useState(0);
  const [previewScreen, setPreviewScreen] = useState(false);
  const [searching, setSearching] = useState(false);
  const [hmPartnerList,setHmPartnerList]=useState([]);
  const [hmPartnerId,setHmPartnerId] = useState('');

   const [fundTrsAction, setFundTrsAction] = useState('VALIDATE');
  //let fundTrsAction='';
  const [oldFundAmount, setOldFundAmount]=useState([]);
  const [distpaymentAl, setDistpaymentAl]=useState([]);
  const inputRefs = useRef({});
  const [triggerFetch, setTriggerFetch] = useState(false); // New state to trigger fetch
  const [rowchecked, setRowchecked] = useState(false);

  const [pagechange, setPagechange] = useState(false);
let distvariable='';

  const handleChangePage = (event, newPage) => {
    // debugger;
    setPage(newPage);
    setPagechange(true);
    setErrorMsg('')
  };
  const [filteredSubDistributorList, setFilteredSubDistributorList] = useState([]);

  const styleObj = {
    minHeight: '27px',
    fontSize: '11px',
    padding: '7px 10px',
    maxHeight: '27px',
    margin: '10px 5px 5px 5px',
    
    borderRadius: '5px',
    color: '#1976d2',
    // boxShadow: '0px 6px 15px rgb(25 118 210)',
    // scale: '0.9',
    transition: '0.5s',
    opacity: '1',
    background: '#fff',
    color: '#3399FF',
    border: '1px solid #1976d2',
    textTransform: 'capitalize',
    "&:hover": {
      background: '#3399FF',
      color: '#fff',
      border: '1px solid #3399FF',
      borderRadius: '5px',
    //   boxShadow: '0 4px 6px -1px rgba(0, 0, 0, .1), 0 2px 4px -1px rgb(0 0 0 / 75%)',
    //   transition: '0.5s',
    //   scale: '1',
    },
   "&.Mui-selected": {
    color: '#fff',
    background: '#3399FF',border:' 1px solid #3399FF',
  }
  };

  let startRecord=0;
  let endRecord =10;

let currentRows='';
let accntBalnce="";
let availableTemp="";
console.log(distpaymentAl, "distpaymentAl?????????????")

  const fetchData = async () => {
    try {
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_FUND_TRANSFER;
      const response = await axios.post(apiUrl, {
        userName,
        password,
        partnerId,
        localeVar,
        PARENT_ID:exampleData.PARENT_ID,
        USER_TYPE_ID:exampleData.USER_TYPE_ID,
        distpaymentAl,

        subDistId:subDistributorId,
        subDistFirstName:subDistributorFirstName,
        subDistLastName:subDistributorLastName,
        subDistCompName:companyName,
        subDistLocName:location,

        salesPersonId:subDistributorId,
        salesMDN:mdn,
        salesFirstName:subDistributorFirstName,
        salesLastName:subDistributorLastName,
        salesCompName:companyName,

        distvariable,
        fundTrsAction,
        selTransfer,
        toAcctType,
        perpage,
        fundAmt:mxn,
        thresholdAmt:thresholdAmount,
        noOftimes:noOftimes,
        availableTempCL:creditBal,
        acctBalance:accountBal,
       toAcctId:"",
       firstName:"",
       lastName:"",
       salesID:hmPartnerId,
       startPageNo:startRecord-1,
       //endPageNo:endRecord < 25 ? '25' : endRecord,
       endPageNo:Number(endRecord)
        });
        setIsLoading(false);
        
console.log(response.data, "Response Data");
console.log(accountBal, "accountBal")
console.log(page, "page")
if (mxn === undefined || mxn === "0") {
  // Clear checked rows to uncheck all checkboxes
  setCheckedRows([]);
  setSelectedRowDataList([]); // Clear selected rows if necessary
  setDistpaymentAl([]); // Clear this state if it's related to the checkboxes
  // setFundTrsAction('VALIDATE');
} else {
  setFundTrsAction('FUNDTRANSFER');
}

// if(response.data.tempResultMsg!==''){
//   setTotalTransferAmount("0.00");
//   setMxn("0.00");
// }

if(response.data.tempResultMsg==='FTI0'){
  setErrorMsg(t('4936'));
}else if(response.data.tempResultMsg==='TF0'){
  setErrorMsg(t('4935'));
  setMxn('0.00');
  setPage(1);
}else if(response.data.tempResultMsg==='TF6'){
  setErrorMsg(t('5692'));
}else if(response.data.tempResultMsg==='TF3'){
  setErrorMsg(t('4942'));
}else if(response.data.tempResultMsg==='NO'){
  setErrorMsg(t('4622'));
  setPage(1);
}else if(response.data.tempResultMsg==='MLInsufficientFunds'){
  setErrorMsg(response.data.finalDisplayMsg);
}else if(response.data.tempResultMsg==='TF5'){
  setErrorMsg(response.data.finalDisplayMsg);
}



      if (response.data.responseDescription === "SUCCESS") {
        // setPreviewScreen(false);
        setIsLoading(true);
        const responseData = response.data;
        accntBalnce=responseData.acctBalance;
        availableTemp=responseData.availableTempCL;
        setAccountBal(responseData.acctBalance);
        setCreditBal(responseData.availableTempCL);
        setThresholdAmount(responseData.thresholdAmt);
        setNoOftimes(responseData.noOftimes);
        // setMxn(responseData.fundAmt);
        setHeaderCheckbox(false);


        // Check if selTransfer matches the condition for t('097')
         if (selTransfer === t('097')) {
                let updatedList = [];
              if (responseData.hmPartnerListSize === "No Records") {
                setHmPartnerList(["---"]); // Add "---" as the only option
                setHmPartnerId("---");  // Set hmPartnerId to "---" when no records are found
              } else if (responseData.hmPartnerListSize) {
                const partnerListArray = Object.keys(responseData.hmPartnerListSize).sort(); // Extract keys as array
                setHmPartnerList(partnerListArray);  // Set the array in state
                setHmPartnerId(prevId => (partnerListArray.includes(prevId) ? prevId : partnerListArray[0])); // Set default partnerId if needed
               }
              // else {
                  // Filter out empty objects if toAcctIdsList is an array
                  updatedList = Array.isArray(responseData.toAcctIdsList)
                      ? responseData.toAcctIdsList.filter(item => item && Object.keys(item).length > 0)
                      : [];
                // }

              setFilteredSubDistributorList(updatedList);  // Update the filtered sub-distributor list
            } else {
              // For other cases, directly use the responseData.toAcctIdsList
              setFilteredSubDistributorList(responseData.toAcctIdsList);
            }
            // Set other necessary state values
                      setTotalRecordsSatisfied(responseData.totalRecordsSatisfied);
                      setTransactionpassword("");  // Reset transaction password
                      // setDistpaymentAl([]);  // Clear distpaymentAl

         }
      
    } catch (error) {
      console.error("An error occurred:", error);
    }
  };


    const sumitFund = () => {
    setFundTrsAction("AMTTRNSSUBMIT");
    setPreviewScreen(false);
    setIsLoading(false);
    setFilteredSubDistributorList([]);
    setSelectedRowDataList([]);
    setCheckedRows([]);
    setTriggerFetch(true);
  };

  useEffect(() => {
    // Set the browser title
      document.title = t('2472_021');
  }, []);

// Effect that triggers fetchData after state is updated
useEffect(() => {
  if (triggerFetch) {
    fetchData(); // Call fetchData when triggerFetch is set to true
    setTriggerFetch(false); // Reset triggerFetch
    setFundTrsAction('FUNDTRANSFER');
  }
// eslint-disable-next-line react-hooks/exhaustive-deps
}, [triggerFetch]); // Dependencies include the state variables being updated



  const fetchDistributorFundPopup =async () =>{
    try {
      const apiUrl= window.config.apiUrl + process.env.REACT_APP_DISTRIBUTOR_FUND_POPUP;
      console.log("apiurl=====",apiUrl)
      const response = await axios.post(apiUrl, {
        userName,
        password,
        localeVar,
        toAcctId : maxLimit,
        partnerId,
        toAcctType,
        oldFundAmount :distributorIdentity
        });
        console.log(response);
        console.log(response.data);
        setErrorMsg('');
    }
    catch (error){

    }
  }

useEffect(() =>{
  if (checkedRows.length > 0 && checkedRows.length === filteredSubDistributorList.length) {
    setHeaderCheckbox(true);
} else {
    setHeaderCheckbox(false);
}
},[checkedRows])
  
  
  
  useEffect(() => {
    // if (!hasFunctionBeenCalled.current) {
      calculateTotalTransferAmount(checkedRows);
      // hasFunctionBeenCalled.current = true; // Update the ref to indicate the function has been called
    // }
   
  }, [checkedRows, filteredSubDistributorList]);

// Modified handleSearch function
const handleSearch = () => {
  setErrorMsg('');
  if (selTransfer === (t('097'))) {
    setFundTrsAction('VALIDATE');
    setToAcctType("6");
  } else {
    setFundTrsAction('CHANGED');
  }
  
  // Trigger fetchData after state updates
  setTriggerFetch(true);
  setCheckedRows([]);
};

  // GETTING DATA FROM TABLE TO INPUT BOX
  const handleClickOpen = (value, id) => {
    setOpen(true);
    setMaxLimit(id);
    setDistributorIdentity(value);
    setOldFundAmount(value);
  };
  // MODAL CLOSING FUNCTION
  const handleClose = () => {
    setOpen(false);
  };
  // SUBMITTING DATA FROM MODAL TO TABLE
  const handleSubmit = () => {
    const distributorValueChnage =
      numeral(distributorIdentity).format("0,0.00");
      setDistributorIdentity(distributorValueChnage);
    const updatedList = filteredSubDistributorList.map((item) =>
      item.partnerId === maxLimit
        ? { ...item, maxFundLimt: distributorValueChnage }
        : item
    );
    setFilteredSubDistributorList(updatedList);
    setOpen(false);
    fetchDistributorFundPopup();
  };
  
  // const handleHeaderCheckboxChange = (event) => {
  //   const isChecked = event.target.checked;
  //   // Update the header checkbox state
  //   setHeaderCheckbox(isChecked);
  //   if (isChecked) {
      
  //     // When the checkbox is checked, validate each row
  //     const validRows = [];
  //     const updatedList = filteredSubDistributorList.map((item) => {
  //       const maxLimit = item.maxFundLimt ? parseFloat(item.maxFundLimt.replace(/,/g, '')) : 0;

  //       // const maxLimit = parseFloat(item.maxFundLimt.replace(/,/g, ''));
  //       const acctBal = parseFloat(item.acctBal.replace(/,/g, ''));
  //       const transferamount = parseFloat(item.transferAmt.replace(/,/g, ''));
  
  //       if ((acctBal >= maxLimit && transferamount !== 0) || (maxLimit === 0 && transferamount !== 0)) {
  //         // Show alert for invalid rows
  //         alert(`${t("2480_010")} ${item.partnerId}`);
  //         inputRefs.current[item.partnerId]?.focus();
  //         // Set invalid rows' transferAmt and rawValue to 0.00
  //         return { ...item, transferAmt: "0.00", rawValue: "0.00" };
          
  //       } else {
  //         // Valid rows
  //         validRows.push(item);
  //         return item;
  //       }
  //     });
  
  //     // Update the list after validation
  //     setFilteredSubDistributorList(updatedList);
  
  //     const validPartnerIds = validRows.map(item => item.partnerId);
  
  //     // Set the checked rows to the valid ones
  //     setCheckedRows(validPartnerIds);
  //     setSelectedRowDataList(validRows);
  //     calculateTotalTransferAmount(validPartnerIds);
  
  //   } else {
  //     // When the checkbox is unchecked, set all rows' transferAmt to 0.00
  //     const updatedList = filteredSubDistributorList.map((row) => ({
  //       ...row,
  //       // transferAmt: "0.00", // Set all rows' transferAmt to 0.00
  //       // rawValue: "0.00"     // Set all rows' rawValue to 0.00
  //     }));
  
  //     // Set the updated list to state
  //     setFilteredSubDistributorList(updatedList);
  
  //     // Reset checked and selected rows
  //     setCheckedRows([]);
  //     setSelectedRowDataList([]);
  //     calculateTotalTransferAmount([]);
  //   }
  // };
  const validRowsRef = useRef([]); // Store previously valid rows persistently

  const handleHeaderCheckboxChange = (event) => {
    const isChecked = event.target.checked;
    setHeaderCheckbox(isChecked);

    if (isChecked) {
    const validRows = [...validRowsRef.current]; // Start with previously valid rows
      const updatedList = filteredSubDistributorList.map((item) => {
        const maxLimit = item.maxFundLimt ? parseFloat(item.maxFundLimt.replace(/,/g, '')) : 0;
        const acctBal = parseFloat(item.acctBal.replace(/,/g, ''));
        const transferamount = parseFloat(item.transferAmt.replace(/,/g, ''));
  
        if ((acctBal >= maxLimit && transferamount !== 0) || (maxLimit === 0 && transferamount !== 0)) {
          alert(`${t("2480_010")} ${item.partnerId}`);
          inputRefs.current[item.partnerId]?.focus();
          return { ...item, transferAmt: "0.00", rawValue: "0.00" };
        } else {
        // Ensure new valid rows are added
        if (!validRows.some(row => row.partnerId === item.partnerId)) {
          validRows.push(item);
        }
          return item;
        }
      });
  
    // Persist valid rows for the next function call
    validRowsRef.current = validRows;

      setFilteredSubDistributorList(updatedList);
  
      const validPartnerIds = validRows.map(item => item.partnerId);
           setCheckedRows(validPartnerIds);
      setSelectedRowDataList(validRows);
      calculateTotalTransferAmount(validPartnerIds);
    } else {
    setFilteredSubDistributorList(filteredSubDistributorList);
      setCheckedRows([]);
      setSelectedRowDataList([]);
      calculateTotalTransferAmount([]);
    }
  };
  
  const handleRowCheckboxChange = (event, id) => {
    setRowchecked(true);
    const isChecked = event.target.checked;
    let checkMaxLimit= filteredSubDistributorList.find((item) => item.partnerId === id);
    const maxFundLimt = checkMaxLimit.maxFundLimt ?parseFloat(checkMaxLimit.maxFundLimt.replace(/,/g, '')):0;
    const acctBal = parseFloat(checkMaxLimit.acctBal.replace(/,/g, ''));
    const transferAmt = parseFloat(checkMaxLimit.transferAmt.replace(/,/g, ''));
    if (
      (maxFundLimt === 0 && transferAmt !== 0) ||
      (maxFundLimt <= acctBal && transferAmt !== 0) ||
      (maxFundLimt < transferAmt)
      )
    
    // if(
    //   (parseFloat(checkMaxLimit.maxFundLimt.replace(/,/g, ''))===0 && 
    //   parseFloat(checkMaxLimit.transferAmt.replace(/,/g, ''))!==0)||
    //   (parseFloat(checkMaxLimit.maxFundLimt.replace(/,/g, '')) <=
    //    parseFloat(checkMaxLimit.acctBal.replace(/,/g, ''))) && parseFloat(checkMaxLimit.transferAmt.replace(/,/g, ''))!==0)
      {
      // toast.error(<>{t("2480_010")} {checkMaxLimit.partnerId}</>);
      inputRefs.current[checkMaxLimit.partnerId]?.focus();
      
      setFilteredSubDistributorList(
        filteredSubDistributorList.map((item) => {
          // Check if the partnerId matches the id
          if (item.partnerId === id) {
            // Return a new object with the updated acctBal
            return { ...item, transferAmt: "0.00",  rawValue:"0.00"  };
          }
          // Return the item as is if no match
          return item;
        })
      );
      checkMaxLimit="";
        }
        else{
          const newCheckedRows = isChecked
          ? [...checkedRows, id]
          : checkedRows.filter((rowId) => rowId !== id);
        setCheckedRows(newCheckedRows);
    
        const newSelectedRowDataList = isChecked
          ? [...selectedRowDataList.filter((row) => row.partnerId !== id), filteredSubDistributorList.find((item) => item.partnerId === id)]
          : selectedRowDataList.filter((row) => row.partnerId !== id);
        setSelectedRowDataList(newSelectedRowDataList);
        calculateTotalTransferAmount(newCheckedRows);
        }
   
  };

  
 // ADDING TRANSFER AMOUNT & POST TRANSFER AMOUNT TO THE ARRAY
 const handleInputChange = (event, id, fieldName) => {
  // //debugger;
    let newValue = event.target.value;
    let regex=''

     if(selTransfer===t('0100')){
       //regex = /^-?\d*\.?\d*$/; 
       regex = /^-*\d*\.?\d*$/;
       
     }else{
    // Validate to ensure only numbers and decimals
     regex = /^\d*\.?\d*$/;
     }

    if (regex.test(newValue)) {
      const updatedList = filteredSubDistributorList.map(item => {
        if (item.partnerId === id) {
          if (fieldName === 'transferAmt') {
            return {
              ...item,
              transferAmt: newValue
            };
          } else if (fieldName === 'acctBalTransferAmt') {
            return {
              ...item,
              acctBalTransferAmt: newValue
            };
          }
        }
        return item;
      });
      setFilteredSubDistributorList(updatedList);

    }
  }

  // ADDING THE CURRENT BALANCE AND TRANSFER AMOUNT
  const handleBlurInput = (event, id, fieldName) => {
    let newValue = event.target.value;
    let parsedValue = parseFloat(newValue.replace(/,/g, '')) || 0;
    let formattedValue = parsedValue.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  
    const checkMaxLimit = filteredSubDistributorList.find(item => item.partnerId === id);
    if (!checkMaxLimit) return;
  
    // Update filteredSubDistributorList with new value for the current row (postBalance always updates)
    const updatedList = filteredSubDistributorList.map(item => {
      if (item.partnerId === id) {
        let postTransferAmountValue = parsedValue + parseFloat(item.acctBal.replace(/,/g, ''));
        let formattedPostTransferAmount = postTransferAmountValue.toLocaleString('en-US', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
        return {
          ...item,
          [fieldName]: formattedValue,
          rawValue: parsedValue.toString(),
          acctBalTransferAmt: formattedPostTransferAmount
        };
      }
      return item;
    });
  
    setFilteredSubDistributorList(updatedList);
  
    // Check if the row is checked before proceeding
    if (checkedRows.includes(id)) {
      // Condition: Remove from checkedRows if maxFundLimt is 0 or less than acctBal
      if (
        (parseFloat(checkMaxLimit.maxFundLimt.replace(/,/g, '')) <=
          parseFloat(checkMaxLimit.acctBal.replace(/,/g, ''))) ||
        (parseFloat(checkMaxLimit.maxFundLimt.replace(/,/g, '')) === 0)
      ) {


        toast.error(<>{t("2480_010")}{checkMaxLimit.partnerId}</>);
  
        // Remove row from checkedRows and reset its transferAmt
        setCheckedRows(prevCheckedRows => prevCheckedRows.filter(rowId => rowId !== id));
    // Uncheck the checkbox for this row
        setFilteredSubDistributorList(
          filteredSubDistributorList.map(item => {
            if (item.partnerId === id) {
              return { ...item, transferAmt: "0.00", rawValue:"0.00" };
           
            }
            return item;
          })
        );
  
        // Also remove this row from selectedRowDataList
        setSelectedRowDataList(prevSelectedRowDataList =>
          prevSelectedRowDataList.filter(row => row.partnerId !== id)
        );
      } else {
        // Update selectedRowDataList for checked rows
        const updatedSelectedRowDataList = selectedRowDataList.map(row => {
          if (row.partnerId === id) {
            return {
              ...row,
              [fieldName]: formattedValue,
              rawValue: parsedValue.toString(),
              acctBalTransferAmt: updatedList.find(item => item.partnerId === id).acctBalTransferAmt
            };
          }
       
          return row;
        });
  
        setSelectedRowDataList(updatedSelectedRowDataList);
        calculateTotalTransferAmount(checkedRows);
      }
    } else {
      //If row is not checked, only update postBalance but do not reset transferAmt to 0.00
      setFilteredSubDistributorList(
        filteredSubDistributorList.map(item => {
          if (item.partnerId === id) {
            return {
              ...item,
              [fieldName]: formattedValue,
              acctBalTransferAmt: updatedList.find(u => u.partnerId === id).acctBalTransferAmt,
              rawValue: parsedValue.toString()  // Update rawValue for post balance
              // Keep transferAmt unchanged when unchecked
            };
          }
          return item;
        })
      );


    }
  };
  
  
  const handleFocusInput = (event, id, fieldName) => {
    const updatedList = filteredSubDistributorList.map(item => {
      if (item.partnerId === id) {
        return {
          ...item,
          [fieldName]: item.rawValue || item[fieldName] // Switch to raw value for editing
        };
      }
      return item;
    });
    setFilteredSubDistributorList(updatedList);
  };
  
  
const calculateTotalTransferAmount = (checkedRows) => {
  // debugger;
  if (checkedRows.length > 0) {
    const total = checkedRows.reduce((sum, rowId) => {
      const row = filteredSubDistributorList.find((item) => item.partnerId === rowId);
      const resultVal = sum + (row ? parseFloat(row.transferAmt.replace(/,/g, '')) || 0 : 0);
      return resultVal;
    }, 0);
    setTotalTransferAmount(total.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }));
  } else {
    setTotalTransferAmount("0.00");
  }
};

  const maxLimitChangeOnBlur = (event) => {
    const changeValue = numeral(event.target.value.replace(/,/g, "")).format(
      "0,0.00"
    );
    setDistributorIdentity(changeValue);
  };
  const maxLimitOnChange = (event) => {
    let newValue = event.target.value;
    // Validate to ensure only numbers and decimals
    const regex = /^\d*\.?\d*$/;
    if (regex.test(newValue)) {
      setDistributorIdentity(newValue);
      setChangeFundValue(newValue.toString());
    }
  };
  const maxLimitChangeOnFocus = (event) => {
    let changeValue = parseFloat(event.target.value.replace(/,/g, "")) || 0;
    //setDistributorIdentity(changeValue.toString());
    setDistributorIdentity(changeValue === 0 ? "" : changeValue.toString()); // Set empty if 0, else keep the value
  };

  const handlePageSelectChange = (event, newValue) => {
    // debugger;
    setPerPage(Number(newValue));
    handleChangePage(event, page);
    setMxn('0.00');
    setPage(1);

  };
  // const totalRecords = filteredSubDistributorList ? filteredSubDistributorList.length : '';
   startRecord = (page - 1) * perpage + 1;
   endRecord =totalRecordsSatisfied > 0 
   ? Math.min(startRecord + perpage - 1, totalRecordsSatisfied) 
   : (page === 1 ? 25 : page * perpage);
   
  //  Math.min(startRecord + perpage - 1, totalRecordsSatisfied);

   //currentRows = filteredSubDistributorList ? filteredSubDistributorList.slice((page - 1) * perpage, page * perpage) : '';
   currentRows = filteredSubDistributorList ? filteredSubDistributorList : [];
   console.log("current rows::::::::", currentRows)
   console.log("filteredSubDistributorList::::::::", filteredSubDistributorList)

  const totalPages = Math.ceil(totalRecordsSatisfied / perpage);
  const selectrowEndPage=currentRows.length;
  useEffect(() => {

    console.log("Current Rows from UseEffect", currentRows);

    // Extract partner IDs from currentRows (i.e., the current page rows)

    const currentPagePartnerIds = currentRows.map(row => row.partnerId);

  if(!headerCheckbox && pagechange){

    // Remove only current page rows from checkedRows

    setCheckedRows(prevCheckedRows => prevCheckedRows.filter(id => !currentPagePartnerIds.includes(id)));

  

    // Remove only current page rows from selected row data

    setSelectedRowDataList(prevData => prevData.filter(row => !currentPagePartnerIds.includes(row.partnerId)));

  

    // Remove unchecked rows from currentRows

    currentRows =prevRows => prevRows.filter(row => !currentPagePartnerIds.includes(row.partnerId));

   setPagechange(false);

    setHeaderCheckbox(false)

  }

  

  

  }, [currentRows]);

  const previewDistributor = () => {
    setFundTrsAction("FUNDTRANSFERPREVIEW");
  // Ensure latest selectedRowDataList with updated transferAmt
  const updatedSelectedRowDataList = selectedRowDataList.map((row) => {
    const correspondingItem = filteredSubDistributorList.find(item => item.partnerId === row.partnerId);
    if (correspondingItem) {
      return {
        ...row,
        transferAmt: correspondingItem.transferAmt, // Ensure transferAmt is synced
        rawValue: correspondingItem.rawValue
      };
    }
    return row;
  });
  setDistpaymentAl(updatedSelectedRowDataList);
    setErrorMsg('');
    //distpaymentAl=selectedRowDataList;
    if (checkedRows.length === 0) {

    if(!toast.isActive(toastId.current) ){
        if(toAcctType ==='5')
      toastId.current = toast.error(t("2480_019")); 
        else 
          toastId.current = toast.error(t("25160005"));
      }
     }else if(selTransfer === t('0100') && updatedSelectedRowDataList.some(row => parseFloat(row.transferAmt) > 0)) {
      if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t("2480_030"), {
          onClose:() => {
            // Focus the first input where transferAmt is "0.00"
          const firstInvalidRow = updatedSelectedRowDataList.find(row => row.transferAmt > 0);
            if (firstInvalidRow) {
              const inputElement = document.getElementById(`transferAmt-${firstInvalidRow.partnerId}`);
              if (inputElement) {
                inputElement.focus();
              }
            }
          }
        });
      }
    }else if (updatedSelectedRowDataList.some(row => row.transferAmt === "0.00")) {
      
      if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t("2480_018"), {
          onClose:() => {
            // Focus the first input where transferAmt is "0.00"
          const firstInvalidRow = updatedSelectedRowDataList.find(row => row.transferAmt === "0.00");
            if (firstInvalidRow) {
              const inputElement = document.getElementById(`transferAmt-${firstInvalidRow.partnerId}`);
              if (inputElement) {
                inputElement.focus();
              }
            }
          }
        });
      }
      setFundTrsAction("FUNDTRANSFER");
    }else if (transactionpassword.trim() === "") {
      if(!toast.isActive(toastId.current) ){
        toastId.current = toast.error(t("016"),{
          onClose: () => {
            const transpwd=document.getElementById('transactionpassword1');
            transpwd.focus();
          //inputRef.current && inputRef.current.focus(), // Focus input after toast closes
      }})
    }
    setIsMandate(true);
        return;
      //inputRef.current.focus();
    }
    else {
      fetchTransactionPwdData(transactionpassword);
      // if(!previewScreen){
      }
      
    // }
    
   
  };

    const fetchTransactionPwdData = async (transpassword) => {
      try {
        const apiUrl = window.config.apiUrl + process.env.REACT_APP_TRANSACTION_PASSWORD; // Loading API from Environment Variable
        console.log("apiurl=====",apiUrl)
        const response = await axios.post(apiUrl, {
          userName,
          password,
          login_id : partnerId,
          localeVar,
          selTransfer,
          fundTrsAction,
          transactionpassword:transpassword,
          partnerId
          });
          // debugger;
          console.log(response);
          // setDistVariable(response.data.fundTrsAction);
          distvariable=response.data.fundTrsAction;
        if (response.data.transPW === true) {
          setPreviewScreen(true);
          setTransactionpassword('');
          // await fetchData();
          setFilteredSubDistributorList(selectedRowDataList);
        }
        else{
          if(!toast.isActive(toastId.current) ){
            toastId.current = toast.error(t("2480_020")); 
            }
        // toast.error("Please enter correct password.")
          setPreviewScreen(false);
          setTransactionpassword('');
        //inputRef.current.focus();
         }
  
        
      } catch (error) {
        console.error("An error occurred:", error);
      }
    };
  // ADDED FOR "When we selected checked rows then submit Transfer Amount it works for all pages"
// 🚀 Use a ref to store already alerted rows (avoids re-render)
const alertedRowsRef = useRef(new Set());
  useEffect(() => {
    console.log("Syncing transferAmt with map values...", mxn);

    // ✅ Skip validation for empty, "0.00", or invalid values
    const numericValue = parseFloat(mxn.replace(/,/g, "")) || 0;
    if (!mxn || mxn === "0.00" || numericValue === 0 || isNaN(numericValue)) {
return;
    }
else{
  setTimeout(()=>{
    const distributorMap = new Map(
      filteredSubDistributorList.map((item) => [item.partnerId, item])
  );
    const updatedList = selectedRowDataList
    .filter((row) => {
        const isChecked = checkedRows.includes(row.partnerId);
        const maxFundLimt = row.maxFundLimt
            ? parseFloat(row.maxFundLimt.replace(/,/g, "")) 
            : 0;
        const acctBal = parseFloat(row.acctBal.replace(/,/g, "")) || 0;
// ✅ Check if the row exists in filteredSubDistributorList
const isMatched = distributorMap.has(row.partnerId);
        // 🚫 Skip alert if the row is already in the ref
        if (
            isChecked && !isMatched && 
            (maxFundLimt <= acctBal || maxFundLimt === 0) &&
            !alertedRowsRef.current.has(row.partnerId)  // 🚫 Skip duplicates
        ) {
            console.log(`Invalid row: ${row.partnerId}`);

            // ✅ Add the row to the ref to prevent duplicate alerts
            alertedRowsRef.current.add(row.partnerId);

            // 🚫 Show the alert
            alert(`${t("2480_010")} ${row.partnerId}`);
            // 🚫 Remove this invalid row from the list
            return false;  // ❌ Exclude from the updated list
        }

        return true;  // ✅ Keep valid rows
    })
    .map((row) => ({
        ...row,
        transferAmt: mxn || row.transferAmt,
        rawValue: mxn
            ? parseFloat(mxn.replace(/,/g, "")) 
            : row.rawValue
    }));

// ✅ Remove invalid rows from the list
const filteredList = updatedList.filter(
  (row) => !alertedRowsRef.current.has(row.partnerId)  // Exclude alerted rows
);

// ✅ Update the list with only valid rows
setSelectedRowDataList(filteredList);
  },[2000])
}
    

}, [mxn, checkedRows]);  // Trigger when mxn or checkedRows change

  

useEffect(() =>{
      // eslint-disable-next-line react-hooks/exhaustive-deps
      currentRows=[];
      if(currentRows.length===0){
        setIsLoading(false);
      }
   
    const fetchDataAsync = async () => {
      try {

        await fetchData(); // Call your existing fetchData function asynchronously
        
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    }
      fetchDataAsync(); // Fetch data when the component mounts

  }, [toAcctType,selTransfer, perpage, page])

  const handleFundSelectChange = (event, newValue) => {

    setPage(1);
    setPerPage(25);
    console.log("calling fund select=== after fetch")
    setFundTrsAction('VALIDATE');
    setSelTransfer(newValue);
    console.log("seltRansfer===",selTransfer)
    setMxn('0.00');
    setCheckedRows([]);
    setErrorMsg('');
    setHmPartnerId('');
    setNoOftimes('')
    // Check if newValue matches the required value
    if (newValue === t('097')) {
        // Call handleDistributorChange with a mock event to set toAcctType as 6
        handleDistributorChange({ target: { value: "6" } });
    }
};

const handleDistributorChange = (event) => {
  validRowsRef.current = [];
  currentRows='';
  //setCheckedRows([]);
  setFilteredSubDistributorList([]);
  setSelectedRowDataList([]);
    setPage(1);
    setPerPage(25);
    setMxn('0.00');
    setSubDistributorId('');
    setSubDistributorFirstName('');
    setSubDistributorLastName('');
    setCompanyName('');
    setLocation('');
    setMdn('');
    setErrorMsg('');
    setToAcctType(event.target.value);
    setNoOftimes('')
    setThresholdAmount('0.00');
    console.log("toAccountType===",toAcctType)

    if (event.target.value === "5") {
        setSalesperson(true);
    } else {
        setSalesperson(false);
    }
};


  const handlePreviewReturn= async ()=>{
    setFundTrsAction('VALIDATE');
    setCheckedRows([]);
    setFilteredSubDistributorList([]);
    setDistpaymentAl([]);
    setIsLoading(false);
    setPreviewScreen(false);
    setTriggerFetch(true);
    setMxn('0.00');
    setPage(1)
  };

  const RedAsterisk = styled("span")({
    color: "red",
  });


const handleMDNValidation=(e)=>{
  let newValue=e.target.value;
  const regex = /^\d*$/;
  if(regex.test(newValue)){
    setMdn(newValue);
  }
}

  const transactionAmtOnChange =(e)=>{
    let newValue=e.target.value;
    newValue = newValue.replace(/(\..*)\./g, '$1');
    let regex;
    if(selTransfer===t('0100')){
      //regex = /^-?\d*\.?\d*$/; 
      regex = /^-*\d*\.?\d*$/;
    }else{
   // Validate to ensure only numbers and decimals
    regex = /^\d*\.?\d*$/;
    }
    if(regex.test(newValue)){
      setMxn(newValue);
  }
}
const transactionAmtOnFocus = (e) => {
  let newValue = e.target.value.replace(/,/g, ""); // Remove commas before formatting
  let parsedValue = parseFloat(newValue) || 0;

  setMxn(parsedValue === 0 ? "" : parsedValue.toString()); // Set empty if 0, else keep the value
};


  const transactionAmtOnBlur = async (e) => {
    console.log(checkedRows, "checkedRows from Transaction Amount Blur");
    console.log(selectedRowDataList, "selectedRowDataList from Transaction Amount Blur");
    let newValue = e.target.value.replace(/,/g, ""); // Remove commas before formatting
    let parsedValue = parseFloat(newValue) || 0;

    // Format with commas and 2 decimal places
    let formattedValue = parsedValue.toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });


    setMxn(formattedValue); // Set formatted value on blur
   

    filteredSubDistributorList?.forEach((currentRow) => {
      const isChecked = checkedRows.includes(currentRow.partnerId);
        const maxFundLimt =currentRow.maxFundLimt? parseFloat(currentRow.maxFundLimt.replace(/,/g, '')):0;
        const acctBal = parseFloat(currentRow.acctBal.replace(/,/g, ''));  // Current balance

        // If maxFundLimt is invalid, show alert and reset transferAmt
        if (isChecked && (maxFundLimt <= acctBal || maxFundLimt === 0)) {
          alert(`${t("2480_010")} ${currentRow.partnerId}`);

          // Remove row from checkedRows and reset transferAmt
          setCheckedRows(prevCheckedRows => prevCheckedRows.filter(rowId => rowId !== currentRow.partnerId));

          // Reset transferAmt and rawValue in filteredSubDistributorList
          setFilteredSubDistributorList(prevList =>
            prevList.map(item => 
              item.partnerId === currentRow.partnerId 
                ? { ...item, transferAmt: "0.00", rawValue: "0.00", acctBalTransferAmt: "0.00" }  // Reset post transfer amount
                : item
            )
          );

          // Also remove this row from selectedRowDataList
          setSelectedRowDataList(prevSelectedRowDataList => {
            const updatedSelectedList = prevSelectedRowDataList.filter(row => row.partnerId !== currentRow.partnerId);
            
 
            
            return updatedSelectedList;
          });
                     // Call calculateTotalTransferAmount with the updated list
                    //  calculateTotalTransferAmount(checkedRows);
        } else {
          // If maxFundLimt is valid, update transferAmt and rawValue in filteredSubDistributorList
          setFilteredSubDistributorList(prevList => {
            const updatedList = prevList.map(item => 
              item.partnerId === currentRow.partnerId 
                ? { 
                    ...item, 
                    transferAmt: formattedValue,  // Update transferAmt with formatted value
                    rawValue: parsedValue.toString(),  // Set raw value
                    acctBalTransferAmt: (acctBal + parsedValue).toLocaleString('en-US', { // Update the post-transfer amount
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })
                  }
                : item
            );

            return updatedList;
          });

          // Ensure selectedRowDataList contains the updated transferAmt and rawValue
          setSelectedRowDataList(prevSelectedRowDataList => {
            const updatedSelectedList = prevSelectedRowDataList.map(row =>
              row.partnerId === currentRow.partnerId
                ? { 
                    ...row, 
                    transferAmt: formattedValue,  // Set the entered transfer amount
                    acctBalTransferAmt: (acctBal + parsedValue).toLocaleString('en-US', { // Update the post-transfer amount
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })
                  }
                : row
            );
            
            return updatedSelectedList;
          });
        // }
      }
    });
  };
  const [isMandate, setIsMandate] = useState(false);
  const handleTransactionBlur = () => {
    if (transactionpassword.trim() === "") {
      setIsMandate(true);
    } else {
      setIsMandate(false);
    }
  };
  // VARIABLES & FUNCTION DECLARATIONS ENDS
  
  const handleNoOftimesChange = (e) => {
    const value = e.target.value;
    // Only allow numeric input
    if (/^\d*$/.test(value)) {
      setNoOftimes(value);
    }
  };
  const numvalidate = (event) => {
    const keyCode = event.keyCode || event.which;
    const keyValue = String.fromCharCode(keyCode);
    const regex = /^[0-9\b]+$/; // Only allows numbers and backspace
    
    // Prevent non-numeric input
    if (!regex.test(keyValue)) {
      event.preventDefault();
      return false;
    }
  
    return true;
  };

  const thresholdAmountOnFocus = (e) => {
    let newValue = e.target.value.replace(/,/g, ""); // Remove commas before formatting
    let parsedValue = parseFloat(newValue) || 0;
 
    setThresholdAmount(parsedValue === 0 ? "" : parsedValue.toString()); // Set empty if 0, else keep the value
  };
 
 
    const thresholdAmountOnBlur = async (e) => {
      let newValue = e.target.value.replace(/,/g, ""); // Remove commas before formatting
      let parsedValue = parseFloat(newValue) || 0;
 
      // Format with commas and 2 decimal places
      let formattedValue = parsedValue.toLocaleString("en-US", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
      });
 
 
      setThresholdAmount(formattedValue); // Set formatted value on blur
     
    }  
 
    const thresholdAmountOnChange =(e)=>{
      let newValue=e.target.value;
      newValue = newValue.replace(/(\..*)\./g, '$1');
      let regex;
     
     // Validate to ensure only numbers and decimals
      regex = /^\d*\.?\d*$/;
      if(regex.test(newValue)){
        setThresholdAmount(newValue);
    }
  }


  return (
    <table
      border={0}
      cellPadding={0}
      cellSpacing={0}
      id="inSideLayoutTable"
      height={600}
      width={1000}
      align="center"
    >
      <tbody>
       <Header />
        <tr height="65px">
        <PaymentManagerHeading />
         <TopMenu menuLink={localeVar==='en'?"Transactions":"Transacciones"}/>
        </tr>
        <tr>
          {/* <td
            valign="top"
            style={{
              borderRightStyle: "solid",
              borderRightWidth: "1pt",
              borderColor: "rgb(51 153 255)",
              maxWidth: '162px'
            }}
            nowrap="nowrap"
          >
          </td> */}
          <LeftBgImage />
          {/* DISTRIBUTOR FUND TRANFER PAGE CONTENT STARTS HERE */}
          <td valign="top">
            <meta
              httpEquiv="Content-Type"
              content="text/html; charset=ISO-8859-1"
            />
            <title>homepage</title>
            <TransactionTopMenu />
            {singleFundSource === "N" ? 
          <>   
         {!previewScreen ? (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', flexWrap: 'wrap', width: '100%' }}>
        <Tabs indicatorColor="none" value={selTransfer} onChange={handleFundSelectChange}  style={{minHeight: '35px', paddingTop:'5px'}}>

 <Tab sx={styleObj} value={t('096')} label={t('096')}/>
 <Tab sx={styleObj} value={t('097')} label={t('097')} />
{MULTI_LEVEL_TRANSFER_FLAG_VAL==="Y"?<Tab sx={styleObj} value={t('098')} label={t('098')} /> : ""}
{MULTI_LEVEL_TRANSFER_FLG_VALUE==='Y'?<Tab sx={styleObj} value={t('099')} label={t('099')} /> : ""}
{MULTI_LEVEL_TRANSFER_FLG_VALUE==='Y' ? <Tab sx={styleObj} value={t('0100')} label={t('0100')} /> : ""}
</Tabs>
      </Box>
    ) :  <Tabs indicatorColor="none" value={selTransfer} style={{minHeight: '35px', paddingTop:'5px'}}><Tab sx={styleObj} value={selTransfer} disabled  label={selTransfer} /></Tabs>}                   
      
            
      <Box className={"distributor_fund_transfer_sec mL8 input_boxess rehargePreview"}sx={{ flexGrow: 1 }}>                        
              <Box className={'to_bloc'} style={{marginTop:'20px'}}>
              <fieldset  className={'distributor_fieldset'}>
           <legend className={'distributor_legend'}>{t('distributorfund')}:</legend>
            <Grid
                container
                sx={{ width: 1 }}
                spacing={2}
                style={{
                  justifyContent: "flex-start",
                  marginTop: "0px",
                  marginLeft: "0",
                }}
              >
                <Grid
                  className={" displayFlexCenter"}
                  item
                  xs={10}
                  sx={{ textAlign: "left", justifyContent:'flex-start', padding: "0 !important", alignItems: 'center',
                    marginTop: '5px',
                    marginBottom: '10px' }}
                >
                  {/* <span className={"strongerTxtLable"}>
                    {t('0101')}:{" "}
                  </span> &nbsp;&nbsp;&nbsp; */}


    {selTransfer===(t('097'))?
        <>
                <span className={"strongerTxtLable"}>
                  {t("0103")}:{" "}
                  </span> &nbsp;&nbsp;&nbsp;
  
  
  <Select
    className="bankSelect"
    labelId="demo-select-small-label"
    id="demo-select-small"
    value={hmPartnerId} 
    onChange={e => setHmPartnerId(e.target.value)} // Update selected value
>
    {hmPartnerList && hmPartnerList.map((item, index) => (
        <MenuItem key={index} value={item}>
            {item} {/* Display partnerId as the label */}
        </MenuItem>
    ))}
</Select>
        </>
        :
        <>
                <span className={"strongerTxtLable"}>
                    {t('0101')}:{" "}
                  </span> &nbsp;&nbsp;&nbsp;
          <FormControl style={{ width: '80%'}}>
                  {!previewScreen ?<RadioGroup
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    // value={selectedValue}
                    // onChange={(e) => {handleRadioChange(e)}}
                    value={toAcctType}
                    onChange={(e)=>{handleDistributorChange(e)}}
                >
                    <Grid container style={{ marginLeft: '20px', marginTop: '0px' }} spacing={0} width={1}>
                       
                      {selTransfer===t('099') || selTransfer===t('098')?
                        <Grid item xs={3} >
                           <FormControlLabel className={`strongerTxtLable borderWhite ${toAcctType === 5 ? 'selectedRadio' : ''}`} value="5" control={<Radio size="small" />} label={t('2480_017')} />
                       </Grid>
                        :
                        <Grid item xs={3} >
                        <FormControlLabel className={`strongerTxtLable borderWhite ${toAcctType === 5 ? 'selectedRadio' : ''}`} value="5" control={<Radio size="small" />} label={t('0102')} />
                       </Grid>
                        }
                        <Grid item xs={4}>
                            <FormControlLabel className={`strongerTxtLable borderWhite ${toAcctType === 6 ? 'selectedRadio' : ''}`} value="6" control={<Radio size="small" />} label={t('0103')} />
                        </Grid>
                    </Grid>
                </RadioGroup> :
                       <span className={"strongerTxtLable borderWhite"} style={{marginLeft:'10px'}} >{toAcctType === '5' ? t("081") : t("6815")}</span>}
            </FormControl>
        </>}
                 


                </Grid>
                <Grid
                  item
                  xs={2}
                  sx={{
                    textAlign: "right",
                    padding: "4px 0px 4px 0 !important",
                  }}
                  className={'displayFlex'}
                >
                </Grid>
              </Grid>
               <Box style={{display:'flex',gap:'20px', marginTop:'10px'}}>
                  <div className={"distributor_input"}>
                      <TextField
                        label={
                        //   <span>
                            
                        //     {toAcctType === 5  ? t("081") : (selTransfer === (t('097')) || toAcctType === 6) 
                        //       ? `${t("6815")} ${t("0105")}` 
                        //       : t("081") 
                        //   }
                        // </span>
                        <span>
                        {`${toAcctType==5 && selTransfer!==(t('097'))? (selTransfer===t('099') || selTransfer===t('098') ? t("5597_dis") :t("5597")) : t("0103")} `}
                       </span>
                        }
                        size="15"
                        value={subDistributorId}
                        onChange={(e)=> setSubDistributorId(e.target.value)}
                        className={"sampleInput mb5"}
                        type="text"
                        id=""
                      />
                    </div>
                
                  <div className={"distributor_input"}>
                      <TextField
                        label={`${toAcctType==5 && selTransfer!==(t('097'))? (selTransfer===t('099') || selTransfer===t('098') ? t("2480_021_dis") :t("2480_021")) : t("2480_022")}`}
                        size="15"
                        value={subDistributorFirstName}
                        onChange={(e) =>setSubDistributorFirstName(e.target.value)}
                        className={"sampleInput mb5"}
                        type="text"
                        id=""
                      />
                    </div>
                   <div className={"distributor_input"}>
                      <TextField
                      value={companyName}
                      onChange={(e)=> setCompanyName(e.target.value)}
                      label={
                        <span>
                         {`${toAcctType==5  && selTransfer!==(t('097')) ? (selTransfer===t('099') || selTransfer===t('098') ? t("2480_023_dis") :t("2480_023")) : t("2480_024")} `}
                        </span>
                      } 
                      className={"sampleInput mb5"}
                        type="text"
                        id=""
                      />
                    </div>
               </Box>
                <Box style={{display:'flex',gap:'20px'}}>
                  <TextField
                          value={mdn}
                          onChange={handleMDNValidation}
                            label={
                              <span>
                                {`${toAcctType==5  && selTransfer!==(t('097')) ? t('030') : t('054')} `}
                                {/* {`${t('030')}`} */}
                              </span>
                            }
                            size="15"
                            className={"sampleInput mb5"}
                            type="text"
                            id=""
                          />
                      <TextField
                            value={subDistributorLastName}
                            onChange={(e)=> setSubDistributorLastName(e.target.value)}
                            label={
                              <span>
                               {`${toAcctType==5  && selTransfer!==(t('097')) ? (selTransfer===t('099') || selTransfer===t('098') ? t("2480_026_dis") :t("2480_026")) : t("2480_025")}`}
                              </span>
                            }
                            size="15"
                            className={"sampleInput mb5"}
                            type="text"
                            id=""
                          />
                    {selTransfer === t("099") || selTransfer === t("098") ? (
    <></>
  ) : (
    <TextField
      value={location}
      onChange={(e) => setLocation(e.target.value)}
      label={
        <span>
          {`${
            toAcctType == 5 && selTransfer !== t("097")
              ? t("2480_027")
              : t("2480_028")
          }`}
        </span>
      }
      size="15"
      className={"sampleInput mb5"}
      type="text"
      id=""
    />
  )
}

                <Button
                    style={{float:"right", margin: '3px 0px 0px',
                    height: '25.5px'}}
                            className={"hoverEffectButton"}
                            size="small"
                            variant="contained"
                            endIcon={<FindInPageRounded />}
                            onClick={handleSearch}
                          >
                            {t('043')}
                          </Button>
                </Box>
               
                </fieldset>
                <Box>
                  </Box>
               
                </Box>
                <Box className={'from_bloc'} style={{marginTop:'30px'}}>
              <fieldset  className={'distributor_fieldset'}>
  {/* <legend className={'distributor_legend'}>From:</legend> */}
  <Box style={{display:'flex',gap:'20px', marginTop:'10px'}}>
  <div className={"distributor_input"}>



  {!previewScreen ? ( 
                      <TextField
                        label={
                          <span>
                           {`${t('0106')} (MXN)`}
                          </span>
                        }
                        InputLabelProps={{
                          shrink: true, // This will prevent label and value from overlapping
                        }}
                        value={mxn}
                        onChange={transactionAmtOnChange}
                        onBlur={transactionAmtOnBlur}
                        onFocus={transactionAmtOnFocus}
                        className={"sampleInput mb5"}
                        type="text"
                        id=""
                      />
                    ) :<TextField
                      label={
                        <span>
                         {`${t('0106')} (MXN)`}
                        </span>
                      }
                      InputLabelProps={{
                        shrink: true, // This will prevent label and value from overlapping
                      }}
                      disabled
                      value={mxn}
                      onChange={transactionAmtOnChange}
                      onBlur={transactionAmtOnBlur}
                      onFocus={transactionAmtOnFocus}
                      className={"sampleInput mb5"}
                      type="text"
                      id=""
                    /> }
                    </div>
                    <div className={"distributor_input"}>
                      <TextField
                        label={
                          <span>
                            {`${t("027")}`}
                            <RedAsterisk>*</RedAsterisk>
                          </span>
                        }
                        
                        className={`sampleInput mb5 ${isMandate ? 'mandateField' : ''}`}
                        type="password"
                        id="transactionpassword1"
                        value={transactionpassword}
                        ref={inputRef}
                        onChange={(e) => setTransactionpassword(e.target.value)}
                        onBlur={handleTransactionBlur}
                      />
                      {/* <span className="red">*</span> */}
                      <ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
                    </div>
                  <div className={"distributor_input"}>


                         <TextField
                            value={noOftimes}
                            onChange={handleNoOftimesChange}
                            onKeyPress={numvalidate}
                            // onChange={(e)=> setNoOftimes(e.target.value)}
                            label={
                              <span>
                                {`${t('0112')}`}
                              </span>
                            }
                           
                            className={"sampleInput mb5"}
                            type="number"
                            id=""
                          />
         




                          {/* <TextField
                            className={"sampleInput mb5"}
                            type="number"
                            id=""
                            label={
                              <span>
                                {`${t('0112')}`}
                              </span>
                            }
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            value={noOftimes}
                            onChange={(e)=>setNoOftimes(e.target.value)}
                          /> */}
                      
                    </div>
                    </Box>
                    <Box style={{display:'flex', gap:'20px'}}>
                    <div className={"distributor_input"}>
                  <TextField
                         label={
                          <span>
                            {`${t('009')}(MXN)`}
                          </span>
                        }
                        disabled
                        size="15"
                        className={"sampleInput mb5"}
                        value={numeral(accountBal).format('0,0.00')}
                        type="text"
                        autocomplete="off"
                        id=""
                      />
                   {/* <Grid container alignItems="center">
                        <Grid item xs={9} style={{ textAlign: "right" }}>
                          <span className={"strongerTxtLable"}>
                           {t('009')}(MXN)
                          </span>
                        </Grid>
                        <Grid item xs={3} style={{ textAlign: "left" }}>
                          <span className={"strongerTxtLable"} style={{ textAlign: "center", paddingLeft: "25px" }} >
                           {accountBal}
                          </span>
                        </Grid>
                      </Grid> */}
                      </div>
               
                  <div className={"distributor_input"}>
                  <TextField
                         label={
                          <span>
                            {`${t('0111')}(MXN)`}
                          </span>
                        }
                        disabled
                        size="15"
                        className={"sampleInput mb5"}
                        value={numeral(creditBal).format('0,0.00')}
                        // {creditBal}
                        type="text"
                        autocomplete="off"
                        id=""
                      />
                   {/* <Grid container alignItems="center">
                        <Grid item xs={9} style={{ textAlign: "right" }}>
                          <span className={"strongerTxtLable"}>
                            {t('0111')}(MXN)
                          </span>
                        </Grid>
                        <Grid item xs={3} style={{ textAlign: "left" }}>
                          <span  className={"strongerTxtLable"}
                            style={{ textAlign: "center", paddingLeft: "25px" }}
                          >{creditBal}
                          </span>
                        </Grid>
                      </Grid> */}
                      </div>
                   
                   
                    <div className={"distributor_input"}>
                      <TextField
                        label={
                          <span>
                           {` ${t('0107')}(MXN)`}
                          </span>
                        }
                        InputLabelProps={{
                          shrink: true, // This will prevent label and value from overlapping
                        }}
                        className={"sampleInput mb5"}
                        type="text"
                        id=""
                        value={thresholdAmount}
                        // onChange={(e)=>setThresholdAmount(e.target.value)}
                        onChange={thresholdAmountOnChange}
                        onBlur={thresholdAmountOnBlur}
                        onFocus={thresholdAmountOnFocus}
                      />
                    </div>
                </Box>
 </fieldset>
            
              </Box>
              <br />
              <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "0px",
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "8px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
              {errorMsg && (
                  <tr>
                    <td colSpan={6} align="center">
                      <div className="redTxt" style={{color: 'red'}}>{errorMsg}</div>
                    </td>
                  </tr>
               )}
                  {/* <span className={"strongerTxtLable"}>
                    {t('059')} : {totalRecordsSatisfied}
                  </span> */}
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
       {!previewScreen && !searching ? (  <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {currentRows.length >0 ?
                    <> 
                    <span className={"strongerTxtLable"}>
                    {t('059')} : {totalRecordsSatisfied}
                  </span>
                  <span className={"strongerTxtLable"}>
                    &nbsp; / &nbsp;
                    {t('060')} : {startRecord} - {endRecord ? endRecord : 0}
                    </span></>   :
                  <></>}
                </Grid>) : 
                
                <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {currentRows.length >0 ?
                    <> 
                    <span className={"strongerTxtLable"}>
                    {t('059')} : {selectrowEndPage}
                  </span>
                  <span className={"strongerTxtLable"}>
                    &nbsp; / &nbsp;
                    {t('060')} : {startRecord} - {selectrowEndPage ? selectrowEndPage : 0}
                    </span></>   :
                  <></>}
                </Grid> }

              </Grid>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">     
                  <TableHead>
                    <TableRow className={'darkgray subdistributor_table'}>
                      {!previewScreen ? (<TableCell className={'removespacing'} style={{background:'#fff'}}>
                        {currentRows.length<1 && isLoading ? <div style={{width:'32px'}}>&nbsp;</div> :   
                      //   <Checkbox
                      // //  checked={checkedRows.length === filteredSubDistributorList.length && checkedRows.length > 0}
                      // checked={((checkedRows?.length || 0) === (filteredSubDistributorList?.length || 0) && (checkedRows?.length || 0) > 0) && headerCheckbox}
                      //  onChange={handleHeaderCheckboxChange}
                      //   />
                      <Checkbox
                      checked={
                        filteredSubDistributorList.every(row => checkedRows.includes(row.partnerId)) && 
                        filteredSubDistributorList.length > 0
                      }
                       onChange={handleHeaderCheckboxChange}
                    />
                        }
                      
                      </TableCell>) : ''}
                      {selTransfer===t('099') || selTransfer===t('098') ?
                       <>
                      <TableCell>{toAcctType==5 ? t("008") : t("0103")}</TableCell>
                       </>  : 
                      <TableCell>{toAcctType==5 && selTransfer!==(t('097')) ? t("081") : t("0103")} {toAcctType===6 ? "ID" : ''}</TableCell>
                    }
                      <TableCell align="right" style={{ paddingInline: '15px' }}>{toAcctType==6 || selTransfer===(t('097'))? t("6815") : '' } {t('093')}</TableCell>
                      {selTransfer===t('099') || selTransfer===t('098') ?
                      <TableCell align="right">{toAcctType==5 ? t("2480_0211") : t("2480_022")}</TableCell>
                       : 
                      <TableCell align="right">{toAcctType==5 && selTransfer!==(t('097')) ? t("2480_021") : t("2480_022")}</TableCell>
                    }
                     {selTransfer===t('099') || selTransfer===t('098') ? 
                      <TableCell align="right">{toAcctType==5 ? t("2480_0212") : t("2480_025")}</TableCell> 
                     :
                      <TableCell align="right">{toAcctType==5 && selTransfer!==(t('097')) ? t("2480_026") : t("2480_025")}</TableCell> }
                     {selTransfer!==(t('098')) && <> <TableCell align="right">{t('0113')}(MXN)</TableCell>
                     <TableCell align="right">{t('0114')}(MXN)</TableCell></>}
                      
                      
                      <TableCell align="right" >{t('0106')}(MXN)</TableCell>
                      {selTransfer!==(t('098')) && <TableCell align="right">{t('0115')}(MXN)</TableCell>}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                  { (
                    ((currentRows.length>0 && isLoading) ? currentRows.map((list, index) =>
                      <TableRow key={index} className={''}
                      >
                          {!previewScreen ?<TableCell className={'removespacing'} align="center">
                         {!list.maxFundLimt ?"":
                          <Checkbox
                          
                          checked={checkedRows.includes(list.partnerId)}
                          onChange={(event) => handleRowCheckboxChange(event, list.partnerId)}
                        />
                        } 
                          
                        </TableCell> : ''}
                        <TableCell component="th" scope="row" align="center">
                          {!previewScreen ? list.partnerId : list.partnerId}
                        </TableCell>
                        <TableCell align="center">{list.salespersonMDN}</TableCell>
                        <TableCell align="center" style={{overflowWrap:'anywhere'}}>{list.partnerFirstName}</TableCell>
                        <TableCell align="center" style={{overflowWrap:'anywhere'}}>{list.partnerLastName}</TableCell>
                        {selTransfer!==(t('098')) && 
                        <><TableCell align="center">{!previewScreen ? <a style={{ color: '#3399FF', cursor: 'pointer' }} onClick={() => handleClickOpen(list.maxFundLimt, list.partnerId)}>{list.maxFundLimt}</a> : list.maxFundLimt}</TableCell> 

                        
                        <TableCell align="center">{numeral(list.acctBal).format('0,0.00')}</TableCell></>}
                        <TableCell align="center" width={selTransfer!==(t('098')) ? "0%" : "14%" } style={!previewScreen ? { padding: '0', paddingBottom: '8px' } : {}}>
                          
                          {!previewScreen ? <TextField className={"textFieldSmall"}  id={`transferAmt-${list.partnerId}`}   style={{ width: "80%", margin: '1px 0px', height: '17px' }} type="text" value={list.transferAmt} 
                          onChange={(event) => handleInputChange(event, list.partnerId, 'transferAmt')}
                          onBlur={(event) => handleBlurInput(event, list.partnerId, 'transferAmt')} 
                          onFocus={(event) => handleFocusInput(event, list.partnerId, 'transferAmt')} 
                          inputRef={(el) => inputRefs.current[list.partnerId] = el} /> :
                          list.transferAmt}</TableCell>
                        {selTransfer!==(t('098')) && 
                        <TableCell align="center" style={!previewScreen ? { padding: '0', paddingBottom: '8px' } : {}}
                        >{!previewScreen ? <TextField   inputProps={
                            { readOnly: true, }
                        } className={"textFieldSmall"} style={{ width: "80%", margin: '1px 0px', height: '17px' }} type="text" value={numeral(list.acctBalTransferAmt).format('0,0.00')} onChange={(event) => handleInputChange(event, list.partnerId, 'acctBalTransferAmt')} /> : list.acctBalTransferAmt}</TableCell>
                      } 
                      </TableRow>
                   ) : <></>)) }
                   {((currentRows.length<1 && isLoading) ? <><TableRow><TableCell  align="center" style={{color: 'red'}} colSpan={9}>
                    
                    {/* {t('085')} */}
                       {toAcctType==5 ? (t("2480_008")) : (t("2480_009"))} - '{partnerId}'
                    </TableCell></TableRow></> : '') }
                       
                       
                        {!isLoading ?  <><TableRow><TableCell  align="center" colSpan={9}><div className={'spinnerDiv'}> {t("Processing...")}<CircularProgress size="sm" /></div></TableCell></TableRow></> : ''}

                  </TableBody>
                  
                </Table>
              </TableContainer>
              <br />
             {!previewScreen ? ( <Table><tfoot>
                <Box style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                <Box
                  sx={{
                    textAlign: "right",
                    padding: "4px 0px 4px 0 !important",
                  }}
                  className={'displayFlex'}
                >
                  <span className={"strongerTxtLable"}>{t('0104')}: </span>
                 
                <Tabs
                    className={'pageTabs'}
        indicatorColor="none"
        name="pagecount"
        onChange={handlePageSelectChange}
        value={perpage}
        size="1"
        id="pagecount"
                >
                    <Tab sx={styleObj} value={25} label="25" />
                    <Tab sx={styleObj} value={50} label="50" />
                    <Tab sx={styleObj} value={75} label="75" />
                    <Tab sx={styleObj} value={100} label="100" />
                </Tabs>
                </Box>

                {currentRows.length ?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
                </Box>
             
          <tr>
         
          </tr>
        </tfoot>
        </Table>) : ''}
              <TableContainer
                component={Paper}
                style={{ boxShadow: "none", background: "transparent" }}
              >
                <Table
                  sx={{ minWidth: 650, marginTop: "20px" }}
                  size="small"
                  aria-label="a dense table"
                  className={"subdistributor"}
                >
                  <TableBody>
                    <TableRow style={{ background: "#fff" }} className={'totalTransferAmountDisplay'}>
                      <TableCell
                        colSpan={4}
                        style={{ paddingTop: 0, padding: 0, borderBottom: "0", textAlign: 'right' }}
                      >
                        <span className={'strongerTxt'}>{t("6816")}</span>
                      </TableCell>
                      <TableCell
                        style={{
                          paddingBottom: "0",
                          paddingTop: "0",
                          borderBottom: "0",
                        }}
                      >
                        <TextField
                          width={1}
                          className={"smallerTxt textFieldSmall"}
                          type="text"
                          readOnly
                          placeholder="0.00"
                          value={totalTransferAmount}
                        />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
              <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "right",
                  marginTop: "0px",
                  marginLeft: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{
                    textAlign: "right",
                    padding: "0 !important",
                    display: "flex",
                    gap: "8px",
                    justifyContent: "flex-end",
                    marginBottom: '15px'
                  }}
                >
                 {!previewScreen ?( <><Button
                    className={"hoverEffectButton"}
                    size="small"
                    variant="contained"
                    onClick={previewDistributor}
                    endIcon={<RemoveRedEyeRounded />}
                  >
                    {t('0116')}
                  </Button>
                  <Button
                    className={"hoverEffectButton"}
                    size="small"
                    variant="contained"
                    onClick={() => navigate(-1)}
                    endIcon={<KeyboardReturn />}
                  >
                    {t('242410')}
                  </Button> </>) : (
                    <>
                    <Button
                    className={"hoverEffectButton"}
                    size="small"
                    variant="contained"
                    endIcon={<SendIcon />}onClick={()=>sumitFund()}>
                    {t('242409')}
                  </Button>
                  <Button
                    className={"hoverEffectButton"}
                    size="small"
                    variant="contained"
                    onClick={handlePreviewReturn}
                    endIcon={<KeyboardReturn />}
                  >
                    {t('242410')}
                  </Button>
                    </>
                  ) }
                </Grid>
              </Grid>
            </Box>
             </> 
              : <>     
                {/* <table width="100%">
                            <tbody>
                              <tr><td width="100%" class="headingText" style={{paddingLeft: '8px'}}>{t('096')}</td></tr>
                             </tbody>
                </table> */}
                             <br></br>
                             <br></br> 
                            <table align="center" border='0' cellPadding='0' cellSpacing='1' width='100%'>
                                        
                            <tr>
                                <td class='redTxt' align="center" colspan='4'>
                                    {t('047')}
                                    {/*The Fund Transfer Options are not available for Single Fund Source Hierarchy*/}
                                </td>
                            </tr>
                        </table></>}



          
          </td>
        </tr>
        {/* MODAL STARTS HERE */}
        <Dialog
          fullScreen={fullScreen}
          open={open}
          onClose={handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "25px" }}
            className={"headerTxt"}
            align="center"
          >
            {"Maximum limit of account"}
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
            }}
          >
            <CloseIcon />
          </IconButton>
          <DialogContent>
            <DialogContentText>
              <TableContainer component={Paper} style={{ boxShadow: "rgb(25, 118, 210) 0px 6px 15px", borderRadius: '8px' }}>
                <Table
                  sx={{ minWidth: 500 }}
                  size="small"
                  aria-label="a dense table"
                  className={"max_Limit"}
                >
                  <TableHead>
                    <TableRow className={"darkgray"}>
                      <TableCell className={"whiteBldTxt"}>
                        {t('0109')} : {partnerId}
                      </TableCell>
                      <TableCell className={"whiteBldTxt"}>
                        {t('070')} : {maxLimit}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableRow className={""}>
                    <TableCell
                      className={"strongerTxt"}
                      style={{ textAlign: "right" }}
                    >
                     {t('0113')}(USD) :
                    </TableCell>
                    <TableCell className={"strongerTxt"}>
                      <TextField
                        className={"textFieldSmall"}
                        type="text"
                        value={distributorIdentity}
                        onChange={(e) => maxLimitOnChange(e)}
                        onBlur={(e) => maxLimitChangeOnBlur(e)}
                        onFocus={(e) => maxLimitChangeOnFocus(e)}
                        style={{ height: "17px",marginTop: '-6px' }}
                      />
                    </TableCell>
                  </TableRow>
                </Table>
              </TableContainer>
              <div align="center" className={"maxLimit_buttons"} gap={1}>
                <Button className={'hoverEffectButton'} onClick={handleSubmit} size="small" variant="contained" endIcon={<SendIcon />}> 
                 {t('242409')}
                </Button>
                <Button className={'hoverEffectButton'} onClick={handleClose} size="small" variant="contained" endIcon={<KeyboardReturn />}>
                    {t('242410')}
                </Button>
              </div>
            </DialogContentText>
          </DialogContent>
        </Dialog>
        {/* MODAL ENDS HERE */}
        <tr height="60px">
          <td colSpan={2}>
            <Footer />
          </td>
        </tr>
      </tbody>
    </table>
  );
}

export default DistributorFundTransferSample;