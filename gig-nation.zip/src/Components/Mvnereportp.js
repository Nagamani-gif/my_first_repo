/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import { toast } from 'react-toastify';
import * as XLSX from 'xlsx';
import dayjs from 'dayjs';
import { jsPDF } from 'jspdf';
import { saveAs } from 'file-saver';
import TopMenu from "./TopMenu";
import { Header, Footer, PaymentManagerHeading, LeftBgImage, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, CircularProgress, FormControl, FormControlLabel, FormLabel, Grid, InputLabel, Menu, MenuItem, Pagination, Paper, Radio, RadioGroup, Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField } from "@mui/material";
import React, { useState, useEffect, useCallback, useRef } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CancelRounded, CloudDownload, KeyboardReturn } from "@mui/icons-material";
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import ExcelJS from 'exceljs';
import SendIcon from '@mui/icons-material/Send';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { ToastContainer } from 'react-toastify';


const Mvnereportp = () => {
  sessionStorage.setItem("selectedLink", "e_transactions");
 const toastId = useRef(null);
  const { t } = useTranslation();
  const localeVar = i18n.language;
  const now = dayjs();  
  const midnightToday = dayjs().startOf('day');
  const exampleData = JSON.parse(localStorage.getItem("userData"))
  const [partnerLoginId, setPartnerLoginId] = useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [startDateTime, setStartDateTime] = useState(midnightToday);
    const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
    const [endDateTime, setEndDateTime] = useState(now);
    const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));
     
  const [perpage, setPerPage] = useState(10);
  const [anchorEl, setAnchorEl] = useState();
  const closeTimeoutRef = useRef(null);

let reportDays = process.env.REACT_APP_ReportDays;
const [fromDate, setFromDate] = useState(dayjs().format('DD/MM/YYYY HH:mm:ss'));
const [toDate, setToDate] = useState(dayjs().format('DD/MM/YYYY HH:mm:ss'))
 const [submitted, setSubmitted] = useState(false);
  const [hierarchyMode, setHierarchyMode] = useState('N');

  const [subscriberCellularNumber, setSubscriberCellularNumber] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [canalID, setCanalID] = useState('');
  const [terminalID, setTerminalID] = useState('');
  const [sucursalID, setSucursalID] = useState('');

  const [recordsFound, setRecordsFound] = useState(0);
   const transactionIdRef = useRef(null);
   const [mnvoList, setMnvoList] = useState([]);
   const [selectedMnvo, setSelectedMnvo] = useState(' ');
   const [carrierList, setCarrierList] = useState([]);
  const [selectedCarrier, setSelectedCarrier] = useState(' ');
  const [apply,setApply] =useState(false);

  let startRecord = 0;
  let endRecord = 10;

 const handleEndDateTimeChange = (newValue) => {
    setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm') : null;
    setEndDate(formattedDateTime);
  };
    const handleStartDateTimeChange = (newValue) => {
    setApply(false);
    setStartDateTime(newValue); 
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm') : null;
    setStartDate(formattedDateTime);
    console.log("startDate::::::",newValue)
    console.log("startDate::::::",formattedDateTime)
    };


//date validation 
const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
   
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      

    }
    return false;
  }

  return true;
};
const clearData = () => {
       setHierarchyMode('N');
       setSubscriberCellularNumber('')
       setPaymentAmount('')
       setCanalID('')
       setTerminalID('')
       setSucursalID('')
      setSelectedCarrier(' ')
      setSelectedMnvo(' ');
      setStartDateTime(midnightToday);
      setEndDateTime(now);
      setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'))
      setEndDate(now.format('DD/MM/YYYY HH:mm:ss'))
      setStatus(' ')
       
    }

  const navigate = useNavigate();

  console.log("totalRecords++++++++++++", totalRecords)
  const handleChangePage = (event, newPage) => {

    const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       submitted
     });
 
  if (!isValid) {
  setSubmitted(false);  // reset submit flag
  return;
}
if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmitted(false);
    }
return false;

}

    setPage(newPage);
  };


const totalPages = Math.ceil(totalRecords / recordsPerPage);

 startRecord = (page - 1) * perpage + 1;
 endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);


 const handleSubmit = () => {

   if (paymentAmount.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(paymentAmount)) {
        if(!toast.isActive(toastId.current) )  {

              toastId.current =  toast.error(`${t('alrt_01')} in ${t('mvnereport21')}.`);
   }
      }


   const isValid = validateDateRange({
      startDateTime,
      endDateTime,
      reportDays,
      toast,
      toastId,
      t
     }
);

  if (!isValid){
  setApply(false);
  return;
} 

    startRecord=0;
    endRecord=10;
    fetchData();         // Immediate fetch
    setPage(1);
    setApply(true);
    setSubmitted(true);  // Enable watching page changes
  };

  useEffect(() => {
    // Set the browser title
    document.title = t('2472_018');
  }, []);



  useEffect(() => {
    if (submitted) {
      fetchData();
    }
  }, [page,submitted]); // Only runs if page changes and form was submitted


  const fetchData = async () => {

  setIsLoading(true);
    //debugger;

    if (new Date(fromDate) > new Date(toDate)) {
  //  toast.error('From Date should not be before To Date');
  toast.error(t('error.date.one'));
    return;
  }



    localStorage.removeItem('channels');
    setIsLoading(true);
    try {
    //  const apiUrl = window.config.apiUrlJasper+ '/MVNEReportApi';
      const apiUrl = window.config.apiUrlJasper +'/MVNEReportApi';
      console.log(apiUrl,"<=====apiUrlJasper")

      const response = await axios.post(apiUrl, {

        userName,
        password,
        localeVar,
        // piPartnerId: partnerLoginId,
        piPartnerId: partnerLoginId,
        piSubscriberMdn: subscriberCellularNumber,
        piPaymentAmount: paymentAmount,
        piStatus: status,
        isAdmin: 'N',
        fromDate: startDate,
        toDate: endDate,
        carrierId: selectedCarrier,
        piLevelFlag: (hierarchyMode + ''),
        piMVNOId: selectedMnvo,
        piCanalId: canalID,
        piTerminalId: terminalID,
        piSucursalId: sucursalID,
          //piBegRecNo: startRecord,
      // endRecNo: endRecord < 10 ? '10' :endRecord,
       piBegRecNo: (startRecord) + '',
        endRecNo: ((endRecord < 10 ? '10' : endRecord) + ''),
        piDownload: 'N'

      });
      console.log("response::::::", ((endRecord < 10 ? '10' : endRecord) + ''));
console.log("response::::::", response.data);


const dataArray = response.data.summaryConfigArray || [];

setItems(dataArray);

if (dataArray.length > 0) {
  setTotalRecords(dataArray[0].noRows || 0);
  setRecordsFound(dataArray[0].noRows || 0);
} else {
  setTotalRecords(0);
  setRecordsFound(0);
      }

return dataArray;
   
    }
    catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReturn = () => {
    navigate(-1);
  };
 



  const RedAsterisk = styled('span')({
    color: 'red',
  });




  const highlightSelectedLink = (e) => {
    var x = document.querySelector(".subLinkVisited");
    if (x !== null) {
      x.classList.replace("subLinkVisited", "subLink");
    }
    e.target.classList.replace("subLink", "subLinkVisited");
  }


  const [statusList, setStatusList] = useState([]);
  const [status, setStatus] = useState(' ');

  const repChannels = async () => {
    try {
      const apiUrl = window.config.apiUrlJasper +'/orderStatus';
      const response = await axios.post(apiUrl, {
        userName,
        password,
        localeVar,
      });

      const statusArray = response.data?.OrderStatusArray;
      if (Array.isArray(statusArray)) {
        const mapped = statusArray.map((item) => ({
          value: item.OrderStateId,
          label: item.Description,
        }));
        setStatusList(mapped);
      } else {
        console.error('OrderStatusArray not found in response');
        setStatusList([]);
      }
    } catch (error) {
      console.error('Error fetching channels:', error);
    }
  };

  useEffect(() => {
    repChannels();
    fetchPartnerStatus();
    fetchCarriers();

  }, []);



    // Fetch Carrier List
  const fetchCarriers = async () => {
    try {
      const apiUrl = window.config.apiUrlJasper +'/getMVNECarrierList';
      const response = await axios.post(apiUrl, {
        userName,
        password,
        localeVar,
      });

      const carriers = response.data?.mnveCarrierList;
      if (Array.isArray(carriers)) {
        const mapped = carriers.map((item) => ({
          value: item.mnveId,
          label: item.mnveName,
        }));
        setCarrierList(mapped);
      } else {
        console.error('mnveCarrierList not found in response');
        setCarrierList([]);
      }
    } catch (error) {
      console.error('Error fetching carriers:', error);
    }
  };

  const fetchMVNO = async (mvneId) => {

      if (mvneId === ' ')
        mvneId='';
  try {
    const apiUrl = window.config.apiUrlJasper+ '/getMVNOCodeLOV';
    const response = await axios.post(apiUrl, {
      userName,
      password,
      localeVar,
      mvneId,
    });

    const statusArray = response.data?.mvnoDetailsArray;

    if (Array.isArray(statusArray)) {
      const mapped = statusArray.map((item) => ({
        value: item.mvnoId, // Set mvnoCode as the value
        label: `${item.mvnoCode} | ${item.interfaceName}`, // Combine both for display
      }));
      setMnvoList(mapped);
    } else {
      console.error('mvnoDetailsArray not found in response');
      setMnvoList([]);
    }
  } catch (error) {
    console.error('Error fetching MVNO:', error);
  }
};


  // Fetch MVNO list when carrier is selected
  useEffect(() => {
    if (selectedCarrier) {
      fetchMVNO(selectedCarrier);
    } else {
      setMnvoList([]);
      setSelectedMnvo(' ');
    }
  }, [selectedCarrier]);

  const [partnerStatusList, setPartnerStatusList] = useState([]);

  const fetchPartnerStatus = async () => {
    try {
      const apiUrl = window.config.apiUrlJasper+ '/getPartnerStatus';
      const response = await axios.post(apiUrl, {
        userName,
        password,
        localeVar
      });

      const statusArray = response.data?.PartnerStatus;
      if (Array.isArray(statusArray)) {
        const mapped = statusArray.map((item) => ({
          value: item.Status.trim(), // remove trailing space
          label: item.Description,
        }));
        setPartnerStatusList(mapped);
      } else {
        console.error('PartnerStatus not found in response');
        setPartnerStatusList([]);
      }
    } catch (error) {
      console.error('Error fetching partner status:', error);
    }
  };


  const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };


















 const fetchDataDownload = async () => {


 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       submitted
     });
 
if (!isValid) {
  setSubmitted(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmitted(false);
    }
return false;

}



    try {
     // const localeVar = 'en';
      const apiUrlDownload =window.config.apiUrlJasper +'/MVNEReportApi';
      const response = await axios.post(apiUrlDownload, {
      userName,
        password,
        localeVar,
        // piPartnerId: partnerLoginId,
        piPartnerId: partnerLoginId,
        piSubscriberMdn: subscriberCellularNumber,
        piPaymentAmount: paymentAmount,
        piStatus: status,
        isAdmin: 'N',
        fromDate: startDate,
        toDate: endDate,
        carrierId: selectedCarrier,
        piLevelFlag: (hierarchyMode + ''),
        piMVNOId: selectedMnvo,
        piCanalId: canalID,
        piTerminalId: terminalID,
        piSucursalId: sucursalID,
        piBegRecNo:'',
        endRecNo:  '',
        piDownload: 'Y'
        // partnerLoginId,
      });

        if (!Array.isArray(response.data.summaryConfigArray)) {
      throw new Error('Invalid API response: Expected array');
    }
     console.log("response.data.data",response.data.summaryConfigArray)
       return response.data.summaryConfigArray;
    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };


























  //excel

  const handleDownload = async () => {

    const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('MVNE_Report');

    const numberOfColumns = 20;

  // Title row
  const headingRow1 = worksheet.addRow([localeVar === 'en' ? "MVNE Report" : "Informe de MVNE"]);
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    headingRow1.getCell(1).font = { bold: true };
    headingRow1.getCell(1).alignment = { horizontal: 'center' };


  const total = totalRecords || items.length;
  const startRecord = (page - 1) * perpage + 1;
  const endRecord = total > 0
    ? Math.min(startRecord + perpage - 1, total)
    : (page === 1 ? 10 : page * perpage);

  const infoRow = worksheet.addRow([]);
  worksheet.mergeCells(infoRow.number, 1, infoRow.number, 10);
  worksheet.mergeCells(infoRow.number, 11, infoRow.number, numberOfColumns);

  const leftCell = infoRow.getCell(1);
  const rightCell = infoRow.getCell(11);

  leftCell.value = `${t('032')}: ${total}`;
  leftCell.font = rightCell.font = { bold: true };
  leftCell.alignment = { horizontal: 'left' };
  rightCell.alignment = { horizontal: 'right' };

  worksheet.addRow([]); // spacing row

    const columnHeaders = [
    t('mvnereport1'), t('mvnereport2'), t('mvnereport3'), t('mvnereport4'),
    t('mvnereport5'), t('mvnereport6'), t('mvnereport7'), t('mvnereport8'),
    t('mvnereport9'), t('mvnereport10'), t('mvnereport11'), t('mvnereport12'),
    t('mvnereport13'), t('mvnereport14'), t('mvnereport15'), t('mvnereport16'),
    t('mvnereport17'), t('mvnereport18'), t('mvnereport19')
    ];
    const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });

  // Helper function
  const safeText = (val) => val === null || val === undefined || val === '' ? '---' : val;

function safeNumber(value) {
  const num = parseFloat(value);
  return !isNaN(num) ? Number(num.toFixed(2)) : 0;
}
  // Data rows
    if (Array.isArray(downloadItems)) {
      downloadItems.forEach(item => {
        const dataRow = worksheet.addRow([
        safeText(item.transactionDate),
        safeText(item.transactionID),
        safeText(item.authorizationID),
        safeText(item.distributorName),
        safeText(item.distributorID),
        safeText(item.supervisiorIDorParentID),
        safeText(item.mainDistributorIDlevel1),
        safeText(item.subscriberCellularNumber),
       safeNumber(item.rechargeAmount).toFixed(2),
        safeText(item.terminalID),
        safeText(item.canalID),
        safeText(item.sucurscalID),
        safeText(item.trancationCatgory),
        safeText(item.status),
        safeText(item.careerID),
        safeText(item.carrieReferenceID),
        safeText(item.MVNOID),
        safeText(item.MVNOCODE),
        safeText(item.errorDescription),
        ]);
        dataRow.eachCell(cell => {
        cell.alignment = { horizontal: 'center' };
          cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
          };
        });
      });
    } else {
      console.error("items is not an array:", items);
    }

    worksheet.addRow([]);
    const endOfReportRow = worksheet.addRow([t('0171')]);
  worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, numberOfColumns);
    const endOfReportCell = endOfReportRow.getCell(1);
    endOfReportCell.font = { italic: true, underline: true, bold: true };
    endOfReportCell.alignment = { horizontal: 'center' };

  worksheet.columns = Array(numberOfColumns).fill({ width: 40 });

    worksheet.protect('yourPassword', {
      selectLockedCells: true,
      selectUnlockedCells: true,
      formatCells: false,
      formatColumns: false,
      formatRows: false,
      insertColumns: false,
      insertRows: false,
      insertHyperlinks: false,
      deleteColumns: false,
      deleteRows: false,
      sort: false,
      autoFilter: false,
      pivotTables: false
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'MVNE_Report.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  //for pdf
  //for pdf

  const handleDownloadPdf = async () => {
    const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

    const tableBody = [];

    const headers = [
      t('mvnereport1'), t('mvnereport2'), t('mvnereport3'), t('mvnereport4'),
      t('mvnereport5'), t('mvnereport6'), t('mvnereport7'), t('mvnereport8'),
      t('mvnereport9'), t('mvnereport10'), t('mvnereport11'), t('mvnereport12'),
      t('mvnereport13'), t('mvnereport14'), t('mvnereport15'), t('mvnereport16'),
      t('mvnereport17'), t('mvnereport18'), t('mvnereport19')
    ];

    tableBody.push(headers.map(header => ({ text: header, style: 'tableHeader' })));

    if (!Array.isArray(downloadItems) || downloadItems.length === 0) {
      console.warn("No data found to export");
      return;
    }

  const total = totalRecords || items.length;
  const startRecord = (page - 1) * perpage + 1;
  const endRecord = total > 0
    ? Math.min(startRecord + perpage - 1, total)
    : (page === 1 ? 10 : page * perpage);

    downloadItems.forEach(item => {
      const row = [
        item.transactionDate ?? '', item.transactionID ?? '', item.authorizationID ?? '', item.distributorName ?? '',
        item.distributorID ?? '', item.supervisiorIDorParentID ?? '', item.mainDistributorIDlevel1 ?? '',
        item.subscriberCellularNumber ?? '',
        !isNaN(parseFloat(item.rechargeAmount)) ? parseFloat(item.rechargeAmount).toFixed(2) : '---',
        item.terminalID ?? '',
        item.canalID ?? '', item.sucurscalID ?? '', item.trancationCatgory ?? '', item.status ?? '',
        item.careerID ?? '', item.carrieReferenceID ?? '', item.MVNOID ?? '', item.MVNOCODE ?? '',
        item.errorDescription ?? ''
      ];
      tableBody.push(row);
    });

    const docDefinition = {
      content: [
        {
          text: localeVar === 'en' ? "MVNE Report" : "Informe de MVNE",
          style: 'title',
          alignment: 'center',
          margin: [0, 0, 0, 10]
        },
        {
        columns: [
          { text: `${t('032')}: ${total}`, alignment: 'left', style: 'infoText' },
        ],
        margin: [0, 0, 0, 5]
      },
      {
          style: 'tableExample',
          table: {
            headerRows: 1,
            widths: Array(45).fill(45),
            body: tableBody
          },
          layout: {
            fillColor: function (rowIndex) {
              return rowIndex === 0 ? '#3399FF' : null;
            }
          }
        },
        {
          text: t('0171'),
          style: 'endText',
          alignment: 'center',
          margin: [0, 10, 0, 0]
        }
      ],
      styles: {
        title: { fontSize: 12, bold: true },
      infoText: { fontSize: 8, bold: true, margin: [0, 0, 0, 5] },
        tableExample: { margin: [0, 5, 0, 15] },
        tableHeader: { bold: true, fontSize: 8, color: 'white', fillColor: '#3399FF' },
        endText: { italics: true, bold: true, decoration: 'underline', fontSize: 9 }
      },
      pageOrientation: 'landscape',
      defaultStyle: {
      fontSize: 8
      },
      pageSize: 'A3'  // <-- add this to allow wide tables
    };

    pdfMake.createPdf(docDefinition).download('MVNE_Report.pdf');
  };


const handleDownloadCsv = async () => {
    const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

  if (!Array.isArray(downloadItems) || downloadItems.length === 0) {
    console.error("items is not defined or empty");
    return;
  }


  const headers = [
    t('mvnereport1'), t('mvnereport2'), t('mvnereport3'), t('mvnereport4'),
    t('mvnereport5'), t('mvnereport6'), t('mvnereport7'), t('mvnereport8'),
    t('mvnereport9'), t('mvnereport10'), t('mvnereport11'), t('mvnereport12'),
    t('mvnereport13'), t('mvnereport14'), t('mvnereport15'), t('mvnereport16'),
    t('mvnereport17'), t('mvnereport18'), t('mvnereport19')
  ];

  const total = totalRecords || items.length;
  const startRecord = (page - 1) * perpage + 1;
  const endRecord = total > 0
    ? Math.min(startRecord + perpage - 1, total)
    : (page === 1 ? 10 : page * perpage);
  
  const title = `${localeVar === 'en' ? "MVNE Report" : "Informe de MVNE"}`;

// Number of columns
const columnCount = headers.length;
const centerIndex = Math.floor(columnCount / 2);

// Title row: put title in the middle column
const titleRow = Array(columnCount).fill("");
titleRow[centerIndex] = title;

// Second line: only left info
const infoRow = Array(columnCount).fill("");
infoRow[0] = `${t('032')}: ${total}`;

// Build CSV
let csvContent = titleRow.join(",") + "\n";
csvContent += infoRow.join(",") + "\n\n";
csvContent += headers.join(",") + "\n";




  downloadItems.forEach((item, index) => {
    const row = [
    item.transactionDate ?? '',
    item.transactionID ?? '',
    item.authorizationID ?? '',
    item.distributorName ?? '',
    item.distributorID ?? '',
    item.supervisiorIDorParentID ?? '',
    item.mainDistributorIDlevel1 ?? '',
    item.subscriberCellularNumber ?? '',
    item.rechargeAmount, // raw value - we'll format it below
    item.terminalID ?? '',
    item.canalID ?? '',
    item.sucurscalID ?? '',
    item.trancationCatgory ?? '',
    item.status ?? '',
    item.careerID ?? '',
    item.carrieReferenceID ?? '',
    item.MVNOID ?? '',
    item.MVNOCODE ?? '',
    item.errorDescription ?? ''
    ];

    // Debug: Ensure every row has 20 columns
    if (row.length !== 20) {
      console.warn(`Row ${index} does not have 20 columns`, row);
    }

  const csvRow = row.map((field, colIndex) => {
    // For rechargeAmount (index 8), format to 2 decimal places
    if (colIndex === 8) {
      const num = parseFloat(field);
      const formatted = !isNaN(num) ? num.toFixed(2) : '0.00';
      return `"${formatted}"`;
    }

      const safeValue = String(field).replace(/"/g, '""');
    return `"${safeValue}"`;
    }).join(',');

    csvContent += csvRow + '\n';
  });

const footerRow = Array(columnCount).fill("");
// centerIndex = Math.floor(columnCount / 2); // middle column
footerRow[centerIndex] = t('0171');
csvContent += footerRow.join(",") + '\n';


const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;


  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', 'MVNE_Report.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          <Header />
          <tr height="65px">
            <PaymentManagerHeading />
            <TopMenu menuLink={localeVar === 'en' ? "MVNE Report" : "MVNE Soporte"} />
          </tr>

          <tr>
            {/* <td valign="top"style={{ borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)"}}nowrap="nowrap">

    </td> */}

               <div style={{ display: 'flex' }}>
                 <LeftBgImage1 />
             </div>
 
            <td valign="top">
              <title>{t('2480_112')}</title>
              <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                <tbody>
                  <tr>
                    <td>
                      <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                        <tbody>
                          {/* MIDDLE ROW STARTS */}
                          <tr>
                            <td>
                              <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" height="100%">
                                <tbody>
                                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
                                    <Tabs style={{ minHeight: '35px' }}>
                                      <NavLink
                                        to="/mvnereportp"
                                        onClick={(e) => highlightSelectedLink(e)}
                                        // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
                                        className={({ isActive }) =>
                                          isActive ? 'activeProfilemenu' : `profile_menu 
            ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
                                        }
                                      ><Tab label={t('a_mvnereportp')} /></NavLink>
                                    </Tabs>
                                  </Box>
 <div className={'mL8 input_boxess'}>
                                  <tr valign="top">
                                    <td width="80%">
                                      {/* body starts */}

                                     
                                        <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{ marginTop: '5px' }}>



                                          <Box style={{ display: 'flex', gap: '12px', marginTop: '10px' }}>
                                            <TextField type="text" name="subscriberCellularNumber" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {/* {`${t('053')}`} */}
                                                  {`${t('mvnereport20')}`}

                                                </span>} style={{ maxWidth: '250px', width: '170px' }}
                                              onChange={e => setSubscriberCellularNumber(e.target.value)} value={subscriberCellularNumber} size="15" defaultValue=""
                                            />

                                            <TextField type="text" name="paymentAmount" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {/* {`${t('053')}`} */}
                                                  {`${t('mvnereport21')}`}
                                                </span>} style={{ maxWidth: '250px', width: '170px' }}
                                              onChange={e => setPaymentAmount(e.target.value)} value={paymentAmount} size="15" defaultValue=""
                                            />



                                            <TextField type="text" name="canalID" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {`${t('mvnereport22')}`}
                                                </span>} style={{ maxWidth: '250px', width: '170px' }}
                                              onChange={e => setCanalID(e.target.value)} value={canalID} size="15" defaultValue=""
                                            />

                                            <TextField type="text" name="terminalID" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {`${t('mvnereport23')}`}
                                                </span>} style={{ maxWidth: '250px', width: '170px' }}
                                              onChange={e => setTerminalID(e.target.value)} value={terminalID} size="15" defaultValue=""
                                            />

                                            <TextField type="text" name="sucursalID" className={'sampleInput mb5'}
                                              label={
                                                <span>
                                                  {`${t('mvnereport24')}`}
                                                </span>} style={{ maxWidth: '250px', width: '170px' }}
                                              onChange={e => setSucursalID(e.target.value)} value={sucursalID} size="15" defaultValue=""
                                            />
   <FormControl className={'selected_formcontrol'} sx={{ minWidth: 170 }} size="small">
                                              <InputLabel
                                                id="demo-select-small-label"
                                                sx={{ backgroundColor: '#fff', padding: '0 5px' }}
                                              >
                                                <RedAsterisk>*</RedAsterisk>
                                                {t('partnerstatusreport18')}
                                              </InputLabel>
                                              <Select
                                                className={'bankSelect'}
                                                // style={{ maxWidth: '250px', width: '210px' }}
                                                labelId="demo-select-small-label"
                                                id="demo-select-small"
                                                value={hierarchyMode}
                                                label="Select Channel"
                                                onChange={(e) => setHierarchyMode(e.target.value)}
                                              >
                                                <MenuItem value="Y">{t('Y')}</MenuItem>
                                                <MenuItem value="N">{t('N')}</MenuItem>
                                              </Select>
                                            </FormControl>


                                          </Box>

    <Box style={{ display: 'flex', gap: '12px' }}>

<FormControl className={'selected_formcontrol'} sx={{ minWidth: 170 }} size="small">
                                              <InputLabel
                                                id="demo-select-small-label"
                                                sx={{ backgroundColor: '#fff', padding: '0 5px' }}
                                              >

                                                {t('mvnereport25')}
                                              </InputLabel>
                                              <Select
                                                className={'bankSelect'}
                                                // style={{ maxWidth: '250px', width: '210px' }}
                                                labelId="demo-select-small-label"
                                                id="demo-select-small"
                                                value={status}
                                                label="Select Channel"
                                                onChange={(e) => setStatus(e.target.value)}
                                              >
                                               <MenuItem value=" ">---</MenuItem>
                                                {statusList.map((status) => (
                                                  <MenuItem key={status.value} value={status.value}>
                                                    {status.label}
                                                  </MenuItem>
                                                ))}
                                              </Select>
                                            </FormControl>


{/* Carrier Dropdown */}
<FormControl className="selected_formcontrol" sx={{ minWidth: 170}} size="small">
  <InputLabel
    id="carrier-select-label"
    sx={{ backgroundColor: '#fff', padding: '0 5px' }}
  >
    {t('mvnereport26')} {/* Label: Carrier */}
  </InputLabel>
  <Select
    className="bankSelect"
    // style={{ maxWidth: '250px', width: '170px' }}
    labelId="carrier-select-label"
    id="carrier-select"
    value={selectedCarrier}
    label={t('mvnereport26')}
    onChange={(e) => {
      setSelectedCarrier(e.target.value);
      setSelectedMnvo(' '); // Clear MVNO selection on Carrier change
    }}
  >
    <MenuItem value=" ">---</MenuItem> 

    {carrierList.map((carrier) => (
      <MenuItem key={carrier.value} value={carrier.value}>
        {carrier.label}
      </MenuItem>
    ))}
  </Select>
</FormControl>

{/* MVNO Dropdown */}
<FormControl
  className="selected_formcontrol"
  sx={{ minWidth: 170 }}
  size="small"
 // disabled={!mnvoList.length}
>
  <InputLabel
    id="mvno-select-label"
    sx={{ backgroundColor: '#fff', padding: '0 5px' }}
  >
    {t('mvnereport27')} {/* Label: MVNO */}
  </InputLabel>
  <Select
    className="bankSelect"
      style={{ maxWidth:'200px' }}
    labelId="mvno-select-label"
    id="mvno-select"
    value={selectedMnvo}
    label={t('mvnereport27')}
    onChange={(e) => setSelectedMnvo(e.target.value)}
  >
    <MenuItem value=" ">---</MenuItem>
    {mnvoList.map((item) => (
      <MenuItem key={item.value} value={item.value}>
        {item.label}
      </MenuItem>
    ))}
  </Select>
</FormControl>


<LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
            <DateTimePicker
                  style={{ maxWidth: '210px' }}
                  className={'datePickerrr'}
                  // label="Select Date and Time"
                  value={startDateTime}
                  onChange={handleStartDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
                  label={
                    <span>
                      {`${t('mvnereport28')}`}
                   <RedAsterisk>*</RedAsterisk>
                    </span>}
                    format="DD/MM/YYYY HH:mm:ss"
                  inputFormat=" " // Keeps the input field empty unless a date is selected
                  renderInput={(params) => <TextField
                    {...params}
                    InputLabelProps={{
                      shrink: true, // Always shrink the label to allow for a floating effect
                    }}
                    fullWidth
                    variant="outlined"
                    sx={{ width: "210px", height: "40px", padding: '20px' }}
                  />}
                />

          </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                  style={{ marginTop: '20px', maxWidth: '210px' }}
               className={'datePickerrr mt20'}
               label={
                <span>
                  {`${t('mvnereport29')}`}
                                                <RedAsterisk>*</RedAsterisk>
                </span>}
                format="DD/MM/YYYY HH:mm:ss"
                  value={endDateTime}
                 onChange={handleEndDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
               renderInput={(params) => <TextField {...params} />} />

              </LocalizationProvider>
                                            



                                            <Box style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'flex-end', marginTop: '-16px' }}>
                                              <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
                                                onClick={handleSubmit}
                                              >
                                                {t('mvnereport31')}
                                              </Button>

                                              <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
                                              onClick={clearData}
                                              >
                                                {t('mvnereport32')}
                                              </Button>

                                            </Box>
                                          </Box>
                                          {/* </fieldset>
</Box> */}

                                          {/* </Box> */}
                                          <Grid
                                            container
                                            spacing={2}
                                            sx={{ width: 1 }}
                                            className={""}
                                            style={{
                                              justifyContent: "center",
                                              marginTop: "5px",
                                              marginBottom: '0px',
                                              marginLeft: "0px",
                                              borderBottom: "1px solid #fff",
                                              paddingInline: "0px",
                                            }}
                                          >
                                            <Grid
                                              item
                                              xs={4}
                                              sx={{ textAlign: "left", padding: "0 !important" }}
                                            >
                                            </Grid>
                                            <Grid
                                              item
                                              xs={3}
                                              sx={{ textAlign: "center", padding: "0 !important" }}
                                            ></Grid>
                                            <Grid
                                              item
                                              xs={5}
                                              sx={{ textAlign: "right", padding: "0 !important" }}>
                                              {totalRecords > 0 ?
                                                <><span className={"strongerTxtLable"}>
                                                  {t('032')} : {totalRecords}
                                                </span><span className={"strongerTxtLable"}>
                                                    &nbsp; / &nbsp;
                                                    {t('033')} : {startRecord} - {endRecord}
                                                  </span></> :
                                                <></>}
                                            </Grid>
                                          </Grid>
                                          <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                                            <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
                                              <TableHead>
                                                <TableRow className="darkgray">



                                                  <TableCell align="center">  {t('mvnereport1')} </TableCell>
                                                  <TableCell align="center">  {t('mvnereport2')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport3')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport4')} </TableCell>
                                                  <TableCell align="center">  {t('mvnereport5')} </TableCell>
                                                  <TableCell align="center">  {t('mvnereport6')} </TableCell>
                                                  <TableCell align="center">  {t('mvnereport7')} </TableCell>
                                                  <TableCell align="center">  {t('mvnereport8')} </TableCell>
                                                  <TableCell align="center">  {t('mvnereport9')} </TableCell>
                                                  <TableCell align="center">  {t('mvnereport10')} </TableCell>
                                                  <TableCell align="center">  {t('mvnereport11')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport12')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport13')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport14')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport15')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport16')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport17')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport18')}</TableCell>
                                                  <TableCell align="center">  {t('mvnereport19')}</TableCell>
                                                  {/* <TableCell align="center">  {t('mvnereport34')}</TableCell> */}



                                                </TableRow>
                                              </TableHead>
                                              <TableBody>
                                                {isLoading ? (
         
                                                             <TableRow>
                                                                <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
                                                                  {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
                                                                </TableCell>
                                                              </TableRow>
                                                ) : items?.length > 0 ? (
                                                  // Show table rows when data is available
                                                  items.map((item, index) => (
                                                    <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
                                                      <TableCell align="center">&nbsp;{item.transactionDate}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.transactionID}&nbsp;</TableCell>
                                                      <TableCell align="center">{item.authorizationID}</TableCell>
                                                      <TableCell align="center">&nbsp;{item.distributorName}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.distributorID}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.supervisiorIDorParentID}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.mainDistributorIDlevel1}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.subscriberCellularNumber}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{Number(item.rechargeAmount).toFixed(2)}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.terminalID}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.canalID}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.sucurscalID}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.trancationCatgory}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.status}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.careerID}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.carrieReferenceID}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.MVNOID}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.MVNOCODE}&nbsp;</TableCell>
                                                      <TableCell align="center">&nbsp;{item.errorDescription}&nbsp;</TableCell>
                                                      {/* <TableCell align="center">&nbsp;{item.noRows}&nbsp;</TableCell> */}

                                                    </TableRow>
                                                  ))
                                                ) : (
                                                  // Show 'No data found' message if no items are found after loading
                                                   <TableRow>
                                                                                                     <TableCell colSpan={20} align="center" className="redTxt" style={{ color: 'red' }}>
                                                                                                       {submitted ? t("2481_061") : t("038")}
                                                                                                     </TableCell>
                                                                                                   </TableRow>
                                                )}
                                              </TableBody>
                                            </Table>
                                          </TableContainer>
                                          <br></br>
                                          <Table>
                                            <tfoot>
                                              <Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                                                <Box
                                                  sx={{ textAlign: "right", padding: "4px 0px 4px 0 !important" }}
                                                  className={'displayFlex'}></Box>


                                                {items.length>0?<Pagination
                                                  count={totalPages}
                                                  page={page}
                                                  onChange={handleChangePage}
                                                  showFirstButton
                                                  showLastButton
                                                /> : <></>}
                                              </Box>
                                              <tr>
                                              </tr>
                                            </tfoot>
                                          </Table>
                                          <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                  
                                            {items?.length > 0 ?
                                              <div onMouseLeave={handleClose}>
                                                <Button
                                                  className="hoverEffectButton"
                                                  size="small"
                                                  variant="contained"
                                                  endIcon={<CloudDownload />}
                                                  onMouseEnter={handleHover}
                                                >
                                                 {t('089')}
                                                </Button>

                                                <Menu
                                                  anchorEl={anchorEl}
                                                  open={Boolean(anchorEl)}
                                                  onClose={() => setAnchorEl(null)}
                                                  anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                  transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                  MenuListProps={{
                                                    onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                    onMouseLeave: handleClose,
                                                  }}
                                                >
                                                  <MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>  {t('mvnereport37')}</MenuItem>
                                                  <MenuItem onClick={() => { setAnchorEl(null); handleDownload(); }}>  {t('mvnereport35')}</MenuItem>
                                                  <MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>  {t('mvnereport36')}</MenuItem>

                                                </Menu>
                                              </div>
                                              : <></>}

                                            <Button
                                              className={"hoverEffectButton"}
                                              size="small"
                                              variant="contained"
                                              onClick={handleReturn}
                                              endIcon={<KeyboardReturn />}
                                            > {t('013')}</Button>
                                          </div>
                                          <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                                        </table>
                                   
                                    </td></tr>
                                       </div>
                                </tbody>
                              </table>
                            </td>
                          </tr>{/* MIDDLE ROW ENDS HERE  */}
                        </tbody>
                      </table>
                    </td></tr>
                </tbody>
                <ToastContainer
                                                                                  position="top-right"
                                                                                  autoClose={3000}
                                                                                  hideProgressBar={false}
                                                                                  newestOnTop={false}
                                                                                  closeOnClick
                                                                                  rtl={false}
                                                                                  pauseOnFocusLoss
                                                                                  draggable
                                                                                  pauseOnHover
                                                                                  style={{
                                                                                      width: "fit-content",
                                                                                      minWidth: "300px",
                                                                                      minHeight: "100px",
                                                                                      fontSize: "18px",
                                                                                  }}
                                                                              />
              </table>
            </td></tr>
          <tr height="60px"><td colSpan={2}>
            <Footer />
          </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default Mvnereportp;
