/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { ArrowDownward, ArrowUpward, UnfoldMore } from '@mui/icons-material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
// import React, { useState, useEffect, useCallback ,useRef} from 'react';
import dayjs from 'dayjs';
import { CloudDownload, KeyboardReturn, DoneAllRounded, RestartAltRounded, SaveRounded } from '@mui/icons-material';
import TopMenu from "./TopMenu";
import { Header, Footer, PaymentManagerHeading, LeftBgImage, TransactionTopMenu, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, Menu, CircularProgress, FormControl, Grid, InputLabel,Autocomplete, MenuItem, Pagination, Paper, Select, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, styled } from "@mui/material";
import React, { useState, useEffect, useCallback, useRef } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
// import { CancelRounded, CloudDownload, KeyboardReturn } from "@mui/icons-material";
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import ExcelJS from 'exceljs';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { ToastContainer, toast } from "react-toastify";
import { FixedSizeList } from 'react-window';
// import { useRef, useEffect } from "react";


function FundTransferReport() {
  const dropdownItemStyle = {
    display: 'block',
    width: '100%',
    padding: '8px 12px',
    textAlign: 'left',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '14px',
    fontFamily: 'inherit',
    outline: 'none',
  };

  sessionStorage.setItem("selectedLink", "e_transactions");
  const [showOptions, setShowOptions] = useState(false);
  const dropdownRef = useRef(null);
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
  const { t } = useTranslation();
  const localeVar = i18n.language;
  const [trans, setTrans] = useState("---");
  // const [sortDirection, setSortDirection] = useState(null); // 'asc' or 'desc'
  // const [sortedItems, setSortedItems] = useState(items); // To hold sorted data

  const [sortedItems, setSortedItems] = useState([]);
  const [sortDirection, setSortDirection] = useState(null);

  const now = dayjs();
  const midnightToday = dayjs().startOf('day');

  const [startDateTime, setStartDateTime] = useState(midnightToday);
  const [startDate, setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
  const [endDateTime, setEndDateTime] = useState(now);
  const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));
  // const [download, setDownload] = useState('');
  //  const [download, setDownload] = useState('');
  const exampleData = JSON.parse(localStorage.getItem("userData"));
  const [items, setItems] = useState([]);
  const [filterItems, setfilterItems] = useState([]);
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [sourceMdn, setSourceMdn] = useState('');
  const [partnerId, setPartnerId] = useState('');
  const [destMdn, setDestMdn] = useState('');
  const [authId, setAuthId] = useState('');
  const [auth, setAuth] = useState('');
  const [submit, setSubmit] = useState(false);
  // const [eventArray, setEventArrey] = useState([]);

  // const [transID, setTransID] = useState('6');

  const [transID, setTransID] = useState(""); // initial empty string to send on Apply
  const [transIDDisplay, setTransIDDisplay] = useState("6"); // show 3045 by default
  const userRole = 'salesPerson';
  const [fundTransId, setFundTransId] = useState('F');
  const [personId, setPersonId] = useState("");
  const [status, setStatus] = useState('N');

  const [showError, setShowError] = useState(false);
  const [partnerLoginId, setPartnerLoginId] = useState(exampleData.LOGIN_ID);
  const toastId = useRef(null);
  const closeTimeoutRef = useRef(null);
  const [anchorEl, setAnchorEl] = useState();

  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [mdn, setMdn] = useState('');
  const [submitted, setSubmitted] = useState(false);
  let reportDays = process.env.REACT_APP_ReportDays;
 const [partnerList, setPartnerList] = useState([]);
 const [apply,setApply] =useState(false);


//for spi dropdown
const defaultOption = { partnerId: "---" };
const fullPartnerList = [defaultOption, ...partnerList];
const LISTBOX_PADDING = 8; 
const [loading, setLoading] = useState(false);

  let startRecord = 1;
  let endRecord = 10;



  const navigate = useNavigate();

  console.log("totalRecords++++++++++++", totalRecords);


  // const handleChangePage = (event, newPage) => {
  //   setPage(newPage);
  // };

  const handleChangePage = async (event, newPage) => {
  event.preventDefault();

  if (newPage === page) {
    return; // Do nothing if same page is clicked
  }

   const isValid = validateDateRange({
         startDateTime,
         endDateTime,
         reportDays,
         toast,
         toastId,
         t,
         submitted
       });
   
    if (!isValid) {
    setSubmitted(false);  // reset submit flag
    return;
  }

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmitted(false);
    }
return false;

}

  setPage(newPage);
  await fetchData(newPage);
};


  const RedAsterisk = styled('span')({
    color: 'red',
  });

  useEffect(() => {
    if (items && items.length) {

      console.log("items===>", items)
      setSortedItems(items);
    }
  }, [items]);



  const parseDate = (dateStr) => {
    // Expected format: DD/MM/YYYY HH:mm:ss
    const [datePart, timePart] = dateStr.split(' ');
    const [day, month, year] = datePart.split('/');
    return new Date(`${year}-${month}-${day}T${timePart}`);
  };

  const handleSortByDate = () => {
    const newDirection = sortDirection === 'asc' ? 'desc' : 'asc';

    const sorted = [...sortedItems].sort((a, b) => {
      const dateA = parseDate(a.fundTransferDate);
      const dateB = parseDate(b.fundTransferDate);
      return newDirection === 'asc' ? dateA - dateB : dateB - dateA;
    });

    setSortedItems(sorted);
    setSortDirection(newDirection);
  };


  useEffect(() => {
    // Set the browser title
    document.title = t('2472_018');
  }, []);



  //date validation 
  const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
    // debugger;
    const start = new Date(startDateTime);
    const end = new Date(endDateTime);
    const oneDay = 1000 * 60 * 60 * 24

console.log("start",start);
     console.log("end",end);
      console.log("oneDay",oneDay);

    if (end < start) {
      if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t('error.date.one'));

      }
      return false;
    }

    const diffDays = Math.floor((end - start) / oneDay);
    console.log("diffDays:", diffDays);

    if (diffDays >= reportDays) {
      if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t('error.config.days') + " " + reportDays);


      }
      return false;
    }

    return true;
  };
  const handleSubmit = async () => {
    // e.preventDefault(); 
    try {
      console.log("status", status);

      const isValid = validateDateRange({
        startDateTime,
        endDateTime,
        reportDays,
        toast,
        toastId,
        t
      });

                     
if (!isValid){
  setApply(false);
  return;
} 

    
      await fetchData();
      setPage(1)
      setSubmit(true)
        setApply(true);
    } catch (error) {
      console.error("An error occurred:", error);
    }

  };

  // const fetchData = async () => {

const fetchPartnerData = async (typeId) => {
  try {
    setLoading(true); // Start loading
   const apiUrl = window.config.apiUrlJasper+'/getChildPartners';
    const response = await axios.post(apiUrl, {
      userName,
      password,
      partnerTypeId: typeId,
      partnerId: partnerLoginId,
      localeVar,
    });

    const partnerData = response.data.summaryPartnerArray || [];
    const activePartners = partnerData.filter(p => p.status === "Y");
    setPartnerList(activePartners);
  } catch (err) {
    console.error("Error fetching partner data:", err);
  } finally {
    setLoading(false); // End loading
  }
};

useEffect(() => {
  if (transIDDisplay) {
    fetchPartnerData(transIDDisplay);
  }
}, [transIDDisplay]);

  const fetchData = async (pageNumber = 1) => {
    const startRecord = (pageNumber - 1) * perpage + 1;
    const endRecord = startRecord + perpage - 1;
    setSubmitted(true)

    const startRecordString = startRecord.toString();
    const endRecordString = endRecord.toString();
    setIsLoading(true);
    try {
      const apiUrl = window.config.apiUrlJasper + '/getFundTransfer';
      const response = await axios.post(apiUrl, {
        userName,
        password,
        toDist:personId,
        fromMDN: sourceMdn,
        toMDN: destMdn,
        distType: transIDDisplay,
        transType:fundTransId,
        transactionType: "",
        authId: auth,
        fromDate: startDate,
        toDate: endDate,
        partnerId:partnerLoginId,
        localeVar,
        levelFlag: status,
        begRecNo: startRecordString,
        endRecNo: endRecordString,
        download: "Y"
      });
      const reportData = response.data.fundTransferReport;
      console.log("response.data.fundTransferReport=====>", reportData);
      console.log("response.data=====>",response.data)

      if (Array.isArray(reportData) && reportData.length > 0) {
        setItems(reportData);
        setTotalRecords(response.data.noRows);
        setShowError(false); // clear error state if it was set previously
      } else {
        // Clear previous data
        setItems([]);
        setTotalRecords(0);
        setTrans('');
        if (!toast.isActive(toastId.current)) {
          setShowError(true);
        }
      }

    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };
 
  const handleReturn = () => {
    navigate(-1);
  };


  const doReset = async () => {
    setSourceMdn("");
    setDestMdn("");
    setTransID("");
    setTransIDDisplay("6");
    setFundTransId("F");
    setPersonId("");
    setStartDateTime(midnightToday)
    setEndDateTime(now)
    setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'))
    setEndDate(now.format('DD/MM/YYYY HH:mm:ss'))
    setStatus("N");
    setAuth("");

  }



  const fetchDataDownload = async () => {


     const isValid = validateDateRange({
           startDateTime,
           endDateTime,
           reportDays,
           toast,
           toastId,
           t,
           submitted
         });
     
      if (!isValid) {
      setSubmitted(false);  // reset submit flag
      return;
    }
    
    if(!apply){
    
    if (!toast.isActive(toastId.current)) {
          toastId.current = toast.error(t('apply_validation'));
         setSubmitted(false);
        }
    return false;
    
    }

    try {

      const apiUrlDownload = window.config.apiUrlJasper + '/getFundTransfer';
      console.log('API URL:', apiUrlDownload);
      console.log('Partner Login ID:', partnerLoginId);
      const responseDownload = await axios.post(apiUrlDownload, {
        userName,
        password,
        toDist: personId,
        fromMDN: sourceMdn,
        toMDN: destMdn,
        distType: transIDDisplay,
        transType:fundTransId,
         transactionType:"" ,
        authId: auth,
        fromDate: startDate,
        toDate: endDate,
        partnerId:partnerLoginId,
        localeVar,
        levelFlag: status,
        begRecNo: "",
        endRecNo: "",
        download: ""
      });

      console.log('Response:', responseDownload);

      if (!responseDownload.data || !responseDownload.data.fundTransferReport) {
        throw new Error('Invalid API response');
      }
      const downloadData = responseDownload.data.fundTransferReport.map(partner => ({
        authId: partner.authId,
        fundTransferDate: partner.fundTransferDate,
        fundTransferId: partner.fundTransferId,
        fundTransAmount: partner.fundTransAmount,
        currencySymbol: partner.currencySymbol,
        transType: partner.transType,
        fromAccount: partner.fromAccount,
        fromParentDistComp: partner.fromParentDistComp,
        fromSalesPersonMDN: partner.fromSalesPersonMDN,
        fromAccType: partner.fromAccType,
        fromPartnerCompName: partner.fromPartnerCompName,
        fromAccPreBalance: partner.fromAccPreBalance,
        fromAccPostBalance: partner.fromAccPostBalance,
        bankRefferenceId: partner.bankRefferenceId,
        toAccount: partner.toAccount,
        toParentDistComp: partner.toParentDistComp,
        toSalesPersonMDN: partner.toSalesPersonMDN,
        toAccType: partner.toAccType,
        toPartnerCompName: partner.toPartnerCompName,
        toAccPreBalance: partner.toAccPreBalance,
        toAccPostBalance: partner.toAccPostBalance,
        transferedBy: partner.transferedBy,
        replenChannelDesc: partner.replenChannelDesc,
        levl: partner.levl

      }));

      console.log('Download Data:', downloadData);

      return downloadData;
    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };




  const totalPages = Math.ceil(totalRecords / recordsPerPage);



  const DownloadXL = async () => {
    const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('FundTransferReport', {
      pageSetup: { paperSize: 9, orientation: 'landscape' }
    });

    // === Set 30 columns width
    worksheet.columns = new Array(30).fill({ width: 25 });
    const endOfReportText = t('0171');

    // === Insert Title Row (Row 1)
    worksheet.insertRow(1, [
      localeVar === 'en' ? 'FundTransferReport' : 'Reportes de Transferencias de Fondos'
    ]);
    worksheet.mergeCells('A1:AD1');
    worksheet.getCell('A1').font = { bold: true, size: 14 };
    worksheet.getCell('A1').alignment = { horizontal: 'center' };

    // === Insert Summary Row (Row 2) with left and right alignment
    const summaryRow = worksheet.insertRow(2, new Array(30).fill(''));

    summaryRow.getCell(1).value = `${t('032')} : ${downloadItems.length}`;
    summaryRow.getCell(1).alignment = { horizontal: 'left' };

    // summaryRow.getCell(24).value = `${t('033')} : 1 - ${downloadItems.length}`;
    // summaryRow.getCell(24).alignment = { horizontal: 'right' };

    //summaryRow.font = { italic: true, size: 10 };

    // === Group Header Row (Row 3)
    const groupHeaders = [
      ...Array(14).fill(t('624')),
      ...Array(7).fill(t('625')),
      ...Array(3).fill(t(''))
    ];
    const headerRow1 = worksheet.addRow(groupHeaders);
    worksheet.mergeCells('A3:N3'); // 624
    worksheet.mergeCells('O3:U3'); // 625
    worksheet.mergeCells('V3:X3'); // ''

    headerRow1.eachCell((cell) => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' }
        // fgColor: { argb: 'b3d9ff' }
      };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });

    // === Column Headers (Row 4)
    const columnHeaders = [
      t('611'), t('023'), t('616'), t('6827'), t('251620'), t('617'), t('623'), t('3132'),
      t('rtr_002'), t('072'), t('1146'), t('1150'), t('618'), t('619'),
      t('623'), t('3132'), t('rtr_002'), t('072'), t('1146'), t('1150'),
      t('618'), t('620'), t('621'), t('626')
    ];
    const headerRow2 = worksheet.addRow(columnHeaders);

    headerRow2.eachCell(cell => {
        cell.font = { bold: true };
      // cell.font = { bold: true, color: { argb: 'FFFFFF' } };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFFFFFFF' }
        // fgColor: { argb: '3399FF' }
      };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });

    // === Add Data Rows (Starting from Row 5)
    downloadItems.forEach(item => {
      const row = [
        item.authId,
        item.fundTransferDate,
        item.fundTransferId,
        item.fundTransAmount,
        item.currencySymbol,
        item.transType,
        item.fromAccount,
        item.fromParentDistComp,
        item.fromSalesPersonMDN,
        item.fromAccType,
        item.fromPartnerCompName,
        item.fromAccPreBalance,
        item.fromAccPostBalance,
        item.bankRefferenceId,
        item.toAccount,
        item.toParentDistComp,
        item.toSalesPersonMDN,
        item.toAccType,
        item.toPartnerCompName,
        item.toAccPreBalance,
        item.toAccPostBalance,
        item.transferedBy,
        item.replenChannelDesc,
        item.levl
      ];
      worksheet.addRow(row);
    });

    // === End of Report Message
    const endOfReportRow = worksheet.addRow([endOfReportText]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
    endOfReportRow.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
    endOfReportRow.getCell(1).font = { bold: true };

    // === Generate Excel File
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
    saveAs(blob, 'FundTransferReport.xlsx');
  };

  const highlightSelectedLink = (e) => {
    var x = document.querySelector(".subLinkVisited");
    if (x !== null) {
      x.classList.replace("subLinkVisited", "subLink");
    }
    e.target.classList.replace("subLink", "subLinkVisited");
  }
  const handleMdnChange = (e) => {
    const value = e.target.value;
    if (/^\d{0,10}$/.test(value)) {
      setMdn(value);
    }
  };

  const handleEndDateTimeChange = (newValue) => {
    setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };
  const handleStartDateTimeChange = (newValue) => {
    setApply(false);
    setStartDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setStartDate(formattedDateTime);
    console.log("startDate::::::", newValue)
    console.log("startDate::::::", formattedDateTime)
  };


  useEffect(() => {
    if (!endDateTime) {
      setEndDateTime(dayjs()); // 👈 Set default to current date-time
    }
  }, [endDateTime]);



  const handleDownloadPdf = async () => {
    const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;
    const totalRecords = downloadItems.length;
    const startRecord = 1;
    const endRecord = totalRecords;

    const tableBody = [];

    // === 1) Group Header (must total 24 cells) ===
    const Mainheaders = [
      // blank for first 5 columns
      { text: t('624'), colSpan: 14, style: 'mainHeader', alignment: 'center' },
      ...Array(13).fill({ text: '', style: 'mainHeader' }),

      // next 9 columns as group "624"
      { text: t('625'), colSpan: 7, style: 'mainHeader', alignment: 'center' },
      ...Array(6).fill({ text: '', style: 'mainHeader' }),

      // next 9 columns as group "625"
      { text: t(''), colSpan: 3, style: 'mainHeader', alignment: 'center' },
      ...Array(2).fill({ text: '', style: 'mainHeader' }),

    ];
    tableBody.push(Mainheaders);

    // === 2) Column Headers (24 of them) ===
    const headers = [
      t('611'), t('023'), t('616'), t('6827'), t('251620'),
      t('617'), t('623'), t('3132'), t('rtr_002'), t('072'),
      t('1146'), t('1150'), t('618'), t('619'), t('623'),
      t('3132'), t('rtr_002'), t('072'), t('1146'), t('1150'),
      t('618'), t('620'), t('621'), t('626')
    ];
    tableBody.push(
      headers.map(h => ({ text: h, style: 'tableHeader' }))
    );

    // === 3) Data Rows ===
    downloadItems.forEach(item => {
      const row = [
        item.authId, item.fundTransferDate, item.fundTransferId,
        item.fundTransAmount, item.currencySymbol,
        item.transType, item.fromAccount, item.fromParentDistComp,
        item.fromSalesPersonMDN, item.fromAccType,
        item.fromPartnerCompName, item.fromAccPreBalance,
        item.fromAccPostBalance, item.bankRefferenceId,
        item.toAccount, item.toParentDistComp, item.toSalesPersonMDN,
        item.toAccType, item.toPartnerCompName,
        item.toAccPreBalance, item.toAccPostBalance,
        item.transferedBy, item.replenChannelDesc, item.levl
      ];

      tableBody.push(
        row.map(val => ({ text: val != null ? String(val) : '', fontSize: 5 }))
      );
    });

    // === PDF Definition ===
    const docDefinition = {
      content: [
        {
          text: localeVar === 'en'
            ? 'FundTransferReport'
            : 'Reportes de Transferencias de Fondos',
          style: 'title',
          alignment: 'center',
          margin: [0, 0, 0, 10]
        },
        {
          columns: [
            {
              text: `${t('032')} : ${totalRecords}`,
              alignment: 'left',
              fontSize: 8
            }
            // ,
            // {
            //   text: `${t('033')} : ${startRecord} - ${endRecord}`,
            //   alignment: 'right',
            //   fontSize: 8
            // }
          ],
          margin: [0, 0, 0, 5]
        },
        {
          style: 'tableExample',
          table: {
            headerRows: 2,
            widths: new Array(24).fill('*'),
            body: tableBody
          },
          layout: {
        fillColor: function (rowIndex) {
          return rowIndex === 0 ? '#3399FF' : rowIndex === 1 ? '#3399FF' : null;
        }
      }
        },
        {
          text: t('0171'),
          style: 'endText',
          alignment: 'center',
          margin: [0, 10, 0, 0]
        }
      ],
      styles: {
        title: { fontSize: 12, bold: true },
        tableExample: { margin: [0, 5, 0, 10] },
        mainHeader: { bold: true, fontSize: 6, color: '#000' },
        tableHeader: { bold: true, fontSize: 5, color: '#fff', alignment: 'center' },
        endText: { italics: true, bold: true, decoration: 'underline', fontSize: 8 }
      },
      pageOrientation: 'landscape',
      pageSize: 'A3',
      pageMargins: [10, 10, 10, 10],
      defaultStyle: { fontSize: 5 }
    };

    pdfMake.createPdf(docDefinition)
      .download('FundTransferReport.pdf');
  };






  const handleDownloadCsv = async () => {
    const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  const formatAmount = (value) => {
    const num = parseFloat(value);
    return !isNaN(num) ? num.toFixed(2) : '0.00';
  };

  const formatDateTime = (value) => {
    if (!value) return "---";
    const date = new Date(value);
    if (isNaN(date.getTime())) return value;
    const pad = (n) => (n < 10 ? '0' + n : n);
    return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

    const totalRecords = downloadItems.length;
    const startRecord = 1;
    const endRecord = downloadItems.length;

  const title = t('634');
    const summaryText = `${t('032')} : ${totalRecords}`;
    // const summaryText = `${t('032')} : ${totalRecords}  /  ${t('033')} : ${startRecord} - ${endRecord}`;

const groupHeaders = [
t('624'),
t(''),t(''),t(''),t(''),t(''),t(''),t(''),
t(''),t(''),t(''),t(''),t(''),t(''),t('625'),t('')
  ];

    const columnHeaders = [
    t('611'), t('023'), t('616'), t('6827'), t('251620'), t('617'), t('623'), t('3132'),
      t('rtr_002'), t('072'), t('1146'), t('1150'), t('618'), t('619'), t('623'), t('3132'),
      t('rtr_002'), t('072'), t('1146'), t('1150'), t('618'), t('620'), t('621'), t('626')
    ];

    const rows = downloadItems.map(item => [
    item.authId ?? "---",
   item.fundTransferDate,
    item.fundTransferId ?? "---",
  item.fundTransAmount,
    item.currencySymbol ?? "---",
    item.transType ?? "---",
    item.fromAccount ?? "---",
    item.fromParentDistComp ?? "---",
    item.fromSalesPersonMDN ?? "---",
    item.fromAccType ?? "---",
    item.fromPartnerCompName ?? "---",
  item.fromAccPreBalance,
  item.fromAccPostBalance,
    item.bankRefferenceId ?? "---",
    item.toAccount ?? "---",
    item.toParentDistComp ?? "---",
    item.toSalesPersonMDN ?? "---",
    item.toAccType ?? "---",
    item.toPartnerCompName ?? "---",
  item.toAccPreBalance,
   item.toAccPostBalance,
    item.transferedBy ?? "---",
    item.replenChannelDesc ?? "---",
    item.levl ?? "---"
    ]);

    const escapeCSV = value => {
      if (value == null) return '';
    const strVal = String(value).trim().replace(/"/g, '""');

    if (/^\d+\.\d{2}$/.test(strVal)) {
      return `="${strVal}"`;
    } else if (/^\d{2}\/\d{2}\/\d{4}/.test(strVal)) {
      return `="${strVal}"`;
    } else {
      return `"${strVal}"`;
    }
    };

    const csvLines = [];

const totalCols = columnHeaders.length;
const centerIndex = Math.floor(totalCols / 2);

const titleRow = Array(totalCols).fill('');
titleRow[centerIndex] = title;

  // csvLines.push(`"${title}"`);
  csvLines.push(titleRow.map(escapeCSV).join(','));


    csvLines.push(`"${summaryText}"`);

 
    csvLines.push(groupHeaders.map(escapeCSV).join(','));

 
    csvLines.push(columnHeaders.map(escapeCSV).join(','));

    rows.forEach(row => {
      csvLines.push(row.map(escapeCSV).join(','));
    });



 
// create empty columns, place text in middle
const centeredRow = Array(totalCols).fill('');
centeredRow[centerIndex] = t('0171');
 
csvLines.push(centeredRow.map(escapeCSV).join(','));

    let csvContent = csvLines.join('\n');

const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;


    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const fileName = 'FundTransferReport.csv';

    if (navigator.msSaveBlob) {
      navigator.msSaveBlob(blob, fileName);
    } else {
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', fileName);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
  const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };


  const handleTransIDChange = (event) => {
    const selectedValue = event.target.value;

    // Map 6 (3045) to empty string for backend
    if (selectedValue === "6") {
      setTransID(""); // send empty string to backend
      setTransIDDisplay("6"); // still show 3045 on UI
    } else {
      setTransID(selectedValue);
      setTransIDDisplay(selectedValue);
    }
  };

  //for sales person identity drop down performance 
function renderRow(props) {
  const { data, index, style } = props;
  return React.cloneElement(data[index], {
    style: {
      ...style,
      top: style.top + LISTBOX_PADDING,
    },
  });
}
const ListboxComponent = React.forwardRef(function ListboxComponent(props, ref) {
  const { children, ...other } = props;
  const itemCount = Array.isArray(children) ? children.length : 0;
  const itemSize = 36;

  return (
    <div ref={ref} {...other}
     style={{ overflow: 'hidden' }}>
      <FixedSizeList
        height={Math.min(8, itemCount) * itemSize + 2 * LISTBOX_PADDING}
        itemCount={itemCount}
        itemSize={itemSize}
        width="100%"
      >
        {({ index, style }) =>
          renderRow({
            data: children,
            index,
            style,
          })
        }
      </FixedSizeList>
    </div>
  );
});
//
  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          <Header />
          <tr height="65px">
            <PaymentManagerHeading />
            <TopMenu menuLink={localeVar === 'en' ? "Transactions" : "Transacciones"} />
          </tr>

          <tr>
            <div style={{ display: 'flex' }}>
              <LeftBgImage1 />
            </div>
            <td valign="top">
              <title>Prepaid Movistar -View Sub Distributor</title>
              <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                <tbody>
                  <tr>
                    <td>
                      <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                        <tbody>
                          {/* MIDDLE ROW STARTS */}
                          <tr>
                            <td>
                              <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" height="100%">

                                <tbody>
                                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
                                    <Tabs style={{ minHeight: '35px' }}>
                                      {/* <TransactionTopMenu /> */}
                                      <NavLink
                                        to="/FundTransferReport"
                                        onClick={(e) => highlightSelectedLink(e)}
                                        // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
                                        className={({ isActive }) =>
                                          isActive ? 'activeProfilemenu' : `profile_menu 
                                     ${"menuHighlight" ? 'addingDynClass' : ''}`
                                        }><Tab label={t('634')} /></NavLink>
                                    </Tabs>
                                  </Box>



                        <div className={'mL8 input_boxess'}>
                                  <tr valign="top">
                                    <td width="80%">
                                      {/* body starts */}

                                     
                                        <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{ marginTop: '5px' }}>


                                          <Box style={{ display: 'flex', gap: '12px', marginTop: '10px' }}>



                                           

                                            <FormControl className="selected_formcontrol" sx={{ minWidth: 210, ml: 0 }} size="small">
                                                    <InputLabel id="transID-label">
                                                      {t('607')}<RedAsterisk>*</RedAsterisk>
                                                    </InputLabel>
                                                    <Select
                                                      className="bankSelect"
                                                      value={transIDDisplay}
                                                      labelId="transID-label"
                                                      id="transID"
                                                      label={t('607')}
                                                      onChange={handleTransIDChange}
                                                    >
                                                      <MenuItem value="6">{t("sales")}</MenuItem>
                                                      <MenuItem value="5">{t("2480_017")}</MenuItem>
                                                    </Select>
                                                  </FormControl>


                                            <FormControl className={'selected_formcontrol'} sx={{ minWidth: 215, marginLeft: '0px' }} size="small" align="left">
                                              <InputLabel id="demo-select-small-label">{t('2616026')}<RedAsterisk>*</RedAsterisk></InputLabel>

                                              <Select className={'bankSelect'} value={fundTransId} labelId="demo-select-small-label" id="demo-select-small"
                                                label={t('2616026')} onChange={e => setFundTransId(e.target.value)} >
                                                <MenuItem value="F">{t("622")}</MenuItem>
                                                <MenuItem value="L">{t("612")}</MenuItem>
                                                <MenuItem value="MN">{t("613")}</MenuItem>
                                                <MenuItem value="ML">{t("5969")}</MenuItem>
                                                <MenuItem value="N">{t("615")}</MenuItem>
                                              </Select>
                                            </FormControl>

                                             <TextField type="text"
                                              name="sourceMdn"
                                              id="sourceMdn" className={'sampleInput mb5'}
                                              onChange={e => setSourceMdn(e.target.value)}

                                              value={sourceMdn} label={
                                                <span>
                                                  {`${t('605')}`}
                                                </span>} style={{ width: '180px' }}
                                              maxLength={10}
                                              pattern="\d{10}"
                                            />
                                            <TextField type="text" name="destMdn" id="destMdn" className={'sampleInput mb5'}
                                              onChange={e => setDestMdn(e.target.value)} value={destMdn} label={

                                                <span>
                                                  {`${t('606')}`}
                                                </span>} style={{ width: '180px' }} />


   <TextField type="text" name="auth" id="auth" className={'sampleInput mb5'}
                                              onChange={e => setAuth(e.target.value)} value={auth} label={

                                                <span>
                                                  {`${t('611')}`}
                                                </span>} style={{ width: '180px' }} />

                                          </Box>

                                          <Box style={{ display: 'flex', gap: '12px'}}>
                                             <Box display="flex" alignItems="center">
  <Autocomplete
  className="selected_formcontrol"
  sx={{
    minWidth: 210, // ✅ keep dropdown trigger width
    ml: 0,
    '& .MuiAutocomplete-endAdornment': {
      right: 10,
    },
    '& .MuiAutocomplete-popupIndicator': {
      transform: 'scale(1.5)', // 🔥 Make dropdown arrow bigger
    },
  }}
  size="small"
  options={fullPartnerList}
  loading={loading}
  getOptionLabel={(option) => option?.partnerId || ""}
  onChange={(event, newValue) =>
    setPersonId(newValue?.partnerId === "---" ? "" : newValue?.partnerId || "")
  }
  value={fullPartnerList.find(p => p.partnerId === personId) || defaultOption}
  filterOptions={(options, { inputValue }) =>
    options.filter((option) =>
      option.partnerId?.toLowerCase().includes(inputValue.toLowerCase())
    )
  }
  renderInput={(params) => (
    <TextField
      {...params}
      label={t('609')}
      InputProps={{
        ...params.InputProps,
        endAdornment: (
          <>
            {loading ? <CircularProgress size={20} sx={{ mr: 2 }} /> : null}
            {params.InputProps.endAdornment}
          </>
        ),
      }}
    />
  )}
  ListboxComponent={ListboxComponent}
  disableListWrap
  slotProps={{
    popper: {
      sx: {
        '& .MuiAutocomplete-listbox': {
          fontSize: '0.7rem', // reduce font size
          padding: 0,
        },
        '& .MuiAutocomplete-option': {
          minHeight: '28px',
        },
      },
    },
  }}
/>
 
</Box>

                                            <FormControl className={'selected_formcontrol'} sx={{ minWidth: 210 }} size="small">
                                              <InputLabel id="demo-select-small-label">{t('610')}<RedAsterisk>*</RedAsterisk></InputLabel>
                                              <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
                                                label={t('610')} value={status} onChange={e => setStatus(e.target.value)}>
                                                {/* <MenuItem value="E">{t('2616011')}</MenuItem> */}
                                                <MenuItem value="Y">{t('2616020')}</MenuItem>
                                                <MenuItem value="N">{t('2616021')}</MenuItem>
                                              </Select>
                                            </FormControl>

                                          

                                                 <LocalizationProvider dateAdapter={AdapterDayjs} style={{ marginLeft: '5px' }} adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                                              <DateTimePicker
                                                style={{ maxWidth: '150px' }}
                                                className={'datePickerrr'}
                                                // label="Select Date and Time"
                                                value={startDateTime}
                                                onChange={handleStartDateTimeChange}
                                                ampm={false} // Disable AM/PM, use 24-hour format
                                                label={
                                                  <span>
                                                    {`${t('80')}`}
                                                    <RedAsterisk>*</RedAsterisk>
                                                  </span>}
                                                format="DD/MM/YYYY HH:mm:ss"
                                                inputFormat=" " // Keeps the input field empty unless a date is selected
                                                renderInput={(params) => <TextField
                                                  {...params}
                                                  InputLabelProps={{
                                                    shrink: true, // Always shrink the label to allow for a floating effect
                                                  }}
                                                  fullWidth
                                                  variant="outlined"
                                                  sx={{ width: "180px", height: "40px", padding: '20px' }}
                                                />}
                                              />

                                            </LocalizationProvider>
                                            <LocalizationProvider dateAdapter={AdapterDayjs} style={{ marginLeft: '5px' }} adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                                              <DateTimePicker
                                                style={{ marginTop: '20px', maxWidth: '180px' }}
                                                className={'datePickerrr mt20'}
                                                label={
                                                  <span>
                                                   {t('81')}
                                                    <RedAsterisk>*</RedAsterisk>
                                                  </span>}
                                                format="DD/MM/YYYY HH:mm:ss"
                                                value={endDateTime}
                                                onChange={handleEndDateTimeChange}
                                                ampm={false} // Disable AM/PM, use 24-hour format
                                                renderInput={(params) => <TextField {...params} />} />

                                            </LocalizationProvider>

                                            <Box style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'flex-end', marginTop: '-16px' }}>
                                              <Box>
                                                <Button className={'hoverEffectButton'} style={{ marginTop: '3px' }} size="small" variant="contained" onClick={() => handleSubmit()} endIcon={<CheckCircleIcon />}>{t('602')}</Button>
                                              </Box>
                                              <Box>
                                                <Button className={'hoverEffectButton'} style={{ marginTop: '3px' }} size="small" variant="contained" onClick={() => doReset()} endIcon={<RestartAltRounded />}>{t('603')}</Button>
                                              </Box>
                                              {/* <Box>
                    <Button className={'hoverEffectButton'} style={{marginTop:'3px'}} size="small" variant="contained" onClick={() => ""} endIcon={<SaveRounded />}>{t('604')}</Button>
                    </Box> */}
                                            </Box>

                                          </Box>

                                          <Grid
                                            container
                                            spacing={2}
                                            sx={{ width: 1 }}
                                            className={""}
                                            style={{
                                              justifyContent: "center",
                                              marginTop: "15px",
                                              marginBottom: '0px',
                                              marginLeft: "0px",
                                              borderBottom: "1px solid #fff",
                                              paddingInline: "0px",
                                            }}
                                          >
                                            <Grid
                                              item
                                              xs={4}
                                              sx={{ textAlign: "left", padding: "0 !important" }}
                                            >
                                            </Grid>
                                            <Grid
                                              item
                                              xs={3}
                                              sx={{ textAlign: "center", padding: "0 !important" }}
                                            ></Grid>

                                          <Grid
  item
  xs={5}
  sx={{ textAlign: "right", padding: "0 !important" }}
>
  {totalRecords > 0 ? (
    <>
      <span className={"strongerTxtLable"}>
        {t('032')} : {totalRecords}
      </span>
      <span className={"strongerTxtLable"}>
        &nbsp; / &nbsp;
        {t('033')} : {startRecord} - {totalRecords < 10 ? totalRecords : endRecord}
      </span>
    </>
  ) : null}
</Grid>


                                          </Grid>

                                          <div style={{ height: "5px" }}></div>

                                          <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                                            <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
                                              <TableHead>
                                                <TableRow className="darkgray" style={{
                                                  position: 'sticky',
                                                  top: 0,
                                                  backgroundColor: '#d3d3d3',
                                                  zIndex: 2,
                                                }}>
                                                  <TableCell colSpan={14} align="center">{t('624')}</TableCell>
                                                  <TableCell colSpan={7} align="center">{t('625')}</TableCell>
                                                  <TableCell colSpan={3}></TableCell>
                                                </TableRow>
                                              </TableHead>
                                              <TableHead>
                                                <TableRow className="darkgray" style={{
                                                  position: 'sticky',
                                                  top: 27, // Adjust based on height of previous sticky row (usually ~48px)
                                                  backgroundColor: '#f5f5f5',
                                                  zIndex: 2,
                                                }} >
                                                  <TableCell className="whiteboldtext" align="center" >{t('611')}</TableCell>
                                                  <TableCell
                                                    className="whiteboldtext"
                                                    align="center"
                                                    onClick={handleSortByDate}
                                                    style={{ cursor: 'pointer', userSelect: 'none', display: 'flex-center', justifyContent: 'center', alignItems: 'center' }}
                                                  >
                                                    {t('023')}&nbsp;
                                                    {sortDirection === 'desc' ? (
                                                      <ArrowUpward fontSize="small" />
                                                    ) : sortDirection === 'asc' ? (
                                                      <ArrowDownward fontSize="small" />
                                                    ) : (
                                                      <UnfoldMore fontSize="small" />
                                                    )}
                                                  </TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('616')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('6827')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('251620')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('617')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('623')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('3132')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('rtr_002')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('072')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('1146')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('1150')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('618')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('619')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('623')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('3132')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('rtr_002')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('072')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('1146')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('1150')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('618')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('620')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('621')}</TableCell>
                                                  <TableCell className="whiteboldtext" align="center">{t('626')}</TableCell>
                                                </TableRow>
                                              </TableHead>
                                              <TableBody>
                                                {isLoading ? (
                                                  // Show loading spinner while data is being fetched
                                                  <TableRow>
                                                    <TableCell colSpan={24} align="center" className={'spinnerDiv'}>
                                                      {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
                                                    </TableCell>
                                                  </TableRow>
                                                ) : items.length > 0 ? (
                                                  // Show table rows when data is available
                                                  // items.map((item, index) => (
                                                  sortedItems.map((item, index) => (
                                                    <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
                                                      <TableCell align="center">{item.authId ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fundTransferDate ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fundTransferId ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fundTransAmount ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.currencySymbol ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.transType}</TableCell>
                                                      <TableCell align="center">{item.fromAccount ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fromParentDistComp ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fromSalesPersonMDN ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fromAccType ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fromPartnerCompName ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fromAccPreBalance ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.fromAccPostBalance ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.bankRefferenceId ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.toAccount ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.toParentDistComp ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.toSalesPersonMDN ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.toAccType ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.toPartnerCompName ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.toAccPreBalance ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.toAccPostBalance ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.transferedBy ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.replenChannelDesc ?? '---'}</TableCell>
                                                      <TableCell align="center">{item.levl ?? '---'}</TableCell>

                                                    </TableRow>
                                                  ))
                                                ) : (
                                                  // Show 'No data found' message if no items are found after loading
                                                  <TableRow>
                                                    <TableCell colSpan={25} align="center" className="redTxt" style={{ color: 'red' }}>

                                                      {submitted ? t('2481_061') /* “No data found” */
                                                        : t('038') /* “Please provide search criteria” */}
                                                    </TableCell>
                                                  </TableRow>
                                                )}
                                              </TableBody>
                                            </Table>
                                          </TableContainer>

                                          <br></br>
                                          
                                          <Table>
                                            <tfoot>

                                              <Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                                                <Box
                                                  sx={{ textAlign: "right", padding: "4px 0px 4px 0 !important" }}
                                                  className={'displayFlex'}></Box>


                                                {items.length > 0 ? <Pagination
                                                  count={totalPages}
                                                  page={page}
                                                  onChange={handleChangePage}
                                                  showFirstButton
                                                  showLastButton
                                                /> : <></>}
                                              </Box>
                                              <tr>
                                              </tr>
                                            </tfoot>
                                          </Table>


                                          <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                            {items.length > 0 ?
                                              <div onMouseLeave={handleClose}>
                                                <Button
                                                  className="hoverEffectButton"
                                                  size="small"
                                                  variant="contained"
                                                  endIcon={<CloudDownload />}
                                                  onMouseEnter={handleHover}
                                                >
                                                  {t('089')}
                                                </Button>


                                                <Menu
                                                  anchorEl={anchorEl}
                                                  open={Boolean(anchorEl)}
                                                  onClose={() => setAnchorEl(null)}
                                                  anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                  transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                  MenuListProps={{
                                                    onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                    onMouseLeave: handleClose,
                                                  }}
                                                >
                                                  <MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{t('638')}</MenuItem>
                                                  <MenuItem onClick={() => { setAnchorEl(null); DownloadXL(); }}>{t('639')}</MenuItem>
                                                  <MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{t('640')}</MenuItem>

                                                </Menu>
                                              </div>
                                              : <></>}

                                            <Button
                                              className={"hoverEffectButton"}
                                              size="small"
                                              variant="contained"
                                              onClick={handleReturn}
                                              endIcon={<KeyboardReturn />}
                                            > {t('013')}</Button>
                                          </div>
                                          <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                                        </table>
                                    </td></tr>
                                  </div>
                                </tbody>
                              </table>
                            </td>
                          </tr>{/* MIDDLE ROW ENDS HERE  */}
                        </tbody>
                      </table>
                    </td></tr>
                </tbody>
              </table>
              <ToastContainer
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                style={{
                  width: "fit-content",
                  minWidth: "300px",
                  minHeight: "100px",
                  fontSize: "18px",
                }}
              />
            </td></tr>
          <tr height="60px"><td colSpan={2}>
            <Footer />
          </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default FundTransferReport;
