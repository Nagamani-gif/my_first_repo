import { Footer, Header, LeftBgImage, LeftMenu, PaymentManagerHeading, ProfileMenu } from './PageComponents';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import {useState} from 'react';
import {useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import TopMenu from './TopMenu';
import { CancelRounded, KeyboardReturn } from '@mui/icons-material';
import SendIcon from '@mui/icons-material/Send';
import { Button, Box , Paper, Tab, Table, TableBody, TableCell, TableContainer, Pagination,TableHead, TableRow, TextField, Grid } from '@mui/material';
import i18n from './i18n';


function ResetPassword(){
    //sessionStorage.setItem("selectedIndex", 1);
 sessionStorage.setItem("selectedLink", "a_profile");
    //Pagination
    const [page, setPage] = useState(1);
    const [perPage, setPerPage] = useState(10);
    const [satisfiedRecords, setsatisfiedRecords] = useState(0);

const localeVar=i18n.language;
    const {t} = useTranslation();
    const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
    console.log("exampleData LOGIN_ID====>"+exampleData.LOGIN_ID);
         //setting For user login
  const partnerLoginId = exampleData.LOGIN_ID;
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;

    const [partnersList, setPartnersList] = useState([]);
    const [submit, setSubmit] = useState(false);

    const [distributorId, setDistributorId] = useState("");
  const [salesPersonMdn, setSalesPersonMdn] = useState("");
  const [partnerCompName, setPartnerCompName] = useState("");
    // const clear = () => {
    //     document.getElementById('distributorId').value = "";
    //     document.getElementById('salesPersonMdn').value = "";
    //     document.getElementById('partnerCompName').value = "";
    // }
    const clear = () => {
      setDistributorId("");
      setSalesPersonMdn("");
      setPartnerCompName("");
    };

    let startRecord = (page - 1) * perPage + 1;
    let endRecord = satisfiedRecords > 0 
      ? Math.min(startRecord + perPage - 1, satisfiedRecords) 
      : (page === 1 ? 10 : page * perPage);
    const totalPages = Math.ceil(satisfiedRecords / perPage);


    const handleSubmit=()=>{
        setPage(1);
        doSubmit(1);
    }

    const handleChangePage = (event, newPage) => {
        setPage(newPage);   
      doSubmit(newPage);
    };
     
    // useEffect(() => {
    //   doSubmit(); // Fetch data on initial render and whenever the page changes
    // }, [page]); // Dependency on page to refetch data

    const doSubmit = async (currentPage) => {
        console.log("partnersList.length="+partnersList.length);
        
        try {
            var distributorId = document.getElementById('distributorId').value.trim("");
            var salesPersonMdn = document.getElementById('salesPersonMdn').value;
            var partnerCompName = document.getElementById('partnerCompName').value;

            console.log("in doSubmit");

            const apiUrl = window.config.apiUrl + process.env.REACT_APP_GETPARTNERDETAILSPWDREST;
            const response = await axios.post(apiUrl, {
              userName,
              password,
                partnerLoginId,
                distributorId,
                salesPersonMdn,
                partnerCompName,
                startPageNo: (currentPage - 1) * perPage,
                endPageNo: currentPage * perPage,
            });
            const data = response.data;

            console.log("data = "+data);
            setsatisfiedRecords(data.totalRecords);
            console.log("satisfiedRecords===",satisfiedRecords);
            setPartnersList(data.partnersList);
            console .log("partnersList.length ="+partnersList.length)
            console.log("partnersList.size = "+partnersList.length);
            console.log("data.partnersList = "+data.partnersList);


            setSubmit(true);
    
        } catch (error) {
          console.log("error in doSubmit");
        }

    }

    const navigate = useNavigate();
    const handleReturn = () => {
      navigate(-1);
    };

    useEffect(() => {
      // Set the browser title
      document.title = t('2472_016');
    }, []);
   
    return (
        <>
            <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <tbody>
                            <Header />
                    <tr height="65px">
                    <PaymentManagerHeading />
                     <TopMenu menuLink= {localeVar==='en'?"Profile":"Perfil"}/>
                    </tr>
                    <tr>
                       <LeftBgImage />

                        <table border={0} width="100%" cellSpacing={0} cellPadding={1}>
                            <tbody>
                                <ProfileMenu />
                                <tr>
                                    <td align="center">&nbsp;</td>
                                    <td align="center">&nbsp;</td>
                                </tr>
                            </tbody>
                        </table>


<div className={'mL8 input_boxess'}>
                            <Box className={'distPaymentt resetPwd'} sx={{display:'flex', width:'100%', gap: '20px', alignItems:'center'}}>
                            <TextField type="text"  label={
                                    <span>
                                      {`${t("008")}`}
                                    </span>
                                  } name="distributorId" id="distributorId" maxlength={25} size="25"  className={"sampleInput mb5"} value={distributorId} onChange={(e) => setDistributorId(e.target.value)}/>
                                  
                                  <TextField
  type="text"
  label={<span>{`${t("030")}`}</span>}
  name="salesPersonMdn"
  id="salesPersonMdn"
  size="25"
  className="sampleInput mb5"
  value={salesPersonMdn}
  onChange={(e) => {
    const value = e.target.value;

    // Allow only numbers (0-9) and limit length to 26
    if (/^\d*$/.test(value) && value.length <= 26) {
      setSalesPersonMdn(value);
    }
  }}
  
  onKeyDown={(e) => {
    const allowedKeys = ['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Tab'];
    if (allowedKeys.includes(e.key) || 
        (e.key >= '0' && e.key <= '9')) {
      return;
    }
    if (e.key === 'e' || e.key === 'E') {
      e.preventDefault();
    }
  }}
/>
    <TextField type="text" label={<span>{`${t("resetpassword1")}`}</span>}
      name="partnerCompName" id="partnerCompName" maxlength={25} size="25"  className={"sampleInput mb5"} 
    value={partnerCompName} onChange={(e) => setPartnerCompName(e.target.value)} />
  <div style={{display:'flex', justifyContent:'center', gap:'8px', alignItems:'center', height: '42px', marginTop:'-13px'}}>
  <Button className={'hoverEffectButton'} size="small"  onClick={clear} variant="contained" endIcon={<CancelRounded />}>
        {t('003')}               
      </Button>
  <Button className={'hoverEffectButton'}  size="small" variant="contained" onClick={handleSubmit} endIcon={<SendIcon />}>
      {t('028')}
      </Button>
                                 
     
  </div>
  </Box>
  <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "18px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
                <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}
                > 
{partnersList.length > 0  ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {satisfiedRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}


                {/* <span className={"strongerTxtLable"}>
                {t('032')} :  {recordsFound}
                </span>
                  <span className={"strongerTxtLable"}>
                  &nbsp; / &nbsp;
                   {t('033')} : {startRecord}-{endRecord}
                  </span> */}
                </Grid>
              </Grid>


                        <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px',marginTop:"5px" }}>
                        <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
                        <TableHead  className={'darkgray subdistributor_table'}>
                           <TableRow class="darkgray">

                                <TableCell  class="whiteboldtext">{/*Partner Id*/}{t('034')}</TableCell >
                                <TableCell  class="whiteboldtext">{/*Company Name*/}{t('resetpassword1')}</TableCell >
                                <TableCell  class="whiteboldtext">{/*First Name*/}{t('resetpassword2')}</TableCell >
                                <TableCell  class="whiteboldtext">{/*Last Name*/}{t('resetpassword3')}</TableCell >
                                <TableCell  class="whiteboldtext">{/*e-mail Addres*/}{t('037')}</TableCell >
                                <TableCell  class="whiteboldtext">{/*MDN*/}{t('030')}</TableCell >
                            </TableRow>
                            </TableHead>
                            <TableBody>
                            { submit ? <></> : <TableRow align="center"><TableCell colspan="6" style={{color: 'red'}}class="redTxt" align="center">{/*Please provide search criteria.*/}{t('038')}</TableCell></TableRow> }
                            { partnersList.length === 0 && submit ? <TableRow><TableCell colspan="6" class="redTxt" style={{color: 'red', textAlign:'center'}} align="center">{/*Requested data not found. Please refine your search criteria.*/}{t('4202')}</TableCell></TableRow> : <></> }
                            { partnersList.length > 0 ? partnersList.map((partner, index) => 
                                                                        <TableRow class={ index % 2 === 0 ? "lightgreen" : "lightyellow" }  >
                                                                            <TableCell class="arlCtrBlk" align="center" nowrap>
                                                                                <Link to={"/passwordResetVerification?distId="+partner.distributorId
                                                                                            +"&company="+partner.partnerCompName
                                                                                            +"&fName="+partner.partnerFirstName
                                                                                            +"&lName="+partner.partnerLastName
                                                                                            +"&eMail="+partner.partnerEmailId
                                                                                            +"&mdn="+partner.salesPersonMdn
                                                                                        } class="nav" style={{justifyContent:'center', textDecoration:'none', cursor: 'pointer'}} >{partner.distributorId}</Link>
                                                                            </TableCell>
                                                                            <TableCell class="arlCtrBlk" align="center" nowrap>{partner.partnerCompName}</TableCell>
                                                                            <TableCell class="arlCtrBlk" align="center"  style={{overflowWrap:'anywhere'}} nowrap>{partner.partnerFirstName}</TableCell>
                                                                            <TableCell class="arlCtrBlk" align="center" style={{overflowWrap:'anywhere'}} nowrap>{partner.partnerLastName}</TableCell>
                                                                            <TableCell class="arlCtrBlk" align="center" style={{overflowWrap:'anywhere'}} nowrap>{partner.partnerEmailId}</TableCell>
                                                                            <TableCell class="arlCtrBlk" align="center" nowrap>{partner.salesPersonMdn}</TableCell>
                                                                        </TableRow>
                                                                    ) 
                                                    : <></> }

                  

                               
                                                                
                            </TableBody>
                        </Table>
                        </TableContainer>
                        <tr><td>&nbsp;</td></tr>
                        </div>
                        {/* <input type="button" value={t('013')} class="inputButton" onClick={handleReturn} /> */}
                         {partnersList.length ?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
                        <Button
                        style={{float: 'right', marginTop: '15px', marginBottom:'15px'}}
                    className={"hoverEffectButton"}
                    size="small"
                    variant="contained"
                    onClick={handleReturn}
                    endIcon={<KeyboardReturn />}
                  >
                    {t('013')}
                  </Button>
                    </tr>
                    {/* <tr>&nbsp;</tr> */}
                    <tr height="60px">
                        <td colSpan={2}>

                            <Footer />

                        </td>
                    </tr>

                </tbody>
            </table>
        </>

    );
}

export {ResetPassword};
