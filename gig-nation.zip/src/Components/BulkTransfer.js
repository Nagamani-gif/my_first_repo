/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import { useTranslation } from "react-i18next";
import TopMenu from "./TopMenu";
import {
  LeftMenu,
  Header,
  Footer,
  PaymentManagerHeading,
  JasperLeftMenu,
  TransactionTopMenu,
  LeftBgImage,
} from "./PageComponents";
import { useCallback, useRef, useState,useEffect } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
// Importing toastify module
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import { useSelector } from "react-redux";
import { Backup, Cancel, Download, FileUpload } from "@mui/icons-material";
import SendIcon from "@mui/icons-material/Send";
import ThumbUpAltIcon from "@mui/icons-material/ThumbUpAlt";
import i18n from "./i18n";
import { useDropzone } from "react-dropzone";
import CloseIcon from "@mui/icons-material/Close";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";

function BulkTransfer() {
  const { t } = useTranslation();
  //sessionStorage.setItem("selectedIndex", 5);
 sessionStorage.setItem("selectedLink", "e_transactions");

  const [open, setOpen] = useState(false);
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState();
  const [fileNamee, setFileNamee] = useState(t("6842"));
  const [statusSuccess, setStatusSuccess] = useState(false);
  const [fileDetails, setFileDetails] = useState(false);
  const [totalTransactions, setTotalTransactions] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);
  const [availableAmount, setAvailableAmount] = useState(0);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
  const exampleData = JSON.parse(localStorage.getItem("userData"));
  const localeVar = i18n.language;
  const partnerId = exampleData.LOGIN_ID;
  const USER_TYPE_ID = exampleData.USER_TYPE_ID;
  const [pageSubmit , setPageSubmit] =useState("");

  const MAX_ROWS = 100000; // Maximum allowed rows
  const MAX_FILE_SIZE_MB = 2800; // Maximum allowed file size in MB
  const [error,setError]=useState('');
  const toastId = useRef(null);

 const [loading, setLoading] = useState(false); // Add this line
 let responseCode='';
 let responseDescription='';
 let ListUser= [];


  const isValidFileUploaded = (file) => {

    const validExtensions = ["csv"];
    const fileExtension = file.name.split(".").pop();
    return validExtensions.includes(fileExtension);
  };
  // const handleOnChangeFile = (e) => {
  //   setStatusSuccess(false);
  //   setFile(e.target.files[0]);
  //   setFileNamee(e.target.files[0].name);
  // };

//   const handleOnChangeFile = (e) => {
//     setStatusSuccess(false);

//     if (!e.target.files || e.target.files.length === 0) {
//         // console.error("No file selected.");
//         setFile(null);
//         setFileNamee(t("6842")); // Reset file name
//         return;
//     }

//     const selectedFile = e.target.files[0];

//     if (!selectedFile) {
//         // console.error("Selected file is undefined.");
//         setFile(null);
//         setFileNamee(t("6842"));
//         return;
//     }

//     setFile(selectedFile);
//     setFileNamee(selectedFile.name);
// };


  const handleOnChangeFile = (e) => {
  // Check if files exist and contain at least one file
    if (!e.target.files || e.target.files.length === 0) {
        // console.error("No file selected.");
        setFile(null);
      setFileNamee(t("6842")); // Reset file name to default
        return;
    }

    const selectedFile = e.target.files[0];

    if (!selectedFile) {
        // console.error("Selected file is undefined.");
        setFile(null);
        setFileNamee(t("6842"));
        return;
    }

    setError("");
    setStatusSuccess(false);
    setFile(selectedFile);
  setFileNamee(selectedFile?.name || t("6842")); // ✅ Ensures `name` exists
  };
 




 
  const validateCSVContent = (csvText) => {
    const lines = csvText
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line);
    const headers = lines[0].split(",").map((header) => header.trim());

    // Expected headers
    // const expectedHeaders = [t('6825'), t('6826'), t('6827')];
    // if (headers.join(",") !== expectedHeaders.join(",")) {
    //   return false;
    // }

    const expectedHeaders = [t("6825"), t("6826"), t("6827")]; // Headers will auto-switch based on language

const validateHeaders = (headers) => {
  return headers.join(",") === expectedHeaders.join(",");
};




    for (let i = 1; i < lines.length; i++) {
      const columns = lines[i].split(",").map((col) => col.trim());
      if (columns.length !== 3) {
        return false;
      }
    }

    return true;
  };

  // useEffect(() => {
  //   // Set the browser title
  //   if(pageSubmit!==""){
  //   successTransaction();
  //   }
  // }, [pageSubmit]);


  const handleOnSubmitFile = (e) => {
    e.preventDefault();
    setPageSubmit("Submit");
   // setFileNamee(t("6842"));
    console.log(file, "file????????");
    if (!file) {
      //toast.error("Please upload a file.");
      if (!toast.isActive(toastId.current)) {     
        toastId.current = toast.error(t("5515"));
       }
    }
    else{
      if (!isValidFileUploaded(file)) {
        if (!toast.isActive(toastId.current)) {     
          toastId.current =toast.error(t('6844'));
         }
        setFileDetails(false);
        return;
      }
  
       const fileSizeMB = file.size / (1024 * 1024); // Convert to MB
       if (fileSizeMB > MAX_FILE_SIZE_MB) {
        if (!toast.isActive(toastId.current)) {     
          toastId.current =toast.error("File Cannot Exceed 2800 MB in Size"); // Display error if file is too large
         }
         
         return;
       }
  
      const reader = new FileReader();
      reader.onload = (event) => {
      const csvText = event.target.result;
      const rows = csvText.split(/\r\n|\n/);
       if (rows.length > MAX_ROWS) {
        setError(t("7010"));
        setFileDetails(false);
        setFile('');
        // setFileNamee(t("6842"));
        return;
      }
  
        if (validateCSVContent(csvText)) {
          setFileDetails(true);
          setFileName(file.name);
          // successTransaction();
          successTransaction("Submit");
        }
      else if(isValidFileUploaded(file) && !validateCSVContent(csvText))
      {
        setError(t('12'))
        //setFileDetails(false);
        setFile('');
        setFileNamee(t("6842"));
  
      }
        else {
          // File is invalid
          setStatusSuccess(false);
          if (!toast.isActive(toastId.current)) {     
            toastId.current =toast.error(t('6845'));
           }
         // toast.error(t('6845'));
          setFile('');
          // setFileNamee(t("6842"));
  
        }
      };
      reader.readAsText(file);
    }
  };


 

  const proceedTransaction = async () => {
    setPageSubmit("Proceed"); // Schedule state update
    await successTransaction("Proceed"); // Pass "Proceed" explicitly
    setFileDetails(false);
    setStatusSuccess(true);
  };


  const successTransaction = async (pageSubmitValue) => {
  
    const formData = new FormData();
    formData.append("file", file);
    formData.append("pageSubmit", pageSubmitValue || pageSubmit);
    formData.append("USER_TYPE_ID",USER_TYPE_ID);
    formData.append("partnerId", partnerId);
    formData.append("localeVar", localeVar);
    formData.append("totalTransactions", totalTransactions);
    formData.append("totalAmount", totalAmount);

    console.log("form Data::001::",formData);
    
    for (let pair of formData.entries()) {
      console.log(pair[0] + ': ' + pair[1]); // Debugging log to verify form data
  }

    
    //const apiUrl="http://10.10.19.55:8080/airmanage/rest/upload/bulkTransferFileUpload";
    const apiUrl = window.config.apiUrlUpload + process.env.REACT_APP_BULK_UPLOAD_URL;
 
    console.log("API URL",apiUrl)
    setLoading(true);
     axios.post(apiUrl, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })

      .then((response) => {
        console.log("response::::::::::::",response.data);
        //setPageSubmit('');
        responseCode=response.data.responseCode;
        ListUser=response.data.ListUser;
        responseDescription=response.data.responseDescription;

     if (ListUser && ListUser.length > 0) {
          const userData = ListUser[0];
          setFileName(userData.fileName);
          setTotalTransactions(userData.totalTransactions);
          setTotalAmount(userData.totalAmount);
          setAvailableAmount(userData.availableAmount);
          setFileDetails(true);
          setError('');
        }else{
         console.error(responseDescription);
          setError(responseDescription);
          setFileDetails(false);
          setFile('');
          setFileNamee(t("6842"));
          //setFileDetails(false);
          //setError(responseDescription);
        }
      })
      .catch((error) => {
        console.log(error);
        console.error("An error occurred during the API call.");
      })
      .finally(() => {
        // Set loading to false after the API call finishes
        setLoading(false);
      });
  };

 
  const onDrop = useCallback((acceptedFiles) => {
    setFile(acceptedFiles[0]);
    setFileNamee(acceptedFiles[0].name);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ".csv",
    multiple: false,
    noClick: true, // Prevents click interaction
  });
  const handleCancel = () => {
    setFile('');
    setFileNamee(t("6842"));
    // setFileDropNamee('No File Chosen');
  };
  // MODAL CLOSING FUNCTION
  const handleClose = () => {
    setOpen(false);
  };

  useEffect(() => {
    // Set the browser title
      document.title = t('2472_024');
  }, []);

  return (
    <table
      border={0}
      cellPadding={0}
      cellSpacing={0}
      id="inSideLayoutTable"
      height={600}
      width={1000}
      align="center"
    >
      <tbody>
       <Header />
        <tr height="65px">
          <PaymentManagerHeading />
          <TopMenu
            menuLink={
              localeVar === "en" ? "Transactions" : "Transacciones"
            }
          />
        </tr>
        <tr>
          {/* <td
            valign="top"
            style={{
              borderRightStyle: "solid",
              borderRightWidth: "1pt",
              borderColor: "rgb(51 153 255)",
            }}
            nowrap="nowrap"
          >
          </td> */}
          <LeftBgImage />
          <td valign="top">
            <meta
              httpEquiv="Content-Type"
              content="text/html; charset=ISO-8859-1"
            />
            <title>homepage</title>
            <TransactionTopMenu />
            <Typography
              className={"headingText"}
              sx={{
                fontSize: "9pt",
                fontWeight: "bold",
                marginBottom: "5px",
                textAlign: "center",
              }}
              variant="body1"
              component="h2"
            >
              {/* {t("6818")} */}
            </Typography>

      
            {statusSuccess ? (
              <>
                <br />
                <p
                  className={"green"}
                  style={{
                    color: "rgb(0, 128, 0)",
                    textAlign: "center",
                    fontWeight: "bold",
                  }}
                >
                {error}
                  {/* {t("6821")} */}
                </p>
              </>
            ) : (
             <div className="redTxt" style={{ color: 'red' }} align="center">{error}</div>
            )}
            <Box className={"bulkTransfersec"}>
              <Grid
                container
                spacing={2}
                className={"displayFlexCenter"}
                style={{
                  border: "1px solid #39f",
                  borderRadius: "8px",
                  marginBottom: "10px",
                  width: "100%",
                  padding: "0px",
                }}
              >
                <Grid item xs={4} style={{ padding: "0", paddingLeft: "20px" }}>
                  <div
                    className={"strongerTxt"}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "5px",
                    }}
                  >
                    {/* &nbsp;&nbsp;{t('6819')} <span className="red">*</span> :{" "} */}
                    <div
                      className={"csvFile"}
                      style={{ position: "relative", marginTop: "0px" }}
                    >
                      <input
                        type="file"
                        id={"csvFileInput"}
                        accept={".csv"}
                        onChange={handleOnChangeFile}
                        style={{
                          position: "absolute",
                          opacity: "0",
                          cursor: "pointer",
                          zIndex: "1",
                          width: "154px",
                          height: "36px",
                        }}
                      />
                      <Button
                        variant="contained"
                        className={"uploadButtonn"}
                        color="primary"
                        endIcon={<Backup />}
                        style={{ cursor: "pointer", marginBottom: "7px" }}
                      >
                        {t("6820")}
                      </Button>
                    </div>
                  </div>
                </Grid>
                <Grid
                  item
                  xs={1}
                  style={{ padding: "0" }}
                  className={"bulkuploadLine"}
                >
                  <p style={{ paddingTop: "9px", paddingRight: "5px" }}>
                    {/* (OR) */}
                    {t("6841")}
                    </p>
                </Grid>
                <Grid item xs={7} style={{ padding: "0px 20px 0px 20px" }}>
                  <div
                    {...getRootProps()}
                    style={{
                      backgroundColor: isDragActive ? "#3399ff8a" : "#fff",
                      border: "2px dashed rgb(51 153 255)",
                      textAlign: "center",
                      marginTop: "0px",
                      height: "151px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      flexDirection: "column",
                    }}
                  >
                    <FileUpload
                      style={{
                        width: "37px",
                        height: "37px",
                        color: isDragActive ? "#fff" : "rgb(51 153 255)",
                        paddingBottom: "10px",
                      }}
                    />
                    <input {...getInputProps()} />
                    <p
                      style={{
                        color: isDragActive ? "#fff" : "rgb(51 153 255)",
                        fontSize: "14px",
                      }}
                    >
                      {/* Drag & drop */}
                      {t("6839")}
                    </p>
                  </div>
                </Grid>
              </Grid>
              <Grid
                container
                spacing={2}
                className={"displayFlexCenter"}
                style={{ marginTop: "10px", marginBottom: "10px" }}
              >
                <Grid
                  xs={12}
                  item
                  style={{
                    padding: "0",
                    paddingRight: "14px",
                    marginBottom: "10px",
                  }}
                >
                  {fileNamee && (
                    <span
                      style={{
                        fontSize: "11px",
                        marginBottom: "0",
                        overflowWrap: "anywhere",
                        textAlign: "center",
                        border: "1px solid #39f",
                        borderRadius: "5px",
                        padding: "9px 12px",
                        maxWidth: "100px",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        color: fileNamee === t('6842') ? "#39f" : "#fff",
                        background:
                          fileNamee === t('6842') ? "#fff" : "#39f",
                      }}
                    >
                      {/* Selected file: */}
                      {t("6840")}
                       <b>{fileNamee}</b>
                    </span>
                  )}
                </Grid>
                {/* <Grid item xs={4}></Grid> */}
                <Grid item xs={8}></Grid>
                <Grid
                  item
                  xs={4}
                  className={"displayFlexCenter"}
                  style={{
                    gap: "8px",
                    padding: "0",
                    justifyContent: "flex-end",
                    paddingRight: "15px",
                  }}
                >
                  {/* <p style={{textAlign: 'center', marginBottom: '0px'}}>&nbsp;&nbsp;{fileNamee}</p> */}
                  <Button
                    variant="contained"
                    style={{ height: "25px" }}
                    className={"hoverEffectButton"}
                    color="primary"
                    endIcon={<Cancel />}
                    onClick={handleCancel}
                  >
                    {t("242411")}
                  </Button>
                  <Button
                    className={"hoverEffectButton"}
                    onClick={(e) => {
                      handleOnSubmitFile(e);
                    }}
                    size="small"
                    variant="contained"
                    endIcon={<SendIcon />}
                  >
                    {t("6832")}
                  </Button>
                </Grid>
              </Grid>
              {/* <br /> */}

              <Grid container spacing={2} style={{ marginTop: "0px" }}>
                <Grid
                  item
                  xs={12}
                  style={{ display: "flex", paddingTop: "0px", gap: "10px" }}
                >
                  <Typography className={"strongerTxt"}>
                    {t("6822")} :
                  </Typography>

                  <Typography style={{ fontSize: "10px" }}>
                    {t("6823")}
                  </Typography>
                </Grid>
                <Grid item xs={8} style={{ paddingTop: "3px" }}>
                  <Typography
                    style={{
                      fontSize: "10px",
                      cursor: "pointer",
                      color: "#39f",
                      paddingLeft: "42px",
                    }}
                    onClick={() => setOpen(true)}
                  >
                    {t("6824")}
                  </Typography>
                </Grid>
                <br></br>
                &nbsp;&nbsp;
                {fileDetails && !loading ? (
                  <>
                    <TableContainer
                      component={Paper}
                      className={"shadowTable"}
                      style={{ boxShadow: "none" }}
                    >
                      <Table
                        sx={{ minWidth: 400 }}
                        size="small"
                        stickyHeader
                        aria-label="sticky table"
                        // sx={{ width: 350, margin: "0" }}
                        align="center"
                        className={"paddingzero"}
                      >
                        <TableBody>
                          <TableRow>
                            <TableCell class="strongerTxt" align="left">
                              {t("6833")}
                            </TableCell>
                            {/* <TableCell
                            style={{ padding: "0", borderLeft: "0" }}
                          >
                            :
                          </TableCell> */}
                            <TableCell class="smallerTxt" align="center">
                              &nbsp;&nbsp;{fileName}
                              <input
                                type="hidden"
                                name="fileName"
                                value="Bulk (1).csv"
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell class="strongerTxt" align="left">
                              {t("6834")}
                            </TableCell>
                            {/* <TableCell
                            style={{ padding: "0", borderLeft: "0" }}
                          >
                            :
                          </TableCell> */}

                            <TableCell class="smallerTxt" align="center">
                              &nbsp;&nbsp;
                              {totalTransactions}
                              <input
                                type="hidden"
                                name="totaltrans"
                                value={totalTransactions}
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell class="strongerTxt" align="left">
                              {t("6835")}
                            </TableCell>
                           <TableCell class="smallerTxt" align="center">
                              &nbsp;&nbsp;{totalAmount}
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell class="strongerTxt" align="left">
                              {t("6836")}
                            </TableCell>
                            <TableCell class="smallerTxt" align="center">
                              &nbsp;&nbsp;{availableAmount}
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                   <Button
                      style={{ marginLeft: "auto", marginTop: "10px" }}
                      className={"hoverEffectButton"}
                      onClick={proceedTransaction}
                      size="small"
                      variant="contained"
                      endIcon={<ThumbUpAltIcon />}
                    >
                      {t("6837")}
                    </Button>
                  </>
                ) : (
                  <></>
                )}
              </Grid>
            </Box>
          </td>
        </tr>
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          style={{
            width: "fit-content",
            minWidth: "300px",
            minHeight: "100px",
            fontSize: "18px",
          }}
        />

        <Dialog
          fullScreen={fullScreen}
          open={open}
          onClose={handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "20px", paddingBottom: "0px" }}
            className={"headerTxt"}
            align="center"
          >
            {t("68244")}
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
            }}
          >
            <CloseIcon />
          </IconButton>
          <DialogContent>
            <DialogContentText>
              <TableContainer
                component={Paper}
                className={"shadowTable"}
                style={{ boxShadow: "none" }}
              >
                <Table
                  sx={{ minWidth: 550 }}
                  size="small"
                  stickyHeader
                  aria-label="sticky table"
                  align="center"
                  className={"paddingzero"}
                >
                  <TableHead>
                    <TableRow className={"darkgray subdistributor_table"}>
                      <TableCell
                        class="strongerTxtLable"
                        align="center"
                        nowrap=""
                      >
                        {t("6825")}
                      </TableCell>
                      <TableCell
                        class="strongerTxtLable"
                        align="center"
                        nowrap=""
                      >
                        {t("6826")}
                      </TableCell>
                      <TableCell
                        class="strongerTxtLable"
                        align="center"
                        nowrap=""
                      >
                        {t("6827")}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell align="center">1</TableCell>
                      <TableCell align="center">858698</TableCell>
                      <td align="center">500</td>
                    </TableRow>
                    <TableRow>
                      <TableCell align="center">2</TableCell>
                      <TableCell align="center">9374932757</TableCell>
                      <td align="center">200</td>
                    </TableRow>
                    <TableRow>
                      <TableCell
                        style={{ textAlign: "left" }}
                        colspan="3"
                        class="strongerTxt"
                      >
                        {t("6828")}
                        <br />
                        {t("6829")}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell
                        style={{ textAlign: "left" }}
                        colspan="3"
                        class="strongerTxt"
                      >
                        {t("6830")}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell
                        style={{ textAlign: "left" }}
                        colspan="3"
                        class="strongerTxt"
                      >
                        {t("6831")}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </DialogContentText>
          </DialogContent>
        </Dialog>
        {/* MODAL ENDS HERE */}
        <tr height="60px">
          <td colSpan={2}>
            <Footer />
          </td>
        </tr>
      </tbody>
    </table>
  );
}

export default BulkTransfer;
