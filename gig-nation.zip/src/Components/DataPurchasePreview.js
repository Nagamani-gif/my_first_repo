/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import { LeftMenu, Header, Footer, PaymentManagerHeading, JasperTopMenu, LeftBgImage } from './PageComponents';
import { Link } from "react-router-dom";
import TopUpPhone from "./TopUpPhone";
import { KeyboardReturn, PlayArrow } from "@mui/icons-material";
import { Box, Grid, TextField, Typography, Button, TableContainer, TableCell, Paper, TableRow, TableHead, Table, TableBody } from "@mui/material";
import { useNavigate } from 'react-router';
import { useLocation } from 'react-router-dom';
import ThumbUpAltIcon from '@mui/icons-material/ThumbUpAlt';
import PrintIcon from '@mui/icons-material/Print';
import ReactToPrint from "react-to-print";
import { useRef } from "react";
import { useTranslation } from 'react-i18next';


function DataPurchasePreview(){
  
  const location = useLocation();
  const {t} = useTranslation();
  sessionStorage.setItem("selectedLink", "b_sellprepaidcards");

  const {partnerID, partnerMDN, paymentAmount, cellularNumber, orderId,  orderDateAndTime, typeOfTransaction,rechargeType2} = location.state || {};

  console.log("rechargeType2===========",rechargeType2);

  let typTrns='';
if(rechargeType2 ==="AIRDAT"){
  typTrns= <>{t("2480_011")}</>
}else if(rechargeType2==="SMS"){
  typTrns=<>{t("2480_014")}</>
}else if(rechargeType2==="REC"){
  typTrns=<>{t("2480_015")}</>
}else if(rechargeType2==="DAT"){
  typTrns=<>{t("2480_013")}</>  
}else if(rechargeType2==="AIRSMS"){
  typTrns=<>{t("2480_012")}</>
}


  const exampleData = JSON.parse(localStorage.getItem("userData"));
  const companyName = exampleData.COMPANY_NAME;

  const navigate = useNavigate();
  let componentRef = useRef();
  return (
      
    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
    <tbody>
       <Header/>
      <tr height="65px">
      <PaymentManagerHeading />
       <TopMenu/>
      </tr>
      <tr>
        {/* <td valign="top" style={{borderRightStyle: 'solid', borderRightWidth: '1pt',borderColor: "rgb(51 153 255)"}} nowrap="nowrap">


        </td> */}
        <LeftBgImage/>
        <td valign="top">
          <meta httpEquiv="Content-Type" content="text/html; charset=ISO-8859-1" />
          <title>homepage</title>
          <JasperTopMenu menu="menuHighlight" />
         <br />
          <Box className={'displayFlexCenter print-center-content flexDirectionColumn'} ref={(el) => (componentRef = el)}>
          <TableContainer component={Paper} className={'shadowTable'} sx={{ maxWidth: 550 }}>
                <Table  size="small" className={''} stickyHeader aria-label="sticky table">     
                  <TableHead>
                   <TableRow className={'darkgray subdistributor_table'}> <TableCell colSpan={2}>{typTrns} </TableCell></TableRow>
                  </TableHead>
                  <TableBody>    
                  <TableRow>
                  <TableCell>{t("Reprint_47")}</TableCell>
                  <TableCell>{partnerID}</TableCell>
                  </TableRow>
                  <TableRow>
                  <TableCell>{t("commercialName")}</TableCell>
                  <TableCell>{companyName} </TableCell>
                  </TableRow>
                  <TableRow>
                  <TableCell>{t("typeOfTransaction")} </TableCell>
                  <TableCell>{typeOfTransaction}</TableCell>
                  </TableRow>
                  <TableRow>
                  <TableCell>
                   {t("030")}
                    </TableCell>
                  <TableCell>{partnerMDN}</TableCell>
                  </TableRow>
                  <TableRow>
                  <TableCell>{t("049")}(MXN)</TableCell> 
                  <TableCell> ${paymentAmount}</TableCell> 
                  </TableRow>
                  <TableRow>
                  <TableCell>{t("0140")}</TableCell>
                  <TableCell>{cellularNumber}</TableCell>
                  </TableRow>
                  <TableRow>
                  <TableCell> {t("authorizationNumber")}</TableCell>
                  <TableCell> {orderId} </TableCell>
                  </TableRow>
                  <TableRow>
                  <TableCell>{t("orderAcceptDate")}</TableCell>
                  <TableCell>{orderDateAndTime}</TableCell>
                  </TableRow>
                  </TableBody>
              </Table>
             </TableContainer>
             <Typography className={'red_Text'}>{t("toTheDN")}  [{cellularNumber}]   , {t("wereYouPaid")}: [${paymentAmount}]</Typography>
          <Typography className={'regular_txt show_regular'}> {t("dial611")} 
          </Typography>
             
          </Box>
          <br />
          <Box className={'displayFlexCenter'} style={{gap:'8px'}}>
                <ReactToPrint
          trigger={() => <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<PrintIcon />}> 
          {t("print")}
         </Button>}
          content={() => componentRef}
        />
        <Button className={'hoverEffectButton'} size="small" variant="contained" onClick={() => navigate('/electronic-recharge')} endIcon={<ThumbUpAltIcon />}>
        {t("ok")}
                </Button>
          </Box>
          <br />

          <Typography className={'regular_txt hide_regular'}> {t("dial611")} 
          </Typography>
          <br />
        </td>
      </tr>

      
      <tr height="60px">
        <td colSpan={2}>
       <Footer/>
        </td>
      </tr>
    </tbody></table>
  );
}

export default DataPurchasePreview;
