import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import SendIcon from '@mui/icons-material/Send';
import Stack from '@mui/material/Stack';
import '../sample.css';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Radio from '@mui/material/Radio';
import { styled } from '@mui/material/styles';
import FormControlLabel from '@mui/material/FormControlLabel';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import Paper from '@mui/material/Paper';
import { v4 as uuidv4 } from 'uuid';
import { Checkbox, FormGroup, Grid, TableContainer, TableRow, Typography } from '@mui/material'
import BoyRoundedIcon from '@mui/icons-material/BoyRounded';
import { AccountBalance, AddCardRounded, Backup, Boy, BoyRounded, CallMissedOutgoingRounded, CancelOutlined, CancelRounded, CancelScheduleSendRounded, CloudDownload, CurrencyRupeeRounded, EditAttributesOutlined, FindInPage, FindInPageRounded, KeyboardReturn, ManageSearch, ManageSearchRounded, RemoveRedEyeRounded, RouteOutlined, ScreenSearchDesktop, Search, ThumbsUpDown, ViewAgendaOutlined } from '@mui/icons-material';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import ThumbUpAltIcon from '@mui/icons-material/ThumbUpAlt';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import EditIcon from '@mui/icons-material/Edit';
import AddIcon from '@mui/icons-material/Add';
function App() {
  const [value, setValue] = React.useState('one');

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const [rechargeInfo, setRechargeInfo] = useState([
    {
        id: uuidv4(),
        denomValue: '2.0',
        airTime: '1',
        packetPlanValue: '9.0',
        validityDays: '1'
    },
    {
        id: uuidv4(),
        denomValue: '9.0',
        airTime: '9',
        packetPlanValue: '9.0',
        validityDays: '1'
    },
    {
        id: uuidv4(),
        denomValue: '29.0',
        airTime: '10',
        packetPlanValue: '8.0',
        validityDays: '80000'
    },
    {
        id: uuidv4(),
        denomValue: '2.0',
        airTime: '1',
        packetPlanValue: '9.0',
        validityDays: '1'
    },
    {
        id: uuidv4(),
        denomValue: '9.0',
        airTime: '9',
        packetPlanValue: '9.0',
        validityDays: '1'
    },
    {
        id: uuidv4(),
        denomValue: '29.0',
        airTime: '10',
        packetPlanValue: '8.0',
        validityDays: '80000'
    }
 ]);
 const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: '#3399FF',
      borderLeft: '1px solid #e5e5e5',
      color: theme.palette.common.white,
      padding: '3px',
      fontWeight: '700',
fontFamily: 'Arial',
fontSize: 11,

    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 11,
     padding: '0px',
fontFamily: 'Arial',
borderLeft: '1px solid #e5e5e5',

    },
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: '#E5E5E5',
    },
    '&:nth-of-type(odd) td': {
      borderLeft: '1px solid #fff',
    },
    // hide last border
    '&:last-child td, &:last-child th': {
    },
  }));
  const BpIcon = styled('span')(({ theme }) => ({
    borderRadius: '50%',
    width: 16,
    height: 16,
    boxShadow:
      theme.palette.mode === 'dark'
        ? '0 0 0 1px rgb(16 22 26 / 40%)'
        : 'inset 0 0 0 1px rgba(16,22,26,.2), inset 0 -1px 0 rgba(16,22,26,.1)',
    backgroundColor: theme.palette.mode === 'dark' ? '#394b59' : '#f5f8fa',
    backgroundImage:
      theme.palette.mode === 'dark'
        ? 'linear-gradient(180deg,hsla(0,0%,100%,.05),hsla(0,0%,100%,0))'
        : 'linear-gradient(180deg,hsla(0,0%,100%,.8),hsla(0,0%,100%,0))',
    '.Mui-focusVisible &': {
      outline: '2px auto rgba(19,124,189,.6)',
      outlineOffset: 2,
    },
    'input:hover ~ &': {
      backgroundColor: theme.palette.mode === 'dark' ? '#30404d' : '#ebf1f5',
    },
    'input:disabled ~ &': {
      boxShadow: 'none',
      background:
        theme.palette.mode === 'dark' ? 'rgba(57,75,89,.5)' : 'rgba(206,217,224,.5)',
    },
  }));
  
  const BpCheckedIcon = styled(BpIcon)({
    backgroundColor: '#137cbd',
    backgroundImage: 'linear-gradient(180deg,hsla(0,0%,100%,.1),hsla(0,0%,100%,0))',
    '&::before': {
      display: 'block',
      width: 16,
      height: 16,
      backgroundImage: 'radial-gradient(#fff,#fff 28%,transparent 32%)',
      content: '""',
    },
    'input:hover ~ &': {
      backgroundColor: '#106ba3',
    },
  });
  const styleObj = {
    minHeight: 'auto',
    padding: '12px 15px',
    maxHeight: 'max-content',
    margin: '10px 15px',
    border:' 1px solid #1976d2',
    borderRadius: '5px',
    color: '#1976d2',
    boxShadow: '0px 6px 15px rgb(25 118 210)',
    scale: '0.9',
    transition: '0.5s',
    "&:hover": {
      background: '#1976d2',
      color: '#fff',
      borderRadius: '5px',
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, .1), 0 2px 4px -1px rgb(0 0 0 / 75%)',
      transition: '0.5s',
      scale: '1',
    },
   "&.Mui-selected": {
    background: '#1976d2',
    color: '#fff',
  }
  };
  const [age, setAge] = React.useState('');
  const handledropdown =(event)=>{
    setAge(event.target.value);
    alert(event.target.value);
  }
  return (
    <div>
      <h1>Buttons</h1>
    <Stack direction="row" spacing={2}>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}>
        Submit
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CloudDownload />}>
        Download
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<KeyboardReturn />}>
        Return
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<AccountBalance />}>
        Deposit Balance
      </Button>
      {/* <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<ManageSearchRounded />}>
        Search
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<Search />}>
        Search
      </Button> */}
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<FindInPageRounded />}>
        Search
      </Button>
     
      
      {/* <Button className={"iconEffectButton"} size="small" variant="contained"><span>Submit</span> <SendIcon className={'hovericon'} /></Button> */}
      {/* <Button variant="outlined" size="small">
          Submit
        </Button>
        <Button className={'sampleButton'} variant="contained" size="small">
          Submit
        </Button> */}
    </Stack>
    <br />

    <Stack direction="row" spacing={2}>
    <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<AddCardRounded />}>
        Add
      </Button>
      {/* <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelScheduleSendRounded />}>
        Clear
      </Button> */}
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelRounded />}>
        Clear
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CallMissedOutgoingRounded />}>
       Go
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RemoveRedEyeRounded />}>
        Preview
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelOutlined />}>
        Cancel
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<ThumbUpAltIcon />}>
        Proceed
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<TaskAltIcon />}>
        Execute
      </Button>
      {/* <Button className={"iconEffectButton"} size="small" variant="contained"><span>Submit</span> <SendIcon className={'hovericon'} /></Button> */}
      {/* <Button variant="outlined" size="small">
          Submit
        </Button>
        <Button className={'sampleButton'} variant="contained" size="small">
          Submit
        </Button> */}
    </Stack>

    <br />
    <Stack direction="row" spacing={2}>
   <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<AddIcon />}>
        Add Route
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RemoveRedEyeRounded />}>
        View Route
      </Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<EditIcon />}>
        Edit Route
      </Button>
   </Stack>
    <br />
    <h1>Input Boxes</h1>
    
    <Box
      component="form"
      sx={{
        '& .MuiTextField-root': { m: 1, width: '25ch' },
      }}
      noValidate
      autoComplete="off"
    >
       <div style={{position: 'relative'}}>
      <TextField type="file" style={{position: 'absolute', opacity: '0', cursor: 'pointer', zIndex: "1"}} />
      <Button variant="contained" color="primary" endIcon={<Backup />} style={{cursor : 'pointer'}}>
        Upload
      </Button>
    </div>
    <TextField
    className={'sampleInput'}
          id="outlined"
          label="Required"
          defaultValue=""
        />
        <TextField
        style={{background: '#1976d21a'}}
    className={'sampleInput'}
          required
          id="outlined"
          label="Required"
          defaultValue=""
        />
         <TextField
          className={'sampleInput'}
          required
          id="filled"
          label="Required"
          defaultValue=""
          variant="filled"
        />
        <br />
          <TextField
           className={'sampleInput'}
          required
          id="standard-required"
          label="Required"
          defaultValue=""
          variant="standard"
        />
        </Box>
    <br />
        <h1>Radio Button</h1>
      <FormControlLabel value="Male" control={<Radio
        
        value="a"
        name="radio-buttons"
        inputProps={{ 'aria-label': 'A' }}
      />} label="Male" >

      </FormControlLabel>
      <FormControlLabel value="female" control={<Radio
      disableRipple
      color="default"
      checkedIcon={<BpCheckedIcon />}
      icon={<BpIcon />}
    />} label="Female" />
  <br />
  <h1>Checkboxes</h1>
  <FormGroup>
  <FormControlLabel control={<Checkbox defaultChecked />} label="Label" />
</FormGroup>
  <br />
    <h1>Tables</h1>
    
    <TableContainer component={Paper} style={{marginTop: '10px', borderRadius: '8px', boxShadow: '0px 6px 15px rgb(25 118 210)'}}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table" style={{  border: '1px solid #e5e5e5'}}>
        <TableHead>
          <TableRow>
            <StyledTableCell></StyledTableCell>
            <StyledTableCell align="center">Denom Value</StyledTableCell>
            <StyledTableCell align="center">Air Time</StyledTableCell>
            <StyledTableCell align="center">Packet Plan Value</StyledTableCell>
            <StyledTableCell align="center">Validity Days</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rechargeInfo.map((row) => (
            <>
            <StyledTableRow key={row.id} style={{
            boxShadow: '0px 0px 9px 0px rgba(0,0,0,0.1)', margin: '10px'}}>
              <StyledTableCell component="th" scope="row" align='center'>
                <Radio style={{height: '30px'}} size="small" />
              </StyledTableCell>
              <StyledTableCell align="center" className={'smallerTxt'}>{row.denomValue}</StyledTableCell>
              <StyledTableCell align="center" className={'smallerTxt'}>{row.airTime}</StyledTableCell>
              <StyledTableCell align="center" className={'smallerTxt'}>{row.packetPlanValue}</StyledTableCell>
              <StyledTableCell align="center" className={'smallerTxt'}>{row.validityDays}</StyledTableCell>
            </StyledTableRow>
            </>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <TableContainer component={Paper} style={{marginTop: '10px', borderRadius: '8px'}}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table" style={{  border: '1px solid #e5e5e5'}}>
        <TableHead>
          <TableRow>
            <StyledTableCell></StyledTableCell>
            <StyledTableCell align="center"><BoyRoundedIcon /> Employee Name</StyledTableCell>
            <StyledTableCell align="center"><CurrencyRupeeRounded />Transfered Amount</StyledTableCell>
            <StyledTableCell align="center">Packet Plan Value</StyledTableCell>
            <StyledTableCell align="center">Validity Days</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rechargeInfo.map((row) => (
            <>
            <StyledTableRow key={row.id} style={{
            boxShadow: '0px 0px 9px 0px rgba(0,0,0,0.1)', margin: '10px'}}>
              <StyledTableCell component="th" scope="row" align='center'>
                <Radio style={{height: '30px'}} size="small" />
              </StyledTableCell>
              <StyledTableCell align="center" className={'smallerTxt'}>{row.denomValue}</StyledTableCell>
              <StyledTableCell align="center" className={'smallerTxt'}>{row.airTime}</StyledTableCell>
              <StyledTableCell align="center" className={'smallerTxt'}>{row.packetPlanValue}</StyledTableCell>
              <StyledTableCell align="center" className={'smallerTxt'}>{row.validityDays}</StyledTableCell>
            </StyledTableRow>
            </>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <br />
    <h1>Dropdowns</h1>
   
    <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
      <InputLabel id="demo-select-small-label">Age</InputLabel>
      <Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        label="Age"
        value={age}
        onChange={handledropdown}
      >
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    </FormControl>
    <h1>Tabs</h1>
    <Tabs
        value={value}
        onChange={handleChange}
        className={'sampleTabEffect'}
        indicatorColor="none"
      >
        <Tab sx={styleObj} value="one" label="Item One" />
        <Tab sx={styleObj} value="two" label="Item Two" />
        <Tab sx={styleObj} value="three" label="Item Three" />
      </Tabs>
      <br />
      <Typography style={{paddingLeft: '30px'}}>{value}</Typography>
      <br />
      <Tabs
        value={value}
        onChange={handleChange}
        className={'sampleTab'}
      >
        <Tab value="one" label={
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <BoyRoundedIcon style={{ marginRight: 8, color: '#3399FF' }} />
            Item One
          </div>
        }  />
        <Tab value="two" label="Item Two" />
        <Tab value="three" label="Item Three" />
      </Tabs>
      <Typography style={{paddingLeft: '30px'}}>{value}</Typography>
      <br />
    </div>
  );
}

export default App;
