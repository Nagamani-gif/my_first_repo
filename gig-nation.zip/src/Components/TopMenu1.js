/* eslint-disable jsx-a11y/alt-text */
import React from 'react';
import { useNavigate } from 'react-router';
import { useState } from "react";
import { useSelector } from 'react-redux';

function TopMenu() {

  //const [menulist,setmenuList] =useState([]);
 const menulist = useSelector(state => state.example.data.userPrivileges);
 console.log("menulist::::",menulist);


 //Extracting the values from menulist at specific indices
 const homeReplacement = menulist[5] ? "Home": Object.keys(menulist[5])[0];
 const Profile = menulist[7] ? "Profile": Object.keys(menulist[7])[0];
 const ElectronicRcg = menulist[1] ?"Electronic Recharge":Object.keys(menulist[1])[0];
 const SalesPeople = menulist[8] ? Object.keys(menulist[8])[0] : "Sales People";
 const Subdistributors = menulist[9] ? Object.keys(menulist[9])[0] : "Subdistributors";
 const Transactions = menulist[2] ? Object.keys(menulist[2])[0] : "Transactions";
 const PublicTelphn = menulist[0] ? Object.keys(menulist[0])[0] : "Public Telephones";
 const PostPaidpymnt = menulist[6] ? Object.keys(menulist[6])[0] : "PostPaid Payments";
 const SIMmngmnt = menulist[3] ? Object.keys(menulist[3])[0] : "SIM Management";

  const menuLinks = [homeReplacement,Profile, ElectronicRcg, 'Sales People', 'Subdistributors', 'Transactions', 'Public Telephones', 'PostPaid Payments', 'SIM Management'];

  const navigate = useNavigate();

  const [selectedLink, setSelectedLink] = useState(0);

  const handleLinkClick = async (path, index) => {
    console.log("selectedLink in function===="+selectedLink);
    console.log("index in function====",index);

    setSelectedLink(selectedLink === index ? null : index);
    navigate(path);
  };
 
 

  const linksSize = menuLinks.length;

  const getContent = (menuLinks) => {

    let content = []; 

    
    for(let i = 0; i < linksSize; i++){
      content.push(
        <td  key={i}><table cellPadding={0} cellSpacing={0}><tbody>
        <tr height={28}><td>&nbsp;<img border={0} src={require("../images/arrow_icon.gif")}  width={3} height={5} /></td>
        <td>
          <div className={selectedLink === i ? "tabSelected" : "tab"}
              onClick={() => handleLinkClick(`/${menuLinks[i].toLowerCase().replace(/\s/g, '-')}`,i)}> 
          &nbsp;&nbsp;{menuLinks[i]}
         
        </div></td></tr></tbody></table></td>
      );
      if((i + 1) % 4 === 0 ){
        content.push(<tr></tr>);
      }
 
    }

    //console.log("selectedLink====>"+selectedLink);

    return content;
  }

  return(
    <>
      {getContent(menuLinks)}
    </>
  );
}

export default TopMenu;
