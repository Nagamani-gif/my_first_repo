/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, LeftBgImage, LeftBgImage1 } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, CircularProgress, FormControl, Grid, InputLabel, MenuItem, Pagination, Paper,styled, Select, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, Menu, Dialog, DialogTitle, DialogContent, IconButton } from "@mui/material";
import React, { useState, useEffect, useCallback, useRef } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CancelRounded, CloudDownload, KeyboardReturn, SaveAs } from "@mui/icons-material";
import {  NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
 import ExcelJS from 'exceljs';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import TransactionDetails from "./TransactionDetails";
import dayjs from "dayjs";
import { toast, ToastContainer } from "react-toastify";




function Transactions(){

  sessionStorage.setItem("selectedLink", "e_transactions");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);

  const toastId = useRef(null);

  const [items, setItems] = useState([]);
  const [debitAmt, setDebitAmt] = useState(0);
    const [totalAmt, setTotalAmt] = useState('');
  
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
  const [apply,setApply] =useState(false);
 
  const[cellularNumber,setCellularNumber]=useState('');
  const[subDistId,setSubDistId]=useState('');
  const[orderId,setOrderId]=useState('');
  const[sequenceIso,setSequenceIso]=useState('');
  const[transId,setTransId]=useState('');
  const[authorizationId,setAuthorizationId] =useState('');
  const[distCelNum,setDistCelNum] =useState('');
  const[startAmt,setStartAmt] =useState('');
  const[endAmt,setEndAmt] =useState('');
  const[canalId,setCanalId] =useState('');
  const[terminalId,setTerminalId] =useState('');
  const[sucursalId,setSucursalId] =useState('');

  const now = dayjs();  
  const midnightToday = dayjs().startOf('day');

  const [startDateTime, setStartDateTime] = useState(midnightToday);
  const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
  
  const [endDateTime, setEndDateTime] = useState(now);
  const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));
  const [status, setStatus] = useState('A');
  const [hierarchyMode, setHierarchyMode] = useState('N');
 const [repchannels, setRepchannels] = useState([]);
 const [prePaidSystem, setPrepaidSystem] = useState([]);
 const[prpaidSys,setPrpaidSys]=useState(0);
 const[repValue,setRepValue]=useState(0);
const [anchorEl, setAnchorEl] = useState(null);

 const [hasSubmitted, setSubmit] = useState(false);
const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedTransId, setSelectedTransId] = useState(null);
  const [selectedTransDate, setSelectedTransDate] = useState(null);
    const [parentName, setparentName] = useState(null);

let netAmt= 0;

  let reportDays = process.env.REACT_APP_ReportDays;


  const [transIdError, setTransIdError] = useState('');

  const navigate = useNavigate();

  console.log("totalRecords++++++++++++",totalRecords)


   let startRecord = 0;
   let endRecord = 10;


  const handleChangePage =(event, newPage) => {
    event.preventDefault();

 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       hasSubmitted
     });
 
  if (!isValid) {
  setSubmit(false);  // reset submit flag
  return;
}
if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmit(false);
    }
return false;

}

    setPage(newPage);
  };

  
  useEffect(() => {
  if (!hasSubmitted) return;
  fetchData();           // runs every time `page` changes
}, [page,hasSubmitted]);



const orderIdRef = useRef(null);
const authorizationIdRef = useRef(null);
const transIdRef = useRef();
const startAmtRef =useRef();
const endAmtRef = useRef();


  const handleSubmit1= ()=>{

    try {
      console.log("status",status);

    if (orderId.trim() !== '' && !/^-?\d+$/.test(orderId)) {
      if (!toast.isActive(toastId.current)) {
     toastId.current = toast.error(`${t('alrt_02')} ${t('2480_0019')} ${t('2480_032')}.`, {
      onClose: () => {
        orderIdRef.current?.focus();  // Focus after toast closes
      }
    });
  }
    return;
    }

     if (transId.trim() !== '' && !/^-?\d+$/.test(transId)) {
      if (!toast.isActive(toastId.current)) {
         toastId.current = toast.error(`${t('alrt_02')} ${t('2480_0019')} ${t('2480_052')}.`, {
         onClose: () => {
        transIdRef.current?.focus();  // Focus after toast closes
      }
    });
  }
      return;
    }

    if (authorizationId.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(authorizationId)) {
      if (!toast.isActive(toastId.current)) {
     toastId.current = toast.error(`${t('alrt_01')} ${t('2480_0019')} ${t('2480_033')}.`, {
      onClose: () => {
       authorizationIdRef.current?.focus();  // Focus after toast closes
      }
    });
  }
    return;
   }


    if (startAmt.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(startAmt)) {
    if (!toast.isActive(toastId.current)) {
     toastId.current = toast.error(`${t('alrt_01')} ${t('2480_0019')} ${t('2480_053')}.`, {
      onClose: () => {
       startAmtRef.current?.focus();  // Focus after toast closes
      }
    });
  }
    return;
   }

if (endAmt.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(endAmt)) {
  if (!toast.isActive(toastId.current)) {
     toastId.current = toast.error(`${t('alrt_01')} ${t('2480_0019')} ${t('2480_054')}.`, {
      onClose: () => {
       endAmtRef.current?.focus();  // Focus after toast closes
      }
    });
  }
    return;
   }


 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       hasSubmitted
     });
 
//   if (!isValid) {
//   setSubmit(false);  // reset submit flag
//   return;
// }
if (!isValid){
  setApply(false);
  return;
} 

    startRecord=0;
    endRecord =10;
     fetchData();
      setPage(1);
      setSubmit(true)
      setApply(true);
    
    } catch (error) {
      console.error("An error occurred:", error);
    }
      
  }

  


 const RedAsterisk = styled('span')({
    color: 'red',
  });

  let transStatus="A";

 
 
 
  if(status==="A"){
    transStatus="";
  }else if(status==="Y"){
    transStatus="Y";
  }else if(status==="N"){
    transStatus="N";
  }

useEffect(() => {
  fetchRepChannels();
  fetchPrepaidSytem();
  }, []);

  const fetchRepChannels=async () => {
    const apiUrl =window.config.apiUrlJasper+ '/replenishmentChannels'
    //const apiUrl= window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
    console.log(apiUrl);
    const response= await axios.post(apiUrl, {
      userName,
      password,
      localeVar,
    });
   setRepchannels(response.data)
   console.log("repchannel;;;;;;",response.data)
  }


const fetchPrepaidSytem=async () => {
    const apiUrl =window.config.apiUrlJasper+ '/prepaidSystemLOV'
    //const apiUrl= window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
    console.log(apiUrl);
    const response= await axios.post(apiUrl, {
      userName,
      password,
    });
   //setPrepaidSystem(response.data)
   const responseData =response.data;
   setPrepaidSystem(responseData.connectionDetails || [])

   console.log("prepaidSystem;;;;;;",responseData.connection)
  }



  useEffect(() => {
    // Set the browser title
      document.title = t('2472_010');
  }, []);



//date validation 
const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t,hasSubmitted }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
     setSubmit(false);
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      
    }
    return false;
  }

  return true;
};

 const handleEndDateTimeChange = (newValue) => {
  setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };
    const handleStartDateTimeChange = (newValue) => {
      setApply(false);
      setStartDateTime(newValue); 
     const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
     setStartDate(formattedDateTime);
      console.log("startDate::::::",newValue)
       console.log("startDate::::::",formattedDateTime)
    };


    console.log("sequenceIso====>",sequenceIso);

  const fetchData = async () => {
    localStorage.removeItem('channels');
    setIsLoading(true);
    try {
      const apiUrl = window.config.apiUrlJasper+ '/transReport';
      const response = await axios.post(apiUrl, {          
        userName,
        password,
        partnerId:partnerLoginId,
        localeVar,
        cellularNumber,
        subDistId,
        orderId,
        paymentrefId:sequenceIso,
        transId,
        authorizationId,
        salesPersonMdn:distCelNum,
        startAmt,
        endAmt,
        canalId,
        terminalId,
        sucursalId,
        replenishChnl:repValue,
        prepaidSys:prpaidSys,
        status:transStatus,
        lavelFlag: hierarchyMode,
        transFromDate:startDate,
        transToDate:endDate,
        startpage: startRecord,
        endpage: endRecord < 10 ? '10' :endRecord
      });
      console.log("response::::::",response.data);
       if (response.status === 200) {
        setItems(response.data.data);
        setTotalRecords(response.data.noOfRecord);
        setDebitAmt(response.data.debitAmt);
        setTotalAmt(response.data.totalAmt)

       }
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };



  const handleOpen = (transId,transDate,parentName) => {
    setSelectedTransId(transId);
    setSelectedTransDate(transDate);
    setparentName(parentName)
    setIsDialogOpen(true);
  };

  const handleClose = () => {
    setIsDialogOpen(false);
    setSelectedTransId(null);
  };


 const fetchDataDownload = async () => {


 const isValid = validateDateRange({
       startDateTime,
       endDateTime,
       reportDays,
       toast,
       toastId,
       t,
       hasSubmitted
     });
 
if (!isValid) {
  setSubmit(false);  // reset submit flag
  return;
}

if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmit(false);
    }
return false;

}


    try {
     // const localeVar = 'en';
      const apiUrlDownload = window.config.apiUrlJasper+ '/transReport';

      const response = await axios.post(apiUrlDownload, {
        userName,
        password,
        transFromDate:startDate,
        transToDate:endDate,
         partnerId:partnerLoginId,
        localeVar,
        cellularNumber,
        subDistId,
        orderId,
        paymentrefId:sequenceIso,
        transId,
        authorizationId,
        salesPersonMdn:distCelNum,
        startAmt,
        endAmt,
        canalId,
        terminalId,
        sucursalId,
        replenishChnl:repValue,
        prepaidSys:prpaidSys,
        status:transStatus,
        lavelFlag: hierarchyMode,
        // partnerLoginId,
      });

        if (!Array.isArray(response.data.data)) {
      throw new Error('Invalid API response: Expected array');
    }
     console.log("response.data.data",response.data.data)
       return response.data.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };



 const exportAsExcel = async () => {
    const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Transaction_Monitor_Report_V2');

    const numberOfColumns = 32;
    const headingRow1 = worksheet.addRow([t('0_transactions')]);
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    headingRow1.getCell(1).font = { bold: true };
    headingRow1.getCell(1).alignment = { horizontal: 'center' };
    worksheet.addRow([]);
  
const columnHeaders = [
    t('2480_079'), t('2480_031'), t('2480_032'), t('2480_033'), t('2480_034'), t('2480_035'), t('2480_036'), t('023'),
    t('0122'), t('5597_dis'), t('251608'), t('2480_037'), t('251620'), t('2480_059'), t('7056'), t('2480_038'),
    t('055'), t('2480_039'), t('2480_060'), t('2480_040'), t('2480_041'), t('2480_042'), t('2480_043'), t('1245'), t('2480_051'),
    t('2480_044'), t('2480_045'), t('2480_046'), t('0142'), t('2480_047'), t('2480_048'), t('2480_049'), t('2480_050')
  ];

const totalRecords = downloadItems[0]?.noOfRecord || downloadItems.length;

const amtRecv     = totalAmt;
const debtAmtRecv = debitAmt;

const summaryRow = worksheet.addRow([]);   // start with an empty row


const totalColumns = numberOfColumns;
const oneThird = Math.floor(totalColumns / 3);

const leftStart   = 1;
const middleStart = oneThird + 1;
const rightStart  = (2 * oneThird) + 1;

// Merge cells first
worksheet.mergeCells(summaryRow.number, leftStart, summaryRow.number, middleStart - 1);
worksheet.mergeCells(summaryRow.number, middleStart, summaryRow.number, rightStart - 1);
worksheet.mergeCells(summaryRow.number, rightStart, summaryRow.number, totalColumns);

// Now set values (after merge!)
summaryRow.getCell(leftStart).value   = `${t('2480_061')}(MXN): ${amtRecv}`;
summaryRow.getCell(middleStart).value = `${t('2480_062')}(MXN): ${debtAmtRecv}`;
summaryRow.getCell(rightStart).value  = `${t('2480_063')}(MXN): ${amtRecv-debtAmtRecv}`;


summaryRow.eachCell(cell => {
  cell.font = { bold: true };
  cell.alignment = { horizontal: 'left' }; // Use 'center' if preferred
});

//const totalRecordsRow = worksheet.addRow([`${t('032')}: ${totalRecords}`]);

const sameLineRow = worksheet.addRow(
  Array(numberOfColumns).fill('') // Fill the entire row with empty cells
);

// Set left-side label (first cell)
const leftCell = sameLineRow.getCell(1);
leftCell.value = `${t('032')}: ${totalRecords}`; // e.g., "Total: 100"
leftCell.font = { bold: true };
leftCell.alignment = { horizontal: 'left' };

// Set right-side label (last cell)
// const rightCell = sameLineRow.getCell(numberOfColumns);
// rightCell.value = `${t('033')}: ${totalRecords}`; // e.g., "Displayed: 100"
// rightCell.font = { bold: true };
// rightCell.alignment = { horizontal: 'right' };


// worksheet.mergeCells(totalRecordsRow.number, 1, totalRecordsRow.number, numberOfColumns);
// totalRecordsRow.getCell(1).font = { bold: true };
// totalRecordsRow.getCell(1).alignment = { horizontal: 'left' };

   worksheet.addRow([]);
    const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' }, left: { style: 'thin' },
        bottom: { style: 'thin' }, right: { style: 'thin' },
      };
    });

    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
      item.cellularNumber,
        item.customerType === 'Retail Subscriber' 
                     ? t('2480_064')         
                    : item.customerType,
     // item.customerType,
      item.orderId,
      item.authorizationId,
      item.transId,
      item.sequenceISO,
      item.recSeqNum,
      item.transactionDate,
           item.paymentType === 'Cash' ? t('020') :
                   item.paymentType === 'Bank' ? t('021') :
                   item.paymentType,
     // item.paymentType,
      item.distId,
      item.distName,
      !isNaN(parseFloat(item.transAmt)) ? parseFloat(item.transAmt).toFixed(2) : '---',
      item.currency,
      item.replenishChnl,
      item.parentId,
      item.distCelNum,
      item.status,
      item.parentName,
      item.parentCompanyName,
      item.originCode,
      item.transCategory,
      item.promotionName,
      item.altamiraPlanName,
      item.packetCode,
      item.terminalId,
      item.canalId,
      item.sucursalId,
      !isNaN(parseFloat(item.feeAmt)) ? parseFloat(item.feeAmt).toFixed(2) : '---',
      !isNaN(parseFloat(item.airAmt)) ? parseFloat(item.airAmt).toFixed(2) : '---',
      !isNaN(parseFloat(item.debtAmt)) ? parseFloat(item.debtAmt).toFixed(2) : '---',
      !isNaN(parseFloat(item.insuranceAmt)) ? parseFloat(item.insuranceAmt).toFixed(2) : '---',
      item.level,
      item.mainDistCompanyName
      ]);
       dataRow.eachCell(cell => {
      cell.border = {
        top: { style: 'thin' }, left: { style: 'thin' },
        bottom: { style: 'thin' }, right: { style: 'thin' },
      };
      cell.alignment = { horizontal: 'center' };
    });
  });

  worksheet.addRow([]);
  const endOfReportRow = worksheet.addRow([t('0171')]);
  worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
  const endOfReportCell = endOfReportRow.getCell(1);
  endOfReportCell.font = { italic: true, underline: true, bold: true };
  endOfReportCell.alignment = { horizontal: 'center' };

  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });

  worksheet.protect('yourPassword', {
    selectLockedCells: true,
    selectUnlockedCells: true,
    formatCells: true,
      formatColumns: true,
      formatRows: true,
  });

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });

  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'Transaction_Monitor_Report_V2.xlsx';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};



 
const formatter = new Intl.NumberFormat('en-US', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});


const formatAmount = (value) => {
  return value != null && !isNaN(value) ? formatter.format(Number(value)) : "---";
};
const exportAsPdf = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  // Use A2 for wider space to fit all columns
  const doc = new jsPDF({
    orientation: 'landscape',
     format: [500, 1000],
    unit: 'pt'
  });

  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;
  const amtRecv     = totalAmt;
  const debtAmtRecv =debitAmt;
  const  totalAmount   =amtRecv-debtAmtRecv
  // Heading
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text(t('2480_085'), doc.internal.pageSize.getWidth() / 2, 40, { align: 'center' });

  // Total records
// Heading
// doc.setFontSize(18);
// doc.setFont(undefined, 'bold');
// doc.text('Transacciones', doc.internal.pageSize.getWidth() / 2, 40, { align: 'center' });

// Data row
doc.setFontSize(10);
doc.setFont(undefined, 'normal');
// doc.text(`${t('2480_061')} (MXN): ${amtRecv}`,           15, 60);
// doc.text(`${t('2480_062')} (MXN): ${debtAmtRecv}`,       400, 60);
// doc.text(`${t('2480_063')} (MXN): ${amtRecv - debtAmtRecv}`, 855, 60); // col 2  (≈ +100 px)
// // col 3  (≈ +100 px)
// doc.text(`${t('032')}: ${totalRecords}`, 15, 75); 




const columnHeaders = [
    t('2480_079'), t('2480_031'), t('2480_032'), t('2480_033'), t('2480_034'), t('2480_035'), t('2480_036'), t('023'),
    t('0122'), t('5597_dis'), t('251608'), t('2480_037'), t('251620'), t('2480_059'), t('7056'), t('2480_038'),
    t('055'), t('2480_039'), t('2480_060'), t('2480_040'), t('2480_041'), t('2480_042'), t('2480_043'), t('1245'), t('2480_051'),
    t('2480_044'), t('2480_045'), t('2480_046'), t('0142'), t('2480_047'), t('2480_048'), t('2480_049'), t('2480_050')
  ];


  const rows = downloadItems.map(item => [
    item.cellularNumber,
      item.customerType === 'Retail Subscriber' 
                     ? t('2480_064')         
                    : item.customerType,
     // item.customerType,
      item.orderId,
      item.authorizationId,
      item.transId,
      item.sequenceISO,
      item.recSeqNum,
      item.transactionDate,
           item.paymentType === 'Cash' ? t('020') :
                   item.paymentType === 'Bank' ? t('021') :
                   item.paymentType,
     // item.paymentType,
      item.distId,
      item.distName,
      formatAmount(item.transAmt),
      item.currency,
      item.replenishChnl,
      item.parentId,
      item.distCelNum,
      item.status,
      item.parentName,
      item.parentCompanyName,
      item.originCode,
      item.transCategory,
      item.promotionName,
      item.altamiraPlanName,
      item.packetCode,
      item.terminalId,
      item.canalId,
      item.sucursalId,
      formatAmount(item.feeAmt),
      formatAmount(item.airAmt),
      formatAmount(item.debtAmt),
      formatAmount(item.insuranceAmt),
      item.level,
      item.mainDistCompanyName
  ]);


doc.autoTable({
  startY: 50,
  head: [
    [
      {
        content: `${t('2480_061')} (MXN): ${formatter.format(amtRecv)}`,
        colSpan: Math.floor(columnHeaders.length / 3),
        styles: {
          halign: 'left',
          fillColor: [51, 153, 255],
          textColor: [255, 255, 255],
          fontSize: 6
        }
      },
      {
        content: `${t('2480_062')} (MXN): ${formatter.format(debtAmtRecv)}`,
        colSpan: Math.floor(columnHeaders.length / 3),
        styles: {
          halign: 'center',
          fillColor: [51, 153, 255],
          textColor: [255, 255, 255],
          fontSize: 6
        }
      },
      {

   

        content: `${t('2480_063')} (MXN): ${formatter.format(totalAmount)}`,
        colSpan: Math.ceil(columnHeaders.length / 3),
        styles: {
          halign: 'right',
          fillColor: [51, 153, 255],
          textColor: [255, 255, 255],
          fontSize: 6
        }
      }
    ],
    [
      {
        content: `${t('032')}: ${totalRecords}`,
        colSpan: columnHeaders.length,
        styles: {
          halign: 'left',
          fillColor: [51, 153, 255],
          textColor: [255, 255, 255],
          fontSize: 6
        }
      }
    ]
  ],
  body: [],
  margin: { left: 10, right: 10 }
});



const verticalGap = 1; // 🔧 increase this for more space (10pt ≈ 3.5mm)
const startDataTableY = doc.lastAutoTable.finalY + verticalGap;

  // AutoTable
  doc.autoTable({
    // startY: 80,
    startY: startDataTableY,
    head: [columnHeaders],
    body: rows,
    styles: {
      fontSize: 5,       // Smaller font for more data
      overflow: 'linebreak',
      cellPadding: 1
    },
    headStyles: {
      
      fillColor: [51, 153, 255],
      halign: 'center',
      fontSize: 6
    },
    theme: 'grid',
    margin: { top: 70, left: 10, right: 10 }
  });

  // Footer
  doc.setFontSize(10);
  doc.setFont(undefined, 'italic');
  doc.text(t('0171'), doc.internal.pageSize.getWidth() / 2, doc.lastAutoTable.finalY + 20, { align: 'center' });

  doc.save('Transaction_Monitor_Report_V2.pdf');
};


const exportAsCSV = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;


    const numberOfColumns = 27;
	const columnHeaders = [
    t('2480_079'), t('2480_031'), t('2480_032'), t('2480_033'), t('2480_034'), t('2480_035'), t('2480_036'), t('023'),
    t('0122'), t('5597_dis'), t('251608'), t('2480_037'), t('251620'), t('2480_059'), t('7056'), t('2480_038'),
    t('055'), t('2480_039'), t('2480_060'), t('2480_040'), t('2480_041'), t('2480_042'), t('2480_043'), t('1245'), t('2480_051'),
    t('2480_044'), t('2480_045'), t('2480_046'), t('0142'), t('2480_047'), t('2480_048'), t('2480_049'), t('2480_050')
  ];

  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;

  const amtRecv = totalAmt;
  const debtAmtRecv = debitAmt;

  // Function to format date as text for Excel
  // const formatDate = (val) => {
  // if (!val || val.trim() === "") return "";

  // const parts = val.split(" ");
  // if (parts.length < 2) return val;

  // const [day, month, year] = parts[0].split("/");
  // const [hh = "00", mm = "00", ss = "00"] = parts[1].split(":");

  // const dd = day.padStart(2, "0");
  // const mmn = month.padStart(2, "0");
  // const yyyy = year;
  // const hh24 = hh.padStart(2, "0");
  // const min = mm.padStart(2, "0");
  // const sec = ss.padStart(2, "0");
  // return `="${dd}/${mmn}/${yyyy} ${hh24}:${min}:${sec}"`;
  // };

  const formatDate = (value) => {
    if (!value) return "---";
    const date = new Date(value);
    if (isNaN(date.getTime())) return value;
    const pad = (n) => (n < 10 ? '0' + n : n);
    return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };
 


  // CSV Rows
  const rows = [];

  // Add title

 const title = t('e_transactions');
 const leftPadding = Math.floor((numberOfColumns - 1) / 2);
  const titleRow = Array(leftPadding).fill('').concat(title).concat(Array(numberOfColumns - leftPadding - 1).fill(''));
  rows.push(titleRow);

  // rows.push([t('e_transactions')]);
  rows.push([]);

  rows.push([
    `${t('2480_061')}(MXN): ${Number(amtRecv).toFixed(2)}`, // doubled
    '',
    '',
    '',
    `${t('2480_062')}(MXN): ${Number(debtAmtRecv).toFixed(2)}`, // doubled
    '',
    '',
    '',
    '',
    `${t('2480_063')}(MXN): ${Number(amtRecv - debtAmtRecv).toFixed(2)}` // doubled
  ]);

  rows.push([]);
  // Add total records
  rows.push([`${t('032')}: ${totalRecords}`]);
  rows.push([]);

  // Add headers
  rows.push(columnHeaders);

  // Add data rows
  downloadItems.forEach(item => {
    rows.push([
      item.cellularNumber,
      item.customerType === 'Retail Subscriber' 
                     ? t('2480_064')         
                    : item.customerType,
      //item.customerType,
      item.orderId,
      item.authorizationId,
      item.transId,
      item.sequenceISO,
      item.recSeqNum,
      item.transactionDate, // formatted and locked
      item.paymentType === 'Cash' ? t('020') :
                   item.paymentType === 'Bank' ? t('021') :
                   item.paymentType,
     // item.paymentType,
      item.distId,
      item.distName,
      Number(item.transAmt).toFixed(2),
      item.currency,
      item.replenishChnl,
      item.parentId,
      item.distCelNum,
      item.status,
      item.parentName,
      item.parentCompanyName,
      item.originCode,
      item.transCategory,
      item.promotionName,
      item.altamiraPlanName,
      item.packetCode,
      item.terminalId,
      item.canalId,
      item.sucursalId,
      Number(item.feeAmt).toFixed(2),
      Number(item.airAmt).toFixed(2),
      Number(item.debtAmt).toFixed(2),
      Number(item.insuranceAmt).toFixed(2),
      item.level,
      item.mainDistCompanyName
    ]);
  });


// const totalColumns = columnHeaders.length;         // total number of columns
// const centerIndex = Math.floor(totalColumns / 2);  // middle column index
// // create empty row
// const endRow = Array(totalColumns).fill('');

// // place the text in the center
// endRow[centerIndex] = t('0171');

  // Add end-of-report
  rows.push([]);

  const endRep = t('0171');
  const endleftPadding = Math.floor((numberOfColumns - 1) / 2);
  const endtitleRow = Array(endleftPadding).fill('').concat(endRep).concat(Array(numberOfColumns - endleftPadding - 1).fill(''));
  rows.push(endtitleRow);
//  rows.push([t('0171')]);

// CSV string creation - skip quoting if value starts with ="
// let csvContent = rows
//   .map(row => row.map(val => {
//     if (val != null && typeof val === 'string' && val.startsWith('="')) {
//       return val;
//     }
//     return `"${val != null ? val : ''}"`;
//   }).join(','))
//   .join('\n');

  let csvContent = rows
  .map(row =>
    row.map(val => {
      const strVal = String(val ?? '').trim();

      // Format floats and date-like strings for Excel-safe display
      if (/^\d{1,3}(,\d{3})*(\.\d{2})?$/.test(strVal) || /^\d+\.\d{2}$/.test(strVal)) {
        return `="${strVal}"`; // Excel-safe numeric text
      } else if (/^\d{2}\/\d{2}\/\d{4}/.test(strVal)) {
        return `="${strVal}"`; // Excel-safe date
      } else {
        return `"${strVal.replace(/"/g, '""')}"`;
      }
    }).join(',')
  )
  .join('\n');

const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;


  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", "Transaction_Monitor_Report_V2.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};



 const handleDownload = async (type) => {
  setAnchorEl(null);
  if (type === 'excel') {
    await exportAsExcel();
  } else if (type === 'pdf') {
    await exportAsPdf();
  } else if (type === 'csv') {
     await exportAsCSV();
  }
};


const totalPages = Math.ceil(totalRecords / recordsPerPage);

 startRecord = (page - 1) * perpage + 1;
 endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);


const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}



  const clearData=()=>{
 setCellularNumber('')
  setSubDistId('');
  setOrderId('');
 setSequenceIso('');
  setTransId('');
  setAuthorizationId('');
  setDistCelNum('')
setStartAmt('')
setEndAmt('')
setCanalId('')
setTerminalId('')
setSucursalId('')
setStartDateTime(midnightToday)
setEndDateTime(now)
setStartDate(midnightToday.format('DD/MM/YYYY HH:mm'))
setEndDate(now.format('DD/MM/YYYY HH:mm'))
setStatus('A');
setPrpaidSys(0);
setRepValue(0);
setHierarchyMode('N');
setTransIdError('');
}




return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Transactions":"Transacciones"}/>
  </tr>

  <tr>
  <div style={{ display: 'flex' }}>
    <LeftBgImage1 />
</div>
<td valign="top">
<title>Prepaid Movistar -Transaction Monitor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
   <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
       <NavLink
            to="/transactions"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${"menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab label={t('e_transactions')} /></NavLink>
   </Tabs>
  </Box>
    <div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="80%">
            {/* body starts */}
          

    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>
          
               <Box style={{display:'flex', gap:'12px',marginTop:'10px'}}> 
                
              <TextField type="text"name="celNum" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_079')}`} </span>} style={{maxWidth:'180px',width:'210px'}}
               onChange={e => setCellularNumber(e.target.value)} value={cellularNumber} size="15" defaultValue=""
               />
              <TextField type="text"name="setSubDistId" className={'sampleInput mb5'}
                 label={<span>{`${t('5597_dis')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
                onChange={e => setSubDistId(e.target.value)} value={subDistId} size="15" defaultValue=""
               />
      
              
      
          <TextField type="text"name="orderId" className={'sampleInput mb5'}
                 label={ <span>{`${t('2480_032')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
                 onChange={e => setOrderId(e.target.value)} value={orderId} inputRef={orderIdRef} size="15" defaultValue=""
               />

              <TextField type="text"name="sequenceIso" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_035')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
                  onChange={e => setSequenceIso(e.target.value)} value={sequenceIso} size="15" defaultValue=""
               />

             <TextField type="text"name="transId" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_052')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
                 onChange={e => setTransId(e.target.value)} value={transId}  inputRef={transIdRef}
                 size="15" defaultValue=""
               />
            <TextField type="text"name="authorizationId" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_033')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
                 onChange={e => setAuthorizationId(e.target.value)} value={authorizationId} inputRef={authorizationIdRef} size="15" defaultValue=""
               />
</Box>
 
 <Box style={{display:'flex', gap:'12px'}}>

          <TextField type="text"name="distCelNum" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_038')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
                 onChange={e => setDistCelNum(e.target.value)} value={distCelNum} size="15" defaultValue=""
               />

          <TextField type="text"name="startAmt" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_053')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
                onChange={e => setStartAmt(e.target.value)} value={startAmt}  inputRef={startAmtRef} size="15" defaultValue=""
               />

           <TextField type="text"name="endAmt" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_054')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
               onChange={e => setEndAmt(e.target.value)} value={endAmt} inputRef={endAmtRef} size="15" defaultValue=""
            />
          <TextField type="text"name="canalId" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_044')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
               onChange={e => setCanalId(e.target.value)} value={canalId} size="15" defaultValue=""
            />
            <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_051')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
                onChange={e => setTerminalId(e.target.value)} value={terminalId} size="15" defaultValue=""
            />
            
          <TextField type="text"name="salesId" className={'sampleInput mb5'}
                 label={<span>{`${t('2480_045')}`}</span>} style={{maxWidth:'180px',width:'210px'}}
               onChange={e => setSucursalId(e.target.value)} value={sucursalId} size="15" defaultValue=""
            />
</Box>
   
   <Box style={{display:'flex',gap:'12px'}}>
     <FormControl className={'selected_formcontrol'} sx={{  minWidth: 150 }}size="small">
            <InputLabel id="demo-select-small-label">{t('2480_059')}</InputLabel>
            <Select className={'bankSelect'} value={repValue} labelId="demo-select-small-label" id="demo-select-small"
             label={t('2480_059')} onChange={e => setRepValue(e.target.value)} >
              <MenuItem value={0}>---</MenuItem>
              {repchannels.map(e => (
               <MenuItem value={e.value}>{e.label}</MenuItem>
               ))}
          </Select>
    </FormControl>


         <FormControl className={'selected_formcontrol'} sx={{  minWidth: 150 }} size="small">
            <InputLabel id="demo-select-small-label">{t('2480_055')}</InputLabel>
          <Select className={'bankSelect'} value={prpaidSys} labelId="demo-select-small-label" id="demo-select-small"
             label={t('2480_055')} onChange={e => setPrpaidSys(e.target.value)} >
              <MenuItem value={0}>---</MenuItem>
              {prePaidSystem.map(e => (
               <MenuItem value={e.connectionId}>{e.companyDesc}</MenuItem>
               ))}
          </Select>
          </FormControl>

        <FormControl className={'selected_formcontrol'} sx={{  minWidth: 150 }} size="small">
            <InputLabel id="demo-select-small-label">{t('055')}</InputLabel>
            <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
              label="status" value={status} 
              onChange={e =>setStatus(e.target.value)}>
              <MenuItem value="A" selected>---</MenuItem>
              <MenuItem value="Y">{t('057')}</MenuItem>
              <MenuItem value="N">{t('058')}</MenuItem>
            </Select>
        </FormControl>



<LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
            <DateTimePicker
                  style={{ maxWidth: '120px' }}
                  className={'datePickerrr'}
                  // label="Select Date and Time"
                  value={startDateTime}
                  onChange={handleStartDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
                  label={
                    <span>
                      {`${t('80')}`}
                   <RedAsterisk>*</RedAsterisk>
                    </span>}
                    format="DD/MM/YYYY HH:mm:ss"
                  inputFormat=" " // Keeps the input field empty unless a date is selected
                  renderInput={(params) => <TextField
                    {...params}
                    InputLabelProps={{
                      shrink: true, // Always shrink the label to allow for a floating effect
                    }}
                    fullWidth
                    variant="outlined"
                    sx={{ width: "140px", height: "40px", padding: '20px' }}
                  />}
                />
                
          </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                  style={{ marginTop: '20px', maxWidth: '150px' }}
               className={'datePickerrr mt20'}
               label={
                <span>
                  {`${t('81')}`}
                  <RedAsterisk>*</RedAsterisk>
                </span>}
                format="DD/MM/YYYY HH:mm:ss"
                  value={endDateTime}
                 onChange={handleEndDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
               renderInput={(params) => <TextField {...params} />} />

              </LocalizationProvider>

 <FormControl className={'selected_formcontrol'} sx={{  minWidth: 150 }} size="small">
                <InputLabel id="demo-select-small-label">{t('2480_056')}<RedAsterisk>*</RedAsterisk></InputLabel>
                    <Select className={'bankSelect'}  labelId="demo-select-small-label" id="demo-select-small"
                      label="Modo de jerarquia"value={hierarchyMode} onChange={e => setHierarchyMode(e.target.value)}>
                        <MenuItem value="Y">{t('Y')}</MenuItem>
                        <MenuItem value="N">{t('N')}</MenuItem>
                      </Select>
          </FormControl>


{/* </Box>
<Box style={{display:'flex', gap:'20px'}}> */}


          <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
            onClick={handleSubmit1}>{t('2480_065')}</Button>
           
            <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
            onClick={clearData}>{t('045')}</Button>
              
               {/* <Button style={{height: '27px'}} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SaveIcon />}
            //onClick={clearData}
            >
              {/* {t('003')} Save
            </Button> */}
               </Box>
            </Box>
{/* </fieldset>
</Box> */}

{/* </Box> */}
           <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
              </Grid>
        <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
      <TableHead>
        <TableRow className="darkgray" style={{
          position: 'sticky',
          top: 0,
          backgroundColor: '#d3d3d3',
          zIndex: 2,
        }}>
            <TableCell align="center" colSpan={8}>
              <div>{t('2480_061')}(MXN)</div>
              <div>&nbsp; {!totalAmt || totalAmt === "---" ? "---" : Number(totalAmt).toFixed(2)}&nbsp;</div>
            </TableCell>
            <TableCell align="center"colSpan={16}>
              <div>{t('2480_062')}(MXN)</div>
                <div>&nbsp;{!debitAmt || debitAmt === "---" ? "---" : Number(debitAmt).toFixed(2)}&nbsp;</div>
            </TableCell>
            <TableCell align="center"colSpan={22}>
              <div>{t('2480_063')}(MXN)</div>
              <div>&nbsp;
                {(!totalAmt || totalAmt === "---" || !debitAmt || debitAmt === "---")? "---": Number(totalAmt - debitAmt).toFixed(2)}
              &nbsp;</div>
            </TableCell>
        </TableRow>
          
          <TableRow className="darkgray" style={{
          position: 'sticky',
          top: 47, // Adjust based on height of previous sticky row (usually ~48px)
          backgroundColor: '#f5f5f5',
          zIndex: 2,
        }} >
            <TableCell align="center">{t('2480_079')}</TableCell>
            <TableCell align="center">{t('2480_031')}</TableCell>
            <TableCell align="center">{t('2480_032')}</TableCell>
            <TableCell align="center">{t('2480_033')}</TableCell>
            <TableCell align="center">{t('2480_034')}</TableCell>
            <TableCell align="center">{t('2480_035')}</TableCell>
            <TableCell align="center">{t('2480_036')}</TableCell>
            <TableCell align="center">{t('023')}</TableCell>
            <TableCell align="center">{t('0122')}</TableCell>
            <TableCell align="center">{t('5597_dis')}</TableCell>
            <TableCell align="center">{t('251608')}</TableCell>
            <TableCell align="center">{t('2480_037')}</TableCell>
            <TableCell align="center">{t('251620')}</TableCell> 
            <TableCell align="center">{t('2480_059')}</TableCell>
            <TableCell align="center">{t('7056')}</TableCell>
            <TableCell align="center">{t('2480_038')}</TableCell>
            <TableCell align="center">{t('055')}</TableCell>
            <TableCell align="center">{t('2480_039')}</TableCell>
            <TableCell align="center">{t('2480_060')}</TableCell>
            <TableCell align="center">{t('2480_040')}</TableCell>
            <TableCell align="center">{t('2480_041')}</TableCell> 
            <TableCell align="center">{t('2480_042')}</TableCell>
            <TableCell align="center">{t('2480_043')}</TableCell>
            <TableCell align="center">{t('1245')}</TableCell>
            <TableCell align="center">{t('2480_051')}</TableCell>
            <TableCell align="center">{t('2480_044')}</TableCell>
            <TableCell align="center">{t('2480_045')}</TableCell>
            <TableCell align="center">{t('2480_046')}</TableCell>
            <TableCell align="center">{t('0142')}</TableCell>
            <TableCell align="center">{t('2480_047')}</TableCell>
            <TableCell align="center">{t('2480_048')}</TableCell>
            <TableCell align="center">{t('2480_049')}</TableCell>
            <TableCell align="center">{t('2480_050')}</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
            <TableRow>
              <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
              {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : items.length > 0 ? (
            // Show table rows when data is available
            items.map((item, index) => (
              <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
                <TableCell align="center">&nbsp;{item.cellularNumber}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;
                  {/* {item.customerType} */}
                   {item.customerType === 'Retail Subscriber' 
                     ? t('2480_064')         
                    : item.customerType}
                  &nbsp;</TableCell>
  

                <TableCell align="center">&nbsp;{item.orderId}&nbsp;</TableCell>
                <TableCell align="center">{item.authorizationId}</TableCell>

                <TableCell align="center"style={{color:"#3399FF", cursor:'pointer'}} 
                 onClick={() => handleOpen(item.transId,item.transactionDate,item.parentName)}>{item.transId}</TableCell>
                <TableCell align="center">&nbsp;{item.sequenceISO}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.recSeqNum}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.transactionDate}&nbsp;</TableCell>
                <TableCell align="center">
                  &nbsp;
                  {item.paymentType === 'Cash' ? t('020') :
                   item.paymentType === 'Bank' ? t('021') :
                   item.paymentType}&nbsp;
                  </TableCell>
                <TableCell align="center">&nbsp;{item.distId}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.distName}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{formatAmount(item.transAmt)}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.currency}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.replenishChnl}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.parentId}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.distCelNum}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.status}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.parentName}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.parentCompanyName}&nbsp;</TableCell>
                <TableCell align="center">{item.originCode}</TableCell>
                <TableCell align="center">{item.transCategory}</TableCell>
                <TableCell align="center">{item.promotionName}</TableCell>
                <TableCell align="center">{item.altamiraPlanName}</TableCell>
                <TableCell align="center">{item.packetCode}</TableCell>
                <TableCell align="center">{item.terminalId}</TableCell>
                <TableCell align="center">{item.canalId}</TableCell>
                <TableCell align="center">{item.sucursalId}</TableCell>
                <TableCell align="center">{formatAmount(item.feeAmt)}</TableCell>
                <TableCell align="center">{formatAmount(item.airAmt)}</TableCell>
                <TableCell align="center">{formatAmount(item.debtAmt)}</TableCell>
                <TableCell align="center">{formatAmount(item.insuranceAmt)}</TableCell>
                <TableCell align="center">{item.level}</TableCell>
                <TableCell align="center">{item.mainDistCompanyName}</TableCell>
              </TableRow>
            ))
          ) : (
            // Show 'No data found' message if no items are found after loading
            <TableRow>
            <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
             
             {hasSubmitted ? t('2481_061') /* “No data found” */
                          : t('038') /* “Please provide search criteria” */}</TableCell>
            </TableRow>
          )}


       <Dialog open={isDialogOpen} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>
  <div className={"headerTxt"} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
    <span>Monitor de Transacciones emergente</span>
    <IconButton
      aria-label="close"
      onClick={handleClose}
      sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
        }}
    >
      <CancelRounded />
    </IconButton>
  </div>
   </DialogTitle>

        <DialogContent>
       <TransactionDetails parentName={parentName} transactionId={selectedTransId} handleClose={handleClose} transactionDate={selectedTransDate}/>
        </DialogContent>
      </Dialog>

        </TableBody>
      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?                                                 <Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
    <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap:'8px' }}>
      {items.length>0?
      // <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CloudDownload />}
      //   onClick={handleDownload}>
      //    {t('089')} 
      //    </Button> 
        <div
          onMouseEnter={(e) => setAnchorEl(e.currentTarget)}
          onMouseLeave={() => setAnchorEl(null)}
          style={{ display: 'inline-block' }}
        >
          <Button
            className="hoverEffectButton"
            size="small"
            variant="contained"
            endIcon={<CloudDownload />}
            type="button"
            onClick={(e) => setAnchorEl(e.currentTarget)}
            aria-controls={Boolean(anchorEl) ? 'download-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={Boolean(anchorEl) ? 'true' : undefined}
          >
            {t('089')}
          </Button>

          <Menu
            id="download-menu"
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={() => setAnchorEl(null)}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            transformOrigin={{ vertical: 'top', horizontal: 'left' }}
            MenuListProps={{
              onMouseEnter: (e) => setAnchorEl(e.currentTarget),
              onMouseLeave: () => setAnchorEl(null),
              // style: { minWidth: 60 },
            }}
            PaperProps={{
              sx: { minWidth: 60, mt: 1.0 },
            }}
          >
            <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('pdf'); }}>{t('2480_080')}</MenuItem>
            <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('excel'); }}>{t('2480_081')}</MenuItem>
            <MenuItem onClick={(e) => { e.preventDefault(); handleDownload('csv'); }}>{t('2480_082')}</MenuItem>
          </Menu>
        </div>

       :<></>}

    <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</td></tr>
</div>
</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>

<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />



<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  );
}

export default Transactions;
