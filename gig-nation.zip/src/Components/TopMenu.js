/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { Box, Tab, Tabs } from '@mui/material';
import i18n from './i18n';
import { Home, Person2 } from '@mui/icons-material';
import { useTranslation } from 'react-i18next';
// import { ReactComponent as Icon } from '../images/icon.svg';
import icon from '../images/transactions/post_paid.png';
import ER from '../images/transactions/ER1.png';
import sales from '../images/transactions/salesPerson.png';
import sub from '../images/transactions/subDistributor.png';
import telephone from '../images/transactions/telephone.png';
import transactions from '../images/transactions/transaction.png';

function TopMenu() {
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const localeVar = i18n.language;

  const [selectedIndex, setSelectedIndex] = useState(
    () => Number(sessionStorage.getItem('selectedIndex')) || 0
  );

  useEffect(() => {
    const storedIndex = sessionStorage.getItem('selectedIndex');
      if (storedIndex !== null) {
      setSelectedIndex(Number(storedIndex));
    }
  }, [location.pathname]);

    const styleObj = {
        minHeight: '44px',
        fontSize: '14px',
    padding: localeVar === 'en' ? '9px 9px' : '9px 7px',
        maxHeight: 'max-content',
        margin: '5px 0px',
    border: '1px solid #3399FF',
        borderRadius: '5px',
        color: '#1976d2',
    minWidth: 'auto',
      height: '44px',
        display: 'flex',
        flexDirection: 'row',
        gap: '2px',
        transition: '0.5s',
        opacity: '1',
        color: '#3399FF',
    cursor: 'pointer',
        textTransform: 'capitalize',
    '&:hover': {
          background: '#3399FF',
          color: '#fff',
          borderRadius: '5px',
      boxShadow:
        '0 4px 6px -1px rgba(0, 0, 0, .1), 0 2px 4px -1px rgb(0 0 0 / 75%)',
          transition: '0.5s',
        },
    '&:hover img': {
          filter: 'brightness(0) invert(1)',
        },
    '&.Mui-selected': {
        background: '#3399FF',
        color: '#fff',
      },
    '&.Mui-selected img': {
        filter: 'brightness(0) invert(1)',
      },
      };

      const menuLinks = [
        {
          label: t("profile"),
          route: "/profile",
          icon: <Person2 style={{ marginBottom: "4px", width: "18px", height: "18px" }} />
        },
        {
          label: t("jobs"),
          route: "/jobs",
          src: sub,       // add your image
          width: "24px",
          height: "24px"
        },
        {
          label: t("reports"),
          route: "/reports",
          src: telephone,
          width: "24px",
          height: "24px"
        },
        {
          label: t("notifications"),
          route: "/notifications",
          src: sub,
          width: "24px",
          height: "24px"
        },
        {
          label: t("grievance"),
          route: "/grievance",
          src: sales,
          width: "24px",
          height: "24px"
        }
      ];
      

  const handleMenuSelectChange = (event, newValue) => {
    const selectedMenu = menuLinks[newValue];
    if (selectedMenu && selectedMenu.route) {
      setSelectedIndex(newValue);
      sessionStorage.setItem('selectedIndex', newValue);
      sessionStorage.setItem('selectedLink', selectedMenu.label);
      sessionStorage.setItem('rechargeTypeFromRechargePreview', '');
      navigate(selectedMenu.route);
    }
  };

  // If user clears cache, go back to login
  useEffect(() => {
    const handleCacheClear = () => {
      if (!localStorage.getItem('isLoggedIn')) {
        navigate('/');
        console.log('Cache cleared');
      }
    };

    window.addEventListener('click', handleCacheClear);
    window.addEventListener('keydown', handleCacheClear);
  
    return () => {
      window.removeEventListener('click', handleCacheClear);
      window.removeEventListener('keydown', handleCacheClear);
    };
  }, [location, navigate]);

  return (
    <>
      <td
        valign="top"
        style={{
          borderBottomStyle: 'solid',
          borderBottomWidth: '1pt',
          borderColor: 'rgb(51 153 255)',
        }}
      >
              <table border={0} cellPadding={0} cellSpacing={0} valign="top">
          <Box
            sx={{
              display: 'flex',
              flexWrap: 'wrap',
              width: '100%',
              alignItems: 'center',
              marginTop: {
        md: '10px',
        lg: '6px',
                xl: '5px',
      },
      marginBottom: {
        md: '10px',
        lg: '6px',
                xl: '0px',
              },
            }}
            className={'sampleTabEffect'}
          >
            <Tabs
              value={selectedIndex}
              onChange={handleMenuSelectChange}
              indicatorColor="none"
            >
              {menuLinks.map((item, index) => (
                <Tab
                  key={item.label}
                  sx={styleObj}
                  className={selectedIndex === index ? 'highlighted_class' : ''}
            icon={
                    item.icon
                      ? item.icon
                      : item.src
                      ? (
                        <img
                          src={item.src}
                          alt="icon"
                          style={{
                            marginTop: '3px',
                            width: item.width,
                            height: item.height,
                          }}
                        />
                        )
              : null
            }
                  value={index}
                  label={item.label}
                />
              ))}
        </Tabs>
      </Box>
      </table>
      </td>
    </>
  );
}

export default TopMenu;