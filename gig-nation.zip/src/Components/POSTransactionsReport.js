/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import dayjs from 'dayjs';
import { CloudDownload, KeyboardReturn,DoneAllRounded,RestartAltRounded, SaveRounded } from '@mui/icons-material';
import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, LeftBgImage,TransactionTopMenu } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, CircularProgress, FormControl, Grid, InputLabel, MenuItem, Pagination, Paper, Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField } from "@mui/material";
import React, { useState, useEffect, useCallback ,useRef} from 'react';
import { useTranslation } from 'react-i18next';
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
 import ExcelJS from 'exceljs';
import { ToastContainer, toast } from "react-toastify";
import pdfMake from 'pdfmake/build/pdfmake';
import Menu from '@mui/material/Menu';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';




function POSTransactionsReport(){
  sessionStorage.setItem("selectedLink", "e_transactions");

  const [page, setPage] = useState(1);
 const [perpage, setPerPage] = useState(10);
  const {t}=useTranslation();
 const localeVar=i18n.language;

    const [download, setDownload] = useState('');
     
    const transIdRef = useRef(null);
    const exampleData = JSON.parse(localStorage.getItem("userData")) 
    const [items, setItems] = useState([]);
    const [filterItems, setfilterItems] = useState([]);
    const [name, setName] = useState('');
    const [isLoading, setIsLoading]=useState(false);
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
    
    const [startDateTime, setStartDateTime] = useState(null);
   const [endDateTime, setEndDateTime] = useState(null);
    const [showError, setShowError] = useState('F');
    const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
    //const toastId = useRef(null);
    const toastIds = useRef({
  mdnInvalid: null,
  mdnEmpty: null,
  authInvalid: null,
  authEmpty: null,
  amountInvalid: null,
  amountEmpty: null
});
     const[begPageNumber , setBegPageNumber] =useState('');
     const[endPageNumber , setEndPageNumber] =useState('');

  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [mdn, setMdn] = useState('');

 
  const [Authid, setAuthid] = useState('');
  const [Amount, setAmount] = useState('');
   const [anchorEl, setAnchorEl] = useState();
   const closeTimeoutRef = useRef(null);
   const mdnRef = useRef(null);
const authIdRef = useRef(null);
const amountRef = useRef(null);


 const [isMandate, setIsMandate] = useState(false);
  const [isMandate1, setIsMandate1] = useState(false);
  const [isMandate2, setIsMandate2] = useState(false);
  const handleBlur = () => {
    if (mdn.trim() === "") {
      setIsMandate(true);
    } else {
      setIsMandate(false);
    }
  };
  const handlePartnerPwd = () => {
    if (Authid.trim() === "") {
      setIsMandate1(true);
    } else {
      setIsMandate1(false);
    }
  };
  const handleConfirmPwd = () => {
    if (Amount.trim() === "") {
      setIsMandate2(true);
    } else {
      setIsMandate2(false);
    }
  };




  
  const RedAsterisk = styled('span')({
    color: 'red',
  });

  const navigate = useNavigate();

  console.log("totalRecords++++++++++++",totalRecords)


  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  


  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);


    const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };
 
  const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };

  const fetchData = async () => {
   // debugger;
   
if (mdn == 0 || mdn === "") {
  if (!toast.isActive(toastIds.current.mdnEmpty)) {
    toastIds.current.mdnEmpty = toast.error(`${t("rtr_067")} ${t('2480_0019')} ${t("rtr_031")}.`);
          }
  mdnRef.current?.focus();
        return false;
        }

          if (!/^\d+(\.\d+)?$/.test(mdn)) {
  if (!toast.isActive(toastIds.current.mdnInvalid)) {
    toastIds.current.mdnInvalid = toast.error(`${t("alrt_01")}  ${t('2480_0019')} ${t("rtr_031")}.`);
    }
  mdnRef.current?.focus();
    return false;
  }

// === Auth ID Validation ===
        if (!Authid || Authid.trim() === "") {
  if (!toast.isActive(toastIds.current.authEmpty)) {
    toastIds.current.authEmpty = toast.error(`${t("rtr_068")}  ${t('2480_0019')} ${t("rtr_032")}.`);
          }
  authIdRef.current?.focus();
        return;
}

if (!/^\d+(\.\d+)?$/.test(Authid)) {
  if (!toast.isActive(toastIds.current.authInvalid)) {
    toastIds.current.authInvalid = toast.error(`${t("alrt_02")}  ${t('2480_0019')} ${t("rtr_032")}.`);
  }
  authIdRef.current?.focus();
  return;
        }

// === Amount Validation ===
if (Amount == 0 || Amount === "") {
  if (!toast.isActive(toastIds.current.amountEmpty)) {
    toastIds.current.amountEmpty = toast.error(`${t("rtr_069")}  ${t('2480_0019')} ${t("rtr_033")}.`);
          }
  amountRef.current?.focus();
        return;
        }

if (!/^\d+(\.\d+)?$/.test(Amount)) {
  if (!toast.isActive(toastIds.current.amountInvalid)) {
    toastIds.current.amountInvalid = toast.error(`${t("alrt_01")}  ${t('2480_0019')} ${t("rtr_033")}.`);
    }
  amountRef.current?.focus();
    return;
  }





setIsLoading(true);
setShowError('');
    try {
      const apiUrl = window.config.apiUrlJasper+ '/getPOSTransactionReport';
  
  const response = await axios.post(apiUrl, {
      userName,
      password,
       subsMdn:mdn,
      authId:Authid,
      amount:Amount,
      partnerId:partnerLoginId,
      begRecNo:begPageNumber ,
      endRecNo:endPageNumber,
      download:download

     
  });
  const reportData = response.data.mvnoDetailsArray;
  console.log("response::::::",response);
      if (response.status === 200) {
        setItems(response.data.mvnoDetailsArray);
        setTotalRecords(response.data.records);
      }


    // console.log("response.data.mvnoDetailsArray=====>", reportData);
    // if (Array.isArray(reportData) && reportData.length > 0) {
    //   setItems(reportData);
    //  setTotalRecords(response.data.records);
    // } 
    
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };







  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

const doReset1 = () => {
  // Add your reset logic here
  console.log("Reset clicked");
  // For example, reset state variables
};
const doReset = async () => {
//window.location.reload();

 setMdn(""); 
 setAuthid("");
 setAmount("");
setShowError('F');

}



const handleDownloadPdf = async () => {
  const downloadItems = await fetchDataDownload(); // same data as Excel
    if (!downloadItems || downloadItems.length === 0) return;
  const tableBody = [];

  // Table Headers (first row)
  const headers = [
 t('rtr_028'), t('rtr_032'), t('rtr_033'), t('rtr_034'), t('rtr_035'), t('rtr_036'), t('rtr_037'), t('rtr_038')

  
  ];
  tableBody.push(headers.map(header => ({ text: header, style: 'tableHeader' })));

  // Table Rows
  downloadItems.forEach(item => {
    const row = [
       item.SubscriberMdn || '---',
          item.AuthorizationId || '---',
          Number(item.setAmount || 0).toFixed(2) || '---',
          item.ReportDate || '---',
          item.RequestTime || '---',
          item.ResponseTime || '---' ,
          item.PortNumber || '---' ,
          item.SourceFileName || '---'
    ];
    tableBody.push(row);
  });

  // Content Structure
  const content = [
    {
      text: localeVar === 'en' ? 'POSTransactionReport' : 'Informe de transacciones POS',
      style: 'title',
      alignment: 'center',
      margin: [0, 0, 0, 10]
    },
 {
  columns: [
    {
      text: `${t('032')} : ${totalRecords}`,
      alignment: 'left',
      fontSize: 8
    },
    // {
    //   text: `${t('033')} : ${startRecord} - ${endRecord}`,
    //   alignment: 'right',
    //   fontSize: 8
    // }
  ],
  margin: [0, 0, 0, 5]
},
    {
      style: 'tableExample',
      table: {
        headerRows: 1,
        widths: [
          90, 90, 90, 90, 90, 90, 90, 90, 90, 90,
          90, 90, 90, 90, 90, 90, 90, 90, 90
        ],
        body: tableBody
      },
      layout: {
        fillColor: function (rowIndex) {
          return rowIndex === 0 ? '#3399FF' : null;
        }
      }
    },
    {
      text: t('0171'),
      style: 'endText',
      alignment: 'center',
      margin: [0, 10, 0, 0]
    }
  ];

  // PDF Definition
  const docDefinition = {
    content: content,
    styles: {
      title: { fontSize: 16, bold: true },
      subheader: { fontSize: 10, bold: true },
      tableExample: { margin: [0, 5, 0, 15] },
      tableHeader: { bold: true, fontSize: 8, color: '#fff' },
      endText: { italics: true, bold: true, decoration: 'underline', fontSize: 10 }
    },
    pageOrientation: 'landscape',
    defaultStyle: {
      fontSize: 8
    }
  };

  pdfMake.createPdf(docDefinition).download('POSTransactionReport.pdf');
};

const handleDownloadCsv = async () => {
  const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

  const headers = [
    t('rtr_028'), t('rtr_032'), t('rtr_033'), t('rtr_034'),
    t('rtr_035'), t('rtr_036'), t('rtr_037'), t('rtr_038')
  ];

  const title = localeVar === 'en'
    ? 'POSTransactionReport'
    : 'Informe de transacciones POS';

  const summaryLeft = `${t('032')} : ${totalRecords}`;
  const summaryRight = ``;

  // Title centered in 8 columns
  const paddedTitleRow = `,,,${title},,,,\n`;

  // Summary: left part in 1st cell, right part in 8th cell
  const paddedSummaryRow = `${summaryLeft},,,,,,${summaryRight}\n`;

  // Prepare CSV content
  let csvContent = '';
  csvContent += paddedTitleRow;
  csvContent += paddedSummaryRow;
  csvContent += '\n'; // empty line
  csvContent += headers.join(',') + '\n';

  downloadItems.forEach(item => {
    const row = [
      item.SubscriberMdn || '---',
      item.AuthorizationId || '---',
      Number(item.setAmount || 0).toFixed(2) || '---',
      item.ReportDate || '---',
      item.RequestTime || '---',
      item.ResponseTime || '---',
      item.PortNumber || '---',
      item.SourceFileName || '---'
    ];

    const csvRow = row
      .map(field =>
        typeof field === 'string' && field.includes(',') ? `"${field}"` : field
      )
      .join(',');
    csvContent += csvRow + '\n';
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', 'POSTransactionReport.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


















  const fetchDataDownload = async () => {
    debugger;
    try {


        const apiUrlDownload = window.config.apiUrlJasper+ '/getPOSTransactionReport';
        console.log('API URL:', apiUrlDownload);
        console.log('Partner Login ID:', partnerLoginId);

        const responseDownload = await axios.post(apiUrlDownload, {
          userName,
          password,
      subsMdn:mdn,
      authId:Authid,
      amount:Amount,
      partnerId:partnerLoginId,
      begRecNo:begPageNumber ,
      endRecNo:endPageNumber,
      download:download
        });

        console.log('Response:', responseDownload);

        if (!responseDownload.data || !responseDownload.data.mvnoDetailsArray) {
            throw new Error('Invalid API response');
        }
        const downloadData = responseDownload.data.mvnoDetailsArray.map(partner => ({
            SubscriberMdn: partner.SubscriberMdn,
            AuthorizationId: partner.AuthorizationId,
            setAmount: partner.setAmount,
            ReportDate: partner.ReportDate,
            RequestTime: partner.RequestTime,
            ResponseTime: partner.ResponseTime,
            PortNumber: partner.PortNumber,
            SourceFileName: partner.SourceFileName
            
            
        }));

        console.log('Download Data:', downloadData);

        return downloadData;
    } catch (error) {
        console.error('Error fetching data:', error);
        return [];
    }
};
  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  
 const handleDownload = async () => {
  const downloadItems = await fetchDataDownload();

  const totalPages = Math.ceil(totalRecords / recordsPerPage); // Use these variables from your context
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('POSTransactionReport');

  const numberOfColumns = 8;

 


  // Title row
  const titleRow = worksheet.addRow([t('POSTransactionReport')]);
  worksheet.mergeCells(titleRow.number, 1, titleRow.number, numberOfColumns);
  const titleCell = titleRow.getCell(1);
  titleCell.font = { bold: true };
  titleCell.alignment = { horizontal: 'center' };

  worksheet.addRow([]); // Empty row

  // Summary row
  const summaryRow = worksheet.addRow([]);
  summaryRow.getCell(1).value = `${t('032')} : ${totalRecords}`; // Total records
  //summaryRow.getCell(5).value = `${t('033')} : ${startRecord} - ${endRecord} / ${t('pages')} : ${totalPages}`; // Displayed and pages

  summaryRow.getCell(1).alignment = { horizontal: 'left' };
  summaryRow.getCell(5).alignment = { horizontal: 'right' };

  worksheet.mergeCells(summaryRow.number, 1, summaryRow.number, 4); // Left
  //worksheet.mergeCells(summaryRow.number, 5, summaryRow.number, 8); // Right

  worksheet.addRow([]); // Empty row

  // Column headers
  const columnHeaders = [
    t('rtr_028'), t('rtr_032'), t('rtr_033'), t('rtr_034'),
    t('rtr_035'), t('rtr_036'), t('rtr_037'), t('rtr_038')
  ];
  const headerRow = worksheet.addRow(columnHeaders);
  headerRow.eachCell(cell => {
    cell.font = { bold: true };
    cell.alignment = { horizontal: 'center' };
    cell.border = {
      top: { style: 'thin' },
      left: { style: 'thin' },
      bottom: { style: 'thin' },
      right: { style: 'thin' }
    };
  });

  // Data rows
  downloadItems.forEach(item => {
    const dataRow = worksheet.addRow([
      item.SubscriberMdn || '---',
      item.AuthorizationId || '---',
      Number(item.setAmount || 0).toFixed(2) || '---',
      item.ReportDate || '---',
      item.RequestTime || '---',
      item.ResponseTime || '---',
      item.PortNumber || '---',
      item.SourceFileName || '---'
    ]);
    dataRow.eachCell(cell => {
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });
  });

  worksheet.addRow([]);
  worksheet.addRow([]);

  // End of report
  const endText = t('0171'); // e.g., "*** End of Report ***"
  const endRow = worksheet.addRow([endText]);
  worksheet.mergeCells(endRow.number, 1, endRow.number, numberOfColumns);
  const endCell = endRow.getCell(1);
  endCell.font = { italic: true, underline: true, bold: true };
  endCell.alignment = { horizontal: 'center' };

  // Column widths
  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });
  // Protect sheet
  worksheet.protect('yourPassword', {
    selectLockedCells: true,
    selectUnlockedCells: true,
    formatCells: false,
    formatColumns: false,
    formatRows: false,
    insertColumns: false,
    insertRows: false,
    insertHyperlinks: false,
    deleteColumns: false,
    deleteRows: false,
    sort: false,
    autoFilter: false,
    pivotTables: false
  });

  // Generate and download Excel file
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });

  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'POSTransactionReport.xlsx';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};




let startRecord = (page - 1) * perpage + 1;
let endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);


const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}


// const handleMdnChange = (e) => {
//   const value = e.target.value;
//   if (/^\d{0,10}$/.test(value)) {
//     setMdn(value);
//   }
// };



return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Transactions":"Transacciones"}/>
  </tr>

  <tr>
 
  <LeftBgImage />

<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    
    <tbody>
   <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
     {/* <TransactionTopMenu /> */}
      <NavLink
            to="/POSTransactionReport"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${"menuHighlight" ? 'addingDynClass' : ''}`
            }><Tab label={t('z_postranslogrptp')} /></NavLink>
   </Tabs>
  </Box>
<div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="50%">
      

  <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>

<Box style={{display:'flex', gap:'12px',marginTop:'10px'}}> 
               

   <TextField
  type="text"
  //size="24"
      name="mdn"
  id="mdn"
      value={mdn}

  label={
    <span>
      {t('rtr_028')}
      <RedAsterisk>*</RedAsterisk>
    </span>
  }
  onChange={(e) => setMdn(e.target.value)}
  onBlur={handleBlur}
 inputRef={mdnRef} 
  className={`sampleInput mb5 ${isMandate ? 'mandateField' : ''}`}
  style={{ width: '145px' }}
    />
    
<TextField
  type="text"
  //size="24"
  name="Authid"
  id="Authid"
  value={Authid}
  
  label={
    <span>
      {t('rtr_029')}
      <RedAsterisk>*</RedAsterisk>
    </span>
    }
  onChange={(e) => setAuthid(e.target.value)}
  onBlur={handlePartnerPwd}
  inputRef={authIdRef} 
 className={`sampleInput mb5 ${isMandate1 ? 'mandateField' : ''}`}
  style={{ width: '145px' }}
/>

<TextField
  type="text"
//  size="24"
  name="Amount"
  id="Amount"
  value={Amount}
  
  label={
    <span>
      {t('rtr_030')}
      <RedAsterisk>*</RedAsterisk>
    </span>
    }
  onChange={(e) => setAmount(e.target.value)}
  onBlur={handleConfirmPwd}
  inputRef={amountRef} 
  className={`sampleInput mb5 ${isMandate2 ? 'mandateField' : ''}`}
  style={{ width: '145px' }}
/>
 
 
 
 
<Box>
 <Button className={'hoverEffectButton'} style={{marginTop:'3px'}} size="small" variant="contained" onClick={() => fetchData()} endIcon={<CheckCircleIcon />}>{t('602')}</Button>
&nbsp; &nbsp;
<Button className={'hoverEffectButton'} style={{marginTop:'3px'}} size="small" variant="contained" onClick={() => doReset()} endIcon={<RestartAltRounded/>}>{t('603')}</Button>
           
</Box>

</Box>
          
   
           <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
              
                <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
              </Grid>
              <div>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
   <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table">
              
                    </Table>
</TableContainer>
</div>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '200px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
          <TableRow className="darkgray">
                                        <TableCell align="center" >{t('rtr_031')}</TableCell>
                                        <TableCell align="center">{t('rtr_032')}</TableCell>
                                        <TableCell align="center">{t('rtr_033')}</TableCell>
                                        <TableCell align="center">{t('rtr_034')}</TableCell>
                                        <TableCell align="center">{t('rtr_035')}</TableCell>
                                        <TableCell align="center">{t('rtr_036')}</TableCell>
                                        <TableCell align="center">{t('rtr_037')}</TableCell>
                                        <TableCell align="center">{t('rtr_038')}</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
            <TableRow>
              <TableCell colSpan={20} align="center" className={'spinnerDiv'}>
              {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : items.length > 0 ? (
            // Show table rows when data is available
            items.map((item, index) => (
              <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
              
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.SubscriberMdn || '---'}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.AuthorizationId || '---'}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{Number(item.setAmount || 0).toFixed(2)}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.ReportDate || '---'}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.RequestTime || '---'}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.ResponseTime || '---'}&nbsp;</TableCell>	 
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.PortNumber || '---'}&nbsp;</TableCell>
                <TableCell style={{padding:'0'}} width="20%" className="arlCtrBlk">&nbsp;{item.SourceFileName || '---'}&nbsp;</TableCell>
              </TableRow>
            ))
          ) : (
            showError === 'F' ? <TableRow>
          <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                        {t("038")} {/* No data found for the given search criteria */}
</TableCell>
</TableRow> :
<TableRow>
<TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                        {t("2481_061")} {/* No data found for the given search criteria */}
</TableCell>
</TableRow>
          )
          }
        </TableBody>
      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'flex-start', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
    <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap:'8px' }}>
        {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,
                                                 }}
                                               >
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownloadPdf(); }}>{t('pdf')}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownload(); }}>{t('excel')}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownloadCsv(); }}>{t('csv')}</MenuItem>
                                               </Menu>
                                             </div>
                                              : <></>}
    
    
    
     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</td></tr>
</div>

</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 
</td></tr>
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  );
}

export default POSTransactionsReport;
