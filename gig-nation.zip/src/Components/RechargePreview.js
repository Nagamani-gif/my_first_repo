/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import { Header, Footer, PaymentManagerHeading, JasperTopMenu, LeftBgImage, } from './PageComponents';
import { KeyboardReturn} from "@mui/icons-material";
import { Box, Grid, TextField, Typography, Button, styled } from "@mui/material";
import SendIcon from '@mui/icons-material/Send';
import { useNavigate } from 'react-router';
import { useLocation } from 'react-router-dom';
import { useEffect, useRef, useState } from "react";
// Importing toastify module
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useTranslation } from 'react-i18next';
import axios from "axios";
import i18n from "./i18n";

function RechargePreview(){

  
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const partnerLoginId = exampleData.LOGIN_ID;
  const localeVar = i18n.language;
  const activeCurrencyPrecision = exampleData.activeCurrencyPrecision;
  const systemCurrencySymbol = exampleData.systemCurrencySymbol;
  const partnerCurrencyId = exampleData.partnerCurrencyId;
  const systemCurrencyId = exampleData.systemCurrencyId;



  const navigate = useNavigate();
  sessionStorage.setItem("selectedLink", "b_sellprepaidcards");

  // `useLocation` returns the current location as an object and comes with props
  const location = useLocation();
  const [passwordValue, setPasswordValue]=useState('');
  const [showSubmit, setShowSubmit]=useState(true);
  const [submitBtn, setSubmitBtn]=useState(false);
  const [feeAmt, setFeeAmt] = useState("0.0");
  const [promVal, setPromVal] = useState("0.0");

  const [message, setMessage] = useState("");

  const { selectedRow, cellularNumber, selectedValue, feeSupportFlag, otherAmount } = location.state || {};

  const [rechargeType2, setRechargeType2] = useState(selectedValue);

  const toastId = useRef(null);

  console.log("recharge type in recharge preview", rechargeType2);

  var denomId = "";
  var paymentAmount = 0.0;
  var validityDays = "";
  var airTime = "";
  var packetCode = "";

  if(selectedValue === "REC"){
    denomId = selectedRow.recDenomId;
    paymentAmount = selectedRow.REC_DENOM_VALUE;
    airTime = selectedRow.REC_AIR_TIME;
    if(otherAmount){
      paymentAmount = otherAmount;
      airTime = "0.0";
    }
  }else if(selectedValue === "AIRSMS" || selectedValue === "AIRDAT"){
    denomId = selectedRow.AIR_SMS_DENOM_ID;
    paymentAmount = selectedRow.AIR_SMS_DENOM_VALUE;
    validityDays = selectedRow.AIR_SMS_VALIDITY_DAYS;
    airTime = selectedRow.AIR_SMS_AIR_TIME;
    packetCode = selectedRow.AIR_SMS_PACKET_CODE;
  }else if(selectedValue === "DAT" || selectedValue === "SMS"){
    denomId = selectedRow.DAT_PACKET_ID;
    paymentAmount = selectedRow.DAT_PACKET_VALUE;
    validityDays = selectedRow.DAT_VALIDITY_DAYS;
    packetCode = selectedRow.DAT_PACKET_CODE;
    // airTime = selectedRow.
  }

  console.log("denomId", denomId)
  console.log("paymentAmount", paymentAmount)
  console.log("selectedRow", selectedRow)
  console.log("cellularNumber", cellularNumber)
  console.log("selectedValue", selectedValue)
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;

  useEffect(() => {
    const fetchUsers = async() => {
     let apiUrl = window.config.apiUrl + process.env.REACT_APP_GET_PLAN_PREVIEW_DETAILS;
     let response = await axios.post(apiUrl, {
                     "partnerId":partnerLoginId,
                     userName,
                     password,
                     "localeVar":localeVar,
                     "activeCurrencyPrecision":activeCurrencyPrecision,
                     "activeCurrencySymbol":"",
                     "systemCurrencySymbol":systemCurrencySymbol,
                     "systemCurrencyId":systemCurrencyId,
                     "partnerCurrencyId":partnerCurrencyId,
                     "rechargeType":selectedValue,
                     "denomId":denomId,
                     "subscriberId":cellularNumber,
                     "feeSupportFlag":feeSupportFlag,
                     "Transctionpassword":"",
                     "paymentAmount":paymentAmount,
                     "distributorId":"",
                     "otherAmount":""
                   });

                   const result = response.data.result;

           console.log("response.data.result", response.data.result);
           console.log("feeAmt", result[0].feeAmt)
           setFeeAmt(result[0].feeAmt);
           setPromVal(result[0].promVal);
          //  setRechargeType(selectedValue);
          
    }
    fetchUsers();
  }, [])

  const {t} = useTranslation();

  console.log("feeAmt at 100", feeAmt)


  const buttonRef = useRef(null);

  const submitPlan = async() => {
    let apiUrl = window.config.apiUrl + process.env.REACT_APP_SUBMIT_PLAN_DETAILS;
    let response = await axios.post(apiUrl, {
      
      userName,
      password,
        "localeVar":localeVar,
        "partnerId":partnerLoginId,
        "activeCurrencyPrecision":activeCurrencyPrecision,
        "activeCurrencySymbol":"",
        "systemCurrencySymbol":systemCurrencySymbol,
        "systemCurrencyId":systemCurrencyId,
        "partnerCurrencyId":partnerCurrencyId,
        "rechargeType":selectedValue,
        "denomId":denomId,
        "subscriberId":cellularNumber,
        "feeSupportFlag":feeSupportFlag,
        "feeAmt":feeAmt,
        "promVal":"",
        "transctionPassword":passwordValue,
        "packetCode":packetCode,
        "otherDenomVal":"",
        "paymentAmount":paymentAmount,
        "parentId":"",
        "userTypeId":"",
        "commercialName":""
    });
    const responseData = response.data;

    console.log("submit plan result", responseData.target)

    let partnerID = responseData.partnerID;
    let partnerMDN = responseData.partnerMDN;
    let responseDescription = responseData.responseDescription;
    let orderId = responseData.orderId;
    let orderDateAndTime = responseData.orderDateAndTime;
    let typeOfTransaction = responseData.typeOfTransaction;

    let fromRechargePreview = "Y";
    

    console.log("in RechargePreview responseDescription", responseDescription)
    

    if(response.data.target === "plantranssuccess"){
      setSubmitBtn(true);
      // buttonRef.current.disabled = false;
      setShowSubmit(true);
      navigate('/data-purchase-preview', { state: { partnerID, partnerMDN, paymentAmount, cellularNumber, orderId, orderDateAndTime, typeOfTransaction,rechargeType2 } });
    }
    
    else if(response.data.responseCode === "5800"){
      // if(!toast.isActive(toastId.current) )  {
        
      //   toastId.current = toast.error(responseDescription);
      // }
      
      setMessage(responseDescription);
      setPasswordValue('');
      setShowSubmit(true);
      console.log(responseDescription,"==========responseDescription==========")
    }
    
    else {
      console.log("selected value in recharge preview", rechargeType2)
      sessionStorage.setItem("rechargeTypeFromRechargePreview", rechargeType2)
      navigate('/electronic-recharge', {state : {rechargeType2, responseDescription, fromRechargePreview} });
    }
    //return response.data.target;
  }
  

  const handlePrviewSubmit=()=>{
    if(passwordValue === ""){
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('recharge'));      }
    }
    else{
      if (buttonRef.current && !buttonRef.current.disabled) {
        buttonRef.current.disabled = true;
      setShowSubmit(false);

      let resultString = submitPlan();

      if(resultString === "plantranssuccess"){
        setSubmitBtn(true);
        setShowSubmit(false);
        buttonRef.current.disabled = false;
        setShowSubmit(true);
        navigate('/data-purchase-preview');
      }else
      buttonRef.current.disabled = true;
      setShowSubmit(false);
      }
      
    }
  }

  const handleReturn = () => {
    // navigate(-1);
    let fromRechargePreview = "Y";
    sessionStorage.setItem("rechargeTypeFromRechargePreview", rechargeType2);

      navigate('/electronic-recharge', {state : {rechargeType2,  fromRechargePreview} });
  }
  const RedAsterisk = styled("span")({
    color: "red",
  });
  return (

    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
    <tbody>
         <Header/>
      <tr height="65px">
      <PaymentManagerHeading />
           <TopMenu/>
      </tr>
      <tr>
       <LeftBgImage />
        <td valign="top">
          <meta httpEquiv="Content-Type" content="text/html; charset=ISO-8859-1" />
          <title>homepage</title>
          <JasperTopMenu menu="menuHighlight" />
          <Typography
                className={"headingText"}
                sx={{ fontSize: "9pt", fontWeight: "bold", paddingLeft: '10px' }}
                variant="body1"
                component="h2"
            >
               {t('0146')}
            </Typography>
            <br />
            {message !== "" && 
              <p style={{paddingLeft: '12px', color:"red", fontSize:"larger", fontWeight:"bold", textAlign:"left"}}>{message}</p>
          //  <>{message}</>
             }
          <Box className={'mL8 input_boxess rehargePreview'} >
            <Grid container>
             <Grid item xs={6} align="left">
             {/* <span className={'strongerTxtLable'}> {t('0147')}&nbsp;&nbsp;:&nbsp;&nbsp;</span>
             <span className={'strongerTxtLable color_black'}> {cellularNumber}</span> */}
             <TextField
                        label={t('0147')}
                        disabled
                        size="15"
                        className={"sampleInput mb5"}
                        value={cellularNumber}
                        type="text"
                        autocomplete="off"
                        id=""
                      />
             </Grid>
            </Grid>
            <Grid container>
             <Grid item xs={6} align="left">
             {/* <span className={'strongerTxtLable'}> {selectedValue == "DAT" || selectedValue == "SMS" ? t('0143') : t('0148')}&nbsp;&nbsp;:&nbsp;&nbsp;</span> */}
             {/* <span className={'strongerTxtLable color_black'}> {paymentAmount}</span> */}
             <TextField
                        label={selectedValue == "DAT" || selectedValue == "SMS" ? t('0155') : t('0148')}
                        disabled
                        size="15"
                        className={"sampleInput mb5"}
                        value={paymentAmount}
                        type="text"
                        autocomplete="off"
                        id=""
                      />
             </Grid>
            </Grid>

            {

            selectedValue == "REC"

            &&
                        <Grid container>
                          <Grid item xs={6} align="left">
                          {/* <span className={'strongerTxtLable'}> {t('0142')}&nbsp;&nbsp;:&nbsp;&nbsp;</span>
                         
                          <span className={'strongerTxtLable color_black'}>{airTime}</span> */}
                          <TextField
                        label={t('0142')}
                        disabled
                        size="15"
                        className={"sampleInput mb5"}
                        value={airTime}
                        type="text"
                        autocomplete="off"
                        id=""
                      />
                          </Grid>
                        </Grid>
            }

            <Grid container>
             <Grid item xs={6} align="left">
             {/* <span className={'strongerTxtLable'}> {t('0149')}&nbsp;&nbsp;:&nbsp;&nbsp;</span>
           
             <span className={'strongerTxtLable color_black'}> {feeAmt}</span> */}
             <TextField
                        label={t('0149')}
                        disabled
                        size="15"
                        className={"sampleInput mb5"}
                        value={feeAmt}
                        type="text"
                        autocomplete="off"
                        id=""
                      />
             </Grid>
            </Grid>
            

             {selectedValue == "REC" ? 
                <Grid container>
                    <Grid item xs={6} align="left">
                      {/* <span className={'strongerTxtLable'}> {t('promotionalBenefit')}&nbsp;&nbsp;:&nbsp;&nbsp;</span>

                      <span className={'strongerTxtLable color_black'}> {promVal}</span> */}
                      <TextField
                        label={t('promotionalBenefit')}
                        disabled
                        size="15"
                        className={"sampleInput mb5"}
                        value={promVal}
                        type="text"
                        autocomplete="off"
                        id=""
                      />
                    </Grid>
                </Grid>
              
              : 
                <Grid container>
                  <Grid item xs={6} align="left">
                    {/* <span className={'strongerTxtLable'}> {t('0150')}&nbsp;&nbsp;:&nbsp;&nbsp;</span>

                    <span className={'strongerTxtLable color_black'}> {validityDays}</span> */}
                    <TextField
                        label={t('0150')}
                        disabled
                        size="15"
                        className={"sampleInput mb5"}
                        value={validityDays}
                        type="text"
                        autocomplete="off"
                        id=""
                      />
                  </Grid>
                </Grid>
              }

            
            <Grid container>
             <Grid item xs={6} align="left">
             {/* <span className={'strongerTxtLable'}> {t('0151')}&nbsp;&nbsp;:&nbsp;&nbsp;</span> */}
            
             <TextField
                        // label={t('0151')}
                        label={
                          <span>
                            {`${t("0151")}`}
                            <RedAsterisk>*</RedAsterisk>
                          </span>
                        }
                        size="15"
                        className={`sampleInput mb5 ${passwordValue === '' ? 'mandateField' : ''}`}
                        value={passwordValue}
                        onChange={(e)=>setPasswordValue(e.target.value)}
                        type="password"
                        autocomplete="off"
                        id=""
                      />
             </Grid>
            </Grid>
            
          </Box>
          {/* <br /> */}
          <Box className={'displayFlexCenter mL8'} style={{justifyContent:'flex-start', gap:'8px', marginBottom:'10px'}}>
          {showSubmit ? <Button ref={buttonRef} className={'hoverEffectButton'} size="small" onClick={() => handlePrviewSubmit()} disabled={submitBtn} variant="contained" endIcon={<SendIcon />}> 
              {t('0152')}
                </Button> : '' }
                <Button className={'hoverEffectButton'} size="small"  onClick={() => handleReturn()} variant="contained" endIcon={<KeyboardReturn />}>
                {t('0135')}
                </Button>
               
          </Box>
          
          {/* {!showSubmit ? <Typography align="center">Redirecting....</Typography>: ''} */}
        </td>
      </tr>
      <ToastContainer 
      position="top-right"
      autoClose={3000}
      hideProgressBar={false}
      newestOnTop={false}
      closeOnClick
      rtl={false}
      pauseOnFocusLoss
      draggable
      pauseOnHover
      style={{
        width: "fit-content",
        minWidth: "300px",
        minHeight: "100px",
        fontSize: "18px",
      }}
    />
      
      <tr height="60px">
        <td colSpan={2}>
       <Footer/>
        </td>
      </tr>
    </tbody></table>
  );
}

export default RechargePreview;
