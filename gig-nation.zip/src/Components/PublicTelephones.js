import React, { useCallback, useRef, useState,useEffect } from 'react';
import { Footer, Header, JasperTopMenu, LeftBgImage, PaymentManagerHeading, PublicEnquiry } from './PageComponents';
import TopMenu from './TopMenu';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import Papa from 'papaparse';
import { CSVLink } from 'react-csv';
import { KeyboardReturn, CloudDownload, Backup, Cancel, FileUpload } from '@mui/icons-material';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import Button from '@mui/material/Button';
import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { useDropzone } from 'react-dropzone';
import { Box, Grid, Typography } from '@mui/material';
import SendIcon from "@mui/icons-material/Send";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function PublicTelephones() {
  //sessionStorage.setItem("selectedIndex", 6);
  sessionStorage.setItem("selectedLink", "f_publictelephones");

  const {t}=useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
  const partnerLoginId = exampleData.LOGIN_ID || "";
  const [file, setFile] = useState(null);
  const [fileError, setFileError] = useState('');
  const [uploadError, setUploadError] = useState('');
  const [showDownload, setShowDownload] = useState(false);
  const [errorFileName, setErrorFileName] = useState('error_sample_upload_csv.csv');
  const [fileName, setFileName] = useState(t("6842"));
  const [fileData, setFileData] = useState([]);
 // const expectedColumns = ['MDN', 'Company Name', 'Status', 'PartnerId', 'Error description'];
  const expectedColumns = [(t('0147')), (t('resetpassword1')), (t('055')), (t('092')), (t('errordesp'))];
  const toastId = useRef(null);
              let userName = process.env.REACT_APP_USERNAME;
              let password = process.env.REACT_APP_PASSWORD;

  const fileSelected = () => {
    const fileInput = document.getElementById('fileUpload');
    return fileInput && fileInput.files && fileInput.files.length > 0;
  };

  // const handleFileChange = (e) => {
  //   const selectedFile = e.target.files[0];
  //   if (selectedFile) {
  //     const fileName = selectedFile.name;
  //     const allowedExtensions = ['.csv'];

  //     if (allowedExtensions.some(ext => fileName.toLowerCase().endsWith(ext))) {
  //       setFile(selectedFile);
  //       setFileName(fileName); // Set file name to state
  //       const baseName = fileName.endsWith('.csv') ? fileName.slice(0, -4) : fileName;
  //       setErrorFileName(`err_${baseName}.csv`);
  //       // setFileError('');
  //     } else {
  //       setFile(null);
  //       setFileName(t("6842")); // Clear file name on error
  //       toast.error(t('6847'));
  //     }
  //   } else {
  //     setFile(null);
  //     setFileName(t("6842")); // Clear file name if no file selected
  //     toast.error(t('5515'));
  //   }
  // };

  useEffect(() => {
    // Set the browser title
    document.title = t('2472_011');
  }, []);
  

  document.title = t('2472_005');
  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      const fileName = selectedFile.name;
      const allowedExtensions = ['.csv'];

      if (allowedExtensions.some(ext => fileName.toLowerCase().endsWith(ext))) {
        setFile(selectedFile);
        setFileName(fileName); // Set file name to state
        const baseName = fileName.endsWith('.csv') ? fileName.slice(0, -4) : fileName;
        setErrorFileName(`err_${baseName}.csv`);

        // Read the file and modify the columns if necessary
        Papa.parse(selectedFile, {
          header: true,
          complete: (result) => {
            const data = result.data;
            const header = result.meta.fields || [];

            // Modify columns if they don't match the expected ones
            const updatedData = data.map(row => {
              const updatedRow = {};
              expectedColumns.forEach((col, index) => {
                updatedRow[col] = row[header[index]] || '';
                // if (col === 'Status') {
                //   updatedRow[col] = 'No'; // Set the Status column to "NO"
                // }
              });
              return updatedRow;
            });

            // Store the modified file data in state
            setFileData(updatedData);
          }
        });

      } else {
        setFile(null);
        setFileName(t("6842")); // Clear file name on error
        if(!toast.isActive(toastId.current) )  {
          toastId.current = toast.error(t('6847')); 
        }
       // toast.error(t('6847'));
      }
    } else {
      setFile(null);
      setFileName(t("6842")); // Clear file name if no file selected
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('5515')); 
      }
      //toast.error(t('5515'));
    }
  };

  const generateErrorFile = () => {
    // Use the fileData to generate the error file
    return fileData.length > 0 ? fileData : [expectedColumns]; // Default to expectedColumns if no data
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) {
      if(!toast.isActive(toastId.current) )  {
        toastId.current = toast.error(t('5515')); 
      }
      return;
    }

    if (file) {

      console.log("inside if file ======")
            const formData = new FormData();
            formData.append("file", file);
            formData.append("partnerId", partnerLoginId);
            formData.append("localeVar", localeVar);
            try {
            //  let apiUrl = window.config.apiUrl + process.env.REACT_APP_UPLOAD_URL;
            //  //const apiUrl="http://10.10.19.55:8080/airmanage/rest/upload/publictelephoneupload";
            // apiUrl = apiUrl.replace("/partner", "/upload");
            const apiUrl = window.config.apiUrlUpload + process.env.REACT_APP_UPLOAD_URL;
 
           console.log(apiUrl);
              console.log(apiUrl,"***********apiUrl")

              const response = await axios.post
              
              (apiUrl, formData, {
                headers: {
                  "Content-Type": "multipart/form-data",
                },
                // userName,
                // password,
              })

              
              if (response.data.responseDescription === '0') {
                // toast.error("File Uploaded Successfully - Click On Download to get details");
                if(!toast.isActive(toastId.current) )  {
                  toastId.current = toast.error(t('error.fullsuccess')); 
                }
                setShowDownload(true);
              }else if(response.data.responseDescription === 'Partial Success')
              {
                // toast.error("Error while adding - Click On Download to get details ");
                if(!toast.isActive(toastId.current) )  {
                  toastId.current = toast.error(t('error.partialsuccess')); 
                }
                setShowDownload(true);
              }else{
                // toast.error("File Upload Failed  - Click On Download to get details");
                if(!toast.isActive(toastId.current) )  {
                  toastId.current = toast.error(t('error.fullyfailed')); 
                }
                setShowDownload(true);
              }

              console.log('Data sent successfully:', response.data);
              setUploadError('');
              // setShowDownload(false);
            } catch (error) {
              console.error('Data send failed:', error);
              setUploadError(t('6846'));
              setShowDownload(true);
            }
         }
  };

  const validateCsv = (header) => {
    if (header.length !== expectedColumns.length) {
      return false;
    }

    for (let i = 0; i < header.length; i++) {
      if (header[i].trim() !== expectedColumns[i]) {
        return false;
      }
    }
    return true;
  };

  const generateTemplateCsv = () => {
    return [expectedColumns];
  };

  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

  const onDrop = useCallback((acceptedFiles) => {
    setFile(acceptedFiles[0]);
    setFileName(acceptedFiles[0].name);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({onDrop,accept: ".csv",multiple: false,noClick: true, // Prevents click interaction
});
  const handleCancel = () => {
    setFile(null);
    setFileName(t("6842"));
  };

  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
         
              <Header />
          <tr height="65px">
          <PaymentManagerHeading />
           
            <TopMenu menuLink= {localeVar==='en'?"Public Telephones":"Teléfonos Públicos"}/>
          </tr>
          <tr>
           <LeftBgImage />
            <td valign="top">
              <title>Prepaid Movistar - View Sales People</title>
              <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                <tbody>
                  <tr><JasperTopMenu /></tr>
                  <tr>
                    <td>
                      <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                        <tbody>
                          <tr>
                            <td colSpan="3" align="center" >
                              <form onSubmit={handleSubmit} style={{marginTop:'-22px' }}>
                              <Box className={"bulkTransfersec"}>
                              <ToastContainer 
                position="top-right" autoClose={3000} hideProgressBar={false} newestOnTop={false}
                closeOnClick rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                style={{
                  width: "fit-content", minWidth: "300px", minHeight: "100px", fontSize: "18px",
                }}/>
                              <Grid
                container
                spacing={2}
                className={"displayFlexCenter"}
                style={{border: "1px solid #39f",borderRadius: "8px",marginBottom: "10px",width: "100%",padding: "0px",
                }}>
                <Grid item xs={4} style={{ padding: "0", paddingLeft: "20px" }}>
                  <div
                    className={"strongerTxt"}
                    style={{display: "flex",alignItems: "center", justifyContent: "center", gap: "5px",
                    }} >
                                      
                    <div
                      className={"csvFile"}
                      style={{ position: "relative", marginTop: "0px" }}
                    >
                      <input
                       type="file" id="fileUpload" accept=".csv"
                       onChange={handleFileChange}
                        style={{ position: "absolute",opacity: "0",cursor: "pointer",zIndex: "1", width: "154px",height: "36px",
                        }} />
                      <Button
                        variant="contained"className={"uploadButtonn"}color="primary"
                        endIcon={<Backup />}style={{ cursor: "pointer", marginBottom: "7px" }}>
                        {t("6820")}
                      </Button>
                    </div>
                  </div>
                </Grid>
                <Grid
                  item xs={1}style={{ padding: "0" }} className={"bulkuploadLine"} >
                  <p style={{ paddingTop: "9px", paddingRight: "5px" }}>{t('6841')}</p>
                </Grid>
                <Grid item xs={7} style={{ padding: "0px 20px 0px 20px" }}>
                  <div
                    {...getRootProps()}
                    style={{backgroundColor: isDragActive ? "#3399ff8a" : "#fff",  border: "2px dashed rgb(51 153 255)",
                      textAlign: "center", marginTop: "0px",height: "151px", display: "flex",justifyContent: "center",
                      alignItems: "center", flexDirection: "column",
                    }}
                  >
                    <FileUpload
                      style={{width: "37px",height: "37px",color: isDragActive ? "#fff" : "rgb(51 153 255)",paddingBottom: "10px",
                      }}
                    />
                    <input {...getInputProps()} />
                    <p
                      style={{
                        color: isDragActive ? "#fff" : "rgb(51 153 255)",
                        fontSize: "14px",
                      }}
                    >
                      {t("6839")}
                    </p>
                  </div>
                </Grid>
              </Grid>
              <Grid
                container
                spacing={2}
                className={"displayFlexCenter"}
                style={{ marginTop: "10px", marginBottom: "10px" }}
              >
                <Grid
                  xs={12}
                  item
                  style={{  padding: "0",paddingRight: "14px",marginBottom: "10px",
                  }}
                >
                  {fileName && (
                    <span
                      style={{fontSize: "11px", marginBottom: "0",overflowWrap: "anywhere",textAlign: "center", border: "1px solid #39f",
                        borderRadius: "5px",padding: "9px 12px",maxWidth: "100px",whiteSpace: "nowrap", overflow: "hidden",
                        textOverflow: "ellipsis",color: fileName == t("6842") ? "#39f" : "#fff",
                        background: fileName == t("6842") ? "#fff" : "#39f",
                      }} >
                      {t('6840')} <b>{fileName}</b>
                    </span>
                  )}
                </Grid>
                <Grid item xs={7}></Grid>
                <Grid
                  item
                  xs={5}
                  className={"displayFlexCenter"}
                  style={{gap: "8px", padding: "0",justifyContent: "flex-end",paddingRight: "15px",
                  }}>
                 
                  <Button
                    variant="contained" style={{ height: "25px" }}
                    className={"hoverEffectButton"} color="primary" endIcon={<Cancel />}onClick={handleCancel}>
                    {t("242411")}
                  </Button>
                  <Button type="submit" className={'hoverEffectButton'} size="small" variant="contained" endIcon={<TaskAltIcon />}
                  onClick={handleSubmit}>        {t('090')}
                                </Button>
                                <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<KeyboardReturn />}
                                                onClick={handleReturn}>
                                                {t('242410')}
                                              </Button>
                </Grid>
              </Grid>
              <Grid container spacing={2} style={{ marginTop: "0px" }}>
                <Grid
                  item
                  xs={12}
                  style={{ display: "flex", padding: "0px", gap: "10px" }}>
                  <Typography className={"strongerTxt"}>
                    {t("6822")} :
                  </Typography>
                              
                  <Typography style={{ fontSize: "10px" }}>
                    {t("6823")}
                  </Typography>
                </Grid>
                </Grid>
                </Box>
                      
                                {fileError && <div className="error" style={{ color: '#d9534f', marginTop: '5px', fontSize: '14px' }}>{fileError}</div>}
                               
                                {uploadError && <div className="error" style={{ color: '#d9534f', marginTop: '10px', fontSize: '11px' }}>{uploadError}</div>}
                                {showDownload && (
                                  <div style={{ marginTop: '10px', textAlign: 'center' }}>
                                    <CSVLink
                                      data={generateErrorFile()}
                                      filename={errorFileName}
                                      className="download-link"
                                      target="_blank"
                                      style={{ textDecoration: 'none' }}
                                    >
                                      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CloudDownload />}>
                                        {t('089')}
                                      </Button>
                                    </CSVLink>
                                  </div>
                                )}
                              </form>
                            </td>
                          </tr>
                          <tr>
                            <td>
                             </td>
                          </tr>
                          {/* MIDDLE ROW ENDS HERE */}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          <tr height="60px">
            <td colSpan={2}>
              <Footer />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
