import React, { useEffect, useState } from 'react'
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import ThumbUpAltIcon from '@mui/icons-material/ThumbUpAlt';
import useMediaQuery from "@mui/material/useMediaQuery";
import { Box, Button, Checkbox, FormGroup, Grid, Paper, Table, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material'
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
//import salesData from '../salesData.json'
import SendIcon from '@mui/icons-material/Send';
import { useTheme } from "@mui/material/styles";
import axios from 'axios';
import { useTranslation } from 'react-i18next';
import i18n from './i18n';
import { useSelector } from 'react-redux';
import { ArrowRight } from '@mui/icons-material';


function DenominationsAssociationPopUp() {
 const [open, setOpen] = useState(false);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("xl"));

  const {t} = useTranslation();
     let exampleData = null;
    const storedData = localStorage.getItem("userData");
    
    try {
        exampleData = JSON.parse(storedData);
    } catch (e) {
        console.error("Failed to parse JSON from localStorage:", e);
        // Handle the error appropriately
    }
  const partnerId = exampleData.LOGIN_ID;

  const localeVar=i18n.language;
  const [userName, setUserName] = useState(process.env.REACT_APP_USERNAME);
  const [password, setPassword] = useState(process.env.REACT_APP_PASSWORD);
const [denomationsData, setDenomationsData]= useState([]);
const [denomationsDataAirTime, setDenomationsDataAirTime]= useState([]);
const [denomationsDataAirTimeData, setDenomationsDataAirTimeData]= useState([]);
const [denomationsDataAirTimeInsurance, setDenomationsDataAirTimeInsurance]= useState([]);
const [denomationsDataAirTimeSMS, setDenomationsDataAirTimeSMS]= useState([]);
const [denomationsAssociationData, setDenomationsAssociationData]= useState([]);
const [denomationsDataSMS, setDenomationsDataSMS]= useState([]);
const [denomationsDataGAME, setDenomationsDataGAME]= useState([]);


  const fetchData =  () => {
     try {
    //   const apiUrl = process.env.REACT_DENOMINATIONS_ASSOCIATION; // Loading API from Environment Variable
    //   const response = await axios.post(apiUrl, {
    //     userName,
    //     password,
    //     partnerId,
    //     localeVar
    //   });

    const storedData = localStorage.getItem('denominations');
    if (storedData) {
      const responseData = JSON.parse(storedData);
     // alert(responseData);
      //const responseData = response.data;
      console.log("Response Data",responseData);
     
      setDenomationsData(responseData);
      setDenomationsDataAirTime(responseData.airtimeAL);
      setDenomationsDataAirTimeData(responseData.airtimedataAL);
      setDenomationsDataAirTimeInsurance(responseData.airtimeinsuranceAL);
      setDenomationsDataAirTimeSMS(responseData.airtimesmsAL);
      setDenomationsAssociationData(responseData.dataAL);
      setDenomationsDataSMS(responseData.smsAL);
      setDenomationsDataGAME(responseData.gameAL);
     
    } 
  }catch (error) {
      console.error("An error occurred:", error);
    }
    //alert(denomationsData);
    console.log(denomationsData, "denominations Data");
    console.log(denomationsDataAirTime, "denomationsDataAirTime");
  };
useEffect(() => {
   fetchData();
}, []);

const handleClickOpen = (value, id) => {
  setOpen(true);
};

const handleClose = () => {
  setOpen(false);
};

const handleRowCheckboxChange = (event, id) => {
  const isChecked = event.target.checked;

};

const handleSalesSubmit = () => {
 
  setOpen(false);
};

  return (
    <>
       
       <a className="underline-link" onClick={handleClickOpen}><ArrowRight className="animated-arrow" style={{color:'#39f'}} /> <span> {t("6811")}</span></a>
      {/* MODAL STARTS HERE */}
      <Dialog
          fullScreen={fullScreen}
          sx={{
            "& .MuiDialog-container": {
              "& .MuiPaper-root": {
                width: "100%",
                maxWidth: "1200px",  // Set your width here
              },
            },
          }}
          open={open}
          onClose={handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "25px", paddingBottom: '0' }}
            className={"headerTxt"}
            align="center"
          >
            {t("6809")}
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
            }}
          >
            <CloseIcon />
          </IconButton>
          <DialogContent>
            <DialogContentText>
              
            <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '500px' }}>
           
              {/* <Box style={{display:'flex', justifyContent: 'space-between', marginTop: '10px', marginRight: '10px'}}>
              <Checkbox />
                <Box style={{display: 'flex', gap: '10px', marginBottom: '10px'}}>
                <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}>
                  Submit
                </Button>
                <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CloseIcon />}>
                  Close
                </Button>
                </Box>
              </Box> */}
              <Table sx={{ minWidth: 500 }} size="small" className={'denomAssociationTable'} stickyHeader aria-label="sticky table"> 
                  <TableHead>
                    <TableRow className={"darkgray"}>
                      <TableCell width="20%" align="center" className={"whiteBldTxt"}>
                      {/* Transaction <br /> Type */}
                      {t("6807")}
                      </TableCell>
                      <TableCell width="80%" align="center" className={"whiteBldTxt"}>
                      {t("6808")}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                 
                    <TableRow className={""}>
                        <TableCell align="center">{t('6801')}</TableCell>
                        
                    <TableCell>
                        <Grid container
                spacing={2}
                sx={{ width: 1 }}
                className={""}>
                   {denomationsDataAirTime.map((denom) =>(
                            <Grid style={{paddingLeft: '5px',maxWidth: '20%', paddingTop : '5px',flexBasis: '20%'}} item xs={2}><Checkbox checked={denom.defCheckFlag === "Y"} disabled />{denom.airTimeValue=== '-1' ? t("other") : (parseFloat(denom.airTimeValue))}</Grid>
                                
                   ))}
                   </Grid>
                    </TableCell>
                    </TableRow>
                    <TableRow className={""}>
                        <TableCell align="center">{t('6802')}</TableCell>
                        
                    <TableCell>
                        <Grid container
                spacing={2}
                sx={{ width: 1 }}
                className={""}>
                   {denomationsAssociationData.map((denom) =>(
                    denom.denomValue != '' ?
                            <Grid style={{paddingLeft: '5px',maxWidth: '20%', paddingTop : '5px',flexBasis: '20%'}} item xs={2}><Checkbox checked={denom.defCheckFlag === "Y"} disabled />{denom.denomValue}({denom.packetCode})</Grid>
                            : ''
                                
                   ))}
                   </Grid>
                    </TableCell>
                    </TableRow>
                    <TableRow className={""}>
                        <TableCell align="center">{t('6803')}</TableCell>
                        
                    <TableCell>
                        <Grid container
                spacing={2}
                sx={{ width: 1 }}
                className={""}>
                   { (denomationsDataSMS.map((denom) =>(
                    denom.denomValue != '' ?
                            <Grid style={{paddingLeft: '5px',maxWidth: '20%', paddingTop : '5px',flexBasis: '20%'}} item xs={2}><Checkbox checked={denom.defCheckFlag === "Y"} disabled />{denom.denomValue}({denom.packetCode})</Grid>
                            : ""
                                
                   )))}
                   </Grid>
                    </TableCell>
                    </TableRow>
                    <TableRow className={""}>
                        <TableCell align="center">{t('6804')}</TableCell>
                        
                    <TableCell>
                        <Grid container
                spacing={2}
                sx={{ width: 1 }}
                className={""}>
                   {denomationsDataAirTimeSMS.map((denom) =>(
                            <Grid style={{paddingLeft: '5px',maxWidth: '20%', paddingTop : '5px',flexBasis: '20%'}} item xs={2}><Checkbox checked={denom.defCheckFlag === "Y"} disabled />{denom.denomValue}</Grid>
                                
                   ))}
                   </Grid>
                    </TableCell>
                    </TableRow>
                    <TableRow className={""}>
                        <TableCell align="center">{t('6805')}</TableCell>
                        
                    <TableCell>
                        <Grid container
                spacing={2}
                sx={{ width: 1 }}
                className={""}>
                   {denomationsDataAirTimeData.map((denom) =>(
                            <Grid style={{paddingLeft: '5px',maxWidth: '20%', paddingTop : '5px',flexBasis: '20%'}} item xs={2}><Checkbox checked={denom.defCheckFlag === "Y"} disabled />{denom.denomValue}</Grid>
                                
                   ))}
                   </Grid>
                    </TableCell>
                    </TableRow>
                    <TableRow className={""}>
                        <TableCell align="center">{t('6806')}</TableCell>
                        
                    <TableCell>
                        <Grid container
                spacing={2}
                sx={{ width: 1 }}
                className={""}>
                   {denomationsDataAirTimeInsurance.map((denom) =>(
                            <Grid style={{paddingLeft: '5px',maxWidth: '20%', paddingTop : '5px',flexBasis: '20%'}} item xs={2}><Checkbox checked={denom.defCheckFlag === "Y"} disabled />{denom.denomValue}</Grid>
                                
                   ))}
                   </Grid>
                    </TableCell>
                    </TableRow>

                    <TableRow className={""}>
                        <TableCell align="center">{t('25160001')}</TableCell>
                        
                    <TableCell>
                        <Grid container
                spacing={2}
                sx={{ width: 1 }}
                className={""}>
                   {denomationsDataGAME.map((denom) =>(
                            <Grid style={{paddingLeft: '5px',maxWidth: '20%', paddingTop : '5px',flexBasis: '20%'}} item xs={2}><Checkbox checked={denom.defCheckFlag === "Y"} disabled />{denom.airTimeValue=== '-1' ? t("other") : (parseFloat(denom.airTimeValue))}</Grid>
                                
                   ))}
                   </Grid>
                    </TableCell>
                    </TableRow>

                </Table>
                <Box style={{display:'flex', justifyContent: 'flex-end', paddingTop: '10px', paddingRight: '10px', position: 'sticky',bottom: 0, zIndex: '999',
    background: '#fff'}}>
                <Box style={{display: 'flex', gap: '10px', marginBottom: '10px'}}>
                <Button className={'hoverEffectButton'} size="small" onClick={handleSalesSubmit} variant="contained" endIcon={<SendIcon />}>
                {t("26160199")}
                </Button>
                <Button className={'hoverEffectButton'} size="small" onClick={handleClose} variant="contained" endIcon={<CloseIcon />}>
                {t("6810")}
                </Button>
                </Box>
              </Box>
              </TableContainer>
            </DialogContentText>
          </DialogContent>
        </Dialog>
        {/* MODAL ENDS HERE */}
    </>
  )
}

export default DenominationsAssociationPopUp;