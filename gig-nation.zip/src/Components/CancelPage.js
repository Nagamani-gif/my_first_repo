import React, { useEffect } from 'react'
import { useNavigate } from 'react-router';
import { Footer } from './PageComponents'
import { Link } from 'react-router-dom';
import Button from '@mui/material/Button';
import { useTranslation } from 'react-i18next';
import Navbar from './Navbar';
import { LoginOutlined } from '@mui/icons-material';
import { useDispatch } from 'react-redux';
import { logoutUser } from '../reducers/exampleSlice';

const CancelPage = () => {
    const dispatch = useDispatch();

    const navigate = useNavigate();
     // BROWSER BACK BUTTON WILL NOT WORK FOR THIS PAGE
     useEffect(() => {
        // Push a new state to history to prevent back navigation
        window.history.pushState(null, document.title, window.location.href);
    
        const handlePopState = (event) => {
          // Prevent navigating back to the previous page
          window.history.pushState(null, document.title, window.location.href);
        };
    
        window.addEventListener('popstate', handlePopState);
    
        return () => {
          window.removeEventListener('popstate', handlePopState);
        };
      }, []);
      useEffect(() => {
        const handleBeforeUnload = (event) => {
            
            // Prevent the default behavior and show a confirmation dialog
            event.preventDefault();
            event.returnValue = ''; // Standard way to trigger a confirmation dialog
        };
    
            // Add event listener to prevent page refresh or navigation away
            window.addEventListener('beforeunload', handleBeforeUnload);
    
            // Cleanup event listener on component unmount
            return () => {
                window.removeEventListener('beforeunload', handleBeforeUnload);
            };
        },
     []);
    
    
    const handleLoginAgain = () => {
      dispatch(logoutUser());
      localStorage.removeItem('sessionId');
      localStorage.removeItem('language');
      navigate('/');
    };
    const { t } = useTranslation();

    useEffect(() => {
        // Set the browser title
          document.title = t('2472_028');
      }, []);
    return (
        <div>
            <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <tbody>
                    <tr>
                        <Navbar />
                    </tr>
                    <tr>
                        <center >


                            <tr>
                                <td height="52" class="headerTxt" align="center" >
                                    <p style={{color: '#000', fontWeight: '600'}}>{t('5')}</p>
                                </td>
                            </tr>

                            <Link to={"/"}>
                                <Button className={'hoverEffectButton'} onClick={handleLoginAgain} size="small" endIcon={<LoginOutlined />} variant="contained" ><b>{t('4')}</b></Button>
                            </Link>

                        </center>
                    </tr>
                    <tr height="50px"><td colSpan={2}>
                        <Footer />
                    </td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}

export default CancelPage;




