/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable jsx-a11y/anchor-is-valid */
import { useTranslation } from 'react-i18next';
import i18n from './i18n';
import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { Link, NavLink } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { logout, logoutUser } from '../reducers/exampleSlice';
import { ArrowForwardIos, Create, DirectionsRun, East, LibraryBooks, LoginOutlined, LogoutOutlined, Person, Person2, PlayArrow, PowerSettingsNew, Summarize } from '@mui/icons-material';
import { Box, Button, Tab, Tabs } from '@mui/material';
import axios from 'axios';
import MeetingRoomIcon from '@mui/icons-material/MeetingRoom';
import EditIcon from '@mui/icons-material/Edit';
import DistributorBlock from './TopSlideshow';
import UserManual from './UserManual';


  function LeftMenu() {

    const {t} = useTranslation();

    const exampleData = JSON.parse(localStorage.getItem("userData")) ;

    const subMenuLinks = exampleData.userPrivileges;

    var selectedLink = sessionStorage.getItem("selectedLink");

    const subMenuObject = subMenuLinks.filter((item) => {
                            return (Object.keys(item))[0] === selectedLink
                        })

    const subMenuArray = subMenuObject[0][selectedLink]


    const leftMenuLinks = [
      { name: 'Transactions', path: '/subdistributors' },
      { name: 'Distributor Fund Transfer', path: '/distributor-fund-transfer' },
      { name: 'MVNE Report', path: '/subdistributors' },
      { name: 'Port-In Report', path: '/subdistributors' },
      { name: 'Lateral Fund Reversal Report', path: '/subdistributors' },
      { name: 'Pending Transactions', path: '/subdistributors' },
      { name: 'Fund Transfer Reports', path: '/subdistributors' },
      { name: 'Reversal Transaction Report', path: '/subdistributors' },
      { name: 'Balance Annulment', path: '/balanceAnnulment' },
      { name: 'Balance Annulment Report', path: '/subdistributors' },
      { name: 'Partner Status Report', path: '/subdistributors' },
      { name: 'Quick Transfer', path: '/quickTransfer'},
      { name: 'Fund Transfer Reversal Report', path: '/quickTransfer' },
      { name: 'Bulk Fund Transfer', path: '/bulk-transfer' },
      { name: 'Bill Payment Report', path: '/quickTransfer' },
      { name: 'Massive Transfers', path: '/quickTransfer' },
      { name: 'Packet Sales Report', path: '/quickTransfer' },
      { name: 'Sales Target Report', path: '/quickTransfer' },
      { name: 'Facre Billing Report', path: '/quickTransfer' },
      { name: 'Account Status Report', path: '/quickTransfer' },
      { name: 'POS Transaction Report', path: '/quickTransfer' }
  ];
  
 
  
     const highlightSubMenu = (index) => {
      sessionStorage.setItem("selectedSubMenuIndex", index)
    }

    var selectedSubMenuIndex = sessionStorage.getItem("selectedSubMenuIndex")

    const showLeftMenuLinks = (subMenuArray, index) => {

      return subMenuArray.map((item, i) => (
        <tr>
          <td width={'33%'} align={'left'} nowrap="nowrap" className={'menuNav'}>
            <PlayArrow style={{width: '12px', height: '12px', paddingRight: '4px'}} />
                <Link to={t(item)} style={{fontSize: '11px'}} className={selectedSubMenuIndex === i ? "subLinkVisited" : "subLink"} onClick={() => highlightSubMenu(i)}>
                  {t(item.split("#")[1])}
                </Link>
          </td>
        </tr>
      ));
    }

    return(
      <> 
        {showLeftMenuLinks(subMenuArray, 0)}
      </>
    );
  }


  
  function JasperLeftMenu() {

    const [jasperUrls, setJasperUrls] = useState({})
    
    const exampleData = JSON.parse(localStorage.getItem("userData")) ;

    console.log("exampleData", exampleData);

    const subMenuLinks = exampleData.userPrivileges;

    var selectedLink = sessionStorage.getItem("selectedLink");

    const subMenuObject = subMenuLinks.filter((item) => {
                            return (Object.keys(item))[0] === selectedLink
                        })

    const subMenuArray = subMenuObject[0][selectedLink]

    useEffect( () => {

      console.log("in useEffect")

      let promise = new Promise( async(resolve, reject) => {
        let count = 0
        let subMenuArrayLength = subMenuArray.length
        let urls = {};
  
        for(let i = 0; i < subMenuArrayLength; i++){
          let url = await getJasperReportUrl(subMenuArray[i].split("_")[1])
          if(url){
            urls[subMenuArray[i].split("_")[1]] = url
            count++;
          }
        }
  
        if(count == subMenuArrayLength){
          resolve(urls)
        }
      }
  
      );
  
      promise.then(
        (urls) => {
          setJasperUrls(urls)
        }
      );
  
    },[])  

    const {t} = useTranslation();

     console.log("jasperUrls", jasperUrls)    
    
    // console.log("subMenuArray", subMenuArray)
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
    const getJasperReportUrl = async(reportName) => {
      let url = window.config.apiUrl + process.env.REACT_APP_JASPER_URL;
      const response = await axios.post(url, {
                             userName,
                             password,
                            "localeVar": i18n.language,
                            "partnerId": exampleData.LOGIN_ID,
                            "reportName": reportName,
                            "remoteHostAddress": localStorage.getItem("clientNetworkIp")
                          });
          
          return String(response.data.jasperPageUrl)       
    }

    // const highlightSelectedLink = (e) => {
      // var x = document.querySelector(".subLinkVisited");
      // if(x !== null){
      //   x.classList.replace("subLinkVisited", "subLink");
      // }
      // e.target.classList.replace("subLink", "subLinkVisited");

    // }
    const [selectedNav, setSelectedNav] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();

  // Set selectedNav based on the current path on component mount
  useEffect(() => {
    const currentPath = location.pathname;
    const matchingItem = subMenuArray.find(item => t(item) === currentPath);
    if (matchingItem) {
      setSelectedNav(matchingItem);
    }
  }, [location.pathname, subMenuArray, t]);

  const highlightSelectedLink = (e, item, isExternal = false, url = '') => {
    e.preventDefault(); // Prevent default action to ensure no page refresh
    setSelectedNav(item);
console.log(url, "URLLLLLL")
    if (isExternal) {
      setTimeout(() => {
        window.open(url, '_blank');
      }, 0);
    } else {
      const internalUrl = t(item); // Get the correct internal URL from t(item)
      navigate(internalUrl);
    }
  };

    const showLeftMenuLinks = (subMenuArray) => {

      return subMenuArray.map((item, i) => {
        const isSelected = selectedNav === item;
        const isExternal = !["distributorfundstransfer", "balanceAnnulmentp", "quicktransferp", "partnerbulkfundtransfersp",
          "topupphonep", "viewsalespeoplep", "addsalespersonp", "viewsubgroups", "distributorshierarchyp", "addsubgroupp", "featureassociation",
          "publictelephoneuploadp", "publictelephoneenquiryp", "postpaidpaymentsp", "postpaidtransactionreportp"
        ].includes(item.split("_")[1]);
        return ( <tr>
          <td width={'33%'} align={'left'} nowrap="nowrap" className={`menuNav ${isSelected ? 'menuNavVisited' : ''}`}>
            <PlayArrow style={{width: '12px', height: '12px', paddingRight: '4px'}} />
            {isExternal ? (
              <a href={jasperUrls[item.split("_")[1]]} target={"_blank"} id={"subLink" + i} style={{ fontSize: '11px' }} className={isSelected ? 'subLinkVisited' : 'subLink'}
                onClick={(e) => highlightSelectedLink(e, item, true, jasperUrls[item.split("_")[1]])}>
                {t(item.split("#")[1])}
              </a>
            ) : (
              <Link to={t(item)} style={{ fontSize: '11px' }} className={isSelected ? 'subLinkVisited' : 'subLink'}
                onClick={(e) => highlightSelectedLink(e, item)}>
                {t(item.split("#")[1])}
              </Link>
            )}

          </td>
        </tr>
        )
    });
    }

    return(
      <> 
        {showLeftMenuLinks(subMenuArray)}
      </>
    );
  }

  function JasperTopMenu( props ) {

    const [jasperUrls, setJasperUrls] = useState({})
    
    const exampleData = JSON.parse(localStorage.getItem("userData")) ;

    console.log("exampleData", exampleData);

    const subMenuLinks = exampleData.userPrivileges;

    var selectedLink = sessionStorage.getItem("selectedLink");

    const subMenuObject = subMenuLinks.filter((item) => {
                            return (Object.keys(item))[0] === selectedLink
                        })


                        // const getJasperReport =(url) => {
                        //   //alert(url);
                        //   const left = (window.screen.width / 2) - (620 / 2);
                        //   const top = (window.screen.height / 2) - (400 / 2);
                        //   const mysource = url;
                        //   let popupWindow = null;
                        //   const mybars = "directories=no,location=no,menubar=no,status=no,toolbar=no,scrollbars=yes,titlebar=no,alwaysraised=yes,dependent";
                        //   const myoptions = `scrollbars=yes,width=${window.screen.width},height=${window.screen.height},resizable=yes,top=${top},left=${left}`;
                        //   const myfeatures = `${mybars},${myoptions}`;
                      
                        //   if (!popupWindow || popupWindow.closed) {
                        //     popupWindow = window.open(mysource, "viewAssociatedChannelsPopUp", myfeatures);
                        //    popupWindow.focus();
                        //   }
                        // };                    

    const subMenuArray = subMenuObject[0][selectedLink]

    useEffect( () => {

      console.log("in useEffect")

      let promise = new Promise( async(resolve, reject) => {
        let count = 0
        let subMenuArrayLength = subMenuArray.length
        let urls = {};
  
        for(let i = 0; i < subMenuArrayLength; i++){
          let url = await getJasperReportUrl(subMenuArray[i].split("_")[1])
          if(url){
            urls[subMenuArray[i].split("_")[1]] = url
            count++;
          }
        }
  
        if(count == subMenuArrayLength){
          resolve(urls)
        }
      }
  
      );
  
      promise.then(
        (urls) => {
          setJasperUrls(urls)
        }
      );
  
    },[])  


    

    const {t} = useTranslation();

    // console.log("jasperUrls", jasperUrls)    
    
    // console.log("subMenuArray", subMenuArray)
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
    const getJasperReportUrl = async(reportName) => {
    
      let url = window.config.apiUrl + process.env.REACT_APP_JASPER_URL;
      const response = await axios.post(url, {
                             userName,
                             password,
                            "localeVar": i18n.language,
                            "partnerId": exampleData.LOGIN_ID,
                            "reportName": reportName,
                            "remoteHostAddress": localStorage.getItem("clientNetworkIp")
                          });
          
          return String(response.data.jasperPageUrl)       
    }

    const highlightSelectedLink = (e) => {
      var x = document.querySelector(".subLinkVisited");
      if(x !== null){
        x.classList.replace("subLinkVisited", "subLink");
      }
      e.target.classList.replace("subLink", "subLinkVisited");
    }

    
    const navigate = useNavigate();

    const handleNavigation = ( menu, e) => {
      e.preventDefault(); // Prevent default anchor behavior
      //window.open(url, "_blank"); // Open in a new tab
      if(menu === "distributorpaymentsp"){
        navigate("/distributorpayments")
      }
      
      
    };
    useEffect(() => {
      // Automatically highlight the first item on mount
      const firstLink = document.querySelector(".profile_menu");
      if (firstLink) {
        highlightSelectedLink({ target: firstLink });
      }
    }, [subMenuArray]); // Runs when subMenuArray changes
  
    const showLeftMenuLinks = (subMenuArray) => {

      return  (<Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
 <Tabs style={{minHeight: '35px'}}>
{subMenuArray.map((item, i) => (
            ["distributorfundstransfer", "balanceAnnulmentp", "quicktransferp", "partnerbulkfundtransfersp",
              "topupphonep", "viewsalespeoplep", "addsalespersonp", "viewsubgroups", "distributorshierarchyp", "addsubgroupp", "featureassociation",
              "publictelephoneuploadp", "publictelephoneenquiryp", "postpaidpaymentsp", "postpaidtransactionreportp"
            ].includes(item.split("_")[1]) ? <NavLink
            to={t(item)}
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab value= {t(item.split("#")[1])} label= {t(item.split("#")[1])} /></NavLink> 
          
          : 

<NavLink
  to="/distributorpayments"
  className={({ isActive }) =>
    isActive
      ? 'activeProfilemenu'
      : `profile_menu ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
  }
>
  <Tab value={t(item.split("#")[1])} label={t(item.split("#")[1])} />
</NavLink>

          // <a
          //  // to={jasperUrls[item.split("_")[1]]}
          //  href={jasperUrls[item.split("_")[1]]}
          //   target={"_blank"}
          //   id={"subLink"+i}
          //   onClick={(e) => {
          //     highlightSelectedLink(e);
          //      handleNavigation(jasperUrls[item.split("_")[1]], item.split("_")[1], e);
          //   }}
            
          //   className={`subLinkVisited1 ${i === 0 ? "activeProfilemenu" : "profile_menu"}`}
            
          // ><Tab style={{minHeight : '35px'}} value={t(item.split("#")[1])} label={t(item.split("#")[1])} /></a>
          

        
      ))
    }
    </Tabs>
    </Box>)
    
    }

    return(
      <> 
        {showLeftMenuLinks(subMenuArray)}
      </>
    );
  }
// REPORTS TOP MENU
function ReportsTopMenu( props ) {
useEffect(()=>{
  // var selectedLink = "e_transactions";
  // var selectedLink = sessionStorage.setItem("selectedLink", selectedLink);

 // sessionStorage.setItem("selectedIndex", 5);
},[])
  const [jasperUrls, setJasperUrls] = useState({})
  
  const exampleData = JSON.parse(localStorage.getItem("userData")) ;

  console.log("exampleData from Report", exampleData);

  const subMenuLinks = exampleData.userPrivileges;

  // var selectedLink = "e_transactions";
  // var selectedLink = sessionStorage.setItem("selectedLink", selectedLink);
  // // var selectedLink = sessionStorage.getItem("selectedLink");
  // sessionStorage.setItem("selectedIndex", 5);

  // const subMenuObject = subMenuLinks.filter((item) => {
  //                         return (Object.keys(item))[0] === selectedLink
  //                     })                  

  // const subMenuArray = subMenuObject[0][selectedLink]
  //const subMenuArray = subMenuLinks[9].e_transactions
  let subMenuArray = [];

  if (subMenuLinks.length > 9 && subMenuLinks[9]?.e_transactions) {
    subMenuArray = subMenuLinks[9].e_transactions;
  } else {
    console.log("subMenuLinks[9] or e_transactions is not available, using all links as fallback");
    subMenuArray = subMenuLinks.flatMap(link => link.e_transactions || []); // Flatten all `e_transactions`
  }
  
  // Use the subMenuArray safely
  console.log("submenuArray", subMenuArray);
  // e_transactions
  useEffect( () => {

    console.log("in useEffect")

    let promise = new Promise( async(resolve, reject) => {
      let count = 0
      let subMenuArrayLength = subMenuArray.length
      let urls = {};

      for(let i = 0; i < subMenuArrayLength; i++){
        let url = await getJasperReportUrl(subMenuArray[i].split("_")[1])
        if(url){
          urls[subMenuArray[i].split("_")[1]] = url
          count++;
        }
      }

      if(count == subMenuArrayLength){
        resolve(urls)
      }
    }

    );

    promise.then(
      (urls) => {
        setJasperUrls(urls)
      }
    );

  },[])  


  

  const {t} = useTranslation();

  // console.log("jasperUrls", jasperUrls)    
  
  // console.log("subMenuArray", subMenuArray)
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const getJasperReportUrl = async(reportName) => {
  
    let url = window.config.apiUrl+process.env.REACT_APP_JASPER_URL;
    const response = await axios.post(url, {
                           userName,
                           password,
                          "localeVar": i18n.language,
                          "partnerId": exampleData.LOGIN_ID,
                          "reportName": reportName,
                          "remoteHostAddress": localStorage.getItem("clientNetworkIp")
                        });
        
        return String(response.data.jasperPageUrl)       
  }

  const highlightSelectedLink = (e) => {
    var x = document.querySelector(".subLinkVisited");
    if(x !== null){
      x.classList.replace("subLinkVisited", "subLink");
    }
    e.target.classList.replace("subLink", "subLinkVisited");
  }
console.log(subMenuArray, "Sub Menu Array from Reports Top Menu")
  const showLeftMenuLinks = (subMenuArray) => {

    return  (
<>
<Box className={'reports_bloc mL8'}>
{subMenuArray.map((item, i) => {
    const reportKey = item.split("_")[1];
    // Skip these specific report keys
    if ([
      "distributorfundstransfer",
      "balanceAnnulmentp",
      "quicktransferp",
      "partnerbulkfundtransfersp",
    ].includes(reportKey)) {
      return null; // skip rendering
    }

    return (
      <NavLink
        key={i}
        to={`/${reportKey}`} // dynamic route for each report
        id={"subLink" + i}
        onClick={(e) => highlightSelectedLink(e)}
        className="profile_menu"
        style={{ position: 'relative' }}
        state={{ jasperUrl: jasperUrls[reportKey] }} // pass URL via location state
      >
        {t(item.split("#")[1])}
        <East
          style={{
            position: 'absolute',
            width: '15px',
            height: '15px',
            right: '-23px',
            color: '#fff',
          }}
        />
      </NavLink>
    );
  })}


{/* {subMenuArray.map((item, i) => (
          ["distributorfundstransfer", "balanceAnnulmentp", "quicktransferp", "partnerbulkfundtransfersp",
          ].includes(item.split("_")[1]) ? <></>
        
        : 
        
          //  <div>
        <a
         // to={jasperUrls[item.split("_")[1]]}
         href={jasperUrls[item.split("_")[1]]}
          target={"_blank"}
          style={{position:'relative'}}
          id={"subLink"+i}
          onClick={(e) => highlightSelectedLink(e)}
          className={'profile_menu'}
        >{t(item.split("#")[1])} <East style={{position: 'absolute',
          width: '15px',
          height: '15px',
          right: '-23px',
          color: '#fff'}} /> </a>
        // </div>

      
    ))
  } */}
  </Box>
  </>
)
  
  }

  return(
    <> 
      {showLeftMenuLinks(subMenuArray)}
    </>
  );
}
// REPORTS TOP MENU
function TransactionTopMenu( props ) {
useEffect(()=>{
  var selectedLink = "e_transactions";
  var selectedLink = sessionStorage.setItem("selectedLink", selectedLink);

  //sessionStorage.setItem("selectedIndex", 5);
},[])
  const [jasperUrls, setJasperUrls] = useState({})
  
  const exampleData = JSON.parse(localStorage.getItem("userData")) ;

  console.log("exampleData from transaction top", exampleData );

  const subMenuLinks = exampleData.userPrivileges;

  // var selectedLink = sessionStorage.getItem("selectedLink");
  // var selectedLink = "e_transactions";
  // var selectedLink = sessionStorage.setItem("selectedLink", selectedLink);

  // sessionStorage.setItem("selectedIndex", 5);
  // const subMenuObject = subMenuLinks.filter((item) => {
  //                         return (Object.keys(item))[0] === selectedLink
  //                     })                  

  // const subMenuArray = subMenuObject[0][selectedLink]
  //const subMenuArray = subMenuLinks[9].e_transactions
 
  let subMenuArray = [];

  if (subMenuLinks.length > 9 && subMenuLinks[9]?.e_transactions) {
    subMenuArray = subMenuLinks[9].e_transactions;
  } else {
    console.log("subMenuLinks[9] or e_transactions is not available, using all links as fallback");
    subMenuArray = subMenuLinks.flatMap(link => link.e_transactions || []); // Flatten all `e_transactions`
  }
  
  // Use the subMenuArray safely
  console.log("submenuArray", subMenuArray);



  useEffect( () => {

    console.log("in useEffect")

    let promise = new Promise( async(resolve, reject) => {
      let count = 0
      let subMenuArrayLength = subMenuArray.length
      let urls = {};

      for(let i = 0; i < subMenuArrayLength; i++){
        let url = await getJasperReportUrl(subMenuArray[i].split("_")[1])
        if(url){
          urls[subMenuArray[i].split("_")[1]] = url
          count++;
        }
      }

      if(count == subMenuArrayLength){
        resolve(urls)
      }
    }

    );

    promise.then(
      (urls) => {
        setJasperUrls(urls)
      }
    );

  },[])  


  

  const {t} = useTranslation();
  const location = useLocation();
console.log("Locatin from TransactionTop", location.pathname)
  // console.log("jasperUrls", jasperUrls)    
  
  // console.log("subMenuArray", subMenuArray)
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const getJasperReportUrl = async(reportName) => {
  
    let url = window.config.apiUrl+process.env.REACT_APP_JASPER_URL;
    const response = await axios.post(url, {
                           userName,
                           password,
                          "localeVar": i18n.language,
                          "partnerId": exampleData.LOGIN_ID,
                          "reportName": reportName,
                          "remoteHostAddress": localStorage.getItem("clientNetworkIp")
                        });
        
        return String(response.data.jasperPageUrl)       
  }

  const highlightSelectedLink = (e) => {
    var x = document.querySelector(".subLinkVisited");
    if(x !== null){
      x.classList.replace("subLinkVisited", "subLink");
    }
    e.target.classList.replace("subLink", "subLinkVisited");
  }

  const showLeftMenuLinks = (subMenuArray) => {

    return  (
<>
<Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
 <Tabs style={{minHeight: '35px'}}>
 <NavLink
            to="/transaction"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab value={t('7057')} label={t('7057')} /></NavLink>
{/* {subMenuArray.map((item, i) => (
          ["distributorfundstransfer", "balanceAnnulmentp", "quicktransferp", "partnerbulkfundtransfersp",
          ].includes(item.split("_")[1]) ? 
          <NavLink
            to={t(item)}
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu ${props.menu === "menuHighlight" ? 'addingDynClass' : ''} ${props.menu === "menuHighlighttt" && location.pathname ==="/balanceAnnulmentSubmit" ? 'addingDynClass' : ''}`
            }
          ><Tab value= {t(item.split("#")[1])} label= {t(item.split("#")[1])} /></NavLink>
        
        : 
        
           <></>

      
    ))
  } */}
  {subMenuArray.map((item, i) => {
  const menuKey = item.split("_")[1]; // Extract the key

  if (menuKey === "balanceAnnulmentp") {
    return (
      <NavLink
        key={i}
        to={t(item)}
        onClick={(e) => highlightSelectedLink(e)}
        className={({ isActive }) =>
          isActive
            ? "activeProfilemenu"
            : `profile_menu ${props.menu === "menuHighlighttt" ? "addingDynClass" : ""}`
        }
      >
        <Tab value={t(item.split("#")[1])} label={t(item.split("#")[1])} />
      </NavLink>
    );
  } 

  return ["distributorfundstransfer", "quicktransferp", "partnerbulkfundtransfersp"].includes(menuKey) ? (
    <NavLink
      key={i}
      to={t(item)}
      onClick={(e) => highlightSelectedLink(e)}
      className={({ isActive }) =>
        isActive
          ? "activeProfilemenu"
          : `profile_menu ${props.menu === "menuHighlight" ? "addingDynClass" : ""}`
      }
    >
      <Tab value={t(item.split("#")[1])} label={t(item.split("#")[1])} />
    </NavLink>
  ) : null;
})}

  </Tabs>
  </Box>
  </>
)
  
  }

  return(
    <> 
      {showLeftMenuLinks(subMenuArray)}
    </>
  );
}
// 
  function CurrentDate(){
    let newDate = new Date();
      let day = newDate.toLocaleString(i18n.language==='en' ? 'en-US' : 'es-ES', {day: '2-digit'});
      let month = newDate.toLocaleString(i18n.language==='en' ? 'en-US' : 'es-ES', { month: 'long' });;
    let year = newDate.getFullYear();
      let weekDay = newDate.toLocaleString(i18n.language==='en' ? 'en-US' : 'es-ES', {weekday:'long'});
  
    return(
      <>
        <font color="#808080" face="Arial" style={{fontSize: '9pt'}}>
          {/* Thursday,&nbsp;  TODO <WeekDay /> */} {weekDay + ","}
      </font>
        <font className="timeClass">
          {/* 21 March 2024   TODO <Date /> */} {day+" "+month+" "+year}
            </font>
      </>
    );
  }

  function Header() {
    const {t} = useTranslation();
    const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
   // console.log("name====>"+exampleData.FIRST_NAME+exampleData.LAST_NAME);
console.log(exampleData, "USER DATAA")
  const navigate = useNavigate();
  const dispatch = useDispatch();


//Audit Reports Code Starts
 
const browser = navigator.userAgent;
const localeVar = i18n.language;
 //console.log("exampleData LOGIN_ID====>"+exampleData.LOGIN_ID);


 console.log("browser-->"+browser);
 // const location1 = useLocation();
 //  console.log("location1.pathname-->"+location1.pathname);  // This will give you the current path (URI)
 
 const Page = window.location.pathname;
 console.log("urlPage-->"+Page.replace('/airmanage',''));
 const urlPage=Page.replace('/airmanage','');
 let partnerId = exampleData?.LOGIN_ID;
 const userName = process.env.REACT_APP_USERNAME;
 const password = process.env.REACT_APP_PASSWORD;
 const userType = exampleData?.USER_TYPE_ID
 const moduleName = "Partner";
 const sessionId = exampleData?.sessionId
 const loginTime = "";
 const logoutTime = "";
 const timeZone = "";
 const remoteAdd = exampleData?.remoteAddress;
 const isNormalLogout = "N";
 const isLogin=false;
 
 console.log("exampleData USER_TYPE_ID====>"+exampleData?.USER_TYPE_ID);
 console.log("exampleData remoteAdd====>"+remoteAdd);
 console.log("exampleData sessionId====>"+exampleData?.sessionId);
 
 // useEffect(() => {
 
 // const fetchDataAsync = async () => {
 // try {
 //   await fetchData(); // Call your existing fetchData function asynchronously
 // } catch (error) {
 //   console.error('Error fetching data:', error);
 // }
 // }
 // fetchDataAsync(); // Fetch data when the component mounts
 // }, []); // Empty dependency array ensures this effect runs only once on mount
 
 const fetchData = async () => {
 try {
 // Fetch data from API
 //alert("called")
 const apiUrl =  window.config.apiUrl + process.env.REACT_APP_AUDIT_REPORT;
 const response = await axios.post(apiUrl, {
   userName,
   password,
   localeVar,
   partnerId,
   userType,
   moduleName,
   sessionId,
   urlPage:"/partner/logout",
   browser,
   remoteAdd,
   isNormalLogout,
   isLogin
 });
 
 console.log("response.data"+JSON.stringify(response.data));
 
 // setPartnerData(response.data);
 
 } catch (error) {
 console.error("An error occurred:", error);
 // Handle error, e.g., display error message to the user
 }
 };
 //Audit Reports Code Ends    


  const handleLogout =()=>{
    fetchData();
    dispatch(logoutUser());
    navigate('/logout');  
  }

    return(
      <>
      <tr height="55px">
            <td colSpan={2} style={{}}>
              <table border={0} cellPadding={0} cellSpacing={0} width="100%">
                <tbody>
   <Box className={'header_sec'} style={{display:'flex', justifyContent:'space-between', padding:'2px 10px 3px'}}>
  <Box style={{width:'10%'}}><img border={0} style={{width: '138px'}} src={require("../images/logo.PNG")} /></Box> 
<Box style={{display:'flex',width:'90%', justifyContent:'flex-end'}}>
<DistributorBlock />
<Box style={{width:'73px'}}><Button style={{ height:'25.5px', marginLeft:'10px', marginTop:'15px'}} onClick={handleLogout} className="hoverEffectButton" size="small" variant="contained" endIcon={<LogoutOutlined />}>
  {t('logout')}
   
  </Button>
  </Box>
</Box>
   </Box>


      {/* <table border={0} cellPadding={0} cellSpacing={0} width="100%">
              <tbody>
                <tr>
                  <td width={138}>
                <img border={0} style={{width: '100%'}} src={require("../images/logo.PNG")} />
                </td>
                  <td>
                <table border={0} width="100%" cellPadding={0} cellSpacing={0} align="right">
                      <tbody><tr height={25}>
                          <td align="right">
                          </td>
                        </tr>
                        <tr height={25}>
                          <td align="right" nowrap={'true'}> 
                          <DistributorBlock />
                  </td>
                          <td align="right" nowrap={'true'}> 
                          <Button style={{marginLeft: '10px', marginBottom:'10px'}} onClick={handleLogout} className="hoverEffectButton" size="small" variant="contained" endIcon={<LogoutOutlined />}>
  {t('logout')}
   
  </Button> */}
                {/* <div style={{marginBottom: '5px', marginTop: '10px'}}>
                          <font color="#808080" face="Arial" style={{fontSize: '8pt'}}>
                       {t('welcome')}
                    </font><b className="loginTextSmall"> <Person2 className={'userIconn'} />
                    &nbsp;{exampleData.FIRST_NAME} {exampleData.LAST_NAME}</b>
                    </div> */}

                          {/* <div className={'logoutbtn_bloc'}> */}
                {/* <Button className="hoverEffectButton" onClick={handleLogout} size="small" variant="contained">
                {t('logout')} 
    <DirectionsRun className="runIcon" />
    <MeetingRoomIcon className="doorIcon" />
    
  </Button> */}
  
 

                {/* </div> */}
                          {/* </td>
                        </tr> */}
                      {/* </tbody></table>
                
                </td>
                </tr>*/}
                <table border={0} cellPadding={0} cellSpacing={0} width="100%">
                  <tbody>
                <tr>
                  <td colSpan={2} style={{fontSize: '1.5px'}} className="lineClass">&nbsp;</td>
                  
                </tr> </tbody>
                </table>
              
              {/* </tbody></table> */}
              </tbody>
              </table>
            </td>
            </tr>
              </>
    );
  }
  
  function PaymentManagerHeading(){
    // eslint-disable-next-line no-unused-vars
    const {t} = useTranslation();

    var language = '';

    const changeLanguage = (lng) => {
      i18n.changeLanguage(lng);
      language = lng;
    };

    // eslint-disable-next-line no-unused-vars
    const [lang, setLang] = useState(language);
    const [displayedText1, setDisplayedText1] = useState('');
    const [displayedText2, setDisplayedText2] = useState('');
    const localeVar = i18n.language;
    const text1 = localeVar === 'ms' ? ' GIG-Nation' : ' GIG-Nation';
    // const text2 = localeVar === 'ms' ? 'Pengurus' : 'Manager';
    useEffect(() => {
      changeLanguage(lang); // Change to English on component mount

      const animateText = async (text, setDisplayedText, delay) => {
        let newText = '';
        for (let i = 0; i <= text.length; i++) {
          newText += text.charAt(i);
          setDisplayedText(newText);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      };
  
      const startAnimation = async () => {
        await Promise.all([
          animateText(text1, setDisplayedText1, 300), // Adjust speed here
          // animateText(text2, setDisplayedText2, 300), // Adjust speed here
        ]);
      };
  
      startAnimation();
    }, [localeVar, text1]);

return(
  <>
  <td style={{borderRightStyle: 'solid', borderRightWidth: '1pt', borderColor: 'rgb(51 153 255)', width: '100px'}}>
  {displayedText1.split('').map((char, index) => (
   
  <p align="left" style={{marginTop: '10px', marginBottom: 0}} key={index} className="loginTextBig animated-char">{char} {/* TODO use properties*/}<font face="Arial" size={4}><b>
      </b></font></p>
       ))}
       <br />
   
  {/* <div className="text-container">
  {displayedText.split('').map((char, index) => (
    <span key={index} className="animated-char">{char}</span>
  ))}
</div> */}
  </td>
  

  </>
);
}
  
  function Footer(){
    const {t} = useTranslation();
    return(
      <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="55px" style={{boxShadow:'rgb(25 118 210 / 72%) 0px 3px 12px', marginTop:'5px'}}>
      <tbody><tr height="55px"><td align="left"  width={'45%'}>
            
              <font face="Arial" style={{fontSize: '8.5pt'}}>
              <Link to="/showTermsConditions" className="nav" style={{textDecoration: 'none', width:'auto', maxWidth:'fit-content'}}><p className={'termsconditions'} style={{paddingLeft: '20px', marginBottom: '0'}}><LibraryBooks style={{     marginBottom: '3px',   width: '16px', height: '16px'}} /> {t("Terms & Conditions")} </p></Link></font><font face="Arial" style={{fontSize: '8.5pt'}}>
            </font></td>
            <td><UserManual /></td>
          <td align={'right'} style={{fontSize: '11px'}} nowrap={'true'}>{t("Powered by")}</td>
          <td align={'right'} width={1}><a target="xius_website" href="http://www.xius.com" className="nav"><img border={0} style={{ marginRight: '20px'}} src={require("../images/bott_logo.png")} width={80} height={40} /></a></td>
        </tr></tbody></table>
    );
  }



function LeftBgImage() {
    const exampleData = JSON.parse(localStorage.getItem("userData")) ;

    const [bgImage, setBgImage] = useState(exampleData?.IMAGE_FILE);
  
    

    return (
      <td
        valign="top"
        style={{
          width: "100px",
          borderRightStyle: "solid",
          borderRightWidth: "1pt",
          borderColor: "rgb(51 153 255)",
        }}
      >
        {bgImage ? (
          <img
            src={bgImage}
            alt=""
            style={{ width: '100%', height: '500px', objectFit: 'cover' }}
          />
        ) : null}
      </td>
    );
  }
  function LeftBgImage1() {
  const exampleData = JSON.parse(localStorage.getItem("userData")) || {};
  const [bgImage] = useState(exampleData.IMAGE_FILE || null);

  return (
    <td
      valign="top"
      style={{
         width: "calc(100px + 1mm)", // adds 1mm to 100px
        // width: "100px",
        borderRight: "1pt solid rgb(51, 153, 255)",
        height: "620px", // keeps cell height consistent
        
      }}
    >
      {bgImage ? (
        <img
          src={bgImage}
          alt=""
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      ) : (
        <div style={{ height: "100%" }}></div> // empty filler
        
      )}
    </td>
  );
}

function ProfileMenu( props ){
console.log("props=====",props);
let userName = process.env.REACT_APP_USERNAME;
let password = process.env.REACT_APP_PASSWORD;
    const [active, setActive] = useState(false);
    const [url, setUrl] = useState("");
    const exampleData = JSON.parse(localStorage.getItem("userData")) ;
  
    // const getJasperReport =() => {
    //   //alert(source);
    //   const left = (window.screen.width / 2) - (620 / 2);
    //   const top = (window.screen.height / 2) - (400 / 2);
    //   const mysource = url;
    //   let popupWindow = null;
    //   const mybars = "directories=no,location=no,menubar=no,status=no,toolbar=no,scrollbars=yes,titlebar=no,alwaysraised=yes,dependent";
    //   const myoptions = `scrollbars=yes,width=${window.screen.width},height=${window.screen.height},resizable=yes,top=${top},left=${left}`;
    //   const myfeatures = `${mybars},${myoptions}`;
  
    //   if (!popupWindow || popupWindow.closed) {
    //     popupWindow = window.open(mysource, "viewAssociatedChannelsPopUp", myfeatures);
    //     popupWindow.focus();
    //   }
    // };
    
    const navigate = useNavigate();

    // const handleNavigationn = (url, e) => {
    //   e.preventDefault(); // Prevent default anchor behavior
    //  // window.open(url, "_blank"); // Open in a new tab
    //     navigate("/distributorPaymentsHistoryReport");
    // };
   

useEffect(()=>{
 getReportUrl('newpaymentalertshistory');
},[])

    const getReportUrl = async(reportName) => {
     // alert(reportName);
      let url = window.config.apiUrl + process.env.REACT_APP_JASPER_URL;
      const response = await axios.post(url, {
                             userName,
                             password,
                            "localeVar": i18n.language,
                            "partnerId": exampleData.LOGIN_ID,
                            "reportName": reportName,
                            "remoteHostAddress": localStorage.getItem("clientNetworkIp")
                          });
        // alert("hello",+response.data)
         setUrl(response.data.jasperPageUrl)     
    }              
    const {t} = useTranslation();
    return (
  // <tr>
  //   <td align="left"><img border={0} src={require("../images/dotted_arrow.gif")} width={3} height={5} />
  //   {/*<a href="/gig-nation/newPaymentAlerts" className="nav1">Distributor Payment </a> */}
  //   &nbsp;<Link to="/newPaymentAlerts" className="nav1">Distributor Payment</Link>
  //   </td>
  //   <td align="left">
  //     <img border={0} src={require("../images/dotted_arrow.gif")} width={3} height={5} />
  //     &nbsp;<Link to="/notificationConfigMain" className="nav1">Configure Notifications</Link>
  //   </td>
  //   <td align="left">
  //     <img border={0} src={require("../images/dotted_arrow.gif")} width={3} height={5} />
  //     &nbsp;<Link to="javascript:newPaymentAlertsHistory();" className="nav1">Distributor Payments History</Link>{" "}
  //   </td>
  //   <td align="left">
  //     <img border={0} src={require("../images/dotted_arrow.gif")} width={3} height={5} />
  //     &nbsp;<Link to="/changePassword"className="nav1">Change Password</Link>
  //   </td>
  //   <td align="left">
  //     <img border={0} src={require("../images/dotted_arrow.gif")} width={3} height={5} />
  //     &nbsp;<Link to="/sample"className="nav1">Sampleee</Link>
  //   </td>
  //   <td align="left">
  //     <img border={0} src={require("../images/dotted_arrow.gif")} width={3} height={5} />
  //     &nbsp;<Link to="/resetPassword" className="nav1">Reset Password</Link>{" "}</td>
  //   </tr>
  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
  <Tabs style={{minHeight: '35px'}}>
     <NavLink
            to="/profile"
            className={({ isActive }) => (isActive ? 'activeProfilemenu' : `profile_menu ${props.menu === "profileHighlight" ? 'addingDynClass' : ''}`)}
          ><Tab value="Profile" label={t('a_profile')} /></NavLink>
 
    {exampleData.USER_TYPE_ID != 6 ? <>
      {exampleData.PARENT_ID === '' ? <>
        <NavLink
            to="/newPaymentAlerts"
            className={({ isActive }) => (isActive ? 'activeProfilemenu' : 'profile_menu')}
          ><Tab value="Distributor Payment" label={t('065')} /></NavLink>
      <NavLink
            to="/notificationConfigMain"
            className={({ isActive }) => (isActive ? 'activeProfilemenu' : 'profile_menu')}
          ><Tab value="Configure Notifications" label={t('066')} /></NavLink>
       {/* added for jasper report */}

          {/* <a href={url}  target={"_blank"} onClick={(e)=>handleNavigationn(url, e)} className={'subLinkVisited1 profile_menu'}><Tab value="Distributor Payments History" label={t('067')} /></a> */}
          <NavLink to="/distributorPaymentsHistoryReport" className={({ isActive }) => (isActive ? 'activeProfilemenu' : 'profile_menu')}><Tab value="Distributor Payments History" label={t('067')} /></NavLink>
          <NavLink to="/changePassword" className={({ isActive }) => (isActive ? 'activeProfilemenu' : 'profile_menu')}><Tab value="Change Password" label={t('242401')} /></NavLink>
          <NavLink to="/resetPassword" 
          // className={({ isActive }) => (isActive ? 'activeProfilemenu' : 'profile_menu')}
          className={({ isActive }) => 
            isActive ? 'activeProfilemenu' : `profile_menu ${props.menu === "highlightmenu" ? 'addingDynClass' : ''}`
          }
          ><Tab value="Reset Password" label={t('029')} /></NavLink>
          </> : <>
          <NavLink to="/changePassword" className={({ isActive }) => (isActive ? 'activeProfilemenu' : 'profile_menu')}><Tab value="Change Password" label={t('242401')} /></NavLink>
          <NavLink to="/resetPassword"
          // className={({ isActive }) => (isActive ? 'activeProfilemenu' : 'profile_menu')}
          className={({ isActive }) =>
            isActive ? 'activeProfilemenu' : `profile_menu ${props.menu === "highlightmenu" ? 'addingDynClass' : ''}`
          }
          ><Tab value="Reset Password" label={t('029')} /></NavLink>
          </>}
    </> : <></>}
          
         
    
</Tabs>
</Box>
    );
  }

 
  export {Header, JasperLeftMenu, JasperTopMenu, LeftMenu,CurrentDate, PaymentManagerHeading,LeftBgImage1, LeftBgImage, Footer,ProfileMenu, ReportsTopMenu, TransactionTopMenu}