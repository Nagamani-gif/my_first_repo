import React, { useEffect, useState } from 'react'
//import fileUrl from '../user_manual.pdf';
import { Download } from '@mui/icons-material';
import { useTranslation } from 'react-i18next';

const UserManual = () => {
      const {t} = useTranslation();
     // const fileUrl = '/user_manual.pdf'
    // const fileUrl = `${window.location.origin}/gig-nation/user_manual.pdf`;
  const fileUrl = window.config.pdfFilePath;
  const fileName = fileUrl.split('/').pop();
  //const fileName = 'user_manual.pdf'; // Replace with the desired filename
   let isLoggedIn = localStorage.getItem("sessionId");
      console.log(isLoggedIn, "isLoggedIn from footer");
  return (
    <td>
    {isLoggedIn && 
    <a
        href={fileUrl}
        download={fileName}
        style={{
          textDecoration: 'none',
          color: '#39f',
          fontSize: '11px',
          cursor: 'pointer',
          animation: 'blink 1.5s infinite',
        }}
      >
        <Download style={{width: '16px'}} />
      {t("usermanual")}
    </a>
  
        }
    <style>
        {`
          @keyframes blink {
            0%, 100% {
              opacity: 1; /* Fully visible */
            }
            50% {
              opacity: 0; /* Invisible */
            }
          }
        `}
      </style>
      </td>
  )
}

export default UserManual
