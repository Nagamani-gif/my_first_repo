import React, { useState, useEffect, useRef } from "react";
import TopMenu from "./TopMenu";
import { useTranslation } from "react-i18next";
import {
  Footer,
  Header,
  JasperLeftMenu,
  JasperTopMenu,
  LeftBgImage,
  PaymentManagerHeading,
} from "./PageComponents";
import axios from "axios";
import {
  CancelRounded,
  KeyboardReturn,
  RemoveRedEyeRounded,
  AddCardRounded,
  ArrowRight,
} from "@mui/icons-material";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import Button from "@mui/material/Button";
import { Checkbox, styled, TextareaAutosize } from "@mui/material";
import { useNavigate } from "react-router-dom";
import SalesPersonPopup from "./SalesPersonPopup";
import i18n from "./i18n";
import { LocationPopUp } from "./LocationPopUp";
import DenominationsAssociationPopUp from "./DenominationsAssociationPopUp";
import { ToastContainer, toast } from "react-toastify";
import ConfigurationNotificationPopup from "./ConfigurationNotificationPopup";
import NavigationIcon from "@mui/icons-material/Navigation";
import { resetData } from "../reducers/exampleSlice";
import GoogleMapPartner from "./GoogleMapPartner";
import { LoadScript } from "@react-google-maps/api";
import {
  Box,
  Grid,
  TextField,
  Typography,
  TableContainer,
  TableCell,
  Paper,
  TableRow,
  TableHead,
  Table,
  TableBody,
} from "@mui/material";
import ThumbUpAltIcon from "@mui/icons-material/ThumbUpAlt";
import SendIcon from "@mui/icons-material/Send";
import numeral from "numeral";
import Accordion from '@mui/material/Accordion';
import AccordionActions from '@mui/material/AccordionActions';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { CircularProgress } from "@mui/joy";

export default function AddSalesPeople() {
  //sessionStorage.setItem("selectedIndex", 3);
  sessionStorage.setItem("selectedLink", "c_salespeople");

  const [data, setData] = useState(() => {
    // Try to get initial state from sessionStorage
    const savedData = sessionStorage.getItem("homePageData");
    return savedData ? JSON.parse(savedData) : null;
  });
const [errorPartnerIdentity, setErrorPartnerIdentity] = useState('');
  const exampleData = JSON.parse(localStorage.getItem("userData")); // Select the data from the Redux store

  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  let componentRef = useRef();
  const localeVar = i18n.language;
  const [usertypes, setUsertypes] = useState([]);
  const [bankRefernceNumber, setBankRefernceNumber] = useState("");
  const [salesData, setsalesData] = useState([]);
  const [channelTransAl, setChannelTransAl] = useState([]);
  const [ChannelcheckFlag, setChannelcheckFlag] = useState("");
  let partnerParentId = exampleData.LOGIN_ID;
  const activeCurrencyPrecision = exampleData.activeCurrencyPrecision;
  const sfsCheck = exampleData.SINGLE_FUND_SOURCE_FLAG_VAL;
  const sfsCheckvalue = sfsCheck==='N'?'Yes':'No';
  const [parentBSUserName, setParentBSUserName] = useState("");

  const [isPasswordHide, setIsPasswordHide] = useState('');
  const [transferFlag, setTransferFlag] = useState("");
  const [transferFlagStatus, setTransferFlagStatus] = useState("");
  const [flagPmconfigstatusDist, setFlagPmconfigstatusDist] = useState(false);
  const [flagPmconfigstatusSales, setFlagPmconfigstatusSales] = useState(false);
  const [flagPmconfigstatusSingle, setFlagPmconfigstatusSingle] = useState(false);
  const [flagPmconfigstatusMulti, setFlagPmconfigstatusMulti] = useState(false);
  const [flagPmConfigStatusMultiTrans, setFlagPmConfigStatusMultiTrans] = useState(false);
  const [flagPmconfigstatus_RechargeRev, setFlagPmconfigstatus_RechargeRev] = useState(false);
  const [flagPmconfigstatus_TransferRev, setFlagPmconfigstatus_TransferRev] = useState(false);
  const [postToSCLEnableFlag, setPostToSCLEnableFlag] = useState("");
  const [partnerPassword, setPartnerPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [ussdPartnerPassword, setUssdPartnerPassword] = useState("");
  const [ussdConfirmPassword, setUssdConfirmPassword] = useState("");
  const [ussdPwdEnabled, setUssdPwdEnabled] = useState('');
  const [simEnabled, setSimEnabled] = useState('');
  const [errorMessage,setErrorMessage]=useState('');
  const [hierarchyStatus, setHierarchyStatus] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [locationArray, setLocationArray] = useState([]);

  console.log("activeCurrencyPrecision-->" + activeCurrencyPrecision);


  const [clear, setClear] = useState(false);

  const [configId,setConfigId]=useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setTimeout(()=>{
    setIsLoading(false);
    }, 1000)
    },[])

  const setClearReset=(check)=>{

    setClear(check);

  }
    // const fetdenominatons = async () => {
    //   const apiUrl4 = window.config.apiUrl + process.env.REACT_APP_DENOMINATIONS_ASSOCIATION;
    //   console.log(apiUrl4);
    //   const response4 = await axios.post(apiUrl, {
    //     userName,
    //     password,
    //     partnerId: partnerParentId,
    //     localeVar,
    //   });
    //   // const[channels]=response.data;

    //   localStorage.setItem("denominations", JSON.stringify(response4.data));
    //   //alert(JSON.stringify(response.data));
    //   //console.log(JSON.stringify(response.data.channels));
    //   //  setsalesData(JSON.stringify(response.data.channels));
    // }
 

    

  

  const [partnerIdentity, setPartnerIdentity] = useState("");
  const [salesMdn, setSalesMdn] = useState("");
  const [partnerId, setPartnerId] = useState(partnerParentId);
  const [partnerCompanyName, setPartnerCompanyName] = useState('');
  const [childPartnerType, setChildPartnerType] = useState("13");
  const [rucNo, setRucNo] = useState("");
  const [sclCode, setSclCode] = useState(exampleData.SCL_CLIENT_CODE);
  const [paymentType, setPaymentType] = useState("1");
  const [maxFundLimit, setMaxFundLimit] = useState("0.00");
  const [partnerContactFirstName, setPartnerContactFirstName] = useState("");
  const [partnerContactLastName, setPartnerContactLastName] = useState("");
  const [locationVal, setLocationVal] = useState("");
  const [contaddress1, setContaddress1] = useState("");
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [contzipcode, setContzipcode] = useState("");
  const [addresschecking, setAddresschecking] = useState("");
  const [billaddress1, setBilladdress1] = useState("");
  const [billzipcode, setBillzipcode] = useState("");
  const [emailID, setEmailID] = useState("");
  const [accountBal, setAccountBal] = useState("0.00");
  const [acctBalThresold, setAcctBalThresold] = useState("0.00");
  const [status, setStatus] = useState("Y");
  const [Currency, setCurrency] = useState("MXN-Peso Mexicano");
  const [isLateralEnabled, setIsLateralEnabled] = useState("N");
  const [isSingleSrcEnabled, setIsSingleSrcEnabled] = useState("");
  const [isMultiLevlEnabled, setIsMultiLevlEnabled] = useState("N");
  const [isMultiLevlRecEnabled, setIsMultiLevlRecEnabled] = useState("N");
  const [isMultiLevelTransferEnabled, setIsMultiLevelTransferEnabled] =
    useState("N");
  const [isMultiLevelReceiveEnabled, setIsMultiLevelReceiveEnabled] =
    useState("N");

    const [pisMultiLevelTransferEnabled, setPisMultiLevelTransferEnabled] = useState("");
	  const [pisMultiLevelReceiveEnabled, setPisMultiLevelReceiveEnabled] = useState("");
  const [isRechargeReversal, setIsRechargeReversal] = useState("N");
  const [isTransferReversal, setIsTransferReversal] = useState("N");
  const [promTopUpListChk, setPromTopUpListChk] = useState("");
  const [selectedChannelsArr, setSelectedChannelsArr] = useState([]);
  const [negativeTransfers, setNegativeTransfers] = useState("N");
  const [salesForceStatus, setSalesForceStatus] = useState("N");
  const [simTransferStatus, setSimTransferStatus] = useState("N");
  const [partnerSimThreshold, setPartnerSimThreshold] = useState("");
  const [gLedgerCode, setGLedgerCode] = useState("");
  const [isChecked, setIsChecked] = useState(false);
  const [isPrepaidDistributor, setIsPrepaidDistributor] = useState("N");

  //parent also Included based on that we can decide this Default Value
  const [useOwnFunds, setUseOwnFunds] = useState("Y");

  //const [salesForceEnable, setsalesForceEnable] = useState("N");
  // const [simtransenable, setsimtransenable] = useState("N");

  //preview

  const [partnerTypeDesc, setPartnerTypeDesc] = useState("");
  const [pisPrepaidDistributor, setPisPrepaidDistributor] = useState(
    isPrepaidDistributor == "N" ? "No" : "Yes"
  );
  const [sclUserName, setSclUserName] = useState(exampleData.SCL_USER_NAME);
  const [chargeMode, setChargeMode] = useState("");
  const [discountValue, setDiscountValue] = useState("");
  const [locationDesc, setLocationDesc] = useState("");
  const [gl_code, setGl_code] = useState("");
  const [currencyId, setCurrencyId] = useState("MXN - Peso Mexicano");
  const [pisLateralEnabled, setPisLateralEnabled] = useState("");
  const [pisSingleSrcEnabled, setPisSingleSrcEnabled] = useState("");
  const [pisMultiLevlEnabled, setPisMultiLevlEnabled] = useState("");
  const [pisMultiLevlRecEnabled, setPisMultiLevlRecEnabled] = useState("");
  const [pnegativeTransfers, setPnegativeTransfers] = useState();
  const [feeSet, setFeeSet] = useState("1");
  const [Maximumaccount, setMaximumaccount] = useState("");
  const [AccountBalance, setAccountBalance] = useState("0.00");
  const [pstatus, setPstatus] = useState("");
  const [UOF, setUOF] = useState("");
  const [psalesForceEnable, setPsalesForceEnable] = useState("");
  const [psimtransenable, setPsimtransenable] = useState();
  const [ppaymentType, setPpaymentType] = useState("");

  //latest
  const [remoteAddress, setRemoteAddress] = useState("");
  const [ivrTransNo, setIvrTransNo] = useState("");
  const [loginPartnerCompanyName, setLoginPartnerCompanyName] = useState("");
  const [location, setLocation] = useState("");
  const [childPartDescp, setChildPartDescp] = useState("");
  const [parentSclCode, setParentSclCode] = useState(
    exampleData.SCL_CLIENT_CODE
  );
  const [isCredit, setIsCredit] = useState("");
  const [distRatings, setDistRatings] = useState("");
  const [parentSclUserName, setParentSclUserName] = useState(
    exampleData.SCL_USER_NAME
  );
  const [creditLmt, setCreditLmt] = useState("");
  const [creditAlloted, setreditAlloted] = useState("");
  const [ratingId, setRatingId] = useState("");
  const [commission, setCommission] = useState("");
  const [radioselect, setRadioselect] = useState("");
  const [promTopUpList, setPromTopUpList] = useState([]);
  const [promTopUpDesc, setPromTopUpDesc] = useState([]);
  const [promGeoLocId, setPromGeoLocId] = useState("");
  const [mapCity, setMapCity] = useState("");
  const [mapCounty, setMapCounty] = useState("");
  const [mapProvince, setMapProvince] = useState("");
  const [mapAddrChngeFlg, setMapAddrChngeFlg] = useState("");
  const [province, setProvince] = useState("");
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [addressStr, setAddressStr] = useState("");
  const [bankReferenceNum, setBankReferenceNum] = useState("");
  const [billingSysUserName, setBillingSysUserName] = useState("");
  const [parentLaternalFlagVal, setParentLaternalFlagVal] = useState(
    ''
  );
  const [parentMultiLevlFlagVal, setParentMultiLevlFlagVal] = useState(
    ''
  );
  const [parentMultiLevlRecFlagVal, setParentMultiLevlRecFlagVal] = useState(
    ''
  );
  const [parentIsSingleSrcFlagVal, setParentIsSingleSrcFlagVal] = useState(
   ''
  );



  const [creditThreshold, setCreditThreshold] = useState("");
  const [parentActiveCurrencyPrecision, setParentActiveCurrencyPrecision] =
    useState(exampleData.activeCurrencyPrecision);
  const [addDistNChannel, setAddDistNChannel] = useState("");
  const [billingCycleId, setBillingCycleId] = useState("");
  const [locationValStr, setLocationValStr] = useState("");
  const [parentEmailId, setParentEmailId] = useState(
    exampleData.LOGIN_USER_EMAIL_ID
  );
  const [eventIDAl, setEventIDAl] = useState([]);
  const [otherDistributionListAl, setOtherDistributionListAl] = useState([]);
  const [childAlertSubscriptionAl, setChildAlertSubscriptionAl] = useState([]);
  const [selfAlertAl, setSelfAlertAl] = useState([]);
  const [deliveryMethodAl, setDeliveryMethodAl] = useState([]);
  const [statusAl, setStatusAl] = useState([]);
  const [jobFlag, setJobFlag] = useState("");
  const [jobFlagAL, setJobFlagAL] = useState([]);
  const [denomTypeAL, setdenomTypeAL] = useState([]);
  const [denomIdAL, setDenomIdAL] = useState([]);

  const [selectedGeographicalLoc, setSelectedGeographicalLoc] = useState("");
  const [selectedGeographicalObj, setSelectedGeographicalLocObj] = useState({});
  const [mapInAdd, setMapInAdd] = useState("");
  const [channelsSelectFlag, setChannelsSelectFlag] = useState(false);
  const [notificationObj, setNotificationObj] = useState([]);
  const [preview, setPreview] = useState(false);
  const [notifSub, setNotifSub] = useState(false);
  const [denomFlag, setDenomFlag] = useState(true);
  const [channelList, setChannelList] = useState("");
  const [channelDesp, setChannelDesp] = useState("");
  const [LocationId, setLocationId] = useState("");
  const [eventId, setEventId] = useState("");
  const [deliveryMethod, setDeliveryMethod] = useState("");
  const [toastShown, setToastShown] = useState(false);
  const [otherDistributionList, setOtherDistributionList] = useState("");
  const [selfAlert, setSelfAlert] = useState("");
  const [childAlertSubsctiption, setChildAlertSubsctiption] = useState("");
  const [serachByStatus, setSerachByStatus] = useState("");
  const [notificationRequest, setNotificationRequest] = useState("");
  const [channel, setChannel] = useState("");
  const [postalcheck,setPostalCheck] = useState('');
  const [errorMsg,setErrorMsg] = useState('');
  const [channels,setChannels] = useState('');

  const [addrComprisionChk, setAddrComprisionChk] = useState("");
  const [geoReferencingMapValue, setGeoReferencingMapValue] = useState("");

  const previewRef = useRef(null);
  useEffect(() => {
      if (preview) {
        // Scroll the entire page to the top
        window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [preview]);
//added for userType Selection
useEffect(() => {
  const fetchUsers = async() => {
    localStorage.removeItem('channels');
    localStorage.getItem('salesData');
  try {
    const apiUrl5 = window.config.apiUrl + process.env.REACT_APP_GET_USER_TYPES;
    console.log(apiUrl5);
    const response5 = await axios.post(apiUrl5, {
      userName,
      password,
      partnerId: partnerParentId,
      localeVar
    })
    setUsertypes(response5.data.userTypes);
    setBankRefernceNumber(response5.data.parentBankRefId);
    setParentBSUserName(response5.data.parentBSUserName);
    console.log("usertypes", usertypes);
    console.log("bankRefernceNumber", bankRefernceNumber);
    console.log("parentBSUserName", parentBSUserName);

    
    setIsPasswordHide(response5.data.isPasswordHide)
    setPartnerCompanyName(exampleData.COMPANY_NAME);
    setTransferFlag(response5.data.transferFlag)
    setTransferFlagStatus(response5.data.transferFlagStatus)
    setFlagPmconfigstatusDist(response5.data.flagPmconfigstatusDist)
    setFlagPmconfigstatusSales(response5.data.flagPmconfigstatusSales)
    setFlagPmconfigstatusSingle(response5.data.flagPmconfigstatusSingle)
    setFlagPmconfigstatusMulti(response5.data.flagPmconfigstatusMulti)
    setFlagPmConfigStatusMultiTrans(response5.data.flagPmConfigStatusMultiTrans)
    setFlagPmconfigstatus_RechargeRev(response5.data.flagPmconfigstatus_RechargeRev)
    setFlagPmconfigstatus_TransferRev(response5.data.flagPmconfigstatus_TransferRev)
    setPostToSCLEnableFlag(response5.data.postToSCLEnableFlag)
    setUssdPwdEnabled(response5.data.ussdPwdEnabled)
    setSimEnabled(response5.data.simEnabled)
    setSimEnabled(response5.data.simEnabled)
    setHierarchyStatus(response5.data.hierarchyStatus)
    if(!response5.data.flagPmconfigstatus_RechargeRev){
      setIsRechargeReversal('Y')
    }
    if(!response5.data.flagPmconfigstatus_TransferRev){
      setIsTransferReversal('Y')
    }

    setParentLaternalFlagVal(exampleData.LATERAL_FLAG_VAL)
    setParentMultiLevlFlagVal(exampleData.MULTI_LEVEL_RECIEVER_FLAG_VAL)
    setParentMultiLevlRecFlagVal(exampleData.MULTI_LEVEL_RECIEVER_FLG_VALUE)
    setParentIsSingleSrcFlagVal(exampleData.SINGLE_FUND_SOURCE_FLAG_VAL)
  
    
    console.log("usertypes", JSON.stringify(response5.data));
    console.log("user dattta", usertypes);
    console.log("bankRefernceNumber", bankRefernceNumber);
    console.log("parentBSUserName", parentBSUserName);
 
}
    catch (error) {
      console.error('Error fetching the IP address', error);
    }
  }


  fetchUsers();

}, [])

useEffect(() => {

  // Set the browser title

  document.title = t('2472_017');

}, []);
useEffect(()=>{
  const fetchChannels=async () => {
     //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
     const apiUrl3 = window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
     console.log(apiUrl3);
     const response3 = await axios.post(apiUrl3, {
       userName,
       password,
       localeVar,
       channelTransAl: "",
     });
     // const[channels]=response.data;
 
     localStorage.setItem("channels", JSON.stringify(response3.data.channels));
     //console.log(JSON.stringify(response.data.channels));
     //  setsalesData(JSON.stringify(response.data.channels));
   }
   fetchChannels();
   //fetdenominatons();
 },
   []
 );



  const toastId = useRef(null);
  const handleUseOwnFundsChange = (event) => {
    setUseOwnFunds(event.target.value);
  };

  const setChannelsAssociation = (obj, checkFlag) => {
    console.log("objjj====", obj);
    console.log("chekflag====", checkFlag);

    setChannelsSelectFlag(checkFlag);
    setChannelTransAl(obj);
    if (checkFlag)
       setAddDistNChannel("channel");
      else
      setAddDistNChannel("");

    if (obj.length > 0) {

      setChannelList(obj.map((channel) => channel.topUpId).join("_-_"));
      setChannelDesp(obj.map((channel) => channel.topupTypeDesc).join("_-_"));
      let channels="_-_"+channelList;
      setPromTopUpList(channels);
    }
    console.log("Channel List: " + channels);
  };

  const setnotificationListObj = (notificationobj, notif) => {
    // alert(t("2616023"));
    console.log("notificationobj==========", notificationobj);

    console.log("notificationobj==========", notificationobj);

    const eventIdArray = notificationobj.map((item) => item.eventId);
    const deliveryMethodArray = notificationobj.map(
      (item) => item.deliveryMethod
    );
    const selfAlertArray = notificationobj.map((item) =>
      item.selfAlert ? "Y" : "N"
    );
    const otherDistributionListArray = notificationobj.map(
      (item) => item.otherDistributionList
    );
    const childAlertSubscriptionArray = notificationobj.map(
      (item) => item.childAlertSubscription
    );
    const statusArray = notificationobj.map((item) => item.status);

    console.log("Event IDs:", eventIdArray);
    console.log("Delivery Methods:", deliveryMethodArray);
    console.log("Self Alerts:", selfAlertArray);
    console.log("Other Distribution Lists:", otherDistributionListArray);
    console.log("Child Alert Subscriptions:", childAlertSubscriptionArray);
    console.log("Statuses:", statusArray);

    console.log("Event IDs:", eventIdArray);
    console.log("Delivery Methods:", deliveryMethodArray);
    console.log("Self Alerts:", selfAlertArray);
    console.log("Other Distribution Lists:", otherDistributionListArray);
    console.log("Child Alert Subscriptions:", childAlertSubscriptionArray);
    console.log("Statuses:", statusArray);

    setNotificationObj(notificationobj);
    setNotifSub(notif);

    setEventIDAl(eventIdArray);
    setOtherDistributionListAl(otherDistributionListArray);
    setChildAlertSubscriptionAl(childAlertSubscriptionArray);
    setSelfAlertAl(selfAlertArray);
    setDeliveryMethodAl(deliveryMethodArray);
    setStatusAl(statusArray);
    if (notif) setJobFlag("I");
  };

  const handleSelectedGeographicalLoc = (obj, loc, mapIn, locId) => {
    setLocationArray(loc.split('-->'));
    setSelectedGeographicalLoc(loc);
    setLocationVal(loc);
    setSelectedGeographicalLocObj(obj);
    setMapInAdd(mapIn);
    setLocationId(locId + "_-_");
    setPostalCheck(obj.zipCodeString);
  };

  const setMapAddress = (address, long, lati, postal) => {
    setContaddress1(address);
    setLatitude(lati);
    setLongitude(long);
    setContzipcode(postal);
  };

  const [selectedAddress, setSelectedAddress] = useState("");

  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

  const { t } = useTranslation();
  const labelsArray = [
    t('251610'),
    t('251611'),
    t('251612'),
    t('251613'),
    t('251650')
  ];
  const maxMDNLength = 10; // process.env.SUB_NUMBER_LENGTH;
  const geoReferencingEnable = "YES"; // process.env.georeferencing.feature.enabled;
  const num_bag = "0123456789";
  console.log("geoReferencingEnable-->" + geoReferencingEnable);
  var flg = true;

  const notescheckCount = (event, maxLimit) => {
    const value = event.target.value;
    if (value.length > maxLimit) {
      // Truncate the value to maxLimit
      event.target.value = value.substring(0, maxLimit);
      setContaddress1(event.target.value); // Update state with truncated value
    }
  };

  const chunkedData = channelTransAl.reduce((resultArray, item, index) => {
    const chunkIndex = Math.floor(index / 4);

    if (!resultArray[chunkIndex]) {
      resultArray[chunkIndex] = []; // start a new chunk
    }

    resultArray[chunkIndex].push(item);

    return resultArray;
  }, []);

  const chunkedDataPreview = channelTransAl.reduce(
    (resultArray, item, index) => {
      const chunkIndex = Math.floor(index / 2);

      if (!resultArray[chunkIndex]) {
        resultArray[chunkIndex] = []; // start a new chunk
      }

      resultArray[chunkIndex].push(item);

      return resultArray;
    },
    []
  );

  const handleClear = () => {

    setPartnerIdentity("");

    setSalesMdn("");

    //setPartnerId("");

    setPartnerCompanyName(exampleData.COMPANY_NAME);

    setChildPartnerType("13");

    setRucNo("");

    setSclCode(exampleData.SCL_CLIENT_CODE);

    setPaymentType("1");

    setMaxFundLimit("0.00");

    setPartnerContactFirstName("");

    setPartnerContactLastName("");

    setLocationVal("");

    setContaddress1("");

    setLatitude("");

    setLongitude("");

    setContzipcode("");

    setAddresschecking("");

    setBilladdress1("");

    setBillzipcode("");

    setEmailID("");

    setAccountBal("0.00");

    setAcctBalThresold("0.00");

    setStatus("Y");

    //setCurrency("MXN-Peso Mexicano");

    setIsLateralEnabled("N");

    //setIsSingleSrcEnabled("");

    setIsSingleSrcEnabled(sfsCheck=='N'?t('N'):t('Y'));

    setIsMultiLevlEnabled("N");

    setIsMultiLevlRecEnabled("N");

    setIsMultiLevelTransferEnabled("N");

    setIsMultiLevelReceiveEnabled("N");

    setIsRechargeReversal("");

    setIsTransferReversal("");

    setPromTopUpListChk("");

    setSelectedChannelsArr([]);

    setNegativeTransfers("N");

    setSalesForceStatus("N");

    setSimTransferStatus("N");

    setPartnerSimThreshold("");

    setGLedgerCode("");

    setIsChecked(false);

    document.forms[0].partnerIdentity.focus();

    setSelectedGeographicalLoc("");

    setChannelTransAl([]);

    setChannelsSelectFlag(false);

    setClear(true);

   setChannelList('')
    setAddDistNChannel('')
  };



  /*
 
  function googleMapGeoLocValidation()
  {
    if(document.forms[0].postalCode.value!=document.forms[0].contzipcode.value)
    {
      alert("<bean:message bundle="tb" key="6462" />");
      return 0;
    }
  }
    */

  const exceptComma = (e) => {
    if (e.key === ",") {
      e.preventDefault();
    }
  };

  const handlePreview = () => {
   
  };

  const FinalSubmitSubmit = async () => {
    setIsSingleSrcEnabled(sfsCheck=='N'?t('N'):t('Y'));
   // alert("hii");
    setIsProcessing(true);
    setRemoteAddress(exampleData.remoteAddress);
    const apiUrl1 = window.config.apiUrl + process.env.REACT_APP_ADD_PARTNER;
    console.log("API URL=="+apiUrl1);
    const response1 = await axios.post(apiUrl1, {
      userName,
      password,
      localeVar,
      status,
      partnerParentId: partnerParentId,
      partnerIdentity,
      rucNo,
      ivrTransNo,
      maxFundLimit,
      partnerType: "6",
      loginPartnerCompanyName,
      partnerCompanyName: partnerCompanyName,
      partnerContactFirstName,
      partnerContactLastName,
      partnerPassword: "",
      confirmPassword: "",
      ussdPartnerPassword: "",
      ussdConfirmPassword: "",
      paymentType,
      location,
      childPartDescp,
      parentSclCode, //parent scl code
      negativeTransfers,
      distRatings,
      parentsclUserName:parentSclUserName,
      creditLmt,
      creditAlloted,
      ratingId,
      commission,
      accountBal,
      gLedgerCode,
      radioselect,
      promTopUpList: channelList,
      promTopUpDesc: channelDesp,
      isLateralEnabled,
      isMultiLevlEnabled,
      isMultiLevlRecEnabled,
      eventId,
      deliveryMethod,
      otherDistributionList,
      selfAlert,
      childAlertSubsctiption,
      serachByStatus,
      isMultiLevelTransferEnabled,
      isMultiLevelReceiveEnabled,
      isRechargeReversal,
      isTransferReversal,
      isSingleSrcEnabled:parentIsSingleSrcFlagVal,
      promGeoLocId,
      billaddress1,
      contaddress1,
      billzipcode,
      contzipcode,
      addresschecking,
      notificationRequest,
      parentLaternalFlagVal,
      parentMultiLevlFlagVal,
      parentMultiLevlRecFlagVal,
      parentIsSingleSrcFlagVal,
      latitude,
      longitude,
      mapCity,
      mapCounty,
      mapProvince,
      mapAddrChngeFlg,
      province,
      city,
      postalCode,
      addressStr,
      creditThreshold,
      acctBalThresold,
      activeCurrencyPrecision,
      addDistNChannel,
      emailID,
      billingCycleId,
      channel,
      locationValStr: locationVal,
      promGeoLocId: LocationId,
      parentEmailId,
      notifSub,
      eventIDAl,
      otherDistributionListAl,
      childAlertSubscriptionAl,
      selfAlertAl,
      deliveryMethodAl,
      statusAl,
      jobFlag,
      jobFlagAL,
      denomTypeAL,
      denomIdAL,
      salesForceStatus,
      simTransferStatus,
      partnerSimThreshold,
      promTopUpListChk,
      remoteAddress,
      bankReferenceNum,
      billingSysUserName,
      parentsclCode:parentSclCode,
      isCredit,
      denomFlag,
      salesMdn,
      childPartnerType,
      radioselect:sfsCheck=='Y'?'N':useOwnFunds
    });
    console.log("Final Api Response===" + JSON.stringify(response1.data));
    if (response1.data.responseCode === "00") {
      localStorage.removeItem('channels');
     // localStorage.removeItem('denominations');
      setIsProcessing(false);
      let distId = partnerIdentity;
      navigate("/profile", { state: { distId } });
    }
    else{
      setErrorMsg(response1.data.responseDescription);
      setErrorMessage(response1.data.errorMsg);
  setErrorPartnerIdentity(partnerIdentity);
      setIsProcessing(false);
  setPreview(false);
     }
  };

  const onlyNumberValidate = (e) => {
    // Allow only numeric keys, backspace, delete, tab, arrow keys, and enter key
    const allowedKeys = [
      "Backspace",
      "Tab",
      "ArrowLeft",
      "ArrowRight",
      "ArrowUp",
      "ArrowDown",
      "Delete",
      "Enter",
      "Home",
      "End",
    ];
    if (allowedKeys.indexOf(e.key) !== -1) {
      return; // Allow the keypress
    }
    // Prevent non-numeric key presses
    if (!/^\d$/.test(e.key)) {
      e.preventDefault();
    }
  };

  const numvalidate = (e) => {
    const allowedKeys = [
      "Backspace",
      "ArrowLeft",
      "ArrowRight",
      "Tab",
      "Delete",
      "Enter",
      ".",
    ];
    const isNumberKey = (key) => /^[0-9]$/.test(key);
    const isDotKey = (key) => key === ".";
    const isControlKey = (e) => e.ctrlKey || e.metaKey;

    if (isControlKey(e)) return; // Allow ctrl+key combinations like ctrl+v

    if (allowedKeys.includes(e.key) || isNumberKey(e.key)) {
      // Allow numeric keys and the dot key
      return;
    } else {
      e.preventDefault(); // Prevent other keys
    }
  };

  function onlyAlphaNumericValidate(event) {
    // Allow only alphanumeric characters, Enter, and Backspace key
    const allowedKeys = /^[a-zA-Z0-9]$/;
    const isAlphanumeric = allowedKeys.test(event.key);
    const isEnterKey = event.key === "Enter";
    const isBackspaceKey = event.key === "Backspace";

    if (!isAlphanumeric && !isEnterKey && !isBackspaceKey) {
      event.preventDefault(); // Prevent the key press if it's not allowed
    }
  }

  function decimalRound(input, pre) {
    var number = 1;
    var output = "";

    number = Math.pow(10, pre);
    output = Math.round(parseFloat(input) * number) / number;

    return output;
  }

  function formatDecimal(argvalue, addzero, decimaln) {
    const numOfDecimal = decimaln == null ? 2 : decimaln;

    if (argvalue.indexOf(".") !== -1)
      argvalue = decimalRound(argvalue, decimaln);

    argvalue = "" + argvalue;

    if (argvalue.indexOf(".") === 0) argvalue = "0" + argvalue;

    if (addzero === true) {
      if (argvalue.indexOf(".") === -1 && decimaln !== 0)
        argvalue = argvalue + ".";

      while (argvalue.indexOf(".") + 1 > argvalue.length - numOfDecimal)
        argvalue = argvalue + "0";
    }
    return argvalue;
  }

  function removeCharContains(amount, charToBeRemove) {
    let tempAmount = "";
    for (let index = 0; index < amount.length; index++) {
      const c = amount.charAt(index);
      if (c !== charToBeRemove) {
        tempAmount += c;
      }
    }
    return tempAmount;
  }

  function isCharsInBagValid(s, bag) {
    for (let i = 0; i < s.length; i++) {
      const c = s.charAt(i);
      if (bag.indexOf(c) === -1) return 0;
    }
    return 1;
  }

  function setCommas(stringAmt) {
    let tempAmt = stringAmt;
    let commaAmt = tempAmt.substring(tempAmt.length - 3, tempAmt.length);

    let commaIndex = 3;
    for (let index = tempAmt.length - 4; index >= 0; index--) {
      const c = tempAmt.charAt(index);

      if (commaIndex === 3 && c !== "-") {
        commaAmt = c + "," + commaAmt;
        commaIndex = 1;
      } else {
        commaAmt = c + commaAmt;
        commaIndex++;
      }
    }

    if (commaAmt.charAt(0) === ",") {
      commaAmt = commaAmt.substring(1, commaAmt.length);
    }

    return commaAmt;
  }

  const handleBlur = (value, setValue) => {
    if (!amountValidation(value, setValue, 17, activeCurrencyPrecision)) {

      if (!toast.isActive(toastId.current))
        {    
          toastId.current = toast.error("Validation error");  
       }
    }
  };

  const amountValidation = (amount, setAmount, maxIntPart, maxDeciPart) => {
    if (amount == null || amount.length <= 0) {
      setAmount(formatDecimal("0", true, maxDeciPart));
      return true;
    } else if (isNaN(removeCharContains(amount, ","))) {
      setAmount(formatDecimal("0", true, maxDeciPart));
      return true;
    } else if (isCharsInBagValid(amount, " ") === 1) {
      setAmount("");
      // If you need to focus the input, you'll need to handle this separately in React
      return false;
    } else if (isCharsInBagValid(amount, "-0123456789 .,") === 0) {
      setAmount("");
      // If you need to focus the input, you'll need to handle this separately in React
      return false;
    } else if (!isCharsInBagValid(amount, "0.") === 0) {
      setAmount(formatDecimal("0", true, maxDeciPart));
      return true;
    } else {
      let tempAmount = "";
      let retAmt = "";

      tempAmount = removeCharContains(amount, ",");
      tempAmount = removeCharContains(tempAmount, " ");

      retAmt = formatDecimal(tempAmount, true, maxDeciPart);
      retAmt = retAmt + "";

      let inclValue;
      let decmlValue;
      let indexxx = retAmt.indexOf(".");
      if (indexxx !== -1) {
        inclValue = retAmt.substring(0, indexxx);
        decmlValue = retAmt.substring(indexxx + 1, retAmt.length);

        inclValue = setCommas(inclValue);

        setAmount(inclValue + "." + decmlValue);
      } else {
        inclValue = setCommas(retAmt);
        setAmount(inclValue);
      }

      return true;
    }
  };

  const handleCheckboxChange = (event) => {
    setIsChecked(event.target.checked);
    if (event.target.checked) {
      setBilladdress1(contaddress1);
      setBillzipcode(contzipcode);
    } else {
      setBilladdress1("");
      setBillzipcode("");
    }
  };

   //i need to map values related to the map values in This
   const geo=()=>
    {
      var mapAddrModifyChk =addrComprisionChk;
       if('YES'==trim(geoReferencingEnable).toUpperCase()&& 'YES'==trim(mapAddrModifyChk).toUpperCase())
        {	
          var mapCounty=document.forms[0].mapCounty.value==null?"":document.forms[0].mapCounty.value;
  
          if('YES'==trim(document.forms[0].mapAddrChngeFlg.value).toUpperCase())
          {
              //if((document.forms[0].mapCity.value==null || document.forms[0].mapCity.value.length == 0) && (document.forms[0].mapCounty.value==null || document.forms[0].mapCounty.value.length == 0) )
              if(document.forms[0].mapCity.value==null || document.forms[0].mapCity.value.length == 0) 
              {
                if((document.forms[0].mapProvince.value==null || document.forms[0].mapProvince.value.length == 0) && (document.forms[0].mapCounty.value==null || document.forms[0].mapCounty.value.length == 0))
                {

                  if (!toast.isActive(toastId.current))
                    {    
                      toastId.current =toast.error(t("24246619"));//alert("<bean:message bundle="tb" key="6619" />"); 
                   }
                  
                  return 0;
                }
                else
                {
                  if (!toast.isActive(toastId.current))
                    {    
                      toastId.current = toast.error(t("24246605"));
                  //alert("<bean:message bundle="tb" key="6605" />");
                   }
                 
                  return 0;
                }
              }
              else if(document.forms[0].mapProvince.value==null || document.forms[0].mapProvince.value.length == 0)
              {
               // toast.error(t("24246625"));
                //alert("<bean:message bundle="tb" key="6625" />");							
                if (!toast.isActive(toastId.current))
                  {    
                    toastId.current =toast.error(t("24246625"));
                    //alert("<bean:message bundle="tb" key="6605" />");
                 }						
                return 0;
              }
              else if(compareGeoStrings(document.forms[0].province.value,document.forms[0].mapProvince.value))
              {
                if(compareGeoStrings(document.forms[0].city.value,document.forms[0].mapCity.value))
                {
                  if (!toast.isActive(toastId.current))
                    {    
                      toastId.current =toast.error(t("24246620"));
                      //alert("<bean:message bundle="tb" key="6605" />");
                   }
                  //toast.error(t("24246620"));
                  //alert("<bean:message bundle="tb" key="6620" />");								
                  return 0;
                }
                else
                {
                  if (!toast.isActive(toastId.current))
                    {    
                      toastId.current =toast.error(t("24246622"));
                      //alert("<bean:message bundle="tb" key="6605" />");
                   }
                  //toast.error(t("24246622"));
                  //alert("<bean:message bundle="tb" key="6622" />");								
                  return 0;
                }
              }
              else if(compareGeoStrings(document.forms[0].city.value,document.forms[0].mapCity.value))
              {
                if (!toast.isActive(toastId.current))
                  {    
                    toastId.current =toast.error(t("24246621"));
                    //alert("<bean:message bundle="tb" key="6605" />");
                 }
                //toast.error(t("24246621"));
                //alert("<bean:message bundle="tb" key="6621" />");
                return 0;
              }					
              else 
                return 1;
          }
          else
            return 1;
        }
       else
          return 1;
    }

  /*
	function compareGeoStrings(loc1,loc2)
	{
		//var cBag='ABCDEFGHIJKLMNOPQRSTUVWXYZ'+'abcdefghijklmnopqrstuvwxyz'+' 0123456789';//here space also necissary for string comparisons
		//var cityHypenChk ='<bean:message bundle="pb" key="geo.cityPattern.hypenChk" />';
		loc1=trim(loc1.toUpperCase())+",";
		loc2=trim(loc2.toUpperCase())+",";
		//alert("loc1-->"+loc1+"\nloc2-->"+loc2);
	    var checkFlag = false;
	   /* var patt=/-/g;
	    if('Y'==trim(cityHypenChk).toUpperCase())
		{	
			if(patt.test(loc2))
			{
				if(loc2.indexOf(loc1)==-1)
					checkFlag=true;

				return checkFlag;
			}
		}
	if(loc1.length == loc2.length)
	 {
		for(i=0;i<loc1.length;i++)
		{
			if(cBag.indexOf(loc1.charAt(i)) == -1 || cBag.indexOf(loc2.charAt(i)) == -1 )
			{
				continue;

			}
			if(loc1.charAt(i) != loc2.charAt(i))
			{
				checkFlag=true;
				break;
			}
		}
	 }
	 else
	    checkFlag=true;*/
  /*    if(loc1.indexOf(loc2)==-1)
        checkFlag=true;
        
      return checkFlag;
    }
*/

function compareGeoStrings(loc1,loc2)
{
  
  loc1=trim(loc1.toUpperCase())+",";
  loc2=trim(loc2.toUpperCase())+",";
  
    var checkFlag = false;
  
    if(loc1.indexOf(loc2)==-1)
    checkFlag=true;
    
  return checkFlag;
}


function googleMapGeoLocValidation() {
  //alert("=====postalcheck==== "+postalcheck+"========contzipcode======"+contzipcode+"==============")
  if (postalcheck !== contzipcode) {
    if (!toastShown) {
      setToastShown(true);
      toast.error(t("24246462"), {
          onClose: () => setToastShown(false)
      });
  }
    // alert(t("24246462"));
      return 0;
    }
      return 1;
  }
    

  // It Romoves White spaces at both ends of a given String
  function trim(value) {
    //alert("value-->"+value)
    var len = value.length;

    var i = 0;

    //Removes White spaces at Front end of the string

    for (i = 0; i < len; i++) {
      var c = value.charAt(i);

      if (c === " ") {
        value = value.substring(i + 1, len);

        i--;
      } else break;
    }

    var len2 = value.length;

    //Removes White spaces at Rear end of the string

    for (i = len2 - 1; i >= 0; i--) {
      var c2 = value.charAt(i);

      if (value.charAt(i) === " ") {
        value = value.substring(0, i);
      } else break;
    }
    return value;
  }

  function isCharsInBag(s, bag) {
    var i;
    var c = "";

    for (i = 0; i < s.length; i++) {
      c = s.charAt(i);
      if (bag.indexOf(c) === -1) return 0;
    }
    return 1;
  }

  function verifyPartnerFields() {
    var creditAlloted = "";
    var creditLmt = "";
    var bag = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-' ";
    var id_bag =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_ .0123456789-";
    var pname_bag =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789.$_*@�";

    var partnerType = "6"; //document.forms[0].partnerType.value;

    if (partnerType === "6") partnerType = "Salesperson";
    else partnerType = "Distributor";

    /*   var profId = '';
	var isPaaswordRuleAplicable = false;
	var profileTypeId = document.forms[0].profileType.value;

	if(profileTypeId != null)
	{
		profidsArryList = profileTypeId.split(',');

		profId = profidsArryList[0];

		if(profileIdsList != null )
		{
				for(var i=0;i<profileIdsList.length; i++)
				{
					if(profileIdsList[i] == profId)
					{
						isPaaswordRuleAplicable=true;
						//document.forms[0].arePasswordRulesApplicable.value=true;

					}

				}
		}
	}*/

    /*
  if(document.forms[0].creditAlloted!=null)
		var creditAlloted = document.forms[0].creditAlloted.value;
	creditAlloted = removeCharContains(creditAlloted, ",");
  */

    const trimmedCompanyName = trim(partnerCompanyName);
    const trimmedPartnerContactFirstName = trim(partnerContactFirstName);
    const trimmedPartnerContactLastName = trim(partnerContactLastName);

    if (partnerIdentity.length === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251684"));
       }
     // toast.error(t("251684"));
      document.forms[0].partnerIdentity.focus();
      return false;
    } else if (isCharsInBag(partnerIdentity, id_bag) === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251685"));
       }
      //toast.error(t("251685"));
      document.forms[0].partnerIdentity.focus();
      return false;
    } else if (
      partnerCompanyName !== null &&
      partnerCompanyName.type === "text" &&
      partnerCompanyName.length === 0
    ) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251686"));
       }
      //toast.error(t("251686"));
      document.forms[0].partnerCompanyName.focus();
      return false;
    } else if (
      partnerCompanyName !== null &&
      partnerCompanyName.type === "text" &&
      trimmedCompanyName.length === 0
    ) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251687"));
       }
      //toast.error(t("251687"));
      document.forms[0].partnerCompanyName.value = "";
      document.forms[0].partnerCompanyName.focus();
      return false;
    } else if (partnerContactFirstName.length === 0) {
      /* this code comments in codebase also-->start
      else
     if(document.forms[0].partnerCompanyName!= null && document.forms[0].partnerCompanyName.type == 'text' )
		{
			alert("Please enter valid "+partnerType+" company name.");

			document.forms[0].partnerCompanyName.focus();
			return false;

		}
     else
	 if(document.forms[0].rucNo.value.length == 0)
	{ 
		alert("Please enter the RUC Number.");
		document.forms[0].rucNo.focus();
		return false;
	}
    else
	if(isCharsInBag(document.forms[0].partnerContactFirstName.value,pname_bag)==0)
	{
		alert("Please enter a valid "+partnerType+" First Name");
		document.forms[0].partnerContactFirstName.focus();
		return false;
	}
    else
	if(isCharsInBag(document.forms[0].partnerContactLastName.value,pname_bag)==0)
	{
		alert("Please enter a valid "+partnerType+" Last Name");
		document.forms[0].partnerContactLastName.focus();
		return false;
	}this code comments in codebase also--->end
    */
      toast.error(t("251688"));
      document.forms[0].partnerContactFirstName.focus();
      return false;
    } else if (trimmedPartnerContactFirstName.length === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251689"));
       }
      //toast.error(t("251689"));
      document.forms[0].partnerContactFirstName.focus();
      //document.forms[0].partnerContactFirstName.value="";
      return false;
    } else if (partnerContactLastName.length === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251690"));
       }
     // toast.error(t("251690"));
      document.forms[0].partnerContactLastName.focus();
      return false;
    } else if (trimmedPartnerContactLastName.length === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251691"));
       }
      //toast.error(t("251691"));
      document.forms[0].partnerContactLastName.focus();
      document.forms[0].partnerContactLastName.value = "";
      return false;
    } else if (checkingMail() === 0) {
      /*
  else
	if(document.forms[0].partnerPassword.value.length < 1)
	{
		alert("Please enter password");
		document.forms[0].partnerPassword.focus();
		return false;
	}
	else
	if(document.forms[0].confirmPassword.value.length < 1)
	{
		alert("Please reenter password.");
		document.forms[0].confirmPassword.focus();
		return false;
	}
	else
	if(document.forms[0].partnerPassword.value != document.forms[0].confirmPassword.value)
	{
		alert("Password and confirmed password must be same.");
		document.forms[0].confirmPassword.focus();
		return false;
	}
	else if(isPaaswordRuleAplicable==true && verifyPwdRules(document.forms[0].partnerPassword) == false){
		return;
	}
    */
      return false;
    }    else if (rucNo.trim().length < 1) {

      if (!toastShown) {

        setToastShown(true);

        toast.error(t("251696"), {

            onClose: () => setToastShown(false) // Reset the state when the toast closes

        });

    }

      document.forms[0].rucNo.focus();

      return false;

    }

  else return true;
    /*
  else
	if(document.forms[0].creditAlloted!=null && document.forms[0].creditAlloted.type == 'text' && document.forms[0].creditAlloted.value.length == 0)
	{
		alert("Please enter Credit Allocation Amount.");
		document.forms[0].creditAlloted.focus();
		return false;
	}
    */
  }

  function checkingMail() {
    var mail = emailID;

    if (emailID === null || emailID.trim() === "") {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251683"));
       }
      //toast.error(t("251683"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (
      isCharsInBag(
        mail,
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789@.,-"
      ) === 0
    ) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
      //toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.indexOf("@") === -1) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
     // toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.lastIndexOf("@") > mail.lastIndexOf(".") + 1) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
     // toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.lastIndexOf("@") !== mail.indexOf("@")) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
     // toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.indexOf(".") === -1) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
     // toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.lastIndexOf(".") === mail.length - 1) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
     // toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (mail.indexOf("@") === mail.length - 1) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
     // toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (
      mail.indexOf("@") === mail.indexOf(".") - 1 ||
      mail.indexOf(".") === mail.indexOf("@") - 1
    ) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
      //toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else if (
      mail.indexOf("@") === 0 ||
      mail.indexOf(".") === 0 ||
      mail.indexOf(" ") > 0
    ) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251674"));
       }
     // toast.error(t("251674"));
      document.forms[0].emailID.focus();
      return 0;
    } else {
      return 1;
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    if (partnerIdentity.trim() === "") {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251684"));
       }
    //  toast.error(t("251684"));
      document.forms[0].partnerIdentity.focus();
      flg = false;
    } else if (salesMdn !== null && isCharsInBag(salesMdn, num_bag) === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251666"));
       }
     // toast.error(t("251666"));
      document.forms[0].salesMdn.focus();
      flg = false;
    } else if (
      salesMdn.length > 0 &&
      salesMdn !== null &&
      salesMdn.length < maxMDNLength
    ) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =toast.error(t("251665") +" "+ maxMDNLength);
       }
     // toast.error(t("251665") + maxMDNLength);
      document.forms[0].salesMdn.focus();
      flg = false;
    }
    // else if(rucNo.trim() === ""){
    //   if (!toast.isActive(toastId.current)) {
    //     toastId.current = toast.error(t("1252"));

    //   }
    //   //  toast.error(t("251666"));
    //   document.forms[0].rucNo.focus();
    //   flg = false;
    // }
    else  if(LocationId.length === 0)
      {
        if (!toast.isActive(toastId.current))
          {    
            toastId.current =toast.error(t("24246078"));
         }
        //toast.error(t('24246078'));
        flg = false;
      }
      // else if(addDistNChannel!='channel'){
      // if(channelTransAl.length<=0)
      // else if(addDistNChannel!='channel'){

        else if(channelTransAl.length<=0)
        {
          if (!toast.isActive(toastId.current))
            {    
              toastId.current =toast.error(t('24246079'));
           }
         // toast.error(t('24246079'));
         // document.forms[0].promTopUpListChk.focus();
         flg = false;
        }
      // }
    else if (sclCode !== null && isCharsInBag(sclCode, num_bag) === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current = toast.error(t("251666"));
       }
     // toast.error(t("251666"));
      document.forms[0].sclCode.focus();
      flg = false;
    } else if (contaddress1.length === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current = toast.error(t("251667"));
       }
      // toast.error(t("251667"));
      document.forms[0].contaddress1.focus();
      flg = false;
    } else if (
      geoReferencingEnable === "YES" &&
      (latitude.length === 0 || longitude.length === 0)
    ) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =  toast.error(t("251668"));
       }
     // toast.error(t("251668"));
      document.forms[0].latitude.focus();
      flg = false;
    } else if (contzipcode.length === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current = toast.error(t("251669"));
       }
      //toast.error(t("251669"));
      document.forms[0].contzipcode.focus();
      flg = false;
    } else if (billaddress1.length === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current = toast.error(t("251670"));
       }
      // toast.error(t("251670"));
      document.forms[0].billaddress1.focus();
      flg = false;
    } else if (billzipcode.length === 0) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current = toast.error(t("251671"));
       }
      // toast.error(t("251671"));
      document.forms[0].billzipcode.focus();
      flg = false;
    } else if (billaddress1 !== contaddress1 || billzipcode !== contzipcode) {
      if (!toast.isActive(toastId.current))
        {    
          toastId.current =  toast.error(t("251672"));
       }
      // toast.error(t("251672"));
      setIsChecked(false);
      flg = false;
    } else if (checkingMail() === 0) {
      return false;
    }

    /*
  		else if((geoReferencingMapValue == 'NMAPS' || geoReferencingMapValue == 'LOCATIONWORLD' )&& geo()==0)		
		{	
				
					flg= false;
		}
		else if( geoReferencingEnable=='YES' && geoReferencingMapValue=='GOOGLEMAPS' && googleMapGeoLocValidation()==0)	//need to change	
		{
				
				flg = false;
			}
    */

      else if(googleMapGeoLocValidation()==0)	//need to change	
      {	
        return false;
        }

    /*
   
   		if(document.forms[0].maxFundLimit.value.length == 0)
			document.forms[0].maxFundLimit.value='<bean:write  name="maxFundLimit"/>';

		if(document.forms[0].isPasswordHide.value =="N" && ussdPassEnbled == 'Y')
		{
		   if(document.forms[0].ussdPartnerPassword.value.length < 1)
		   {
			alert("<bean:message bundle="tb" key="6227" />");
			document.forms[0].ussdPartnerPassword.focus();
			flg = false;
		   }else if(document.forms[0].ussdPartnerPassword.value.length > ussdPassLength)
		   {
			alert("<bean:message bundle="tb" key="6228" /> "+ussdPassLength+" <bean:message bundle="tb" key="6229" />");
			document.forms[0].ussdPartnerPassword.focus();
			flg = false;
		   }else if(document.forms[0].ussdPartnerPassword!=null && isCharsInBag(document.forms[0].ussdPartnerPassword.value,num_bag)==0)
		   {
			 alert("<bean:message bundle="tb" key="6234" />");
			 document.forms[0].ussdPartnerPassword.focus();
			 flg = false;
		   }else if(document.forms[0].ussdConfirmPassword.value.length < 1)
		   {
			alert("<bean:message bundle="tb" key="6230" />");
			document.forms[0].ussdConfirmPassword.focus();
			flg = false;
		   }else if(document.forms[0].ussdConfirmPassword.value.length > ussdPassLength)
		   {
			alert("<bean:message bundle="tb" key="6231" /> "+ussdPassLength+" <bean:message bundle="tb" key="6229" />");
			document.forms[0].ussdConfirmPassword.focus();
			flg = false;
		   }else if(document.forms[0].ussdConfirmPassword!=null && isCharsInBag(document.forms[0].ussdConfirmPassword.value,num_bag)==0)
		   {
			alert("<bean:message bundle="tb" key="6235" />");
			document.forms[0].ussdConfirmPassword.focus();
			flg = false;
		   }else if(document.forms[0].ussdPartnerPassword.value != document.forms[0].ussdConfirmPassword.value)
		   {
			alert("<bean:message bundle="tb" key="6232" />");
			document.forms[0].ussdConfirmPassword.focus();
			flg = false;
		   }
		}
       
    */

    if (flg) {
      //document.forms[0].partnerLoginId.value = document.forms[0].partnerIdentity.value;

      if (verifyPartnerFields()) {
        /*
           if((document.forms[0].gLedgerCode.value.length>0) && (isAlphaNumeric(document.forms[0].gLedgerCode.value)==0 ))
            {
              toast.error(t('251673'));
             document.forms[0].gLedgerCode.focus();
            }
            else
                  {
                if(document.forms[0].isPasswordHide.value =="N")
                {
                    var hexPwdData = Str2Hex(document.forms[0].partnerPassword.value);
                  var revPwd = reverse(hexPwdData);
                  document.forms[0].partnerPassword.value = revPwd;
                 
                  var hexCnfPwdData = Str2Hex(document.forms[0].confirmPassword.value);
                  var revCnfPwd = reverse(hexCnfPwdData);
                  document.forms[0].confirmPassword.value = revCnfPwd;
                }
  
                 if(document.forms[0].isPasswordHide.value =="N" && ussdPassEnbled == 'Y')
              {
                  var hexPwdUssdData = Str2Hex(document.forms[0].ussdPartnerPassword.value);
                  var revUssdPwd = reverse(hexPwdUssdData);
                  document.forms[0].ussdPartnerPassword.value = revUssdPwd;
  
                  var hexCnfUssdData = Str2Hex(document.forms[0].ussdConfirmPassword.value);
                  var revCnfUssdPwd = reverse(hexCnfUssdData);
                  document.forms[0].ussdConfirmPassword.value = revCnfUssdPwd;
              }
  
          document.forms[0].radioselect.value=get_radio_value();
          //document.forms[0].selectedchannels.value=document.forms[0].selectedchannels.value;
          document.forms[0].pageAction.value = "PREVIEW";
          document.forms[0].method = "post";
          //document.forms[0].action = "addPartner.jsp";
          document.forms[0].action = "/partner/salespeople.do?method=addsalespersonp";
          document.forms[0].submit();
        }
          */
        //alert("PREVIEW for AddSalesPeople");


        setPisLateralEnabled(isLateralEnabled=='N'?t('N') : t('Y'))
        setPisSingleSrcEnabled(sfsCheck=='N'?t('N') : t('Y'))
        setPisMultiLevlEnabled(isMultiLevlEnabled=='N'?t('N') : t('Y'))
        setPisMultiLevlRecEnabled(isMultiLevlRecEnabled=='N'?t('N') : t('Y'));
        setPisMultiLevelTransferEnabled(isMultiLevelTransferEnabled==='N'?t('N') : t('Y'));
        setPisMultiLevelReceiveEnabled(isMultiLevelReceiveEnabled==='N'?t('N') : t('Y'));
        setPnegativeTransfers(negativeTransfers=='N'?t('N') : t('Y'))
        setMaximumaccount(maxFundLimit);
        setUOF(useOwnFunds=='N'?t('N') : t('Y'));
        setPsalesForceEnable(salesForceStatus=='N'?t('N') : t('Y'))
        setPsimtransenable(simTransferStatus=='N'?t('N') : t('Y'))
        setPpaymentType(paymentType=='1'?'cash':'')
        setPstatus(status=='Y'?t('057') : t('058'))
        setBankReferenceNum(bankRefernceNumber)
        usertypes.map(item => {
          if (item.id === childPartnerType) {
            setPartnerTypeDesc(item.value)
          }
        })
        //alert(status);
        setPreview(true);
       
      }
    }
  };
  const RedAsterisk = styled("span")({
    color: "red",
  });
  const [isHovered, setIsHovered] = useState(false);
  const [isMandate, setIsMandate] = useState(false);
  const [isMandate1, setIsMandate1] = useState(false);
  const [isMandate2, setIsMandate2] = useState(false);
  const [isMandate3, setIsMandate3] = useState(false);
  const [isMandate4, setIsMandate4] = useState(false);
  return (
    <div>
      <table
        border={0}
        cellPadding={0}
        cellSpacing={0}
        id="inSideLayoutTable"
        height={600}
        width={1000}
        align="center"
      >
        <tbody>
         
                  <Header />
          <tr height="65px">
            <PaymentManagerHeading />
            
                  <TopMenu />
          </tr>
          <tr>
          {/* <td valign="top"style={{ borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)"}}nowrap="nowrap">
          <ToastContainer
                containerId="GlobalApplicationToast"
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                style={{
                  width: "fit-content",
                  minWidth: "300px",
                  minHeight: "100px",
                  fontSize: "18px",
                }}
              />
              <br />
              &nbsp; <br />
            </td> */}
            
            <LeftBgImage />
            {preview == false ? (<td valign="top">
              <meta
                httpEquiv="Content-Type"
                content="text/html; charset=ISO-8859-1"
              />
              <JasperTopMenu />
              <ToastContainer
                containerId="GlobalApplicationToast"
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                style={{
                  width: "fit-content",
                  minWidth: "300px",
                  minHeight: "100px",
                  fontSize: "18px",
                }}
              />
              <div className={'accordion_sec distAccnt input_boxess rehargePreview '}>
              {errorMsg!=undefined&&errorMsg.length>0?( <tr>
                <td width="59%" align="left" className="redTxt" style={{paddingBottom:'10px'}}>
                {errorMsg=='1'?(<>{errorPartnerIdentity+t('4805')}</>):(<>
                  {errorMsg=='2'?(<>{'RUC Number'+rucNo+'already exists, please try again with different RUC Number.'}</>):(<>
                  {errorMsg=='4'?(<>{t('5053')}</>):(<>{errorMsg=='RUC-'?(<>{errorMessage}</>):(<>
                  {errorMsg=='UNIQUE_BANK_REFERENCE_NO'?(<>{t('BANK_UNIQUE1')}</>):(<>
                  </>)}
                  </>)}
                  </>)}</>)}
                  </>)}
                
                </td>
              </tr>):null}
        
              {hierarchyStatus==false?(<>
                    <tr>
                                              <td width='10%'>&nbsp;</td>
                                              <td width="100%" colspan='2' >
                                            <table border = "0" borderColor="blue">
                                           <tr>
                                          <td class="redTxt" style={{paddingBottom:'10px'}} align="left">{t('5217')}</td>
                               </tr>
                            </table>
                          </td>    
                          </tr>
                  </>):null}
                {/* <p
                                                      width="80%"
                                                      className="redtext"
                                                      colSpan={2}
                                                      style={{ color: "red" }}
                                                    >
                                                      {t("242487")}
                                                    </p> */}
                {isLoading && <><br /><div className={'spinnerDiv'}> {t("Processing...")}  <CircularProgress size="sm" /></div></>}

              {!isLoading && <>  <form onSubmit={handleSubmit}>
                  <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel1-content"
                      id="panel1-header"
                    >
                    {t("1250")}

                    </AccordionSummary>
                    <AccordionDetails className={'general_accordion'}>
                   
<Grid container>
  <Grid item xs={3}>
  <TextField
                                                          size="12"
                                                          type="text"
                                                          label={
                                                            <span>
                                                              {`${t("242435")}`}
                                                              <RedAsterisk>*</RedAsterisk>
                                                            </span>
                                                          }
                                                          inputProps={{ maxLength: 25 }}
                                                          name="partnerIdentity"
                                                          id="partnerIdentity"
                                                          className={`sampleInput mb5 ${isMandate ? 'mandateField' : ''}`}
                                                          onKeyDown={
                                                            exceptComma
                                                          }
                                                          value={
                                                            partnerIdentity
                                                          }
                                                          onBlur={() => setIsMandate(partnerIdentity.trim() === "")}
                                                          onChange={(e) =>
                                                            setPartnerIdentity(
                                                              e.target.value.trim()
                                                            )
                                                          }
                                                        />
  </Grid>
  <Grid xs={3} item>
  <TextField
                                                          size="12"
                                                          label={
                                                            <span>
                                                              {`${t("242436")}`}
                                                            </span>
                                                          }
                                                          type="text"
                                                          inputProps={{ maxLength: 10 }}
                                                          name="salesMdn"
                                                          defaultValue=""
                                                          onKeyDown={
                                                            onlyNumberValidate
                                                          }
                                                          className="sampleInput mb5"
                                                          value={salesMdn}
                                                          onChange={(e) =>
                                                            setSalesMdn(
                                                              e.target.value
                                                            )
                                                          }
                                                        />
  </Grid>
 
  <Grid xs={3} item>
  <TextField
                                                          size="12"
                                                          label={
                                                            <span>
                                                              {`${t('242438')}`}
                                                            </span>
                                                          }
                                                          type="text"
                                                          inputProps={{ maxLength: 65 }}
                                                          name="partnerCompanyName"
                                                          className="sampleInput mb5"
                                                          value={
                                                            partnerCompanyName
                                                          }
                                                          onChange={(e) =>
                                                            setPartnerCompanyName(
                                                              e.target.value
                                                            )
                                                          }
                                                        />
  </Grid>
  
  <Grid xs={3} item>
  <TextField
                                                          type="text"
                                                          inputProps={{ maxLength: 25 }}
                                                          label={
                                                            <span>
                                                              {`${t('242440')}`}
                                                              <RedAsterisk>*</RedAsterisk>
                                                            </span>
                                                          }
                                                          className={`sampleInput mb5 ${isMandate1 ? 'mandateField' : ''}`}
                                                          onBlur={() => setIsMandate1(rucNo.trim() === "")}
                                                          name="rucNo"
                                                          defaultValue=""
                                                          onKeyDown={
                                                            onlyAlphaNumericValidate
                                                          }
                                                          value={rucNo}
                                                          onChange={(e) =>
                                                            setRucNo(
                                                              e.target.value
                                                            )
                                                          }
                                                        />
  </Grid>
  
  
  
  <Grid xs={3} item>
  <TextField
                                                        label={
                                                          <span>
                                                            {`${t('242444')}`}
                                                            <RedAsterisk>*</RedAsterisk>
                                                          </span>
                                                        }
                                                          type="text"
                                                          inputProps={{ maxLength: 90 }}
                                                          name="partnerContactFirstName"
                                                          defaultValue=""
                                                          size="25"
                                                          className={`sampleInput mb5 ${isMandate2 ? 'mandateField' : ''}`}
                                                          value={
                                                            partnerContactFirstName
                                                          }
                                                          onBlur={() => setIsMandate2(partnerContactFirstName.trim() === "")}
                                                          onChange={(e) =>
                                                            setPartnerContactFirstName(
                                                              e.target.value
                                                            )
                                                          }
                                                        />
  </Grid>
  <Grid xs={3} item>
  <TextField
                                                          label={
                                                            <span>
                                                              {`${t('242445')}`}
                                                            <RedAsterisk>*</RedAsterisk>
                                                            </span>
                                                          }
                                                          type="text"
                                                          name="partnerContactLastName"
                                                          size="25"
                                                          defaultValue=""
                                                          maxLength={90}
                                                          value={
                                                            partnerContactLastName
                                                          }
                                                          className={`sampleInput mb5 ${isMandate3 ? 'mandateField' : ''}`}
                                                          onChange={(e) =>
                                                            setPartnerContactLastName(
                                                              e.target.value
                                                            )
                                                          }
                                                          onBlur={() => setIsMandate3(partnerContactLastName.trim() === "")}
                                                        />
  </Grid>
  <Grid xs={3} item>
  <TextField
                                                         label={
                                                          <span>
                                                            {`${t('242454')}`}
                                                            <RedAsterisk>*</RedAsterisk>
                                                          </span>
                                                        }
                                                          type="text"
                                                          name="emailID"
                                                          size="25"
                                                          defaultValue=""
                                                          inputProps={{ maxLength: 99 }}
                                                          className={`sampleInput mb5 ${isMandate4 ? 'mandateField' : ''}`}
                                                          value={emailID}
                                                          onChange={(e) =>
                                                            setEmailID(
                                                              e.target.value
                                                            )
                                                          }
                                                          onBlur={() => setIsMandate4(emailID.trim() === "")}
                                                        />
  </Grid>
  {/* <Grid xs={3} item>
  <TextField
                                                          type="text"
                                                          name="maxFundLimit"
                                                          size="10"
                                                          inputProps={{ maxLength: 10 }}
                                                          className="sampleInput mb5"
                                                          defaultValue=""
                                                          onBlur={() =>
                                                            handleBlur(
                                                              maxFundLimit,
                                                              setMaxFundLimit
                                                            )
                                                          }
                                                          label={
                                                            <span>{t("242443")}(MXN)</span>
                                                          }
                                                          onKeyDown={
                                                            numvalidate
                                                          }
                                                          // value={numeral(maxFundLimit).format('0.00')}
                                                            value={maxFundLimit}
                                                          
                                                          onChange={(e) =>
                                                            setMaxFundLimit(
                                                              e.target.value
                                                            )
                                                          }
                                                        />
  </Grid> */}
  <Grid item xs={3}>
  <FormControl
                                                     className={'selected_formcontrol'}
                                                          size="small"
                                                        >
                                                          <InputLabel id="demo-select-small-label">
                                                            {t('242439')}
                                                          </InputLabel>
                                                          <Select
                                                            labelId="demo-select-small-label"
                                                            id="demo-select-small"
                                                            label={t("242439")}
                                                            name="childPartnerType"
                                                            value={
                                                              childPartnerType
                                                            }
                                                            onChange={(e) =>
                                                              setChildPartnerType(
                                                                e.target.value
                                                              )
                                                            }
                                                            className={
                                                              "selected_dropdown"
                                                            }
                                                          >
                                                            {usertypes.map(
                                                              (usertype) => (
                                                                <MenuItem
                                                                  key={
                                                                    usertype.id
                                                                  }
                                                                  value={
                                                                    usertype.id
                                                                  }
                                                                >
                                                                  {
                                                                    usertype.value
                                                                  }
                                                                </MenuItem>
                                                              )
                                                            )}
                                                          </Select>
                                                        </FormControl>
  </Grid>
  <Grid xs={3} item>
  <FormControl
                                                          size="small"
                                                          className={
                                                            "selected_formcontrol"
                                                          }
                                                        >
                                                          <InputLabel id="demo-select-small-label">
                                                            {t('242442')}
                                                          </InputLabel>
                                                          <Select
                                                            labelId="demo-select-small-label"
                                                            id="demo-select-small"
                                                            label={t("242442")}
                                                            name="paymentType"
                                                            value={paymentType}
                                                            onChange={(e) =>
                                                              setPaymentType(
                                                                e.target.value
                                                              )
                                                            }
                                                            className={
                                                              "selected_dropdown"
                                                            }
                                                          >
                                                           
                                                            <MenuItem value="1">
                                                              {/* cash */}
                                                              {t("020")}
                                                            </MenuItem>

                                                            {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                                          </Select>
                                                        </FormControl>
  </Grid>
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {`${t('242437')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={partnerId}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
 
  <Grid xs={3} item>
  
                                                          <TextField
                            label={
                              <span>
                                {`${t('242441')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!sclCode
                              ? "---"
                              : sclCode}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
 
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {t("242455")}(MXN)
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={accountBal}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {`${t('242458')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={Currency}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {`${t('242470')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={bankRefernceNumber}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {`${t('242476')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={parentBSUserName}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
</Grid>


                    </AccordionDetails>
                  </Accordion>
                  <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                    >
                      {t("1248")}
                    </AccordionSummary>
                    <AccordionDetails className={'address_accordion'}>
                    <Grid container>
                    <Grid item xs={3}>
                    <LocationPopUp
                                                            handleSelectedGeographicalLoc={
                                                              handleSelectedGeographicalLoc
                                                            }
                                                          />
                                                          </Grid>
                                                          <Grid item xs={12}>
                          
                          {/* <div style={{ display: 'block', color: 'black', padding: '0px' }}> */}
                          {selectedGeographicalLoc.length >
                              0 ?( <>
                                <span className={'labelText'} style={{ color: '#39f' }}> {t("242447")}</span> : <br/><br/>
  {locationArray.map((part, index) => (
       <TextField
       label={
         <span>
           {labelsArray[index] || `${t('default_label')}`} {/* Fallback label */}
         </span>
       }
       style={{ width: `${part.length + 10}ch`, marginRight: '5px' }} // Adjust width based on text length
       disabled
       InputLabelProps={{
         shrink: true, // Prevent label and value from overlapping
       }}
       size="15"
       className={"sampleInput mb5"}
       value={part}
       type="text"
       autoComplete="off"
       id=""
     />
  ))}</>)
  : <b style={{marginLeft:'30px'}}></b> } 

                        </Grid>
                        </Grid>
                        <p className={'labelText'} style={{ color: '#39f', margin: "10px 0px 1px 0px",  fontWeight:'bold', fontSize:'12px' }}> {t("242448")}</p>
                      <p className={'labelText'} style={{ color: '#39f', margin: "1px 0" }}> {t("242449")}</p>
                      <Grid container>
                        <Grid xs={3} item style={{ position: 'relative' }}>
                     
                        <textarea
                                                          name="contaddress1"
                                                          className="textAreaSmall sampleInput mb5"
                                                          id="idContaddress1"
                                                          rows={4}
                                                          cols={40}
                                                          maxLength={512}
                                                          maxrows={15}
                                                          maxcols={40}
                                                          onKeyDown={(e) =>
                                                            notescheckCount(
                                                              e,
                                                              512
                                                            )
                                                          }
                                                          onKeyUp={(e) =>
                                                            notescheckCount(
                                                              e,
                                                              512
                                                            )
                                                          }
                                                          value={contaddress1}
                                                          onChange={(e) =>
                                                            setContaddress1(
                                                              e.target.value
                                                            )
                                                          }
                                                        />
                         <GoogleMapPartner
                                                          setMapAddress={
                                                            setMapAddress
                                                          }
                                                          mapadd={mapInAdd}
                                                        />
                        </Grid>
                        <Grid item xs={9}>
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("2424501")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="latitude"
                            className="sampleInput  mb5"
                            defaultValue=""
                            id="cLatitude"
                            readOnly="true"
                            style={{ width: `${latitude.length + 150}px`, marginRight: '5px' }}
                            // maxLength={20}
                            inputProps={{ maxLength: 20 }}
                            value={latitude}
                            onChange={(e) =>
                              setLatitude(
                                e.target.value
                              )
                            }
                          />
                        {/* </Grid>
                        <Grid item xs={3}> */}
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("2424502")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="longitude"
                            className="sampleInput mb5"
                            defaultValue=""
                            id="cLongitude"
                            readOnly="true"
                            style={{ width: `${longitude.length + 150}px`, marginRight: '5px' }}
                            // maxLength={20}
                            inputProps={{ maxLength: 20 }}
                            value={longitude}
                            onChange={(e) =>
                              setLongitude(
                                e.target.value
                              )
                            }
                          />
                        {/* </Grid>
                        <Grid item xs={3}> */}
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("242451")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="contzipcode"
                            className="sampleInput mb5"
                            defaultValue=""
                            readOnly="true"
                            style={{ width: `${contzipcode.length + 100}px`, marginRight: '5px' }}
                            // maxLength={9}
                            inputProps={{ maxLength: 9 }}
                            id="idContzipcode"
                            value={contzipcode}
                            onChange={(e) =>
                              setContzipcode(
                                e.target.value
                              )
                            }
                          />
                        </Grid>
                        <Grid item xs={5} style={{ display: 'flex', alignItems: 'center', marginTop: '-7px', marginBottom:'12px' }}>
                          <span
                            width="40%"
                            className="labelText"
                            style={{fontSize:'10px'}}
                          >
                            {t("242452")}{" "}
                          </span>
                          <span
                            width="60%"
                            colSpan={2}
                            className="labelText"
                          >
                            {/* <input
                                                        type="checkbox"
                                                        name="addresschecking"
                                                        checked={isChecked}
                                                        onChange={
                                                          handleCheckboxChange
                                                        }
                                                      /> */}
                            <Checkbox
                               name="addresschecking"
                               checked={isChecked}
                               onChange={
                                 handleCheckboxChange
                               }/>
                          </span>
                        </Grid>
                      </Grid>
                      <p className={'labelText'} style={{ color: '#39f', margin: '1px 0', fontWeight:'bold', fontSize:'12px' }}> {t("242453")}</p>
                      <p className={'labelText'} style={{ color: '#39f', margin: "1px 0" }}> {t("242449")}</p>
                      <Grid container>
                        <Grid item xs={3}>
                     
                        <textarea
                                                          name="billaddress1"
                                                          className="textAreaSmall sampleInput mb5 mb10"
                                                          id="idBilladdress1"
                                                          rows={4}
                                                          cols={40}
                                                          maxLength={512}
                                                          maxrows={15}
                                                          maxcols={40}
                                                          onKeyDown={(e) =>
                                                            notescheckCount(
                                                              e,
                                                              512
                                                            )
                                                          }
                                                          onKeyUp={(e) =>
                                                            notescheckCount(
                                                              e,
                                                              512
                                                            )
                                                          }
                                                          defaultValue={""}
                                                          value={billaddress1}
                                                          onChange={(e) =>
                                                            setBilladdress1(
                                                              e.target.value
                                                            )
                                                          }
                                                        />
                          {/* <font color="red">*</font> */}
                        </Grid>
                        <Grid item xs={3}>
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("242451")}`}
                              </span>
                            }
                            className="sampleInput mb5 mb10"
                            name="billzipcode"
                            defaultValue=""
                            // maxLength={9}
                            inputProps={{ maxLength: 9 }}
                            value={billzipcode}
                            onChange={(e) =>
                              setBillzipcode(
                                e.target.value
                              )
                            }
                          />
                        </Grid>
                        {isPasswordHide !== 'Y' && (<>
                          <Grid item xs={3}>
                            <TextField label={
                              <span>
                                {`${t("10282424")}`}
                              </span>
                            } type="password" name="partnerPassword" value={partnerPassword} class="textBox" size="25"
                              onChange={(e) =>
                                setPartnerPassword(
                                  e.target.value
                                )
                              } autocomplete="off" />
                          </Grid>



                          {ussdPwdEnabled !== 'Y' && (<>
                            <Grid item xs={3}>
                              <TextField type="password"
                                label={
                                  <span>
                                    {`${t('30212424')}`}
                                  </span>
                                } name="confirmPassword" value={confirmPassword} class="textBox" size="25"
                                //  maxlength="30"
                                inputProps={{ maxLength: 30 }}
                                onChange={(e) =>
                                  setConfirmPassword(
                                    e.target.value
                                  )
                                } autocomplete="off" />
                            </Grid>
                            <Grid item xs={3}>
                              <TextField type="password"
                                label={
                                  <span>
                                    {`${t('62252424')}`}
                                  </span>
                                } name="ussdPartnerPassword" value={ussdPartnerPassword} onChange={(e) =>
                                  setUssdPartnerPassword(
                                    e.target.value
                                  )
                                } class="sampleInput"

                                size="25" autocomplete="off" />
                            </Grid>
                            <Grid item xs={3}>
                              <TextField type="password"
                                label={
                                  <span>
                                    {`${t('62262424')}`}
                                  </span>
                                } name="ussdConfirmPassword" value={ussdConfirmPassword}
                                onChange={(e) =>
                                  setUssdConfirmPassword(
                                    e.target.value
                                  )
                                } class="sampleInput"

                                size="25" autocomplete="off" />
                            </Grid>
                            </>)}

</>)}
</Grid>
                     
                    </AccordionDetails>
                  </Accordion>
                  <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel3-content"
                      id="panel3-header"
                    >
                      {t("1249")}
                    </AccordionSummary>
                    <AccordionDetails>
                    <Grid container>
                      {parentIsSingleSrcFlagVal != 'Y' && (
                          <Grid item xs={3}>
                            <FormControl

                              size="small"
                              className={
                                "selected_formcontrol"
                              }
                            >
                              <InputLabel id="demo-select-small-label">
                                {t('24246840')}
                              </InputLabel>
                              <Select
                                labelId="demo-select-small-label"
                                id="demo-select-small"
                                label={t("24246840")}
                                name="isLateralEnabled"
                                value={
                                  useOwnFunds
                                }
                                onChange={handleUseOwnFundsChange}
                                className={
                                  "selected_dropdown"
                                }
                              >

                                <MenuItem value="Y">
                                  {t('Y')}
                                </MenuItem>
                                <MenuItem value="N">
                                  {t('N')}
                                </MenuItem>

                                {/* <MenuItem value={30}>Thirty</MenuItem> */}
                              </Select>
                            </FormControl>
                          </Grid>
                        )}
                        
                        <Grid item xs={3}>
                          <FormControl
                            sx={{ minWidth: 280 }}
                            size="small"
                            className={
                              "selected_formcontrol"
                            }
                          >
                            <InputLabel id="demo-select-small-label">
                              {t('242457')}
                            </InputLabel>
                            <Select
                              labelId="demo-select-small-label"
                              id="demo-select-small"
                              label={t("242457")}
                              name="status"
                              value={status}
                              onChange={(e) =>
                                setStatus(
                                  e.target.value
                                )
                              }
                              className={
                                "selected_dropdown"
                              }
                            >

                              <MenuItem value="Y">
                                {" "}
                                {t("242478")}
                              </MenuItem>
                              <MenuItem value="N">
                                {" "}
                                {t("242479")}
                              </MenuItem>

                              {/* <MenuItem value={30}>Thirty</MenuItem> */}
                            </Select>
                          </FormControl>
                        </Grid>
                        {simEnabled == 'Y' && (<>
                          <Grid item xs={3}>
                            <FormControl
                              sx={{ minWidth: 280 }}
                              size="small"
                              className={
                                "selected_formcontrol"
                              }
                            >
                              <InputLabel id="demo-select-small-label">
                                {t('242473')}
                              </InputLabel>
                              <Select
                                labelId="demo-select-small-label"
                                id="demo-select-small"
                                label={t("242473")}
                                name="salesForceStatus"
                                value={
                                  salesForceStatus
                                }
                                onChange={(e) =>

                                  setSalesForceStatus(
                                    e.target.value
                                  )

                                }
                                className={
                                  "selected_dropdown"
                                }
                              >

                                <MenuItem value="Y">
                                  {t('Y')}
                                </MenuItem>
                                <MenuItem value="N">
                                  {t('N')}
                                </MenuItem>

                                {/* <MenuItem value={30}>Thirty</MenuItem> */}
                              </Select>
                            </FormControl>
                          </Grid></>)}
                          <Grid item xs={3}>
                          <FormControl

                            size="small"
                            className={
                              "selected_formcontrol"
                            }
                          >
                            <InputLabel id="demo-select-small-label">
                              {t('242461')}
                            </InputLabel>
                            <Select
                              labelId="demo-select-small-label"
                              id="demo-select-small"
                              label={t("242461")}
                              name="isMultiLevlEnabled"
                              value={
                                isMultiLevlEnabled
                              }
                              onChange={(e) =>
                                setIsMultiLevlEnabled(
                                  e.target.value
                                )
                              }
                              className={
                                "selected_dropdown"
                              }
                            >

                              <MenuItem value="Y">
                                {t('Y')}
                              </MenuItem>
                              <MenuItem value="N">
                                {t('N')}
                              </MenuItem>

                              {/* <MenuItem value={30}>Thirty</MenuItem> */}
                            </Select>
                          </FormControl>
                        </Grid>
                        <Grid item xs={3}>
                          <TextField
                            type="text"
                            name="maxFundLimit"
                            size="10"
                            label={
                              <span>
                                {`${t("242443")}`}
                              </span>
                            }
                            // maxLength={10}
                            inputProps={{ maxLength: 10 }}
                            className="sampleInput mb5"
                            defaultValue=""
                            onBlur={() =>
                              handleBlur(
                                maxFundLimit,
                                setMaxFundLimit
                              )
                            }
                            onKeyDown={numvalidate}
                            // value={numeral(maxFundLimit).format('0.00')}
                            value={maxFundLimit}
                            
                            onChange={(e) =>
                              setMaxFundLimit(
                                e.target.value
                              )
                            }
                          />
                        </Grid>
                       
                        <Grid item xs={3}>
                          <FormControl
                            size="small"
                            className={
                              "selected_formcontrol"
                            }
                          >
                            <InputLabel id="demo-select-small-label">
                              {t('242472')}
                            </InputLabel>
                            <Select
                              labelId="demo-select-small-label"
                              id="demo-select-small"
                              label={t("242472")}
                              name="negativeTransfers"
                              value={
                                negativeTransfers
                              }
                              onChange={(e) =>
                                setNegativeTransfers(
                                  e.target.value
                                )
                              }
                              className={
                                "selected_dropdown"
                              }
                            >

                              <MenuItem value="Y">
                                {t('Y')}
                              </MenuItem>
                              <MenuItem value="N">
                                {t('N')}
                              </MenuItem>

                              {/* <MenuItem value={30}>Thirty</MenuItem> */}
                            </Select>
                          </FormControl>
                        </Grid>
                        {simEnabled == 'Y' && (<>
                          <Grid item xs={3}>
                            <FormControl
                              sx={{ minWidth: 280 }}
                              size="small"
                              className={
                                "selected_formcontrol"
                              }
                            >
                              <InputLabel id="demo-select-small-label">
                                {t('242474')}
                              </InputLabel>
                              <Select
                                labelId="demo-select-small-label"
                                id="demo-select-small"
                                label={t("242474")}
                                name="paymentsimTransferStatusType"
                                value={
                                  simTransferStatus
                                }
                                onChange={(e) =>
                                  setSimTransferStatus(
                                    e.target.value
                                  )
                                }
                                className={
                                  "selected_dropdown"
                                }
                              >

                                <MenuItem value="Y">
                                  {t('Y')}
                                </MenuItem>
                                <MenuItem value="N">
                                  {t('N')}
                                </MenuItem>

                                {/* <MenuItem value={30}>Thirty</MenuItem> */}
                              </Select>
                            </FormControl>
                          </Grid>
                        </>)}
                        <Grid item xs={3}>
                          <FormControl

                            size="small"
                            className={
                              "selected_formcontrol"
                            }
                          >
                            <InputLabel id="demo-select-small-label">
                              {t('242462')}
                            </InputLabel>
                            <Select
                              labelId="demo-select-small-label"
                              id="demo-select-small"
                              label={t("242462")}
                              name="isMultiLevlRecEnabled"
                              value={
                                isMultiLevlRecEnabled
                              }
                              onChange={(e) =>
                                setIsMultiLevlRecEnabled(
                                  e.target.value
                                )
                              }
                              className={
                                "selected_dropdown"
                              }
                            >

                              <MenuItem value="Y">
                                {t('Y')}
                              </MenuItem>
                              <MenuItem value="N">
                                {t('N')}
                              </MenuItem>

                              {/* <MenuItem value={30}>Thirty</MenuItem> */}
                            </Select>
                          </FormControl>
                        </Grid>
                        <Grid xs={3} item>
  <TextField
                                                          type="text"
                                                          name="acctBalThresold"
                                                          size="20"
                                                          inputProps={{ maxLength: 15 }}
                                                          label={
                                                            <span>
                                                            {t("242456")}(MXN)
                                                            </span>
                                                          }
                                                          className="sampleInput mb5"
                                                          defaultValue=""
                                                          onBlur={() =>
                                                            handleBlur(
                                                              acctBalThresold,
                                                              setAcctBalThresold
                                                            )
                                                          }
                                                          onKeyDown={
                                                            numvalidate
                                                          }
                                                          // value={
                                                          //   numeral(acctBalThresold).format("0.00")
                                                          // }
                                                          value={acctBalThresold}
                                                          onChange={(e) =>
                                                            setAcctBalThresold(
                                                              e.target.value
                                                            )
                                                          }
                                                        />
  </Grid>
                       
                    
                       
                      

                        
                      
                        

                      
                        {flagPmConfigStatusMultiTrans && (<>


                          
                          {transferFlagStatus == 'Y' ? (<>
                            <Grid item xs={3}>
                              <FormControl
                                sx={{ minWidth: 280 }}
                                size="small"
                                className={
                                  "selected_formcontrol"
                                }
                              >
                                <InputLabel id="demo-select-small-label">
                                  {t('242459')}
                                </InputLabel>
                                <Select
                                  labelId="demo-select-small-label"
                                  id="demo-select-small"
                                  label={t("242459")}
                                  name="isLateralEnabled"
                                  value={
                                    isLateralEnabled
                                  }
                                  onChange={(e) =>
                                    setIsLateralEnabled(
                                      e.target.value
                                    )
                                  }
                                  className={
                                    "selected_dropdown"
                                  }
                                >

                                  <MenuItem value="Y">
                                    {t('Y')}
                                  </MenuItem>
                                  <MenuItem value="N">
                                    {t('N')}
                                  </MenuItem>

                                  {/* <MenuItem value={30}>Thirty</MenuItem> */}
                                </Select>
                              </FormControl></Grid></>) : (<>
                                <TextField
                                  label={
                                    <span>
                                      {`${t('242459')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={t('N')}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                              </>)}
                              <Grid item xs={3}>
                          <TextField
                            type="text"
                            name="partnerSimThreshold"
                            size="20"
                            label={
                              <span>
                                {`${t("242475")}`}
                              </span>
                            }
                            // maxLength={15}
                            inputProps={{ maxLength: 15 }}
                            className="sampleInput mb5"
                            onKeyDown={
                              onlyNumberValidate
                            }
                            value={
                              partnerSimThreshold
                            }
                            onChange={(e) =>
                              setPartnerSimThreshold(
                                e.target.value
                              )
                            }
                          />
                        </Grid>
                        {transferFlagStatus == 'Y' ? (<>
                            <Grid item xs={3}>
                              <FormControl
                                size="small"
                                className={
                                  "selected_formcontrol"
                                }
                              >
                                <InputLabel id="demo-select-small-label">
                                  {t('242463')}
                                </InputLabel>
                                <Select
                                  labelId="demo-select-small-label"
                                  id="demo-select-small"
                                  label={t("242463")}
                                  name="isMultiLevelTransferEnabled"
                                  value={
                                    isMultiLevelTransferEnabled
                                  }
                                  onChange={(e) =>
                                    setIsMultiLevelTransferEnabled(
                                      e.target.value
                                    )
                                  }
                                  className={
                                    "selected_dropdown"
                                  }
                                >

                                  <MenuItem value="Y">
                                    {t('Y')}
                                  </MenuItem>
                                  <MenuItem value="N">
                                    {t('N')}
                                  </MenuItem>
                                </Select>
                              </FormControl>
                            </Grid>
                          </>) : (<Grid item xs={3}>
                            <TextField
                              label={
                                <span>
                                  {`${t('242463')}`}
                                </span>
                              }
                              disabled
                              InputLabelProps={{
                                shrink: true, // This will prevent label and value from overlapping
                              }}
                              size="15"
                              className={"sampleInput mb5"}
                              value={t('N')}
                              type="text"
                              autocomplete="off"
                              id=""
                            /></Grid>
                          )}
                          <Grid xs={3} item>
                              <TextField
                                label={
                                  <span>
                                    {`${t('242460')}`}
                                  </span>
                                }
                                disabled
                                InputLabelProps={{
                                  shrink: true, // This will prevent label and value from overlapping
                                }}
                                size="15"
                                className={"sampleInput mb5"}
                                value={parentIsSingleSrcFlagVal!='Y'?(t('N')):(t('Y'))}
                                type="text"
                                autocomplete="off"
                                id=""
                              /> 
                          </Grid>
                         

                        </>)}
                        {flagPmconfigstatus_RechargeRev && (<>
                          <Grid xs={3} item>
                            <TextField
                              label={
                                <span>
                                  {`${t('242465')}`}
                                </span>
                              }
                              disabled
                              InputLabelProps={{
                                shrink: true, // This will prevent label and value from overlapping
                              }}
                              size="15"
                              className={"sampleInput mb5"}
                              value={t('N')}
                              type="text"
                              autocomplete="off"
                              id=""
                            />
                          </Grid>
                        </>)}
                        {flagPmconfigstatus_RechargeRev && (<>
                          <Grid xs={3} item>
                            <TextField
                              label={
                                <span>
                                  {`${t('242466')}`}
                                </span>
                              }
                              disabled
                              InputLabelProps={{
                                shrink: true, // This will prevent label and value from overlapping
                              }}
                              size="15"
                              className={"sampleInput mb5"}
                              value={t('N')}
                              type="text"
                              autocomplete="off"
                              id=""
                            />
                          </Grid>
                        </>)}
                        {flagPmConfigStatusMultiTrans && (<> 
                        {transferFlagStatus == 'Y' ? (<>
                            <Grid xs={3} item>
                              <FormControl
                                size="small"
                                className={
                                  "selected_formcontrol"
                                }
                              >
                                <InputLabel id="demo-select-small-label">
                                  {t('242464')}
                                </InputLabel>
                                <Select
                                  labelId="demo-select-small-label"
                                  id="demo-select-small"
                                  label={t("242464")}
                                  name="isMultiLevelReceiveEnabled"
                                  value={
                                    isMultiLevelReceiveEnabled
                                  }
                                  onChange={(e) =>
                                    setIsMultiLevelReceiveEnabled(
                                      e.target.value
                                    )
                                  }
                                  className={
                                    "selected_dropdown"
                                  }
                                >

                                  <MenuItem value="Y">
                                    {t('Y')}
                                  </MenuItem>
                                  <MenuItem value="N">
                                    {t('N')}
                                  </MenuItem>
                                </Select>
                              </FormControl>
                            </Grid>
                          </>) : (<>
                            <Grid xs={3} item>
                              <TextField
                                label={
                                  <span>
                                    {`${t('242464')}`}
                                  </span>
                                }
                                disabled
                                InputLabelProps={{
                                  shrink: true, // This will prevent label and value from overlapping
                                }}
                                size="15"
                                className={"sampleInput mb5"}
                                value={t('N')}
                                type="text"
                                autocomplete="off"
                                id=""
                              />
                            </Grid>
                          </>)}
                          </>)}
                          </Grid>
                          <Grid container>
                        <Grid item xs={3} style={{marginTop:'-7px'}}>
                          {/* {t('242467')} : */}
                          <SalesPersonPopup
                                                        setChannelsAssociation={
                                                          setChannelsAssociation
                                                        }
                                                        flag={clear}
                                                        reset={setClearReset}
                                                      />
                          <br/>
                         
                          {/* {!channelsSelectFlag &&
                            !channelTransAl.length >
                            0 && (
                             
                                <span
                                  style={{
                                    color:
                                      "#ff0000",
                                    fontFamily:
                                      "Arial, helvetica, sans-serif",
                                    fontSize:
                                      "12px",
                                  }}
                                  colSpan={
                                    2
                                  }
                                  align="left"
                                >
                                  {t(
                                    "245679"
                                  )}
                                </span>
                            )} */}
                             <div
      className="parent-div"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{ marginBottom: '10px' }}
    >
      <span
        style={{ color: "#000", cursor: "pointer" }}
       
      >
        <ArrowRight className="animated-arrow" style={{ color: "#39f" }} /> 
        {t("1253")}
      </span>
      <div className={`scroll-list ${isHovered ? 'show' : ''}`} 
      // style={{ maxHeight: isHovered ? channelTransAl.length * 30 + 'px' : '0', transition: 'max-height 0.5s ease-in-out', overflow: 'hidden' }}
      style={{
        maxHeight: channelTransAl.length > 10
          ? '450px'  // Set a fixed max height for scrolling
          : isHovered 
          ? channelTransAl.length * 40 + 'px' 
          : '0',
        transition: 'max-height 0.5s ease-in-out',
        overflow: channelTransAl.length > 10 ? 'auto' : 'hidden'
      }}
     >
      {channelsSelectFlag ? (
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0' }}>
      <li className="smallerTxt"
        style={{
          color: "#000",
          fontFamily: "Arial, helvetica, sans-serif",
          fontSize: "12px",
          padding: '10px'
        }}>
        {t("245678")}
      </li>
    </ul>
  ) : channelTransAl.length > 0 ? (
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0' }}>
      {chunkedData.map((chunk, rowIndex) =>
        chunk.map((cellData, cellIndex) => (
          <li className="smallerTxt" key={cellIndex}>
            {cellData.topupTypeDesc + " - " + cellData.transCategory}
          </li>
        ))
      )}
    </ul>
  ) : (
    // Fallback for when channelsSelectFlag is false and no data in channelTransAl
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0', marginTop: '-18px' }}>
    <li className="smallerTxt"
      style={{
        color: "#000",
        fontFamily: "Arial, helvetica, sans-serif",
        fontSize: "12px",
        padding: '10px'
      }}>
      {t("1251")}
    </li>
    </ul>
  )}
      </div>
    </div>

                        
                        </Grid>
                       
                        <Grid item xs={3}>
                        <ConfigurationNotificationPopup
                                                        setnotificationListObj={
                                                          setnotificationListObj
                                                        }
                                                        configId={configId}
                                                      />
                        </Grid>
                        <Grid item xs={3}>
                          <DenominationsAssociationPopUp />
                        </Grid>

                      </Grid>
                    </AccordionDetails>
                  </Accordion>
                  <div className={'displayFlexCenter'} style={{ marginBottom: '10px' }}>
                    {hierarchyStatus == true && (<>
                      <Button
                        type="submit"
                        className={
                          "hoverEffectButton"
                        }
                        size="small"
                        variant="contained"
                        endIcon={
                          <RemoveRedEyeRounded
                            style={{}}
                          />
                        }
                      >
                        {t("242484")}
                      </Button>
                      &nbsp;
                      {/* <input
                                    type="button"
                                    defaultValue="Clear"
                                    className="inputButton"
                                    onclick="javascript: clearForm(this.form,'/partner/salespeople.do?method=addsalespersonp');"
                                  /> */}
                      <Button
                        onClick={handleClear}
                        className={
                          "hoverEffectButton"
                        }
                        size="small"
                        variant="contained"
                        endIcon={
                          <CancelRounded />
                        }
                      >
                        {t("242485")}
                      </Button>
                      &nbsp;
                    </>)}
                    {/* <input
                                    type="button"
                                    defaultValue="Return"
                                    className="inputButton"
                                    onclick="javascript:this.className='inputButtonSelected'; pageReturn(); "
                                  /> */}
                    <Button
                      className={
                        "hoverEffectButton"
                      }
                      size="small"
                      variant="contained"
                      onClick={handleReturn}
                      endIcon={
                        <KeyboardReturn />
                      }
                    >
                      {t("242410")}
                    </Button>
                  </div>
                </form></>}
              </div>
              <table
                border={0}
                width="100%"
                cellSpacing={0}
                cellPadding={2}
                bordercolor="red"

              >
                <tbody>
                  

                  {/* <tr>
        <td width="59%" align="center" className="strongerTxt">
          {t('251642')}
        </td>
      </tr> */}
                </tbody>
              </table>

            </td> 
          ) : (
              <td valign="top">
              <form
                name="frmprofile"
                method="post"
                action="/partner/subdistributors.do?method=addsubgroupp"
              >
                <br />

                {/* <Box
                  className={
                    "displayFlexCenter print-center-content flexDirectionColumn"
                  }
                  ref={(el) => (componentRef = el)}
                >
                  <TableContainer
                    component={Paper}
                    className={"shadowTable"}
                    sx={{ maxWidth: 450 }}
                  >
                    <Table
                      size="small"
                      className={""}
                      stickyHeader
                      aria-label="sticky table"
                    >
                      <TableHead>
                        <TableRow className={"darkgray subdistributor_table"}>
                          {" "}
                          <TableCell colSpan={2}>{t("5021")}</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        <TableRow>
                          <TableCell>{t("242435")}</TableCell>
                          <TableCell>
                            {!partnerIdentity ? "---" : partnerIdentity}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("242436")}</TableCell>
                          <TableCell>
                            {!salesMdn ? "---" : salesMdn}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("051")}</TableCell>
                          <TableCell>
                            {!partnerParentId ? "---" : partnerParentId}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("082")} </TableCell>
                          <TableCell>
                            {!partnerCompanyName ? "---" : partnerCompanyName}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251646")}</TableCell>
                          <TableCell>{!rucNo ? "---" : rucNo}</TableCell>
                        </TableRow>
                        {postToSCLEnableFlag=='Y'&&(<>
                          <TableRow>
                <TableCell>{t('251603')}</TableCell>
                <TableCell>{!sclUserName? "---":sclUserName}</TableCell>
                </TableRow>
                <TableRow>
                <TableCell>{t('063')}</TableCell>
                <TableCell>{!sclCode? "---":sclCode}</TableCell>
                </TableRow>
              
                </>)}
                        <TableRow>
                          <TableCell>{t("242442")}</TableCell>
                          <TableCell>
                            {!ppaymentType ? "---" : ppaymentType}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251645")}</TableCell>
                          <TableCell>{partnerTypeDesc}</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("24246839")}</TableCell>
                          <TableCell>
                            {!Maximumaccount ? "---" : Maximumaccount}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251652")}</TableCell>
                          <TableCell>
                            {!partnerContactFirstName
                              ? "---"
                              : partnerContactFirstName}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251653")}</TableCell>
                          <TableCell>
                            {!partnerContactLastName
                              ? "---"
                              : partnerContactLastName}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("242446")}</TableCell>
                          <TableCell>{postalcheck}</TableCell>
                        </TableRow>
                        <Table
                          size="small"
                          className={""}
                          stickyHeader
                          aria-label="sticky table"
                        >
                          <TableHead>
                            <TableRow
                              className={"darkgray subdistributor_table"}
                            >
                              <TableCell colSpan={2}>{t("251639")}</TableCell>
                            </TableRow>
                          </TableHead>
                        </Table>
                        <TableRow>
                          <TableCell>{t("251648")}</TableCell>
                          <TableCell>
                            {!contaddress1 ? "---" : contaddress1}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251649")}</TableCell>
                          <TableCell>
                            {!latitude ? "---" : latitude}&nbsp; <b>&amp;</b>{" "}
                            &nbsp;{!longitude ? "---" : longitude}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251650")}</TableCell>
                          <TableCell>
                            {!contzipcode ? "---" : contzipcode}
                          </TableCell>
                        </TableRow>
                        <Table
                          size="small"
                          className={""}
                          stickyHeader
                          aria-label="sticky table"
                        >
                          <TableHead>
                            <TableRow
                              className={"darkgray subdistributor_table"}
                            >
                              <TableCell colSpan={4}>{t("251640")}</TableCell>
                            </TableRow>
                          </TableHead>
                        </Table>
                        <TableRow>
                          <TableCell>{t("251648")}</TableCell>
                          <TableCell>
                            {!billaddress1 ? "---" : billaddress1}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251650")}</TableCell>
                          <TableCell>
                            {!billzipcode ? "---" : billzipcode}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("242454")}</TableCell>
                          <TableCell>{!emailID ? "---" : emailID}</TableCell>
                        </TableRow>
                        {/* <TableRow>
                          <TableCell>{t("251655")}</TableCell>
                          <TableCell>{!gLedgerCode ? "---" : gLedgerCode}</TableCell>
                        </TableRow> 
                        <TableRow>
                          <TableCell>{t("251633")}</TableCell>
                          <TableCell>
                            {!AccountBalance ? "---" : AccountBalance}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251634")}</TableCell>
                          <TableCell>
                            {!acctBalThresold ? "---" : acctBalThresold}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("242457")}</TableCell>
                          <TableCell>{pstatus}</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251620")}</TableCell>
                          <TableCell>{currencyId}</TableCell>
                        </TableRow>
                        {parentIsSingleSrcFlagVal!=='Y'&&(
                <TableRow>
                <TableCell>{t('24246840')}</TableCell>
                <TableCell>{!UOF?"---":UOF}</TableCell>
                </TableRow>
                )}
                       
                        <TableRow>
                          <TableCell>{t("251622")}</TableCell>
                          <TableCell>{pisLateralEnabled}</TableCell>
                        </TableRow>
                        {flagPmconfigstatusSingle&&(<>
                <TableRow>
                <TableCell>{t('251619')}{" "}</TableCell>
                <TableCell>{pisSingleSrcEnabled}</TableCell>
                </TableRow>
               </>)}
               {flagPmconfigstatusMulti&&(<>
                <TableRow>
                <TableCell>{t('251615')}</TableCell>
                <TableCell>{pisMultiLevlEnabled}</TableCell>
                </TableRow>
                <TableRow>
                <TableCell>{t('251616')}</TableCell>
                <TableCell>{pisMultiLevlRecEnabled}</TableCell>
                </TableRow> </>)}
                {flagPmConfigStatusMultiTrans&&(<>
                <TableRow>
                <TableCell>{t('251617')}</TableCell>
                <TableCell>{pisMultiLevelTransferEnabled}</TableCell>
                </TableRow>
                <TableRow>
                <TableCell>{t('251618')}</TableCell>
                <TableCell>{pisMultiLevelReceiveEnabled}</TableCell>
                </TableRow>
                </>)}
                {flagPmconfigstatus_RechargeRev&&(<>
                <TableRow>
                <TableCell>{t('251624')}</TableCell>
                <TableCell>{isRechargeReversal=='Y'?t('Y'):t('N')}</TableCell>
                </TableRow>
                <TableRow>
                <TableCell>{t('251625')}</TableCell>
                <TableCell>{isTransferReversal=='Y'?t('Y'):t('N')}</TableCell>
                </TableRow>
                </>)}
                        {!channelsSelectFlag && channelTransAl.length > 0 && (
                          <Table
                            size="small"
                            className={""}
                            stickyHeader
                            aria-label="sticky table"
                          >
                            <TableHead>
                              <TableRow
                                className={"darkgray subdistributor_table"}
                              >
                                <TableCell colSpan={2}>
                                  {t("251638")}
                                </TableCell>
                              </TableRow>
                            </TableHead>
                          </Table>
                        )}

                        {!channelsSelectFlag &&
                          channelTransAl.length > 0 &&
                          chunkedDataPreview.map((chunk, rowIndex) => (
                            <TableRow className="graydivider" key={rowIndex}>
                              {chunk.map((cellData, cellIndex) => (
                                <TableCell class="smallerTxt" key={cellIndex}>
                                  {cellData.topupTypeDesc + "-"}
                                  {cellData.transCategory}
                                </TableCell>
                              ))}
                            </TableRow>
                          ))}
                        {channelsSelectFlag && (
                          <TableRow>
                            <TableCell>{t("242467")}</TableCell>
                            <TableCell>{t("245678")}</TableCell>
                          </TableRow>
                        )}

                        <TableRow>
                          <TableCell>{t("251660")}</TableCell>
                          <TableCell>
                            {!bankReferenceNum ? "---" : bankReferenceNum}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251635")}</TableCell>
                          <TableCell>{parentBSUserName}</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251661")}</TableCell>
                          <TableCell>{pnegativeTransfers}</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251626")}</TableCell>
                          <TableCell>
                            {!psalesForceEnable ? "---" : psalesForceEnable}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251627")} </TableCell>
                          <TableCell>
                            {!psimtransenable ? "---" : psimtransenable}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{t("251628")}</TableCell>
                          <TableCell>
                            {!partnerSimThreshold
                              ? "---"
                              : partnerSimThreshold}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </TableContainer>
                  
                </Box>
                <br/> */}
                <div className={'accordion_sec distAccnt input_boxess rehargePreview '} ref={previewRef}>
                      <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel1-content"
                      id="panel1-header"
                    >
                    {t("1250")}

                    </AccordionSummary>
                    <AccordionDetails className={'general_accordion'}>
                   
<Grid container>
  <Grid item xs={3}>
  <TextField
                                  label={
                                    <span>
                                      {`${t('242435')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!partnerIdentity ? "---" : partnerIdentity}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  <Grid xs={3} item>
 <TextField
                                  label={
                                    <span>
                                      {`${t('242436')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!salesMdn ? "---" : salesMdn}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
 
  <Grid xs={3} item>
  <TextField
                                  label={
                                    <span>
                                      {`${t('082')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!partnerCompanyName ? "---" : partnerCompanyName}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  
  <Grid xs={3} item>
                                                        
                                                        <TextField
                                  label={
                                    <span>
                                      {`${t('251646')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!rucNo ? "---" : rucNo}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  
  
  
  <Grid xs={3} item>
  <TextField
                                  label={
                                    <span>
                                      {`${t('251652')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!partnerContactFirstName? "---" : partnerContactFirstName}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  <Grid xs={3} item>
 <TextField
                                  label={
                                    <span>
                                      {`${t('251653')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!partnerContactLastName
                              ? "---"
                              : partnerContactLastName}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  <Grid xs={3} item>
  <TextField
                                  label={
                                    <span>
                                      {`${t('242454')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!emailID ? "---" : emailID}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  
  <Grid xs={3} item>
  
  <TextField
                                  label={
                                    <span>
                                      {`${t('242442')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!ppaymentType ? "---" : ppaymentType}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  <Grid xs={3} item>
  
  <TextField
                                  label={
                                    <span>
                                      {`${t('251645')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={partnerTypeDesc}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  
 {postToSCLEnableFlag=='Y'&&(<>
  <Grid xs={3} item>
  
  <TextField
label={
<span>
{`${t('251603')}`}
</span>
}
disabled
InputLabelProps={{
shrink: true, // This will prevent label and value from overlapping
}}
size="15"
className={"sampleInput mb5"}
value={!sclUserName? "---":sclUserName}
type="text"
autocomplete="off"
id=""
/>
</Grid>
  <Grid xs={3} item>
  
                                                         <TextField
                                  label={
                                    <span>
                                      {`${t('063')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!sclCode? "---":sclCode}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  </>)}
 
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {t("251633")}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!AccountBalance ? "---" : AccountBalance}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {`${t('251620')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={currencyId}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {`${t('251660')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={!bankReferenceNum ? "---" : bankReferenceNum}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
  <Grid xs={3} item>
  <TextField
                            label={
                              <span>
                                {`${t('251635')}`}
                              </span>
                            }
                            disabled
                            InputLabelProps={{
                              shrink: true, // This will prevent label and value from overlapping
                            }}
                            size="15"
                            className={"sampleInput mb5"}
                            value={parentBSUserName}
                            type="text"
                            autocomplete="off"
                            id=""
                          />
  </Grid>
  <Grid xs={3} item>
  <TextField
                                  label={
                                    <span>
                                      {`${t('051')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!partnerParentId ? "---" : partnerParentId}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
</Grid>


                    </AccordionDetails>
                  </Accordion>
                  <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                    >
                      {t("1248")}
                    </AccordionSummary>
                    <AccordionDetails className={'address_accordion'}>
                    <Grid container>
                    <Grid item xs={3}>
                    <TextField
                                  label={
                                    <span>
                                      {`${t('242446')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={postalcheck}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                    </Grid>
                        </Grid>
                        <p className={'labelText'} style={{ color: '#39f', margin: "10px 0px 1px 0px",  fontWeight:'bold', fontSize:'12px' }}> {t("242448")}</p>
                      <p className={'labelText'} style={{ color: '#39f', margin: "1px 0" }}> {t("242449")}</p>
                      <Grid container>
                        <Grid xs={3} item style={{ position: 'relative' }}>
                     
                        <textarea
                                                          name="contaddress1"
                                                          className="textAreaSmall sampleInput mb5"
                                                          id="idContaddress1"
                                                          rows={4}
                                                          cols={40}
                                                          maxLength={512}
                                                           disabled
                                                          maxrows={15}
                                                          maxcols={40}
                                                          value={!contaddress1 ? "---" : contaddress1}
                                                          style={{    border: "1px solid #39f"}}
                                                        />
                        </Grid>
                        <Grid item xs={9}>
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("2424501")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="latitude"
                            className="sampleInput  mb5"
                            defaultValue=""
                            id="cLatitude"
                            readOnly="true"
                            style={{ width: `${latitude.length + 150}px`, marginRight: '5px' }}
                            // maxLength={20}
                            inputProps={{ maxLength: 20 }}
                            value={!latitude ? "---" : latitude}
                            onChange={(e) =>
                              setLatitude(
                                e.target.value
                              )
                            }
                          />
                        {/* </Grid>
                        <Grid item xs={3}> */}
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("2424502")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="longitude"
                            className="sampleInput mb5"
                            defaultValue=""
                            id="cLongitude"
                            readOnly="true"
                            style={{ width: `${longitude.length + 150}px`, marginRight: '5px' }}
                            // maxLength={20}
                            inputProps={{ maxLength: 20 }}
                            value={!longitude ? "---" : longitude}
                            onChange={(e) =>
                              setLongitude(
                                e.target.value
                              )
                            }
                          />
                        {/* </Grid>
                        <Grid item xs={3}> */}
                          <TextField
                            type="text"
                            label={
                              <span>
                                {`${t("251650")}`}
                              </span>
                            }
                            disabled
                            // InputLabelProps={{
                            //   shrink: true, 
                            // }}
                            name="contzipcode"
                            className="sampleInput mb5"
                            defaultValue=""
                            readOnly="true"
                            style={{ width: `${contzipcode.length + 100}px`, marginRight: '5px' }}
                            // maxLength={9}
                            inputProps={{ maxLength: 9 }}
                            id="idContzipcode"
                            value={!contzipcode ? "---" : contzipcode}
                            onChange={(e) =>
                              setContzipcode(
                                e.target.value
                              )
                            }
                          />
                        </Grid>
                        
                      </Grid>
                      <p className={'labelText'} style={{ color: '#39f', margin: '1px 0', fontWeight:'bold', fontSize:'12px' }}> {t("242453")}</p>
                      <p className={'labelText'} style={{ color: '#39f', margin: "1px 0" }}> {t("242449")}</p>
                      <Grid container>
                        <Grid item xs={3}>
                     
                        <textarea
                                                          name="billaddress1"
                                                          className="textAreaSmall sampleInput mb5 mb10"
                                                          id="idBilladdress1"
                                                          rows={4}
                                                          disabled
                                                          cols={40}
                                                          maxLength={512}
                                                          maxrows={15}
                                                          maxcols={40}
                                                          onKeyDown={(e) =>
                                                            notescheckCount(
                                                              e,
                                                              512
                                                            )
                                                          }
                                                          onKeyUp={(e) =>
                                                            notescheckCount(
                                                              e,
                                                              512
                                                            )
                                                          }
                                                          defaultValue={""}
                                                          value={!billaddress1 ? "---" : billaddress1}
                                                          onChange={(e) =>
                                                            setBilladdress1(
                                                              e.target.value
                                                            )
                                                          }
                                                          style={{    border: "1px solid #39f"}}
                                                        />
                          {/* <font color="red">*</font> */}
                        </Grid>
                        <Grid item xs={3}>
                         <TextField
                                  label={
                                    <span>
                                      {`${t('251650')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!billzipcode ? "---" : billzipcode}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                        </Grid>
                        
</Grid>
                     
                    </AccordionDetails>
                  </Accordion>
                  <Accordion defaultExpanded>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel3-content"
                      id="panel3-header"
                    >
                      {t("1249")}
                    </AccordionSummary>
                    <AccordionDetails>
                    <Grid container>
                      {parentIsSingleSrcFlagVal != 'Y' && (
                          <Grid item xs={3}>
                            
                            <TextField
                                  label={
                                    <span>
                                      {`${t('24246840')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!UOF?"---":UOF}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                          </Grid>
                        )}
                        
                        <Grid item xs={3}>
                          <TextField
                                  label={
                                    <span>
                                      {`${t('242457')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={pstatus}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                        </Grid>
                          <Grid item xs={3}>
                            
                            <TextField
                                  label={
                                    <span>
                                      {`${t('251626')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!psalesForceEnable ? "---" : psalesForceEnable}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                          </Grid>
                          <Grid item xs={3}>
                         <TextField
                                  label={
                                    <span>
                                      {`${t('251615')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={pisMultiLevlEnabled}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                        </Grid>
                        <Grid item xs={3}>
                         <TextField
                                  label={
                                    <span>
                                      {`${t('24246839')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!Maximumaccount ? "---" : Maximumaccount}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                        </Grid>
                       
                        <Grid item xs={3}>
                          <TextField
                                  label={
                                    <span>
                                      {`${t('251661')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={pnegativeTransfers}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                        </Grid>
                          <Grid item xs={3}>
                            <TextField
                                  label={
                                    <span>
                                      {`${t('251627')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!psimtransenable ? "---" : psimtransenable}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                          </Grid>
                        <Grid item xs={3}>
                        <TextField
                                  label={
                                    <span>
                                      {`${t('251628')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!partnerSimThreshold
                              ? "---"
                              : partnerSimThreshold}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                        </Grid>
               {flagPmconfigstatusMulti&&(<>

                        <Grid item xs={3}>
                         <TextField
                                  label={
                                    <span>
                                      {`${t('251616')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={pisMultiLevlRecEnabled}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                        </Grid>
</>)}
                        <Grid xs={3} item>
                        <TextField
                                  label={
                                    <span>
                                      {`${t('251634')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={!acctBalThresold ? "---" : acctBalThresold}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
  </Grid>
  
                       
                    
                       
                      

                        
                      
                        

                      
                
                            <Grid item xs={3}>
                             <TextField
                                  label={
                                    <span>
                                      {`${t('251622')}`}
                                    </span>
                                  }
                                  disabled
                                  InputLabelProps={{
                                    shrink: true, // This will prevent label and value from overlapping
                                  }}
                                  size="15"
                                  className={"sampleInput mb5"}
                                  value={pisLateralEnabled}
                                  type="text"
                                  autocomplete="off"
                                  id=""
                                />
                              </Grid>
                        
                           
                          {flagPmConfigStatusMultiTrans&&(<>

                            <Grid item xs={3}>
                             
                            <TextField
                              label={
                                <span>
                                  {`${t('251617')}`}
                                </span>
                              }
                              disabled
                              InputLabelProps={{
                                shrink: true, // This will prevent label and value from overlapping
                              }}
                              size="15"
                              className={"sampleInput mb5"}
                              value={pisMultiLevelTransferEnabled}
                              type="text"
                              autocomplete="off"
                              id=""
                            />
                            </Grid></>
                          )}
                          {flagPmconfigstatusSingle&&(<>
                          <Grid xs={3} item>
                              <TextField
                                label={
                                  <span>
                                    {`${t('251619')}`}
                                  </span>
                                }
                                disabled
                                InputLabelProps={{
                                  shrink: true, // This will prevent label and value from overlapping
                                }}
                                size="15"
                                className={"sampleInput mb5"}
                                value={pisSingleSrcEnabled}
                                type="text"
                                autocomplete="off"
                                id=""
                              /> 
                          </Grid>
                         </>)}

                        
                        {flagPmconfigstatus_RechargeRev && (<>
                          <Grid xs={3} item>
                            <TextField
                              label={
                                <span>
                                  {`${t('251624')}`}
                                </span>
                              }
                              disabled
                              InputLabelProps={{
                                shrink: true, // This will prevent label and value from overlapping
                              }}
                              size="15"
                              className={"sampleInput mb5"}
                              value={isRechargeReversal=='Y'?t('Y'):t('N')}
                              type="text"
                              autocomplete="off"
                              id=""
                            />
                          </Grid>
                        </>)}
                        {flagPmconfigstatus_RechargeRev && (<>
                          <Grid xs={3} item>
                            <TextField
                              label={
                                <span>
                                  {`${t('251625')}`}
                                </span>
                              }
                              disabled
                              InputLabelProps={{
                                shrink: true, // This will prevent label and value from overlapping
                              }}
                              size="15"
                              className={"sampleInput mb5"}
                              value={isTransferReversal=='Y'?t('Y'):t('N')}
                              type="text"
                              autocomplete="off"
                              id=""
                            />
                          </Grid>
                        </>)}
                                      
                          </Grid>
                          <Grid container>
                        <Grid item xs={3} style={{marginTop:'-7px'}}>
                          {/* {t('242467')} : */}
                         
                             <div
      className="parent-div"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{ marginBottom: '10px' }}
    >
      <span
        style={{ color: "#000", cursor: "pointer" }}
       
      >
        <ArrowRight className="animated-arrow" style={{ color: "#39f" }} /> 
        {t("1253")}
      </span>
      <div className={`scroll-list ${isHovered ? 'show' : ''}`} 
      // style={{ maxHeight: isHovered ? channelTransAl.length * 30 + 'px' : '0', transition: 'max-height 0.5s ease-in-out', overflow: 'hidden' }}
      style={{
        maxHeight: channelTransAl.length > 10
          ? '450px'  // Set a fixed max height for scrolling
          : isHovered 
          ? channelTransAl.length * 40 + 'px' 
          : '0',
        transition: 'max-height 0.5s ease-in-out',
        overflow: channelTransAl.length > 10 ? 'auto' : 'hidden'
      }}
     >
      {channelsSelectFlag ? (
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0' }}>
      <li className="smallerTxt"
        style={{
          color: "#000",
          fontFamily: "Arial, helvetica, sans-serif",
          fontSize: "12px",
          padding: '10px'
        }}>
        {t("245678")}
      </li>
    </ul>
  ) : channelTransAl.length > 0 ? (
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0' }}>
      {chunkedDataPreview.map((chunk, rowIndex) =>
        chunk.map((cellData, cellIndex) => (
          <li className="smallerTxt" key={cellIndex}>
            {cellData.topupTypeDesc + " - " + cellData.transCategory}
          </li>
        ))
      )}
    </ul>
  ) : (
    // Fallback for when channelsSelectFlag is false and no data in channelTransAl
    <ul style={{ paddingLeft: '10px', listStyleType: 'disc', marginBottom: '0', marginTop: '-18px' }}>
    <li className="smallerTxt"
      style={{
        color: "#000",
        fontFamily: "Arial, helvetica, sans-serif",
        fontSize: "12px",
        padding: '10px'
      }}>
      {t("1251")}
    </li>
    </ul>
  )}
      </div>
    </div>

                        
                        </Grid>
                       
                        

                      </Grid>
                    </AccordionDetails>
                  </Accordion>
                </div>
                <br />
                <Box className={"displayFlexCenter"} gap={1}>
                {!isProcessing?(<>
                  <Button
                    className={"hoverEffectButton"}
                    onClick={() => {
                      FinalSubmitSubmit();
                    }}
                    size="small"
                    variant="contained"
                    endIcon={<SendIcon />}
                  >
                    {t("242409")}
                  </Button>
                </>):(<>
                  <Button
                    className={"hoverEffectButton"}
                    size="small"
                    variant="contained"
                  >
                    {t("2424444")}
                  </Button>
                </>)}
                  <Button
                    className={"hoverEffectButton"}
                    size="small"
                    variant="contained"
                    onClick={() => {setPreview(false)
                      setIsProcessing(false)
                    }}
                    endIcon={<KeyboardReturn />}
                  >
                    {t("013")}
                  </Button>
                </Box>
              </form>
            </td>)}
          
          </tr>
          <tr height="60px">
            <td colSpan={2}>
              <link
                href="/airmanage/networkadmin/stylesheets/abcstyles-new.css"
                rel="stylesheet"
                type="text/css"
              />
              <Footer />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
