import React from 'react'
import { Footer, Header, JasperLeftMenu, JasperTopMenu, LeftBgImage, PaymentManagerHeading, PostPaidMenu } from './PageComponents'
import TopMenu from './TopMenu'
import { useState,useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import SendIcon from '@mui/icons-material/Send';
import {CancelRounded,KeyboardReturn} from '@mui/icons-material';
import i18n from './i18n';
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,Pagination } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { Box, Grid, TextField, Typography} from "@mui/material";
import ReactToPrint from "react-to-print";
import PrintIcon from '@mui/icons-material/Print';
import { useRef } from "react";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { DatePicker, DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import dayjs from 'dayjs';
import 'dayjs/locale/es'; // Spanish locale
import 'dayjs/locale/en'; // English locale (optional, dayjs default is English)

export default function PostpaidTransaction() {
  //sessionStorage.setItem("selectedIndex", 7);
  sessionStorage.setItem("selectedLink", "n_postpaidpayments");

  const {t} = useTranslation();
  let componentRef = useRef();
   const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
  console.log("exampleData LOGIN_ID====>"+exampleData.LOGIN_ID);

  
  const partnerId = exampleData.LOGIN_ID;

  const [mdn, setMdn] = useState('');
  const [sclcode, setSclcode] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [subscriberMDN, setSubscriberMDN] = useState('');
  const [startPageNo, setstartPageNo] = useState(1);
  const [endPageNo, setendPageNo] = useState(10);
  const [sortOrder, setSortOrder] = useState('DESC');
  const [sortedValue, setSortedValue] = useState('C_TRANSACTION_DATE');
  const [restrictChannel, setRestrictChannel] = useState('');
  const [postpaidtransactionList, setPostpaidtransactionList] = useState([]);
  const [postpaidtransactionPrintList, setPostpaidtransactionPrintList] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [selectedDateTime, setSelectedDateTime] = useState(null);
  const [startDateTime, setStartDateTime] = useState(null);
  const [endDateTime, setEndDateTime] = useState(null);
  const [dateValue, setDateValue] = useState(null);
  const [submit, setSubmit] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage] = useState(10);
  const [page, setPage] = useState(1);
console.log("postpaidtransactionList==="+postpaidtransactionList);
  const [maxValue, setMaxValue] = useState('4');
    const [totalRecords, setTotalRecords] = useState(0);
    const [recordsFound, setRecordsFound] = useState(0);
    const [perpage, setPerPage] = useState(10);
    const toastId = useRef(null);
       
  let startRecord=0;
  let endRecord =10;
  
    const handleStartDateTimeChange = (newValue) => {
      setStartDateTime(newValue); 
      console.log(newValue)
    };
  let localeVar=i18n.language;
    useEffect(() => {
      if (localeVar === 'en') {
        dayjs.locale('en'); // Set English locale
      } else {
        dayjs.locale('es'); // Set Spanish locale
      }
    }, [localeVar]); // Change the locale when localeVar changes

 
  console.log(localeVar);
 
 
  const reactToPrintTriggerRef = useRef();
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;

  const fetchData = async () => {
    try {
      // Fetch data from API
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_POSTPAIDTRANSACTIONREPORT_URL;
      const response = await axios.post(apiUrl, {
          userName,
         password,
        partnerId,
        mdn,
        sclcode,
        transactionId,
        fromDate,
        toDate,
        startPageNo:startRecord-1,
        endPageNo:endRecord < 10 ? '10' : endRecord,
        sortOrder,
        sortedValue,
        localeVar
      });
     
      const responseData = response.data;
      console.log("Response Data",responseData);
     
      setPostpaidtransactionList(responseData.reprintArray || []);
      setTotalRecords(responseData.totalRecords || 0);
      setRecordsFound(responseData.recordsFound || 0);
      
    } catch (error) {
      console.error("An error occurred:", error);
         }
  };
useEffect(() => {
       if (postpaidtransactionPrintList && reactToPrintTriggerRef.current) {
      reactToPrintTriggerRef.current.click();
    }
  }, [postpaidtransactionPrintList]);

  const handlePrintClick = async (transactionId, subscriberMDN) => {
    console.log("Print Preview for Transaction ID", transactionId, subscriberMDN);
    await fetchPrintData(transactionId, subscriberMDN);
  };

  const handleSubmit = async () => {
    try {
        // Validation logic
        if (new Date(endDateTime) < new Date(startDateTime)) {
            // toast.error("To Date cannot be before From Date");
            if(!toast.isActive(toastId.current) )  {
              toastId.current = toast.error(t('2480_078')); 
            }
            //toast.error(t('error.date'));
            return;
        }
       await fetchData(); // Assuming fetchData is an async function 

    } catch (error) {
        console.error("An error occurred:", error);
    }
    setSubmit(true);
};

  const navigate = useNavigate();
    const handleReturn = () => {
      // Go back to the previous page
      navigate(-1);
    }

  const clearData=()=>{
    setMdn('');
    setSclcode('');
    setTransactionId('');
    setEndDateTime(null); 
    setStartDateTime(null);
}
  const [triggerPrint, setTriggerPrint] = useState(false);

  const printPreview = async (transactionId, mdn) => {
    console.log("Print Preview for Transaction ID", transactionId, mdn);
    await fetchPrintData(transactionId, mdn);
    setTriggerPrint(true); // Set the trigger to true to initiate print
  };



  const fetchPrintData = async (transactionId, subscriberMDN) => {
    try {
      // Log the request parameters
      console.log("Fetching print data with params:", { partnerId, mdn, transactionId, localeVar });

      // Fetch data from API
    const apiPrintUrl = window.config.apiUrl + process.env.REACT_APP_POSTPAIDTRANSACTIONPRINT_URL;
      const printsResponse = await axios.post(apiPrintUrl, {
        userName,
        password,
        transactionId,
      mdn: subscriberMDN,
        localeVar,
        partnerId
      });

      const responsePrintData = printsResponse.data;
      console.log("Response Print Data:", responsePrintData);

      // Assuming postpaidtransactionPrintList is a function or a state setter
      setPostpaidtransactionPrintList(responsePrintData.printResult || []);
    } catch (error) {
      console.error("An error occurred while fetching print data:", error);
    }
};
var fromDate='';
if(startDateTime != null){
  var d = new Date(startDateTime);
  var month= d.getMonth()+1;

  var day = d.getDate();
  var year = d.getFullYear();
  var hours = d.getHours();
  var minutes = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;

  // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
  fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
  console.log("StartDate = "+ day + "/" + month + "/" + year + " " + hours + ":" + minutes);
}

var toDate='';
if(endDateTime != null){
  var d = new Date(endDateTime);
  var month2= d.getMonth()+1;
  var hours1 = d.getHours();
  var minutes1 = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours1 = hours1 < 10 ? '0' + hours1 : hours1;
  minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;

  toDate =  d.getDate() + "/" + month2 + "/" + d.getFullYear() + "" + hours1+ ""+ minutes1;
  console.log("EndDate = "+ d.getDate() + "/" +month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1);
}
const formatSpanishNumbers = (date) => {
    return new Intl.DateTimeFormat('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  const handleEndDateTimeChange = (newValue) => {
    setEndDateTime(newValue);
  };

  const handleChange = (e) => {
    const value = e.target.value;
    // Allow only digits and ensure the length is up to 10 characters
    if (/^\d{0,10}$/.test(value)) {
      setMdn(value);
    }
  };
  
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
   // fetchData();
  };
  const totalPages = Math.ceil(recordsFound / recordsPerPage);
  startRecord = (page - 1) * perpage + 1;
  endRecord =  recordsFound > 0 
  ? Math.min(startRecord + perpage - 1, recordsFound) 
  : (page === 1 ? 10 : page * perpage);

    // Get current date and time
    const currentDate = new Date();
    const formattedDate = currentDate.toLocaleDateString('en-US', {
      weekday: 'short', 
      year: 'numeric', 
      month: 'numeric', 
      day: 'numeric'
    });
    const formattedTime = currentDate.toLocaleTimeString('en-US', {
      hour: 'numeric', 
      minute: 'numeric'
    });
  
    useEffect(() => {
      // Set the browser title
        document.title = t('2472_026');
    }, []);

  return (
    <div>
    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
     <tbody>
         <Header/>
    <tr height="65px">
    <PaymentManagerHeading />
      <TopMenu menuLink= {localeVar==='en'?"PostPaid Payments":"Pagos de PostPago"}/>
    </tr>
    <tr>
     <LeftBgImage />

  <td valign="top">
  <title>Prepaid Movistar - Postpaid Transaction Report</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
  <tbody>
    <tr><JasperTopMenu /></tr>
    <tr>
     <td>
       <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
        <tbody>
                    {/* MIDDLE ROW STARTS */}
   <tr>
    {/* <td> */}
  <div className={'mL8 input_boxess'}>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
      <tbody>
       <tr valign="top">
         <td width="80%">
              {/* body starts */}
    <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center">
         <tr><td width="100%">
           <table border={0} bordercolor="green" width="100%"cellSpacing={0}align="left">
                     {/* <tr><td>&nbsp;</td></tr> */}
            <tr>
      <td align="center" width="100%"colSpan={10}>
    <table border={0} cellPadding={2} cellSpacing={2} width="100%" align="left"height="100%">
          <tbody>
    <td style={{ whiteSpace: 'nowrap', padding:'0', width:'33.5%' }} className="" align="left">
        

    <Box style={{display:'flex', gap:'20px', paddingTop:'7px'}}>
    <TextField className={'sampleInput mb5'}
      label={
        <span>
          {`${t('0120')}`}
        </span>} style={{width:'150px'}}  type="tel" name="mdn" value={mdn}
       onChange={handleChange}  maxLength={10}  pattern="\d{10}" defaultValue=""/>
       <TextField className={'sampleInput mb5'}
      label={
        <span>
          {`${t('0121')}`}
        </span>} style={{width:'165px'}} type="text" name="sclcode" value={sclcode} 
      onChange={e => {
        const value = e.target.value;
        // Allow only numbers and limit to 8 digits
        if (/^\d{0,8}$/.test(value)) {
          setSclcode(value);
        }
      }} 
  maxLength={8} // Optional since we already handle it in the onChange
  size="15" 
  defaultValue=""
/>
<TextField className={'sampleInput mb5'}
      label={
        <span>
          {`${t('0117')}`}
        </span>} style={{width:'180px'}} type="text" name="transactionId" value={transactionId} 
  onChange={e => {
    const value = e.target.value;
    // Allow only numbers and limit to 10 digits
    if (/^\d{0,10}$/.test(value)) {
      setTransactionId(value);
    }
  }} 
  maxLength={10} // Optional, for extra safety
  size="15" 
  defaultValue=""
/>
<LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                  style={{ maxWidth: '150px' }}
                  className={'datePickerrr'}
                  // label="Select Date and Time"
                  value={startDateTime}
                  onChange={handleStartDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
                  // label={t('80')} // This serves as the floating label
                  label={
                    <span>
                      {`${t('80')}`}
                    </span>}
                  inputFormat=" " // Keeps the input field empty unless a date is selected
                  renderInput={(params) => <TextField
                    {...params}
                    InputLabelProps={{
                      shrink: true, // Always shrink the label to allow for a floating effect
                    }}
                    placeholder={!startDateTime ? t('80') : ''} // Show the placeholder only if no date is selected
                    fullWidth
                    variant="outlined"
                    sx={{ width: "140px", height: "40px", padding: '20px' }}
                  />}
                />
                
              </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                <DateTimePicker
                  style={{ marginTop: '20px', maxWidth: '150px' }}
               className={'datePickerrr mt20'}
               label={
                <span>
                  {`${t('81')}`}
                </span>}
                  value={endDateTime}
                  onChange={handleEndDateTimeChange}
                  ampm={false} // Disable AM/PM, use 24-hour format
               renderInput={(params) => <TextField {...params} />} />

              </LocalizationProvider>
</Box>
{/* <Box style={{display :'flex', gap:'20px'}}> */}

              <Box className={''} style={{display :'flex', marginTop: '2px', gap:'8px'}}>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}
      onClick={handleSubmit}>{t('028')}</Button>
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CancelRounded />}
      onClick={clearData}>{t('003')}</Button>
   </Box>
    {/* </Box> */}
</td>
{/* <td>&nbsp;</td> */}

      </tbody>
    </table>
   
  </td>
  </tr>
    <tr><td width="100%">&nbsp;</td></tr>
  </table>
</td></tr>
</table>
 

<Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "15px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
                <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}
                > 
{recordsFound >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {recordsFound}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}


                {/* <span className={"strongerTxtLable"}>
                {t('032')} :  {recordsFound}
                </span>
                  <span className={"strongerTxtLable"}>
                  &nbsp; / &nbsp;
                   {t('033')} : {startRecord}-{endRecord}
                  </span> */}
                </Grid>
              </Grid>




  <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px', marginTop: '5px' }}>
  <Table sx={{ minWidth: 650 }} size="small" className={''} stickyHeader aria-label="sticky table"> 
    <TableHead>
      <TableRow className={'darkgray subdistributor_table'}> 
      <TableCell width="20%" className="whiteboldtext">{t('0117')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0118')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0119')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0120')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0121')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0122')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0123')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0124')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0125')}</TableCell>
      <TableCell width="20%" className="whiteboldtext">{t('0126')}</TableCell>
      </TableRow>
      </TableHead>  
      <TableBody>
  
  
  

      {submit ? (
  postpaidtransactionList.length === 0 ? (
    <TableRow align="center">
      <TableCell colSpan="10" className="redTxt" style={{ color: 'red' }} align="center">
        {t('4202')}
       
      </TableCell>
    </TableRow>
  ) : null
) : (
  <TableRow align="center">
    <TableCell colSpan="10" className="redTxt" style={{ color: 'red' }} align="center">
          {t('2025')}
    </TableCell>
  </TableRow>
)}

  {postpaidtransactionList.length > 0 ? (
  postpaidtransactionList.map((postpaidTransaction, index) => (
  <TableRow key={index}>
    <TableCell class="arlCtrBlk" align="center">{postpaidTransaction.transactionId}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{postpaidTransaction.transactiondate}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{postpaidTransaction.partnerId}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{postpaidTransaction.subscriberMDN}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{postpaidTransaction.subscribersclcode}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{postpaidTransaction.PaymentType}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{postpaidTransaction.PaymentAmount}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{postpaidTransaction.Totaltopay}</TableCell>
    <TableCell  class="arlCtrBlk" align="center">{postpaidTransaction.sclresponsedate}</TableCell>    
    <TableCell className="arlCtrBlk" align="center">     
      <Box className="displayFlexCenter" style={{gap:'8px'}}>
        
            <Button
              className="hoverEffectButton"
              size="small"
              variant="contained"
              endIcon={<PrintIcon />}
              
              disabled={postpaidTransaction.restrictChannel  !== 'yes'}
              onClick={() => handlePrintClick(postpaidTransaction.transactionId, postpaidTransaction.subscriberMDN)}
            >
              {t('62')}
            </Button>

      <ReactToPrint
        trigger={() => <button ref={reactToPrintTriggerRef} style={{ display: 'none' }}>Print</button>}
        content={() => componentRef.current}
        />
           
      </Box>
    </TableCell>
    
  </TableRow>
))
) : (
  <TableRow>
    
    </TableRow> 
)
} </TableBody>
    </Table>
    </TableContainer>
    <Box 
  className={'displayFlexCenter print-center-content postpaidTransactionReport flexDirectionColumn'} 
  ref={componentRef}
  style={{
    marginTop: '20px',
    paddingTop: '0',
    alignItems: 'center',
    justifyContent: 'flex-start',
    height: '100vh'
  }}
>

  {postpaidtransactionPrintList.map((post) => (
    <table>
      <tbody>
      <tr>
          <td colSpan="2" style={{ textAlign: 'center'}}>
          {t('63')}
          </td>
        </tr>

        <tr>
              <td colSpan="2" style={{ paddingTop: '30px', textAlign: 'right' }}>
                {/* Display current date and time */}
                {`${formattedDate} ${formattedTime}`}
              </td>
            </tr>
        <tr>
          <td colSpan="2" style={{ paddingTop: '60px', textAlign: 'center', fontWeight: 'bold', fontSize: '16px' }}>
          {t('64')}
          </td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_47')}:</td>
          <td>{post.partnerCompany}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_48')}:</td>
          <td>{post.mainDistContactAddress}</td> {/* You can replace ### with actual data if available */}
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_49')}:</td>
          <td>{post.rucno}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_50')}:</td>
          <td>{post.distCompanyName}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_51')}:</td>
          <td>{post.contactAddress}</td> {/* You can replace ### with actual data if available */}
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_52')}:</td>
          <td>{post.sclCode}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_53')}:</td>
          <td>{post.customername}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_54')}:</td>
          <td>{post.subscriberMDN}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_55')}:</td>
          <td>{post.transactionId}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_56')}:</td>
          <td>{post.transactionId}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_57')}:</td>
          <td>{post.billingAddress}</td> {/* You can replace ### with actual data if available */}
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_58')}:</td>
          <td>1</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_59')}:</td>
          <td>{post.paymentType}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_60')}:</td>
          <td>{`$${post.paymentAmount}`}</td>
        </tr>
        <tr>
          <td style={{fontWeight: 'bold'}}>{t('Reprint_61')}:</td>
          <td>{`$${post.paymentAmount}`}</td>
        </tr>
      </tbody>
    </table>
  ))}
</Box>

 <br/>
{postpaidtransactionList.length>0?<Pagination
count={totalPages}
page={page}
onChange={handleChangePage}
showFirstButton
showLastButton
/>: <></> }

 <table border={0}width="100%" cellSpacing={0} cellPadding={0}>
  <tbody>
    <tr>
     <td width="70%" className="strongerTxt"></td>
      <td width="30%" align="right">
      <Button className={'hoverEffectButton'} style={{marginTop: '15px'}} size="small" variant="contained" endIcon={<KeyboardReturn />}
       onClick={handleReturn}>{t('013')}</Button>
              </td></tr>
       <tr>&nbsp;</tr>
       </tbody>
      </table>
  </td></tr>
</tbody>
  </table>
  </div>
{/* </td> */}
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
 </table>
</td></tr>
</tbody>
</table>
</td></tr>
<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />



<tr height="60px"><td colSpan={2}>
      <Footer/>
      </td>
    </tr>
    </tbody>
</table>
    </div>
  )
}
