/* eslint-disable no-undef */
 /* eslint-disable react-hooks/exhaustive-deps */
 /* eslint-disable no-unused-vars */
 /* eslint-disable jsx-a11y/anchor-is-valid */
 /* eslint-disable react/jsx-no-comment-textnodes */
 /* eslint-disable no-script-url */
 /* eslint-disable jsx-a11y/alt-text */
 import React, { useState, useEffect , useRef,useCallback } from 'react';
 import { Footer, Header, JasperTopMenu, LeftBgImage, LeftBgImage1, PaymentManagerHeading, ReportsTopMenu, SubDistMenu, TransactionTopMenu } from './PageComponents'
 import TopMenu from './TopMenu'
 import axios from 'axios';
 import { Link, useNavigate,NavLink } from 'react-router-dom';
 import { useSelector } from 'react-redux';
 import { Box, Button, Grid, Pagination, Paper, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, Typography,TextField,MenuItem,FormControl ,InputLabel,Select,FormLabel,RadioGroup,FormControlLabel,Radio,Menu,styled  } from '@mui/material';
 import { KeyboardReturn,CloudDownload } from '@mui/icons-material';
 import i18n from './i18n';
 import { useTranslation } from 'react-i18next';
 import { CircularProgress } from '@mui/joy';
 import * as XLSX from 'xlsx';
 import { utils, writeFile } from 'xlsx';
 import ExcelJS from 'exceljs';
import SendIcon from '@mui/icons-material/Send';
import {CancelRounded} from '@mui/icons-material';
import { DatePicker, DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import SaveIcon from '@mui/icons-material/Save'; //Save
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle'; //Apply  As of now use these icons for buttons later if needed we will change 
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import dayjs from "dayjs";
// import 'jspdf-autotable';

const PendingTrans = () => {
    sessionStorage.setItem("selectedLink", "e_transactions");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
   const [recordsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
  const navigate = useNavigate();
 const toastId = useRef(null);

const [cellularNumber, setCellularNumber] = useState('');
const [salesPersonId, setSalesPersonId] = useState('');
const [distCellularNumber, setDistCellularNumber ] = useState('');
const [orderId, setOrderId] = useState('');
const [authorizationId, setAuthorizationId] = useState('');
const [transactionId , setTransactionId] = useState('');
const [canalId, setCanalId] = useState('');
const [terminalId, setTerminalId] = useState('');
const [sucursalId, setSucursalId] = useState('');


  const now = dayjs();  
  const midnightToday = dayjs().startOf('day');
  const [startDateTime, setStartDateTime] = useState(midnightToday);
  const [endDateTime, setEndDateTime] = useState(now);



const [channels, setChannels] = useState([]);
const [selectedChannel, setSelectedChannel] = useState(" ");

const [distributorType, setDistributorType] = useState(' ');
const [transactionType, setTransactionType] = useState(' ');
const [hierarchyMode, setHierarchyMode] = useState('N');

const [anchorEl, setAnchorEl] = useState(null);
const [submit, setSubmit] = useState(false);
 const closeTimeoutRef = useRef(null);
// const open = Boolean(anchorEl);

const orderIdRef = useRef(null);
const transactionIdRef = useRef(null);
const authorizationIdRef = useRef(null);

const [apply,setApply] =useState(false);


let reportDays = process.env.REACT_APP_ReportDays;


  console.log("totalRecords++++++++++++",totalRecords)
let startRecord=0;
  let endRecord =10;



  const styleObj = {
    minHeight: '30px',
    fontSize: '14px',
    padding: '7px 10px',
    maxHeight: '27px',
    margin: '10px 5px 5px 5px',
    borderRadius: '5px',
    color: '#1976d2',
    transition: '0.5s',
    opacity: '1',
    background: '#fff',
    color: '#3399FF',
    border: '1px solid #1976d2',
    textTransform: 'capitalize',
    "&:hover": {
      background: '#3399FF',
      color: '#fff',
      border: '1px solid #3399FF',
      borderRadius: '5px',
    },
   "&.Mui-selected": {
    color: '#fff',
    background: '#3399FF',border:' 1px solid #3399FF',
  }
  };

  const handleSubmit1 = async (e) => {
  e.preventDefault();

  try{

     if (orderId.trim() !== '' && !/^-?\d+$/.test(orderId)) {
          toast.error(`${t('alrt_02')} in ${t('2480_032')}.`);
         orderIdRef.current?.focus();
        return;
      }
       if (transactionId.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(transactionId)) {
        toast.error(`${t('alrt_01')} in ${t('2480_052')}.`);
        transactionIdRef.current?.focus();
        return;
      }
  
      if (authorizationId.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(authorizationId)) {
      toast.error(`${t('alrt_01')} in ${t('2480_033')}.`);
      authorizationIdRef.current?.focus();
      return;
     }
   
        //  const isValid = validateDateRange({
        //     startDateTime,
        //     endDateTime,
        //     reportDays,
        //     toast,
        //     toastId,
        //     t
        //   });

         const isValid = validateDateRange({
            startDateTime,
            endDateTime,
            reportDays,
            toast,
            toastId,
  t,
  // setStartDateTime,
  // setEndDateTime
          });
      
      
if (!isValid){
  setApply(false);
  return;
} 

  const firstPage = 1;
  setPage(firstPage);
  await fetchData(firstPage); // fetch data for page 1
   setSubmit(true);
   setApply(true);

 } catch (error) {
      console.error("An error occurred:", error);
    }

};

const clearData=()=>{
  setCellularNumber('');
  setSalesPersonId('');
  setDistCellularNumber('');
  setOrderId('');
  setAuthorizationId('');
  setTransactionId('');
  setCanalId('');
  setTerminalId('');
  setSucursalId('');
  setDistributorType(' ');
  setSelectedChannel(' ');
  setTransactionType(' ');
  setHierarchyMode('N');
  setEndDateTime(now); 
  setStartDateTime(midnightToday);
}

//date validation 
// const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
//   const start = new Date(startDateTime);
//   const end = new Date(endDateTime);
//   const oneDay = 1000 * 60 * 60 * 24
  
//   if (end < start) {
//     if (!toast.isActive(toastId.current)) {
//       toastId.current = toast.error(t('2480_078'));
   
//     }
//     return false;
//   }

//   const diffDays = Math.floor((end - start) / oneDay);
//   console.log("diffDays:", diffDays);

//   if (diffDays >= reportDays) {
//     if (!toast.isActive(toastId.current)) {
//       toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      

//     }
//     return false;
//   }

//   return true;
// };


const validateDateRange = ({
  startDateTime,
  endDateTime,
  reportDays,
  toast,
  toastId,
  t,
//  setStartDateTime, // pass your state setter for start date
//  setEndDateTime    // pass your state setter for end date
}) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24;
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
   
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
    }

    // Reset fromDate to today 00:00:00
    const todayMidnight = new Date();
    todayMidnight.setHours(0, 0, 0, 0);
      
    // Reset toDate to current date and time
    const now = new Date();

    // Update state
   //   setStartDateTime(dayjs().startOf('day')); // today midnight
   // setEndDateTime(dayjs()); // now

    return false;
  }

  return true;
};

const handleStartDateTimeChange = (newValue) => {
    setApply(false);
      setStartDateTime(newValue); 
      console.log(newValue)
    };

var fromDate='';
if(startDateTime != null){
  var d = new Date(startDateTime);
  var month= d.getMonth()+1;

  var day = d.getDate();
  var year = d.getFullYear();
  var hours = d.getHours();
  var minutes = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;

  // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
  fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
  console.log("StartDate = "+ day + "/" + month + "/" + year + " " + hours + ":" + minutes);
}

var toDate='';
if(endDateTime != null){
  var d = new Date(endDateTime);
  var month2= d.getMonth()+1;
  var hours1 = d.getHours();
  var minutes1 = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours1 = hours1 < 10 ? '0' + hours1 : hours1;
  minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;

  toDate =  d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1;
  console.log("EndDate = "+ d.getDate() + "/" +month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1);
}
const formatSpanishNumbers = (date) => {
    return new Intl.DateTimeFormat('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  const handleEndDateTimeChange = (newValue) => {
    setApply(false);
    setEndDateTime(newValue);
  };

  // useEffect(() => {
  //   if (partnerLoginId) {
  //     // fetchData();
  //   }
  // }, [partnerLoginId, [page]]);



  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);


//  debugger;
  const fetchData = async (pageNumber = 1) => {
  const startRecord = (pageNumber - 1) * perpage + 1;
  const endRecord = startRecord + perpage - 1;



    setIsLoading(true);
    try {

      
   

      const apiUrl = window.config.apiUrlJasper+ '/pendingTransactions';
    //  const apiUrl = window.config.apiUrl + process.env.REACT_APP_PENDING_TRANSACTION_REPORT;
      const response = await axios.post(apiUrl, {          
        userName,
        password,
        localeVar,
        subscriberId : cellularNumber,
        subdistId : salesPersonId,
        partnerId : partnerLoginId,
        salespersonMdn : distCellularNumber,
        orderId,
        authorizationId,
        transactionId : transactionId,
        canalId,
        orderType : transactionType,
       initiatorTypeId : distributorType,
        terminalId,
        sucursalId,
        replenishChnl: selectedChannel === ' ' ? null : selectedChannel,
        transactionCategory :transactionType === ' ' ? null : transactionType,
        transFromDate: fromDate?.trim() === '' ? null : fromDate,
        transToDate: toDate?.trim() === '' ? null : toDate,
        levelFlag : hierarchyMode,
        startPageNo: startRecord,
        endPageNo: endRecord
      
       });
        
      console.log("response::::::",response.data);
      if (response.status === 200 && Array.isArray(response.data)) {
       setItems(response.data);
       setTotalRecords(response.data[0]?.noOfRows ?? 0); // Safely get noOfRows
      
    }
  } catch (error) {
    console.error('An error occurred:', error);
  } finally {
    setIsLoading(false);
  }
};
//  debugger;
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

 
  const fetchDataDownload = async () => {

const isValid = validateDateRange({
            startDateTime,
            endDateTime,
            reportDays,
            toast,
            toastId,
            t,
          });
      
          if (!isValid) return;


if(!apply){

if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('apply_validation'));
     setSubmit(false);
    }
return false;

}




    try {
      const userName = process.env.REACT_APP_USERNAME;
      const password = process.env.REACT_APP_PASSWORD;

      const apiUrlDownload = window.config.apiUrlJasper+ '/pendingTransactions';

      const response = await axios.post(apiUrlDownload, {
        userName,
        password,
        localeVar,
        subscriberId : cellularNumber,
        subdistId : salesPersonId,
        partnerId : partnerLoginId,
        salespersonMdn : distCellularNumber,
        orderId,
        authorizationId,
        transactionId : transactionId,
        canalId,
        orderType : transactionType,
        initiatorTypeId : distributorType,
        terminalId,
        sucursalId,
        replenishChnl: selectedChannel === ' ' ? null : selectedChannel,
        transactionCategory :transactionType === ' ' ? null : transactionType,
        transFromDate: fromDate?.trim() === '' ? null : fromDate,
        transToDate: toDate?.trim() === '' ? null : toDate,
        levelFlag : hierarchyMode,
           
       
       
        startPageNo: 0,
        endPageNo: 0,
        download: "Y"
      });

        if (!Array.isArray(response.data)) {
      throw new Error('Invalid API response: Expected array');
    }

       return response.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };

  const exportAsExcel = async () => {
    const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('pendingTransactions');

    const numberOfColumns = 27;
    const headingRow1 = worksheet.addRow([t('2472_47')]);
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    headingRow1.getCell(1).font = { bold: true };
    headingRow1.getCell(1).alignment = { horizontal: 'center' };
    worksheet.addRow([]);
  
    const columnHeaders = [
      t('2472_03'), t('023'), t('2472_52'),t('2472_04'), t('2481_014'), t('2472_53'), t('2472_10'), t('2472_11'),
      t('2472_12'), t('2472_13'), t('2472_14'),t('2472_06'), t('2472_05'), t('2472_07'), t('2480_084'), t('2472_15'),
      t('251620'), t('2472_16'), t('6814'),t('2472_17'), t('2472_18'), t('2472_19'), t('2472_20'), t('2472_21'),
      t('2472_22'), t('2472_23'), t('2480_048')
    ];

const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;

// Create a new row with only 2 values: left and right
const sameLineRow = worksheet.addRow(
  Array(numberOfColumns).fill('') // Fill the entire row with empty cells
);

// Set left-side label (first cell)
const leftCell = sameLineRow.getCell(1);
leftCell.value = `${t('032')}: ${totalRecords}`; // e.g., "Total: 100"
leftCell.font = { bold: true };
leftCell.alignment = { horizontal: 'left' };

// Set right-side label (last cell)
// const rightCell = sameLineRow.getCell(numberOfColumns);
// rightCell.value = `${t('033')}: ${totalRecords}`; // e.g., "Displayed: 100"
// rightCell.font = { bold: true };
// rightCell.alignment = { horizontal: 'right' };





    const headerRow = worksheet.addRow(columnHeaders);
    
    headerRow.height = 25;

    headerRow.eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' }, left: { style: 'thin' },
        bottom: { style: 'thin' }, right: { style: 'thin' },
      };
    });

    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
      item.orderId,
      item.orderDate,
      item.transactionID,
      item.authorizationID,
      item.subscriberId,
      item.distributorId,
      item.hierarchyLevel,
      item.parentName,
      item.mainPartnerName,
      item.salespersonMdn,
      item.initiatorID,
      item.terminalId,
      item.canalId,
      item.sucursalID,
      item.orderType,
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      item.currency,
      item.orderStateId,
      item.replenishmentChannelId,
     
      item.transactionCategory,
      item.promotionPlanName,
      item.altamiraPlan,
      item.packetCode,
      typeof item.feeAmount === 'number' ? item.feeAmount.toFixed(2) : "---",
      typeof item.airtime === 'number' ? item.airtime.toFixed(2) : "---",
      typeof item.debitAmount === 'number' ? item.debitAmount.toFixed(2) : "---",
      typeof item.insuranceAmount === 'number' ? item.insuranceAmount.toFixed(2) : "---"
      ]);
       dataRow.eachCell(cell => {
      cell.border = {
        top: { style: 'thin' }, left: { style: 'thin' },
        bottom: { style: 'thin' }, right: { style: 'thin' },
      };
      cell.alignment = { horizontal: 'center' };
    });
  });

  worksheet.addRow([]);
  const endOfReportRow = worksheet.addRow([t('0171')]);
  worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
  const endOfReportCell = endOfReportRow.getCell(1);
  endOfReportCell.font = { italic: true, underline: true, bold: true };
  endOfReportCell.alignment = { horizontal: 'center' };

  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 1); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });

  worksheet.protect('yourPassword', {
    selectLockedCells: true,
    selectUnlockedCells: true,
  });

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });

  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'Pending_Transactions_Report.xlsx';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


const exportAsPdf = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  // Use A2 for wider space to fit all columns
  const doc = new jsPDF({
    orientation: 'landscape',
     format: [500, 1000],
    unit: 'pt'
  });

  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;

  const displayedRecords = downloadItems.length;

const pageWidth = doc.internal.pageSize.getWidth();

  // Heading
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text(t('2472_47'), doc.internal.pageSize.getWidth() / 2, 40, { align: 'center' });

  // Total records
  doc.setFontSize(10);
  doc.setFont(undefined, 'normal');
  doc.text(`${t('032')}: ${totalRecords}`, 40, 60);


  // Right: Displayed Records
const displayText = `${t('033')}: ${displayedRecords}`;
const textWidth = doc.getTextWidth(displayText);
doc.text(displayText, pageWidth - 40 - textWidth, 60); // Right-aligned at 40pt margin

  const columnHeaders = [
    t('2472_03'), t('023'), t('2472_52'), t('2472_04'), t('2481_014'), t('2472_53'), t('2472_10'), t('2472_11'),
    t('2472_12'), t('2472_13'), t('2472_14'), t('2472_06'), t('2472_05'), t('2472_07'), t('2480_084'), t('2472_15'),
    t('251620'), t('2472_16'), t('6814'), t('2472_17'), t('2472_18'), t('2472_19'), t('2472_20'), t('2472_21'),
    t('2472_22'), t('2472_23'), t('2480_048')
  ];

  const rows = downloadItems.map(item => [
    item.orderId,
    item.orderDate,
    item.transactionID,
    item.authorizationID,
    item.subscriberId,
    item.distributorId,
    item.hierarchyLevel,
    item.parentName,
    item.mainPartnerName,
    item.salespersonMdn,
    item.initiatorID,
    item.terminalId,
    item.canalId,
    item.sucursalID,
    item.orderType,
    typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
    item.currency,
    item.orderStateId,
    item.replenishmentChannelId,
   
    item.transactionCategory,
    item.promotionPlanName,
    item.altamiraPlan,
    item.packetCode,
    typeof item.feeAmount === 'number' ? item.feeAmount.toFixed(2) : "---",
    typeof item.airtime === 'number' ? item.airtime.toFixed(2) : "---",
    typeof item.debitAmount === 'number' ? item.debitAmount.toFixed(2) : "---",
    typeof item.insuranceAmount === 'number' ? item.insuranceAmount.toFixed(2) : "---"
  ]);

  
  // 1. Summary row table
doc.autoTable({
  startY: 50,
  head: [[
    {
      content: `${t('032')}: ${totalRecords}`,
      colSpan: Math.floor(columnHeaders.length / 2),
      styles: {
        halign: 'left',
        fillColor: [51, 153, 255],
        textColor: [255, 255, 255],
        fontSize: 6
      }
    },

  ]],
  body: [],
  margin: { left: 10, right: 10 }
});

// 2. Add more vertical space manually
const verticalGap = 1; // increase this for more space (10pt ≈ 3.5mm)
const startDataTableY = doc.lastAutoTable.finalY + verticalGap;

// 3. Main table with data
  doc.autoTable({
  startY: startDataTableY,
    head: [columnHeaders],
    body: rows,
    styles: {
    fontSize: 5,
    overflow: 'linebreak',
    cellPadding: { top: 2, bottom: 2, left: 1, right: 1 } // optional row padding
    },
    headStyles: {
      
      fillColor: [51, 153, 255],
      halign: 'center',
    fontSize: 6,
    textColor: [255, 255, 255]
    },
    theme: 'grid',
  margin: { left: 10, right: 10 }
  });

  doc.setFontSize(10);
  doc.setFont(undefined, 'italic');
  doc.text(t('0171'), doc.internal.pageSize.getWidth() / 2, doc.lastAutoTable.finalY + 20, { align: 'center' });

  doc.save('Pending_Transactions_Report.pdf');
};

const exportAsCSV = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  const numberOfColumns = 27;

  const columnHeaders = [
    t('2472_03'), t('023'), t('2472_52'), t('2472_04'), t('2481_014'), t('2472_53'), t('2472_10'), t('2472_11'),
    t('2472_12'), t('2472_13'), t('2472_14'), t('2472_06'), t('2472_05'), t('2472_07'), t('2480_084'), t('2472_15'),
    t('251620'), t('2472_16'), t('6814'), t('2472_17'), t('2472_18'), t('2472_19'), t('2472_20'), t('2472_21'),
    t('2472_22'), t('2472_23'), t('2480_048')
  ];

  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;

  // CSV Rows
  const rows = [];

  // Add title

 const title = t('2472_47');
 const leftPadding = Math.floor((numberOfColumns - 1) / 2);
  const titleRow = Array(leftPadding).fill('').concat(title).concat(Array(numberOfColumns - leftPadding - 1).fill(''));
  rows.push(titleRow);

  // rows.push([t('2472_47')]);
  // rows.push([]);

  // Add total records
  rows.push([`${t('032')}: ${totalRecords}`]);
  rows.push([]);

  // Add headers
  rows.push(columnHeaders);

   const formatAmount = (value) => {
  const num = parseFloat(value);
 return !isNaN(num) ? `="${num.toFixed(2)}"` : `"0.00"`;
};

  // Add data rows
  downloadItems.forEach(item => {
    rows.push([
      item.orderId,
      item.orderDate,
      item.transactionID,
      item.authorizationID,
      item.subscriberId,
      item.distributorId,
      item.hierarchyLevel,
      item.parentName,
      item.mainPartnerName,
      item.salespersonMdn,
      item.initiatorID,
      item.terminalId,
      item.canalId,
      item.sucursalID,
      item.orderType,
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      item.currency,
      item.orderStateId,
      item.replenishmentChannelId,
     
      item.transactionCategory,
      item.promotionPlanName,
      item.altamiraPlan,
      item.packetCode,
      typeof item.feeAmount === 'number' ? item.feeAmount.toFixed(2) : "---",
      typeof item.airtime === 'number' ? item.airtime.toFixed(2) : "---",
      typeof item.debitAmount === 'number' ? item.debitAmount.toFixed(2) : "---",
      typeof item.insuranceAmount === 'number' ? item.insuranceAmount.toFixed(2) : "---"
    ]);
  });

  // Add end-of-report
  rows.push([]);


   const endRep = t('0171');
  const endleftPadding = Math.floor((numberOfColumns - 1) / 2);
  const endtitleRow = Array(endleftPadding).fill('').concat(endRep).concat(Array(numberOfColumns - endleftPadding - 1).fill(''));
  rows.push(endtitleRow);

  // rows.push([t('0171')]);

  let csvContent = rows
  .map(row =>
    row.map(val => {
      const strVal = String(val ?? '').trim();

      // Format floats and date-like strings for Excel-safe display
      if (/^\d{1,3}(,\d{3})*(\.\d{2})?$/.test(strVal) || /^\d+\.\d{2}$/.test(strVal)) {
        return `="${strVal}"`; // Excel-safe numeric text
      } else if (/^\d{2}\/\d{2}\/\d{4}/.test(strVal)) {
        return `="${strVal}"`; // Excel-safe date
      } else {
        return `"${strVal.replace(/"/g, '""')}"`;
      }
    }).join(',')
  )
  .join('\n');

  const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;

  // Download as .csv
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'Pending_Transactions_Report.csv';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


 const handleDownload = async (type) => {
  setAnchorEl(null);
  if (type === 'excel') {
    await exportAsExcel();
  } else if (type === 'pdf') {
    await exportAsPdf();
  } else if (type === 'csv') {
     await exportAsCSV();
  }
};



  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);


const handleChangePage = async (event, newPage) => {
  event.preventDefault();
const isValid = validateDateRange({
            startDateTime,
            endDateTime,
            reportDays,
            toast,
            toastId,
            t,
          });
      
          if (!isValid) return;


          if(!apply){
          
          if (!toast.isActive(toastId.current)) {
                toastId.current = toast.error(t('apply_validation'));
               setSubmit(false);
              }
          return false;
          
          }

  setPage(newPage);
  await fetchData(newPage); // fetch data for the selected page
};

const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}



 const repChannels = async () => {
    try {
      const apiUrl = window.config.apiUrlJasper+ '/replenishmentChannels';
      const response = await axios.post(apiUrl, {
        userName,
        password,
        localeVar,
        
      });

      console.log('Channel API response:', response.data);

      if (Array.isArray(response.data)) {
        setChannels(response.data);
      } else {
        console.error('Expected array, got:', response.data);
        setChannels([]); // Set empty to avoid error
      }
    } catch (error) {
      console.error('Error fetching channels:', error);
    }
  };

// debugger;
useEffect(() => {
  repChannels();
}, []);

 const handleHierarchyChange = (event) => {
    const selectedValue = event.target.value;
    setHierarchyMode([selectedValue]); // Store as array like you mentioned
  };

   const RedAsterisk = styled('span')({
    color: 'red',
  });

   const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };
 
  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };


return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Transactions":"Transacciones"}/>
  </tr>

  <tr>
   
  <div style={{ display: 'flex' }}> 
    <LeftBgImage1 />
</div>
<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
   <NavLink
            to="/pendingtransactions"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab label={t('e_pendingtransactions')} /></NavLink>
   </Tabs>
  </Box>
    {/* <Tabs indicatorColor="none" style={{minHeight: '35px', paddingTop:'5px'}}>
    <Tab sx={styleObj} label={"MVNE Report"} /></Tabs> */}
    <div className={'mL8 input_boxess'}>

     <tr valign="top">
       <td width="80%">
            {/* body starts */}

          
<table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" style={{ marginTop: '15px' }}>
  <tbody>
    <tr>
      <td width="100%">
        <table border={0} borderColor="green" width="100%" cellSpacing={0} align="left">
          <tbody>
            {/* Spacer row (optional) */}
           
            {/* Input Fields Row */}
            <tr>
              <td>
                <Box style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                 
                  <TextField
                    label={t('2472_60')}
                    size="15"
                    className={"sampleInput mb5"}
                    style={{ maxWidth: '250px', width: '150px' }}
                    onChange={e => setCellularNumber(e.target.value)}
                     name="cellularNumber"
                    value={cellularNumber}
                    type="text"
                    autoComplete="off"
                  />

                  <TextField
                    type="text"
                    name="salesPersonId"
                    label={<span>{`${t('2472_01')}`}</span>}
                    style={{ maxWidth: '300px', width: '235px' }}
                    className={'sampleInput mb5'}
                    value={salesPersonId}
                    onChange={e => setSalesPersonId(e.target.value)}
                    autoComplete="off"
                  />

                  <TextField
                    type="text"
                    name="distCellularNumber"
                    label={<span>{`${t('2472_02')}`}</span>}
                    style={{ maxWidth: '250px', width: '200px' }}
                    className={'sampleInput mb5'}
                    value={distCellularNumber}
                    onChange={e => setDistCellularNumber(e.target.value)}
                    autoComplete="off"
                  />

                   <TextField
                   inputRef={orderIdRef}
                    type="text"
                    name="orderId"
                    label={<span>{`${t('2472_03')}`}</span>}
                    style={{ maxWidth: '250px', width: '150px' }}
                    className={'sampleInput mb5'}
                    value={orderId}
                    onChange={e => setOrderId(e.target.value)}
                    autoComplete="off"
                  />

                  <TextField
                   inputRef={authorizationIdRef}
                    type="text"
                    name="authorizationId"
                    label={<span>{`${t('2472_04')}`}</span>}
                    style={{ maxWidth: '250px', width: '150px' }}
                    className={'sampleInput mb5'}
                    value={authorizationId}
                    onChange={e => setAuthorizationId(e.target.value)}
                    autoComplete="off"
                  />

                </Box>
              </td>
            </tr>

            <tr>
              <td>
                <Box style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                  <TextField
                    inputRef={transactionIdRef}
                    type="text"
                    name="transactionId"
                    label={t('2472_52')}
                    style={{ maxWidth: '250px', width: '150px' }}
                    className={"sampleInput mb5"}
                    value={transactionId}
                    onChange={e => setTransactionId(e.target.value)}
                    autoComplete="off"
                  />

                  <FormControl className={'selected_formcontrol'} sx={{  minWidth: 120 }} size="small">
      <InputLabel id="demo-select-small-label" sx={{
      backgroundColor: '#fff',
      padding: '0 5px',
    }}>{t('6814')}</InputLabel>
      <Select className={'bankSelect'} 
                    style={{ maxWidth: '250px', width: '235px' }}
      labelId="demo-select-small-label" 
      id="demo-select-small"
       
        value={selectedChannel}
        label="Select Channel"
        onChange={(e) => setSelectedChannel(e.target.value)}
      >
        <MenuItem value=" ">---</MenuItem>

  {/* Dynamic options from backend */}
  {channels.map((channel) => (
    <MenuItem key={channel.value} value={channel.value}>
      {channel.label}
    </MenuItem>
  ))}
</Select>
    </FormControl>

                  <TextField
                    type="text"
                    name="terminalId"
                    label={<span>{`${t('2472_06')}`}</span>}
                    style={{ maxWidth: '250px', width: '200px' }}
                    className={'sampleInput mb5'}
                    value={terminalId}
                    onChange={e => setTerminalId(e.target.value)}
                    autoComplete="off"
                  />

                  <TextField
                    type="text"
                    name="sucursalId"
                    label={<span>{`${t('2472_07')}`}</span>}
                    style={{ maxWidth: '250px', width: '150px' }}
                    className={'sampleInput mb5'}
                    value={sucursalId}
                    onChange={e => setSucursalId(e.target.value)}
                    autoComplete="off"
                  />


<FormControl className={'selected_formcontrol'} sx={{  minWidth: 120 }} size="small">
      <InputLabel id="demo-select-small-label" sx={{
      backgroundColor: '#fff',
      padding: '0 5px',
    }}>{t('2472_59')}</InputLabel>

      <Select className={'bankSelect'} style={{ maxWidth: '250px', width: '150px' }} labelId="demo-select-small-label" id="demo-select-small"
      label="distributorType"value={distributorType} onChange={e => setDistributorType(e.target.value)}>
        <MenuItem value=" " selected>---</MenuItem>
        <MenuItem value="6">{t('3045')}</MenuItem>
        <MenuItem value="5">{t('2480_017')}</MenuItem>
      </Select>
    </FormControl>
</Box>
</td>
</tr>

          <tr>
              <td>

                
<Box style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>




   <TextField
                    type="text"
                    name="canalId"
                    label={<span>{`${t('2472_05')}`}</span>}
                    style={{ maxWidth: '250px', width: '150px' }}
                    className={'sampleInput mb5'}
                    value={canalId}
                    onChange={e => setCanalId(e.target.value)}
                    autoComplete="off"
                  />





                <FormControl className={'selected_formcontrol'} sx={{  minWidth: 120 }} size="small">
                      <InputLabel id="demo-select-small-label" sx={{
                      backgroundColor: '#fff',
                      padding: '0 5px',
                    }}>{t('2472_58')}</InputLabel>

                      <Select className={'bankSelect'} style={{ maxWidth: '250px', width: '235px' }} labelId="demo-select-small-label" id="demo-select-small"
                      label="transactionType"value={transactionType} onChange={e => setTransactionType(e.target.value)}>
                        <MenuItem value=" " selected>---</MenuItem>
                        <MenuItem value="1">{t('2472_08')}</MenuItem>
                        <MenuItem value="7">{t('2472_09')}</MenuItem>
                      </Select>
                    </FormControl>

           
          

           
           

           <FormControl className={'selected_formcontrol'} sx={{  minWidth: 120 }} size="small">
                      <InputLabel id="demo-select-small-label" sx={{
                      backgroundColor: '#fff',
                      padding: '0 5px',
                    }}>{t('2472_25')}<RedAsterisk>*</RedAsterisk></InputLabel>

                      <Select className={'bankSelect'} style={{ maxWidth: '250px', width: '200px' }} labelId="demo-select-small-label" id="demo-select-small"
                      label="hierarchyMode"value={hierarchyMode} onChange={e => setHierarchyMode(e.target.value)}>
                        {/* <MenuItem value="A" selected>{t('2472_29')}</MenuItem> */}
                        <MenuItem value="N" selected>{t('2616021')}</MenuItem>
                        <MenuItem value="Y">{t('2616020')}</MenuItem>
                      </Select>
                    </FormControl>



           <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                           <DateTimePicker
                             style={{ maxWidth: '140px' }}
                             className={'datePickerrr'}
                    
                             value={startDateTime}
                             onChange={handleStartDateTimeChange}
                             ampm={false} // Disable AM/PM, use 24-hour format
                           
                             label={
                               <span>
                                 {`${t('80')}`}
                                 <RedAsterisk>*</RedAsterisk>
                               </span>}
                               format="DD/MM/YYYY HH:mm:ss"
                             inputFormat=" " // Keeps the input field empty unless a date is selected
                             renderInput={(params) => <TextField
                               {...params}
                               InputLabelProps={{
                                 shrink: true, // Always shrink the label to allow for a floating effect
                               }}
                               placeholder={!startDateTime ? t('80') : ''} // Show the placeholder only if no date is selected
                               fullWidth
                               variant="outlined"
                               sx={{ width: "140px", height: "40px", padding: '20px' }}
                             />}
                           />
                           
                         </LocalizationProvider>
                       <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                           <DateTimePicker
                             style={{ marginTop: '20px', maxWidth: '140px' }}
                          className={'datePickerrr mt20'}
                          label={
                           <span>
                             {`${t('81')}`}
                             <RedAsterisk>*</RedAsterisk>
                           </span>}
                           format="DD/MM/YYYY HH:mm:ss"
                             value={endDateTime}
                             onChange={handleEndDateTimeChange}
                             ampm={false} // Disable AM/PM, use 24-hour format
                          renderInput={(params) => <TextField {...params} />} />
           
                         </LocalizationProvider>

           
                 
              <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
                  <Button
                    style={{ height: '27px' }}
                    className={'hoverEffectButton'}
                    size="small"
                    variant="contained"
                    endIcon={<CheckCircleIcon />}
                    onClick={handleSubmit1}
                  >
                    {t('2472_26')}
                  </Button>

                    <Button
                    style={{ height: '27px' }}
                    className={'hoverEffectButton'}
                    size="small"
                    variant="contained"
                     endIcon={<RestartAltIcon />}
                    onClick={clearData}
                  >
                    {t('2472_27')}
                  </Button>

                   </Box>
                </Box>
              </td>
            </tr>

            {/* Submit Button Row */}
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>





      <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
  item
  xs={5}
  sx={{ textAlign: "right", padding: "0 !important" }}
>
  {items.length > 0 ? (
    <>
      <span className={"strongerTxtLable"}>
        {t('032')} : {totalRecords}
      </span>
      <span className={"strongerTxtLable"}>
        &nbsp; / &nbsp;
        {t('033')} : {startRecord} - {endRecord}
      </span>
    </>
  ) : null}
</Grid>

              </Grid>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
          <TableRow className="darkgray">
            <TableCell align="center">{t('2472_03')}</TableCell>
            <TableCell align="center">{t('023')}</TableCell>
            <TableCell align="center">{t('2472_52')}</TableCell>
            <TableCell align="center">{t('2472_04')}</TableCell>
            <TableCell align="center">{t('2481_014')}</TableCell>
            <TableCell align="center">{t('2472_53')}</TableCell>
            <TableCell align="center">{t('2472_10')}</TableCell>
           <TableCell align="center">{t('2472_11')}</TableCell>
            <TableCell align="center">{t('2472_12')}</TableCell>
            <TableCell align="center">{t('2472_13')}</TableCell>
            <TableCell align="center">{t('2472_14')}</TableCell>
            <TableCell align="center">{t('2472_06')}</TableCell>
            <TableCell align="center">{t('2472_05')}</TableCell>
            <TableCell align="center">{t('2472_07')}</TableCell>
            <TableCell align="center">{t('2480_084')}</TableCell>
            <TableCell align="center">{t('2472_15')}</TableCell>
            <TableCell align="center">{t('251620')}</TableCell>
            <TableCell align="center">{t('2472_16')}</TableCell> 

            <TableCell align="center">{t('6814')}</TableCell> 
            <TableCell align="center">{t('2472_17')}</TableCell> 



             <TableCell align="center">{t('2472_18')}</TableCell> 
             <TableCell align="center">{t('2472_19')}</TableCell> 
             <TableCell align="center">{t('2472_20')}</TableCell> 
             <TableCell align="center">{t('2472_21')}</TableCell> 
             <TableCell align="center">{t('2472_22')}</TableCell> 
             <TableCell align="center">{t('2472_23')}</TableCell> 
             <TableCell align="center">{t('2480_048')}</TableCell> 
             
          </TableRow>
        </TableHead>
        <TableBody>
  {isLoading ? (
    <TableRow>
      <TableCell colSpan={25} align="center" className="spinnerDiv">
        {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
      </TableCell>
    </TableRow>
  ) : Array.isArray(items) && items.length > 0 ? (
    items.map((item, index) => (
      <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
       
        <TableCell align="center">&nbsp;{item.orderId}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.orderDate}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.transactionID}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.authorizationID}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.subscriberId}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.distributorId}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.hierarchyLevel}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.parentName}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.mainPartnerName}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.salespersonMdn}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.initiatorID}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.terminalId}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.canalId}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.sucursalID}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.orderType}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{typeof item.orderAmount === 'number' ? item.orderAmount .toFixed(2) : "---"}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.currency}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.orderStateId}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.replenishmentChannelId}&nbsp;</TableCell>
         <TableCell align="center">&nbsp;{item.transactionCategory}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.promotionPlanName}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.altamiraPlan}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.packetCode}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{typeof item.feeAmount === 'number' ? item.feeAmount .toFixed(2) : "---"}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{typeof item.airtime === 'number' ? item.airtime .toFixed(2) : "---"}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{typeof item.debitAmount === 'number' ? item.debitAmount .toFixed(2) : "---"}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{typeof item.insuranceAmount === 'number' ? item.insuranceAmount.toFixed(2) : "---"}&nbsp;</TableCell>

      </TableRow>
    ))
  ) : (
    <TableRow>
      <TableCell colSpan={25} className="redTxt" style={{ color: 'red' }} align="center">
         {submit ? t("7058") : t("2472_57")} 
      </TableCell>
    </TableRow>
  )}
</TableBody>


      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
{/* <Box style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}> */}
  <Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', width: '100%' }}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
   
      <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
       {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,style: { minWidth: 85 }
                                                 }}
                                                 PaperProps={{
                                                  sx: { minWidth: 85, mt: 1.2 },
                                                }}
                                               >
                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownload('pdf'); }}> {t("2472_54")}</MenuItem>
                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownload('excel'); }}> {t("2472_55")}</MenuItem>
                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownload('csv'); }}> {t("2472_56")}</MenuItem>
                                          </Menu>
                                             </div>
                                              : <></>}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
 </td></tr>
</div>

</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>

<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  )
}

export default PendingTrans
