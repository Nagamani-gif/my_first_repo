
import React, { useState, useEffect, useRef } from 'react';
import { Footer } from './PageComponents'
import { Link } from 'react-router-dom';
import Button from '@mui/material/Button';
import SendIcon from '@mui/icons-material/Send';
import { useTranslation } from 'react-i18next';
import { KeyboardReturn, CancelRounded, LoginOutlined } from '@mui/icons-material';
import Navbar from './Navbar';
import { useLocation } from "react-router-dom";
import i18n from './i18n';
import { Box, FormControl, InputLabel, MenuItem, Select, TextField,styled } from '@mui/material';
import { useDispatch } from 'react-redux';
import { logoutUser } from '../reducers/exampleSlice';
import { useNavigate } from 'react-router-dom';




const ExpireSoonPage = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const { daysleft } = location.state || {}; // Extract 'daysleft' from state

  const validDaysLeft = !daysleft || daysleft.length === 0 ? "0" : daysleft;
  sessionStorage.setItem('fromExpSoon','fromExpSoon');

  let localeVar = i18n.language === "es" ? "es" : "en";
      let tempSession =localStorage.getItem("sessionId");
      let firstName=localStorage.getItem( "firstName");
      let lastName =localStorage.getItem("secondName");
      const [logoutHide, setLogoutHide] = useState(false);
       const dispatch = useDispatch();
   const navigate = useNavigate();
        const handleLogout =()=>{
          dispatch(logoutUser());
          setLogoutHide(true);
          navigate('/logout');
        }      

  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          <table border={0} cellPadding={0} cellSpacing={0} width="100%">
            
            <tbody>

              <Navbar />
              {(tempSession!=null && !logoutHide) ?
      (<Box style={{width: '100%'}} className={'displayFlex'}>
      <font color="#808080" face="Arial" style={{fontSize: '8pt'}}>
                        {t('welcome')}            
                       {/* | */}
                     </font><b className="loginTextSmall">
                     &nbsp; {firstName} {lastName}
                       {/* TODO <LoginName />*/}</b>
                       &nbsp;|&nbsp;
     <span style={{display: 'flex', cursor: 'pointer', textDecoration: 'none'}} className="langLink logoutButton" onClick={handleLogout} >{t("logout")} <LoginOutlined style={{    width: '15px',
     height: '15px',
     marginLeft: '3px'}} /></span>
     </Box>): ''
    }
              <tr > <td height="176" font-weight="bold" > </td></tr>
              
              <tr >
                <td height="22" class="redTxt" align="center" >
                <b>{t('25160006')}{ validDaysLeft } {t('25160007')}</b>
                </td></tr>
               {localeVar === 'en' ? 
              <tr>
                <td height="22" class="redTxt" align="center"><b>
                  If you want to change password now, Click on  <font color="#000000">{t('changepassword')}</font> Button.</b>
                </td>
              </tr> :
              <tr>
                <td height="22" class="redTxt" align="center"><b>
                Si quieres cambiar tu contraseña este momento. Da clic en el botón <font color="#000000">{t('changepassword')}</font> </b>
                </td>
              </tr>}
              {localeVar === 'en' ? 
              <tr>
                <td height="22" class="redTxt" align="center" ><b>

                Otherwise click on <font color="#000000">{t('continue')}</font> Button.</b>
                </td>
              </tr> :
               <tr>
               <td height="22" class="redTxt" align="center" ><b>
               Caso contrario dar clic en el botón <font color="#000000">{t('continue')}</font></b>
               </td>
             </tr> }
             
            </tbody>
          </table>




          <center><br />
            <Link to={"/changepasswordpage"}>
              <Button style={{ marginRight: '10px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}>{t('242401')}</Button><td></td>
            </Link>

            <Link to={"/home"}>
              <Button style={{ marginRight: '10px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}>{t('25160008')}</Button>
            </Link>
            <br></br>
          </center>

          <tr height="60px"><td colSpan={2}>
            <Footer />
          </td>
          </tr>
        </tbody>
      </table>
    </div>
  )
};

export default ExpireSoonPage;




