import { Footer, Header, JasperTopMenu, LeftBgImage, PaymentManagerHeading, ReportsTopMenu, SubDistMenu, TransactionTopMenu } from './PageComponents'

import { KeyboardReturn, CloudDownload } from '@mui/icons-material';
import { Box, Button, Menu, Grid, Pagination, Paper, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, Typography, TextField, FormControl, InputLabel, Select, MenuItem, styled } from '@mui/material';

import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import TopMenu from './TopMenu'

import i18n from './i18n';

import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'

import { useState, useEffect, useRef } from 'react';

import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

import { CircularProgress } from '@mui/joy';

import axios from 'axios';

import ExcelJS from 'exceljs';

import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
import dayjs from "dayjs";
import { toast, ToastContainer } from "react-toastify";
    import jsPDF from 'jspdf';
import 'jspdf-autotable';
import React from 'react';


const AccountStatusReport = () => {

    sessionStorage.setItem("selectedLink", "e_transactions");

    const { t } = useTranslation();
    const navigate = useNavigate();

    const localeVar = i18n.language;

    const exampleData = JSON.parse(localStorage.getItem("userData"))

    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;

      const[hasSubmitted,setSubmit] =useState(false);
    

    const [partnerLoginId, setPartnerLoginId] = useState(exampleData.LOGIN_ID);

    const [authorizationId, setAuthorizationId] = useState('');

        const now = dayjs();  
        const midnightToday = dayjs().startOf('day');

   const [startDateTime, setStartDateTime] = useState(midnightToday);
    const[startDate,setStartDate] = useState(midnightToday.format('DD/MM/YYYY HH:mm:ss'));
    const [endDateTime, setEndDateTime] = useState(now);
    const [endDate, setEndDate] = useState(now.format('DD/MM/YYYY HH:mm:ss'));
    const [isLoading, setIsLoading] = useState(false);

    const [items, setItems] = useState([]);
    const toastId = useRef(null);

    const [totalRecords, setTotalRecords] = useState(0);
    const [recordsPerPage] = useState(10);

    const [page, setPage] = useState(1);
    const [perpage, setPerPage] = useState(10);

    const [anchorEl, setAnchorEl] = useState();
    const closeTimeoutRef = useRef(null);
      let reportDays = process.env.REACT_APP_ReportDays;

      const [hierarchyMode, setHierarchyMode] = useState('N');

      const [showTotal,setShowTotal] = useState(false);

      console.log("show total",showTotal);

      const [totalDepositAmount, setTotalDepositAmount] = useState(0.0);
      const [totalCreditAmount, setTotalCreditAmount] = useState(0.0);

        const [apply,setApply] =useState(false);


  let startRecord=0;
  let endRecord =10;

   const RedAsterisk = styled('span')({
      color: 'red',
    });

    const handleHover = (event) => {
        clearTimeout(closeTimeoutRef.current);
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        closeTimeoutRef.current = setTimeout(() => {
            setAnchorEl(null);
        }, 200); // 200ms delay to prevent flicker
    };


  useEffect(() => {
  if (!hasSubmitted) return;
  fetchData();           // runs every time `page` changes
}, [page,hasSubmitted]);



const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
   
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      

    }
    return false;
  }

  return true;
};

    const handleEndDateTimeChange = (newValue) => {
    setApply(false);
    setEndDateTime(newValue);
    const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
    setEndDate(formattedDateTime);
  };
    const handleStartDateTimeChange = (newValue) => {
      setApply(false);
      setStartDateTime(newValue); 
     const formattedDateTime = newValue ? newValue.format('DD/MM/YYYY HH:mm:ss') : null;
     setStartDate(formattedDateTime);
      console.log("startDate::::::",newValue)
       console.log("startDate::::::",formattedDateTime)
    };





const formatter = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }, {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

const exportAsPdf = async () => {
  const { downloadData, totalRecords, totalDepositAmt, totalCreditAmt } = await fetchDataDownload();

  if (!downloadData || downloadData.length === 0) {
    return;
  }

  const doc = new jsPDF({
    orientation: 'landscape',
    format: [500, 1000],
    unit: 'pt'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const displayedRecords = downloadData.length;
  const firstItem = downloadData[0];

  // ===== Title =====
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text(t('z_accountstatusreportp'), pageWidth / 2, 40, { align: 'center' });

  // ===== Summary line =====
  doc.setFontSize(10);
  doc.setFont(undefined, 'normal');
  const displayText = `${t('033')}: ${displayedRecords}`;
  const textWidth = doc.getTextWidth(displayText);
  doc.text(`${t('032')}: ${totalRecords}`, 40, 60);
  //doc.text(displayText, pageWidth - 40 - textWidth, 60);

  // ===== Partner info row =====
  doc.autoTable({
    startY: 70,
    head: [[
      t('partner'),
      t('1146'), // Company Name
      t('allocatedCreditLimit'),
      t('initialAccountBalance'),
      t('011') // Current Balance
    ]],
    body: [[
      partnerLoginId,
      firstItem.partnerCompanyName || '—',
      // `$ ${firstItem.creditLimit.toFixed(2)}`,
      // `$ ${firstItem.initialValue.toFixed(2)}`,
      // `$ ${firstItem.currentAccBal.toFixed(2)}`
      
`${formatter.format(firstItem.creditLimit)}`,
`${formatter.format(firstItem.initialValue)}`,
`${formatter.format(firstItem.currentAccBal)}`
    ]],
    styles: {
      fontSize: 8,
      halign: 'center'
    },
    headStyles: {
      fillColor: [51, 153, 255],
      textColor: [255, 255, 255],
      fontSize: 8
    },
    theme: 'grid',
    margin: { left: 10, right: 10 }
  });

  // ===== Transaction table =====
  const startY = doc.lastAutoTable.finalY + 10;

  const columnHeaders = [
            t('transactionNumber'),
            t('authorizationId'),
    t('1241'), // Date
            t('time'),
            t('description'),
            t('transactionAmount'),
            t('charge'),
    t('011') // Balance
  ];

  var rows = downloadData.map(item => [
    item.transactionID || '—',
    item.authorizationID || '—',
    item.transactionDate,
    item.transactionTime,
    item.transactionMode || '—',
    formatter.format(item.transferAmount),
     formatter.format(item.creditAmount) ,
    formatter.format(item.initialValue) 
  ]);
  
  var total = ['','','','',t('total'),formatter.format(totalDepositAmt), formatter.format(totalCreditAmt),''];

  rows.push(total);

  doc.autoTable({
    startY,
    head: [columnHeaders],
    body: rows,
    styles: {
      fontSize: 6,
      overflow: 'linebreak',
      cellPadding: { top: 2, bottom: 2, left: 1, right: 1 },
      textColor: [0,0,0]
    },
    headStyles: {
      fillColor: [51, 153, 255],
      halign: 'center',
      fontSize: 6,
      textColor: [255, 255, 255]
    },
    theme: 'grid',
    margin: { left: 10, right: 10 }
  });

  // ===== Footer ("End of Report") =====
  doc.setFontSize(10);
  doc.setFont(undefined, 'italic');
  doc.text(t('0171'), pageWidth / 2, doc.lastAutoTable.finalY + 20, { align: 'center' });

  doc.save('Account_Status_Report.pdf');
};



const exportAsExcel = async () => {
  const { downloadData, totalRecords, totalDepositAmt, totalCreditAmt } = await fetchDataDownload();

  if (!downloadData || downloadData.length === 0) {
    return;
  }

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Account_Status_Report');
  const numberOfColumns = 8;

  // Title
  const headingRow1 = worksheet.addRow([t('z_accountstatusreportp')]);
  worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
  headingRow1.getCell(1).font = { bold: true };
  headingRow1.getCell(1).alignment = { horizontal: 'center' };
  worksheet.addRow([]);


  const infoRow = worksheet.addRow([]);

  worksheet.mergeCells(infoRow.number, 1, infoRow.number, 3);

  infoRow.getCell(1).value = `${t('032')}: ${totalRecords}`;

  worksheet.addRow([]);

  // Summary Header Row
  const headerRow0 = worksheet.addRow([
    t('partner'),
    t('1146'), // Company Name
    t('allocatedCreditLimit'),
    t('initialAccountBalance'),
    t('011') // Current Balance
  ]);

  headerRow0.eachCell(cell => {
    cell.font = { bold: true };
    cell.alignment = { horizontal: 'center' };
    cell.border = {
      top: { style: 'thin' },
      left: { style: 'thin' },
      bottom: { style: 'thin' },
      right: { style: 'thin' }
    };
  });

  // Summary Data Row
  const firstItem = downloadData[0];
  const dataRow0 = worksheet.addRow([
    partnerLoginId,
    firstItem.partnerCompanyName,
`${formatter.format(firstItem.creditLimit)}`,
`${formatter.format(firstItem.initialValue)}`,
`${formatter.format(firstItem.currentAccBal)}`
  ]);
  dataRow0.eachCell(cell => {
    cell.border = {
      top: { style: 'thin' },
      left: { style: 'thin' },
      bottom: { style: 'thin' },
      right: { style: 'thin' }
    };
    cell.alignment = { horizontal: 'center' };
  });

  worksheet.addRow([]);

  // Transaction Table Headers
  const columnHeaders = [
    t('transactionNumber'),
    t('authorizationId'),
    t('1241'), // Date
    t('time'),
    t('description'),
    t('transactionAmount'),
    t('charge'),
    t('011') // Balance
        ];
  const headerRow = worksheet.addRow(columnHeaders);
  headerRow.eachCell(cell => {
    cell.font = { bold: true };
    cell.alignment = { horizontal: 'center' };
    cell.border = {
      top: { style: 'thin' },
      left: { style: 'thin' },
      bottom: { style: 'thin' },
      right: { style: 'thin' }
    };
  });

  // Transaction Data Rows
  downloadData.forEach(item => {
    const dataRow = worksheet.addRow([
                item.transactionID,
                item.authorizationID,
                item.transactionDate,
                item.transactionTime,
                item.transactionMode,
                formatter.format(item.transferAmount),
                formatter.format(item.creditAmount) ,
                formatter.format(item.initialValue) 

                // "$"+Number(item.transferAmount).toFixed(2),
                // item.creditAmount < 0 ? "-$"+Number(Math.abs(item.creditAmount)).toFixed(2) : "$"+Number(item.creditAmount).toFixed(2),
                // item.initialValue < 0 ? "-$"+Number(Math.abs(item.initialValue)).toFixed(2) : "$"+Number(item.initialValue).toFixed(2)
    ]);

    dataRow.eachCell(cell => {
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
      cell.alignment = { horizontal: 'center' };
    });
        });
  
  worksheet.addRow(['', '', '', '', t('total'),formatter.format(totalDepositAmt), formatter.format(totalCreditAmt),''])

  // Footer
  worksheet.addRow([]);
  const endRow = worksheet.addRow([t('0171')]);
  worksheet.mergeCells(endRow.number, 1, endRow.number, columnHeaders.length);
  const endCell = endRow.getCell(1);
  endCell.font = { italic: true, underline: true, bold: true };
  endCell.alignment = { horizontal: 'center' };

  // Column widths
  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });

  // Download file
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'Account_Status_Report.xlsx';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
        };



const formatTime = (val) => {
  if (!val || val.trim() === "") return "";

  const [hh = "00", mm = "00", ss = "00"] = val.split(":");

  return `${hh.padStart(2,"0")}:${mm.padStart(2,"0")}:${ss.padStart(2,"0")}`;

};




const exportAsCSV = async () => {
  const { downloadData, x, totalDepositAmt, totalCreditAmt} = await fetchDataDownload();
  if (!downloadData || downloadData.length === 0) {
    return;
  }

  // const headingText = t('z_accountstatusreportp');

  // const headingRowArray = Array(totalColumns).fill('');
  // headingRowArray[centerIndex] = headingText;

  const header = [
            t('transactionNumber'),
            t('authorizationId'),
    t('1241'), // Date
            t('time'),
            t('description'),
            t('transactionAmount'),
            t('charge'),
    t('011') // Balance
        ];

  const rows = downloadData.map(item => [
                item.transactionID,
                item.authorizationID,
                item.transactionDate,
                formatTime(item.transactionTime),
                item.transactionMode,
                "$"+Number(item.transferAmount).toFixed(2),
                item.creditAmount < 0 ? "-$"+Number(Math.abs(item.creditAmount)).toFixed(2) : "$"+Number(item.creditAmount).toFixed(2),
                item.initialValue < 0 ? "-$"+Number(Math.abs(item.initialValue)).toFixed(2) : "$"+Number(item.initialValue).toFixed(2)
  ]);

  const totalColumns = header.length;          // total number of columns in your CSV
const centerIndex = Math.floor(totalColumns / 2);

// Function to create a centered row
const makeCenteredRow = (text) => {
  const row = Array(totalColumns).fill('');
  row[centerIndex] = text;
  return row;
};

  let csvContent = [
    makeCenteredRow(t('z_accountstatusreportp')),
    [],
    [t('032')+":"+rows.length],
    [],
    [t('partner'), t('1146'), t('allocatedCreditLimit'), t('initialAccountBalance'), t('011')],
    [partnerLoginId, downloadData[0].partnerCompanyName, `$ ${downloadData[0].creditLimit}`, `$ ${downloadData[0].initialValue}`, `$ ${downloadData[0].currentAccBal}`],
    [],
    header,
    ...rows,
    ['', '', '', '', t('total'), "$"+Number(totalDepositAmt).toFixed(2), totalCreditAmt < 0 ? `-$${Math.abs(totalCreditAmt).toFixed(2)}` : `$${totalCreditAmt.toFixed(2)}`, ''],
    [],
    makeCenteredRow(t('0171'))
  ]
    .map(e => e.map(field => `"${field}"`).join(','))
    .join('\n');

        // Create a Blob and trigger download
const BOM = '\uFEFF'; // UTF-8 BOM
csvContent = BOM + csvContent;

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'Account_Status_Report.csv';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };



    var fromDate = '';
    if (startDateTime != null) {
        var d = new Date(startDateTime);
        var month = d.getMonth() + 1;

        var day = d.getDate();
        var year = d.getFullYear();
        var hours = d.getHours();
        var minutes = d.getMinutes();

        // Ensure that hours and minutes are always two digits
        hours = hours < 10 ? '0' + hours : hours;
        minutes = minutes < 10 ? '0' + minutes : minutes;

        // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
        fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
        console.log("StartDate = " + day + "/" + month + "/" + year + " " + hours + ":" + minutes);
    }

    var toDate = '';
    if (endDateTime != null) {
        var d = new Date(endDateTime);
        var month2 = d.getMonth() + 1;
        var hours1 = d.getHours();
        var minutes1 = d.getMinutes();

        // Ensure that hours and minutes are always two digits
        hours1 = hours1 < 10 ? '0' + hours1 : hours1;
        minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;

        toDate = d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1 + ":" + minutes1;
        console.log("EndDate = " + d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1 + ":" + minutes1);
    }




const handleSubmit1= (e)=>{

      e.preventDefault(); 

        startRecord = 1;
        endRecord = 10;

        setPage(1);

      try {

    if (authorizationId.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(authorizationId)) {
      toast.error(`${t('alrt_01')} in ${t('2472_04')}.`);
      return;
    }
  
   const isValid = validateDateRange({
              startDateTime,
              endDateTime,
              reportDays,
              toast,
              toastId,
              t
            });

    if (!isValid){
  setApply(false);
  return;
} 
     
  
        fetchData();
        setSubmit(true);
       setApply(true);
      } catch (error) {
        console.error("An error occurred:", error);
      }
        
    }


    useEffect(() => {
        // Set the browser title
        document.title = t('z_accountstatusreportp')
    }, []);

    // let startRecord = (page - 1) * perpage + 1;
    // let endRecord = totalRecords > 0
    //     ? Math.min(startRecord + perpage - 1, totalRecords)
    //     : (page === 1 ? 10 : page * perpage);


    const clearData = () => {

        setStartDateTime(midnightToday);
        setEndDateTime(now)
       setAuthorizationId('');
       setHierarchyMode('N');
       setStartDate(midnightToday.format('DD/MM/YYYY HH:mm:ss'))
       setEndDate(now.format('DD/MM/YYYY HH:mm:ss'))

    }


    const fetchData = async () => {

        // const startRecordNo = (page - 1) * perpage + 1;
        // const endRecordNo = startRecord + perpage - 1;

        localStorage.removeItem('channels');
        setIsLoading(true);
        try {
            // const apiUrl = window.config.apiUrl + process.env.REACT_APP_ACCOUNT_STATUS_REPORT;
            const apiUrl = window.config.apiUrlJasper+ '/accountStatusReport'
            const response = await axios.post(apiUrl, {
                userName,
                password,
                partnerId: partnerLoginId,
                authorizationId,
                localeVar,
                transFromDate: startDate,
                transToDate: endDate,
                levelFlag:hierarchyMode,
                startPageNo: startRecord,
                endPageNo: endRecord < 10 ? '10' : endRecord,
                download:'N'

            });
            //alert('response', response)
            //console.log("response::::::", response);
            console.log("response.data.accountStatusReportList::::::", response.data);
            console.log("noOfRows===", parseInt(response.data.noOfRecord));
            if (response.status === 200) {
                setItems(response.data.accountStatusReportList);
                setTotalRecords(response.data.noOfRecord);
                setShowTotal(response.data.showTotal);
                console.log("in response, show total", response.data.showTotal);
                setTotalDepositAmount(response.data.depositAmount);
                setTotalCreditAmount(response.data.creditAmount);
            }
        } catch (error) {
            console.error('An error occurred:', error);
        } finally {
            setIsLoading(false);
        }
    };



    const fetchDataDownload = async () => {

       const isValid = validateDateRange({
             startDateTime,
             endDateTime,
             reportDays,
             toast,
             toastId,
             t,
             hasSubmitted
           });
       
        if (!isValid) {
        setSubmit(false);  // reset submit flag
        return;
      }
      
      if(!apply){
      
      if (!toast.isActive(toastId.current)) {
            toastId.current = toast.error(t('apply_validation'));
           setSubmit(false);
          }
      return false;
      
      }


        try {
    const apiUrlDownload = window.config.apiUrlJasper + '/accountStatusReport';
            console.log('API URL:', apiUrlDownload);

    const response = await axios.post(apiUrlDownload, {
                userName,
                password,
                partnerId: partnerLoginId,
                authorizationId,
                localeVar,
                transFromDate:startDate,
                transToDate: endDate,
                download: 'Y' // optional flag to signal full data
            });

    const reportList = response?.data?.accountStatusReportList;
    const totalRecords = response?.data?.noOfRecord || reportList?.length || 0;

    const totalDepositAmt = response?.data?.depositAmount;
    const totalCreditAmt = response?.data?.creditAmount;


    console.log("reportList ", reportList);
    console.log("total deposit amount ", totalDepositAmt);
    console.log("total credit amount ", totalCreditAmt);

    if (!reportList || reportList.length === 0) {
      throw new Error('No data available for PDF download');
            }

    const downloadData = reportList.map(item => ({
                transactionID: item.transactionID,
                authorizationID: item.authorizationID,
      transactionDate: item.transactionDate?.split(" ")[0] || '—',
      transactionTime: item.transactionDate?.split(" ")[1] || '—',
          transactionMode:                                                                            
                          item.transactionMode != null ?
                          item.transactionMode === "Change of Parent" ? t('18273')  :
                          item.transactionMode === "Funds Recoup" ? t('18274')  :
                          item.transactionMode === "Distributor Retire" ? t('18275')  :
                          item.transactionMode === "Distributor Payments" ? t('18276')  :
                          item.transactionMode === "Reversal" ? t('18277')  :
                          item.transactionMode === "SFS Job Update" ? t('18278')  :
                          item.transactionMode === "Recharge" ? t('18279')  :
                          item.transactionMode === "Usage Fee" ? t('18280')  :
                          item.transactionMode === "Credit Limit Changed" ? t('18281')  :
                          item.transactionMode === "Credit Limit Change" ? t('18282')  :
                          item.transactionMode : "---",
      transferAmount: item.depositeAmt ?? 0,
      creditAmount: item.creditAmount ?? 0,
      currentAccBal: item.currentAccBal ?? 0,
                partnerCompanyName: item.partnerCompanyName,
      creditLimit: item.creditLimit ?? 0,
      initialValue: item.initialValue ?? 0
            }));

    return { downloadData, totalRecords, totalDepositAmt, totalCreditAmt};
        } catch (error) {
    console.error('Error fetching download data:', error);
    return { downloadData: [], totalRecords: 0 };
        }
    };

    
  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);

  startRecord = Math.min(startRecord, endRecord);
  
    const handleChangePage = (event, newPage) => {

       const isValid = validateDateRange({
             startDateTime,
             endDateTime,
             reportDays,
             toast,
             toastId,
             t,
             hasSubmitted
           });
       
        if (!isValid) {
        setSubmit(false);  // reset submit flag
        return;
      }
      
      if(!apply){
      
      if (!toast.isActive(toastId.current)) {
            toastId.current = toast.error(t('apply_validation'));
           setSubmit(false);
          }
      return false;
      
      }
        setPage(newPage);
    };



    console.log("totalRecords", totalRecords);
    console.log("recordsPerPage", recordsPerPage);
    console.log("totalPages", totalPages);

     const handleDownload = async (type) => {
  setAnchorEl(null);
  if (type === 'excel') {
    await exportAsExcel();
  } else if (type === 'pdf') {
    await exportAsPdf();
  } else if (type === 'csv') {
     await exportAsCSV();
  }
            };
  

    const handleReturn = () => {
        navigate(-1);
    };

    const highlightSelectedLink = (e) => {
        var x = document.querySelector(".subLinkVisited");
        if (x !== null) {
            x.classList.replace("subLinkVisited", "subLink");
        }
        e.target.classList.replace("subLink", "subLinkVisited");
    }






    return (

        <div>
            <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <Header />
                <tr height="65px">
                    <PaymentManagerHeading />
                    <TopMenu menuLink={localeVar === 'en' ? "Account Status Report" : "Informe de estado de cuenta"} />
                </tr>

                <tr>
                    <LeftBgImage />
                    <td valign='top'>
                        <title>Prepaid Movistar - Port In Report</title>
                        <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                            <tbody>
                                <tr>
                                    <td>
                                        <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" height="100%">
                                                            <tbody>
                                                                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
                                                                    <Tabs style={{ minHeight: '35px' }}>
                                                                        <NavLink
                                                                            to="/accountstatusreportp"
                                                                            onClick={(e) => highlightSelectedLink(e)}

                                                                            className={({ isActive }) =>
                                                                                isActive ? 'activeProfilemenu' : 'profile_menu '}
                                                                        >
                                                                            <Tab label={t('z_accountstatusreportp')} />
                                                                        </NavLink>
                                                                    </Tabs>
                                                                </Box>
                                                           <div className={'mL8 input_boxess'}>

                                                                <tr valign="top">
                                                                    <td width="80%">
                                                                        {/* body starts */}
            
                                                                            <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{ marginTop: '5px' }}>
                                                                                <Box style={{ display: 'flex', gap: '12px', marginTop: '10px' }}>
                                                                                    <TextField size="12" type="text" name="authorizationId"
                                                                                     className={'sampleInput mb5'}
                                                                                        label={
                                                                                            <span>
                                                                                                {t('authorizationId')}
                                                                                            </span>} 
                                                                                          onChange={e => setAuthorizationId(e.target.value) } value={authorizationId}                                                                                           
                                                                                        />

                                                                                            <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                                                                                                        <DateTimePicker
                                                                                                              style={{ maxWidth: '120px' }}
                                                                                                              className={'datePickerrr'}
                                                                                                              // label="Select Date and Time"
                                                                                                              value={startDateTime}
                                                                                                              onChange={handleStartDateTimeChange}
                                                                                                              ampm={false} // Disable AM/PM, use 24-hour format
                                                                                                              label={
                                                                                                                <span>
                                                                                                                  {`${t('80')}`}
                                                                                                               <RedAsterisk>*</RedAsterisk>
                                                                                                                </span>}
                                                                                                              format="DD/MM/YYYY HH:mm:ss"
                                                                                                              inputFormat=" " // Keeps the input field empty unless a date is selected
                                                                                                              renderInput={(params) => <TextField
                                                                                                                {...params}
                                                                                                                InputLabelProps={{
                                                                                                                  shrink: true, // Always shrink the label to allow for a floating effect
                                                                                                                }}
                                                                                                                fullWidth
                                                                                                                variant="outlined"
                                                                                                                sx={{ width: "140px", height: "40px", padding: '20px' }}
                                                                                                              />}
                                                                                                            />
                                                                                                            
                                                                                                      </LocalizationProvider>
                                                                                                        <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                                                                                                            <DateTimePicker
                                                                                                              style={{ marginTop: '20px', maxWidth: '150px' }}
                                                                                                           className={'datePickerrr mt20'}
                                                                                                           label={
                                                                                                            <span>
                                                                                                              {`${t('81')}`}
                                                                                                              <RedAsterisk>*</RedAsterisk>
                                                                                                            </span>}
                                                                                                            format="DD/MM/YYYY HH:mm:ss"
                                                                                                              value={endDateTime}
                                                                                                             onChange={handleEndDateTimeChange}
                                                                                                              ampm={false} // Disable AM/PM, use 24-hour format
                                                                                                           renderInput={(params) => <TextField {...params} />} />
                                                                                            
                                                                                                          </LocalizationProvider>

                                            <FormControl className={'selected_formcontrol'} sx={{ minWidth: 150 }} size="small">
                                              <InputLabel id="demo-select-small-label">{t('2480_056')}<RedAsterisk>*</RedAsterisk></InputLabel>
                                              <Select className={'bankSelect'} labelId="demo-select-small-label" id="demo-select-small"
                                                label="Modo de jerarquia" value={hierarchyMode} onChange={e => setHierarchyMode(e.target.value)}>
                                                <MenuItem value="N">{t('N')}</MenuItem>
                                                <MenuItem value="Y">{t('Y')}</MenuItem>
                                              </Select>
                                            </FormControl>
                                                                                   
                                                                                    <Box style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'flex-end', marginTop: '-16px' }}>
                                                                                        <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CheckCircleIcon />}
                                                                                        onClick={handleSubmit1}
                                                                                        >
                                                                                            {t('apply')}{/* Apply */}
                                                                                        </Button>

                                                                                        <Button style={{ height: '27px' }} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<RestartAltIcon />}
                                                                                            onClick={() => clearData()}
                                                                                        >
                                                                                            {t('045')} {/*Reset*/}
                                                                                        </Button>
                                                                                    </Box>

                                                                                </Box>
</table>
   <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{ marginTop: '0px' }}>
                                                                                {
                                                                                    items.length > 0 ?
                                                                                        <>
                                                                                            <TableContainer component={Paper} className={'shadowTable'} >
                                                                                                <Table size="small" stickyHeader aria-label="sticky table">
                                                                                                  <TableHead>
                                                                                                    <TableRow className="darkgray">
                                                                                                        <TableCell align="center" style={{ fontWeight: "bold", fontSize: "10px" }}>{t('partner')}</TableCell>
                                                                                                        <TableCell align="center" style={{ fontWeight: "bold", fontSize: "10px" }}>{t('1146')/*Company Name*/}</TableCell>
                                                                                                        <TableCell align="center" style={{ fontWeight: "bold", fontSize: "10px" }}>{t('allocatedCreditLimit')}</TableCell>
                                                                                                        <TableCell align="center" style={{ fontWeight: "bold", fontSize: "10px" }}>{t('initialAccountBalance')}</TableCell>
                                                                                                        <TableCell align="center" style={{ fontWeight: "bold", fontSize: "10px" }}>{t('currentAccountBalance')}</TableCell>
                                                                                                    </TableRow>
                                                                                               </TableHead>
                                                                                                    <TableRow>
                                                                                                        <TableCell align="center" style={{ fontSize: "10px" }} >{partnerLoginId}</TableCell>
                                                                                                        <TableCell align="center" style={{ fontSize: "10px" }} >{items[0].partnerCompanyName}</TableCell>
                                                                                                        <TableCell align="center" style={{ fontSize: "10px" }} >{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(items[0].creditLimit)}</TableCell>
                                                                                                        <TableCell align="center" style={{ fontSize: "10px" }} >{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(items[0].initialValue)}</TableCell>
                                                                                                        <TableCell align="center" style={{ fontSize: "10px" }}>{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(items[0].currentAccBal)}</TableCell>
                                                                                                    </TableRow>
                                                                                                </Table>
                                                                                            </TableContainer>
                                                                                            <br></br>
                                                                                        </>
                                                                                        :
                                                                                        <></>
                                                                                }


 <Grid
                                            container
                                            spacing={2}
                                            sx={{ width: 1 }}
                                            className={""}
                                            style={{
                                              justifyContent: "center",
                                              marginTop: "5px",
                                              marginBottom: '0px',
                                              marginLeft: "0px",
                                              borderBottom: "1px solid #fff",
                                              paddingInline: "0px",
                                            }}
                                          >
                                            <Grid
                                              item
                                              xs={4}
                                              sx={{ textAlign: "left", padding: "0 !important" }}
                                            >
                                              {/* <span className={"strongerTxtLable"}>
                          {t('032')} :  {totalRecords}
                  </span> */}
                                            </Grid>
                                            <Grid
                                              item
                                              xs={3}
                                              sx={{ textAlign: "center", padding: "0 !important" }}
                                            ></Grid>
                                            <Grid
                                              item
                                              xs={5}
                                              sx={{ textAlign: "right", padding: "0 !important" }}>
                                              {totalRecords > 0 ?
                                                <><span className={"strongerTxtLable"}>
                                                  {t('032')} : {totalRecords}
                                                </span><span className={"strongerTxtLable"}>
                                                    &nbsp; / &nbsp;
                                                    {t('033')} : {startRecord} - {endRecord}
                                                  </span></> :
                                                <></>}
                                            </Grid>
                                          </Grid>

                                                                                <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
                                                                                    <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
                                                                                        <TableHead>
                                                                                            <TableRow className="darkgray">
                                                                                                <TableCell align="center">{t('transactionNumber')}</TableCell>
                                                                                                <TableCell align="center">{t('authorizationId')}</TableCell>
                                                                                                <TableCell align="center">{t('1241')}{/*Date*/}</TableCell>
                                                                                                <TableCell align="center">{t('time')}</TableCell>
                                                                                                <TableCell align="center">{t('description')}</TableCell>
                                                                                                <TableCell align="center">{t('transactionAmount')}</TableCell>
                                                                                                <TableCell align="center">{t('charge')}</TableCell>
                                                                                                <TableCell align="center">{t('011')}{/*Balance*/}</TableCell>
                                                                                            </TableRow>
                                                                                        </TableHead>
                                                                                        <TableBody>
                                                                                            {isLoading ? (
                                                                                                // Show loading spinner while data is being fetched
                                                                                                <TableRow>
                                                                                                    <TableCell colSpan={7} align="center" className={'spinnerDiv'}>
                                                                                                        {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
                                                                                                    </TableCell>
                                                                                                </TableRow>
                                                                                            ) : items.length > 0 ? <>{(
                                                                                                // Show table rows when data is available
                                                                                                items.map((item, index) => (
                                                                                                    <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
                                                                                                        <TableCell align="center">&nbsp;{item.transactionID}</TableCell>
                                                                                                        <TableCell align="center">&nbsp;{item.authorizationID}&nbsp;</TableCell>

                                                                                                        <TableCell align="center">{item.transactionDate.split(" ")[0]}</TableCell>
                                                                                                        <TableCell align="center">{item.transactionDate.split(" ")[1]}</TableCell>
                                                                                                        <TableCell align="center">{
                                                                                                        
                                                                                                            item.transactionMode != null ?
                                                                                                            item.transactionMode === "Change of Parent" ? t('18273')  :
                                                                                                            item.transactionMode === "Funds Recoup" ? t('18274')  :
                                                                                                            item.transactionMode === "Distributor Retire" ? t('18275')  :
                                                                                                            item.transactionMode === "Distributor Payments" ? t('18276')  :
                                                                                                            item.transactionMode === "Reversal" ? t('18277')  :
                                                                                                            item.transactionMode === "SFS Job Update" ? t('18278')  :
                                                                                                            item.transactionMode === "Recharge" ? t('18279')  :
                                                                                                            item.transactionMode === "Usage Fee" ? t('18280')  :
                                                                                                            item.transactionMode === "Credit Limit Changed" ? t('18281')  :
                                                                                                            item.transactionMode === "Credit Limit Change" ? t('18282')  :
                                                                                                            item.transactionMode : "---"
                                                                                                        
                                                                                                        }</TableCell>
                                                                                                        <TableCell align="center">&nbsp;{item.depositeAmt === 0 ?'---': new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(item.depositeAmt))}&nbsp;</TableCell>
                                                                                                        {/* <TableCell align="center">&nbsp;{item.creditAmount}&nbsp;</TableCell>
                                                                                                        <TableCell align="center">&nbsp;{item.finalValue}&nbsp;</TableCell> */}
                                                                                                        <TableCell align="center">
                                                                                                        &nbsp;{/*item.creditAmount < 0 ? `-$${Math.abs(item.creditAmount).toFixed(2)}` : `$${item.creditAmount.toFixed(2)}`*/
                                                                                                              new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(item.creditAmount))}&nbsp;
                                                                                                        </TableCell>
                                                                                                      <TableCell align="center">
                                                                                                        &nbsp;{/*Number(item.finalValue) < 0 ? `-${new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Math.abs(Number(item.finalValue)))}` : new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(item.finalValue))*/
                                                                                                                                    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(item.finalValue))}&nbsp;
                                                                                                        </TableCell>
                                                                                                    </TableRow>
                                                                                              ))
                                                                                            )}
                                                                                            
                                                                                            {showTotal ? 
                                                                                            
                                                                                            <>
                                                                                              <TableRow>
                                                                                                <TableCell colSpan={4}></TableCell>
                                                                                                <TableCell style={{border:"none"}} align="center">{t('total')}</TableCell>
                                                                                                <TableCell style={{border:"none"}} align="center">{ /*"$"+Number(totalDepositAmount).toFixed(2)*/
                                                                                                                                                    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(totalDepositAmount))}</TableCell>
                                                                                                <TableCell style={{border:"none"}} align="center">{/*totalCreditAmount < 0 ? `-$${Math.abs(totalCreditAmount).toFixed(2)}` : `$${totalCreditAmount.toFixed(2)}`*/
                                                                                                                                                  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(totalCreditAmount))}</TableCell>
                                                                                                <TableCell style={{border:"none"}} ></TableCell>
                                                                                              </TableRow>
                                                                                            </>
                                                                                            
                                                                                            : <></>}
                                                                                            
                                                                                            </> 
                                                                                            
                                                                                            
                                                                                            : (
                                                                                                // Show 'No data found' message if no items are found after loading
                                                                                                      <TableRow>
                                                                                                           <TableCell colSpan="20" className="redTxt" style={{ color: 'red' }} align="center">
                                                                                                            {hasSubmitted ? t('config') /* “No data found” */
                                                                                                             : t('038') /* “Please provide search criteria” */}</TableCell>
                                                                                                      </TableRow>
                                                                                            )                                                                                        
                                                                                            }
                                                                                        </TableBody>
                                                                                    </Table>
                                                                                    
                                                                                               </TableContainer>
                                                                                <br></br>

                                                                                <Table>
                                                                                    <tfoot>
                                                                                        <Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
                                                                                            <Box
                                                                                                sx={{ textAlign: "right", padding: "4px 0px 4px 0 !important" }}
                                                                                                className={'displayFlex'}></Box>


                                                                                            {items.length > 0 ? <Pagination
                                                                                                count={totalPages}
                                                                                                page={page}
                                                                                                onChange={handleChangePage}
                                                                                                showFirstButton
                                                                                                showLastButton
                                                                                            /> : <></>}
                                                                                        </Box>
                                                                                        <tr>
                                                                                        </tr>
                                                                                    </tfoot>
                                                                                </Table>
                                                                                <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
                                                                                    {items.length > 0 ?
                                                                                        <div onMouseLeave={handleClose}>
                                                                                            <Button
                                                                                                className="hoverEffectButton"
                                                                                                size="small"
                                                                                                variant="contained"
                                                                                                endIcon={<CloudDownload />}
                                                                                                onMouseEnter={handleHover}
                                                                                            >
                                                                                                {t('089')}
                                                                                            </Button>

                                                                                            <Menu
                                                                                                anchorEl={anchorEl}
                                                                                                open={Boolean(anchorEl)}
                                                                                                onClose={() => setAnchorEl(null)}
                                                                                                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                                                                transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                                                                MenuListProps={{
                                                                                                    onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                                                                    onMouseLeave: handleClose,
                                                                                                }}
                                                                                            >
                                                                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownload('pdf'); }}> {t("2472_54")}</MenuItem>
                                                                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownload('excel'); }}> {t("2472_55")}</MenuItem>
                                                                                            <MenuItem onClick={() => { setAnchorEl(null); handleDownload('csv'); }}> {t("2472_56")}</MenuItem>
                                                                                            </Menu>
                                                                                        </div>
                                                                                        : <></>}

                                                                                    <Button
                                                                                        className={"hoverEffectButton"}
                                                                                        size="small"
                                                                                        variant="contained"
                                                                                        onClick={handleReturn}
                                                                                        endIcon={<KeyboardReturn />}
                                                                                    > {t('013')}</Button>
                                                                                </div>
                                                                            </table>
                                                                                  </td>
                                                                              </tr>
                                                                        </div>
                                                              
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>

             <ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />

                <tr height="60px">
                    <td colSpan={2}>
                        <Footer />
                    </td>
                </tr>

            </table>
        </div>
    );
}

export default AccountStatusReport;

