import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableRow, Paper, Button } from '@mui/material';
import { useTranslation } from 'react-i18next';
import {ArrowRight, CancelRounded} from '@mui/icons-material';
import axios from 'axios';
import i18n from "./i18n";


const TransactionDetails = ({parentName,transactionId,handleClose,transactionDate} ) => {

const {t} = useTranslation();
const localeVar=i18n.language;



const transactionDetails = [
  [t('2480_034'),transactionId],
  [t('2480_032'),'orderId'],
  [t('2480_066') , 'billSysId'],
  [t('023'),transactionDate],
  [t('2480_067'),'transactionDate'],
  [t('2480_068'),'cellularNumber'],
  [t('5597_dis'),'distId'],
  [t('251608'),'distName'],
  [t('2480_031'),'custType'],
  [t('2480_059'),'replenishChnl'],
  [t('2480_055'),'prepaidSystem'],
  [`${t('0123')} (MXN)`,'paymentAmount'],
  [`${t('2480_069' )}(MXN)`,'billingSysRecAmt'],
  [t('2480_070'),'promotionOriginCode'],
  [`${t('2480_071')}(MXN)'`,'totalCredAmt'],
  [t('2480_035'),'sequenceISO'],
  [t('2480_072'), 'transStatus'],
  [t('0122'),'paymentType'],
  [t('7056'),'parentId'],
  [t('2480_038'),'distCelNum'],
  [t('01622'),'status'],
  [t('2480_039'),parentName],
  [t('2480_073'),'initiateBy'],
  [t('2480_074'),'retailerType'],
  [t('2480_075'),'deviceId'],
  [t('2480_040'),'originCode'],
  [t('2480_076'),'couponSerNo'],
  [t('2480_033'),'authorizationId'],
  [t('2480_077'),'fundSourcePartnerId']
];

  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [items, setItems] = useState([]);



useEffect(() => {
  const callFetchData = async () => {
    try {
      await fetchData(); // fetchData already uses axios internally
    } catch (error) {
      console.error('Error calling fetchData:', error);
    }
  };

  callFetchData(); // Trigger the async function

}, [transactionId, transactionDate]);

 const fetchData = async () => {
    //setIsLoading(true);
    try {
      const apiUrl = window.config.apiUrlJasper+ '/transHistPopup';
      const response = await axios.post(apiUrl, {          
        userName,
        password,
        transactionId,
        localeVar,
       transactionDate
      });
      console.log("response::::::",response.data);
       if (response.status === 200) {
        setItems(response.data.data);
        // setTotalRecords(response.data.noOfRecord);
        // setDebitAmt(response.data.debitAmount);
        // setTotalAmt(response.data.totalAmt)
       }
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
    //  setIsLoading(false);
    }
  };




  return (
<div align='center' className={"headerTxt"}>
   {t('2480_10')}

<TableContainer component={Paper}>
  <Table  size="small" >
    <TableBody>


      {transactionDetails.map(([label, key], index) => (
        <TableRow
          key={key}
          style={{
            backgroundColor: index % 2 === 0 ? '#f0f8ff' : '#ffffff',
          }}
        >
          <TableCell style={{
             fontWeight: 'bold',
              width: '50%',
              padding: '4px 8px',
              fontSize: '0.85rem'
            }}
        // style=  {{ fontWeight: 'bold', width: '50%' }}
          >{label}</TableCell>
          <TableCell  style={{
              width: '50%',
              padding: '4px 8px',
              fontSize: '0.85rem'
            }}
          >

{
  typeof key === 'string' && items[0]?.[key] !== undefined
    ? key === 'custType'
      ? (t(`customerType.${items[0][key]}`) !== `customerType.${items[0][key]}` 
          ? t(`customerType.${items[0][key]}`) 
          : items[0][key])
      : items[0][key]
    : key ?? '---'
}


    {/* {typeof key === 'string' && items[0]?.[key] !== undefined
    ? items[0][key]
    : key ?? '---'} */}
            {/* {items[0]?.[key] ?? '---'} */}
            </TableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>
</TableContainer>
    {/* <div style={{ textAlign: 'right', marginTop: '16px' }}>
        <Button
          className="hoverEffectButton"
          onClick={handleClose}
          size="small"
          variant="contained"
          endIcon={<CancelRounded />}
        >
          {t('6810') || 'Close'}
        </Button>
    </div> */}

    </div>
  );
}

export default TransactionDetails
