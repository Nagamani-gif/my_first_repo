/* eslint-disable no-undef */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import { Header, Footer, PaymentManagerHeading,ProfileMenu, LeftBgImage } from './PageComponents';
import i18n from "./i18n";
import { Box, Button, CircularProgress, FormControl, FormControlLabel, FormLabel, Grid, InputLabel,Menu, MenuItem, Pagination, Paper, Radio, RadioGroup, Select, styled, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField } from "@mui/material";
import React, { useState, useEffect, useCallback,useMemo  } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CancelRounded, CloudDownload, KeyboardReturn } from "@mui/icons-material";
import { Link, NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import ExcelJS from 'exceljs';
import SendIcon from '@mui/icons-material/Send';
import SaveIcon from '@mui/icons-material/Save';
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DateTimePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { useRef } from "react";
import dayjs from "dayjs";


function DistributorPaymentsHistoryReport() {
    sessionStorage.setItem("selectedLink", "a_profile");

    const { t } = useTranslation();
    const localeVar = i18n.language;
    const exampleData = JSON.parse(localStorage.getItem("userData"))
    const [partnerLoginId, setPartnerLoginId] = useState(exampleData.LOGIN_ID);
    const [items, setItems] = useState([]);
    const [totalRecords, setTotalRecords] = useState(0);
    // const [recordsPerPage] = useState(10);
    const [isLoading, setIsLoading] = useState(false);
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;
    const [recordsPerPage] = useState(10);
    const [page, setPage] = useState(1);
    const [perpage, setPerPage] = useState(10);

  const now = dayjs();  
  const midnightToday = dayjs().startOf('day');

    const [startDateTime, setStartDateTime] = useState(midnightToday);
    const [endDateTime, setEndDateTime] = useState(now);
    const [hierarchyMode, setHierarchyMode] = useState('N');
 const [paymentTypeValue, setPaymentTypeValue] = useState('cash');
const [selectedBank, setSelectedBank] = useState(false);
const [bankName, setbankName]=useState(" ");
const [bankList, setBankList] = useState([]);

const [sequenceISO, setSequenceISO] = useState('');
 const [amountRequested, setAmountRequested] = useState('');
  const [aprovedAmt, setAprovedAmt] = useState('');
const [anchorEl, setAnchorEl] = useState(null);
// const [sortConfig, setSortConfig] = useState({ key: '', direction: 'asc' });
const [sortConfig, setSortConfig] = useState({ key: 'requestGeneratedDate', direction: 'desc' });
  const toastId = useRef(null);
const navigate = useNavigate();
const [submit, setSubmit] = useState(false);
 const closeTimeoutRef = useRef(null);
 let reportDays = process.env.REACT_APP_ReportDays;
 const [apply,setApply] =useState(false);

    console.log("totalRecords++++++++++++", totalRecords)
  let startRecord=0;
  let endRecord =10;
 const bankIds = bankName?.split(":")[0] || ""; // Extract BANK_ID


    useEffect(() => {
        // Set the browser title
        document.title = t('2472_018');
    }, []);

//date validation 
const validateDateRange = ({ startDateTime, endDateTime, reportDays, toast, toastId, t }) => {
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);
  const oneDay = 1000 * 60 * 60 * 24
  
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
   
    }
    return false;
  }

  const diffDays = Math.floor((end - start) / oneDay);
  console.log("diffDays:", diffDays);

  if (diffDays >= reportDays) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('error.config.days') + " " + reportDays);
      

    }
    return false;
  }

  return true;
};




const handleStartDateTimeChange = (newValue) => {
    setApply(false);
      setStartDateTime(newValue); 
      console.log(newValue)
    };

var fromDate='';
if(startDateTime != null){
  var d = new Date(startDateTime);
  var month= d.getMonth()+1;

  var day = d.getDate();
  var year = d.getFullYear();
  var hours = d.getHours();
  var minutes = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;

  // fromDate =  d.getDate() + "/" + month + "/" + d.getFullYear();
  fromDate = day + "/" + month + "/" + year + " " + hours + ":" + minutes;
  console.log("StartDate = "+ day + "/" + month + "/" + year + " " + hours + ":" + minutes);
}

var toDate='';
if(endDateTime != null){
  var d = new Date(endDateTime);
  var month2= d.getMonth()+1;
  var hours1 = d.getHours();
  var minutes1 = d.getMinutes();

  // Ensure that hours and minutes are always two digits
  hours1 = hours1 < 10 ? '0' + hours1 : hours1;
  minutes1 = minutes1 < 10 ? '0' + minutes1 : minutes1;

  toDate =  d.getDate() + "/" + month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1;
  console.log("EndDate = "+ d.getDate() + "/" +month2 + "/" + d.getFullYear() + " " + hours1+ ":"+ minutes1);
}
const formatSpanishNumbers = (date) => {
    return new Intl.DateTimeFormat('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  const handleEndDateTimeChange = (newValue) => {
      setApply(false);
    setEndDateTime(newValue);
  };

const amountRequestedRef = useRef(null);
const aprovedAmtRef = useRef(null);
 


const handleSubmit1 = async (e) => {
  e.preventDefault();
 
  if (amountRequested.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(amountRequested)) {
        toast.error(`${t('alrt_01')} in ${t('2472_31')}.`);
        amountRequestedRef.current?.focus();
        return;
      }
 
       if (aprovedAmt.trim() !== '' && !/^-?\d+(\.\d+)?$/.test(aprovedAmt)) {
        toast.error(`${t('alrt_01')} in ${t('2472_32')}.`);
        aprovedAmtRef.current?.focus();
        return;
      }

  // Convert to JS Date objects
  const start = new Date(startDateTime);
  const end = new Date(endDateTime);

  // Check if end date is before start date
  if (end < start) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('2480_078'));
    }
    return;
  }
  const firstPage = 1;
  setPage(firstPage);
  await fetchData(firstPage); // fetch data for page 1
  setSubmit(true);
  setApply(true);
};


    // debugger;
  const fetchData = async (pageNumber = 1) => {
  const startRecord = (pageNumber - 1) * perpage + 1;
  const endRecord = startRecord + perpage - 1;

  
        setIsLoading(true);
        
        try {


           const isValid = validateDateRange({
                      startDateTime,
                      endDateTime,
                      reportDays,
                      toast,
                      toastId,
                      t
                    });
                
if (!isValid){
  setApply(false);
  return;
} 

            const apiUrl = window.config.apiUrlJasper +'/distributorPaymentHistory';
            // const apiUrl = window.config.apiUrl + process.env.REACT_APP_DISTRIBUTOR_PAYMENT_HISTORY;
            const response = await axios.post(apiUrl, {
                userName,
                password,
                // partnerLoginId,
                paymentRefId : sequenceISO,
                requestedAmt : amountRequested,
                aprovedAmt : aprovedAmt,
                pmtType : paymentTypeValue,
                paymentBankId :  bankIds,
                status : selectedStatus,
                initFromDate : fromDate?.trim() === '' ? null : fromDate,
                initToDate : toDate?.trim() === '' ? null : toDate,
                actionFromDate : '',
                actionToDate : '', 
                partnerId : partnerLoginId,
                levelFlag : hierarchyMode,
                startPageNo: startRecord,
                endPageNo: endRecord,
                download : "N",
                localeVar
                
            });
             console.log("response::::::",response.data);
      if (response.status === 200 && Array.isArray(response.data)) {
      setItems(response.data);
      setTotalRecords(response.data[0]?.noOfRows ?? 0); // Safely get noOfRows

    }
  } catch (error) {
    console.error('An error occurred:', error);
  } finally {
    setIsLoading(false);
  }
};
// debugger;
    //  const navigate = useNavigate();
    const handleReturn = () => {
        navigate(-1);
    };

    const fetchDataDownload = async () => {

      const isValid = validateDateRange({
                   startDateTime,
                   endDateTime,
                   reportDays,
                   toast,
                   toastId,
                   t,
                   submit
                 });
             
              if (!isValid) {
              setSubmit(false);  // reset submit flag
              return;
            }
            
            if(!apply){
            
            if (!toast.isActive(toastId.current)) {
                  toastId.current = toast.error(t('apply_validation'));
                 setSubmit(false);
                }
            return false;
            
            }
        try {

            // const apiUrlDownload = window.config.apiUrl + process.env.REACT_APP_DISTRIBUTORS_HIERARCHYDOWNLOAD_URL;
            const apiUrlDownload = window.config.apiUrlJasper +'/distributorPaymentHistory';
            console.log('API URL:', apiUrlDownload);

            const responseDownload = await axios.post(apiUrlDownload, {
                userName,
                password,
                partnerId : partnerLoginId,
                paymentRefId : sequenceISO,
                requestedAmt : amountRequested,
                aprovedAmt : aprovedAmt,
                pmtType : paymentTypeValue,
                paymentBankId :  bankIds,
                status : selectedStatus,
               
                initFromDate : fromDate?.trim() === '' ? null : fromDate,
                initToDate : toDate?.trim() === '' ? null : toDate,

                actionFromDate : '',
                actionToDate : '', 
                levelFlag : hierarchyMode,
                download : "Y",
                localeVar
            });

              if (!Array.isArray(responseDownload.data)) {
      throw new Error('Invalid API response: Expected array');
    }

       return responseDownload.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };
  


  const exportAsExcel = async () => {
      const downloadItems = await fetchDataDownload();
      if (!downloadItems || downloadItems.length === 0) return;
  
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Payment_Alerts_History_Report');
  
      const numberOfColumns = 15;
      const headingRow1 = worksheet.addRow([t('2472_48')]);
      worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
      headingRow1.getCell(1).font = { bold: true };
      headingRow1.getCell(1).alignment = { horizontal: 'center' };
      worksheet.addRow([]);
    
      const columnHeaders = [
        t('2472_33'), t('2472_30'), t('2472_34'),t('2472_32'), t('2472_35'),
        t('2472_36'), t('2472_37'), t('251620'), t('2472_49'), t('2472_38'), 
        t('2472_39'),t('2472_40'), t('2472_41'), t('2472_42'), t('2472_43')
      ];
  
  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;
  
  const totalRecordsRow = worksheet.addRow([`${t('032')}: ${totalRecords}`]);
  worksheet.mergeCells(totalRecordsRow.number, 1, totalRecordsRow.number, numberOfColumns);
  totalRecordsRow.getCell(1).font = { bold: true };
  totalRecordsRow.getCell(1).alignment = { horizontal: 'left' };
  
      const headerRow = worksheet.addRow(columnHeaders);
      
      // Set header row height
      headerRow.height = 25;

      headerRow.eachCell(cell => {
        cell.font = { bold: true };
        cell.alignment = { horizontal: 'center' };
        cell.border = {
          top: { style: 'thin' }, left: { style: 'thin' },
          bottom: { style: 'thin' }, right: { style: 'thin' },
        };
      });
  
      downloadItems.forEach(item => {
        const statusMap = {
    A: t('2472_44'), // Approved
    R: t('2472_46'), // Rejected
    P: t('2472_45'), // Pending
  };
  const statusText = statusMap[item.status] || item.status;

  const dataRow = worksheet.addRow([
     item.requestId ?? "---",
    item.paymentRefNo ?? "---",
    
     !isNaN(parseFloat(item.requestedAmount)) ? parseFloat(item.requestedAmount).toFixed(2) : '---',
      !isNaN(parseFloat(item.aprovedAmount)) ? parseFloat(item.aprovedAmount).toFixed(2) : '---',
       !isNaN(parseFloat(item.discountAmount)) ? parseFloat(item.discountAmount).toFixed(2) : '---',
    !isNaN(parseFloat(item.taxAmount)) ? parseFloat(item.taxAmount).toFixed(2) : '---',
   
   !isNaN(parseFloat(item.sclPaymentAmount)) ? parseFloat(item.sclPaymentAmount).toFixed(2) : '---',
    
    item.distCurrencyId ?? "---",
   item.paymentType
      ? item.paymentType.trim().toUpperCase() === "CASH"
        ? t("cash_1")
        : item.paymentType.trim().toUpperCase() === "BANK"
        ? t("Bank_REP2")
        : item.paymentType.trim().toUpperCase() === "CREDIT CARD"
        ? t("Credit_Card_03")
        : item.paymentType.trim().toUpperCase() === "DEBIT CARD"
        ? t("Debit_Card_4")
        : item.paymentType.trim().toUpperCase() === "DIRECT DEBIT"
        ? t("Direct_Debit_6")
        : item.paymentType
      : "- - -",
    item.requestGeneratedDate ?? "---",
    item.aprovedDate ?? "---",
    item.sclClientCode ?? "---",
    item.partnerCompanyName ?? "---",
    statusMap[item.status] || item.status,
    item.rejectedReason ?? "---"
  ]);
         dataRow.eachCell(cell => {
        cell.border = {
          top: { style: 'thin' }, left: { style: 'thin' },
          bottom: { style: 'thin' }, right: { style: 'thin' },
        };
        cell.alignment = { horizontal: 'center' };
      });
    });
  
    worksheet.addRow([]);
    const endOfReportRow = worksheet.addRow([t('0171')]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
    const endOfReportCell = endOfReportRow.getCell(1);
    endOfReportCell.font = { italic: true, underline: true, bold: true };
    endOfReportCell.alignment = { horizontal: 'center' };
  
    worksheet.columns.forEach(column => {
      let maxLength = 10;
      column.eachCell({ includeEmpty: true }, cell => {
        const cellValue = cell.value ? cell.value.toString() : '';
        maxLength = Math.max(maxLength, cellValue.length + 1); // Add padding
      });
      column.width = maxLength > 30 ? 30 : maxLength; // Optional: cap width to 40
    });
  
    worksheet.protect('yourPassword', {
      selectLockedCells: true,
      selectUnlockedCells: true,
    });
  
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
  
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'Payment_Alerts_History_Report.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

const exportAsPdf = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  const doc = new jsPDF({
    orientation: 'landscape',
    format: [500, 1000],
    unit: 'pt'
  });

  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;

  // Title
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text(t('2472_48'), doc.internal.pageSize.getWidth() / 2, 40, { align: 'center' });

  // Total records
  doc.setFontSize(10);
  doc.setFont(undefined, 'normal');
  doc.text(`${t('032')}: ${totalRecords}`, 40, 60);

  // Header columns
  const columnHeaders = [
    t('2472_33'), t('2472_30'), t('2472_34'), t('2472_32'), t('2472_35'),
    t('2472_36'), t('2472_37'), t('251620'), t('2472_49'), t('2472_38'),
    t('2472_39'), t('2472_40'), t('2472_41'), t('2472_42'), t('2472_43')
  ];

  // Status translation map
  const statusMap = {
    A: t('2472_44'), // Approved
    R: t('2472_46'), // Rejected
    P: t('2472_45'), // Pending
  };
 
  // Data rows
  const rows = downloadItems.map(item => [
    
    item.requestId ?? "---",
    item.paymentRefNo ?? "---",
    
     !isNaN(parseFloat(item.requestedAmount)) ? parseFloat(item.requestedAmount).toFixed(2) : '---',
      !isNaN(parseFloat(item.aprovedAmount)) ? parseFloat(item.aprovedAmount).toFixed(2) : '---',
       !isNaN(parseFloat(item.discountAmount)) ? parseFloat(item.discountAmount).toFixed(2) : '---',
    !isNaN(parseFloat(item.taxAmount)) ? parseFloat(item.taxAmount).toFixed(2) : '---',
   
   !isNaN(parseFloat(item.sclPaymentAmount)) ? parseFloat(item.sclPaymentAmount).toFixed(2) : '---',
    
    item.distCurrencyId ?? "---",
    item.paymentType
      ? item.paymentType.trim().toUpperCase() === "CASH"
        ? t("cash_1")
        : item.paymentType.trim().toUpperCase() === "BANK"
        ? t("Bank_REP2")
        : item.paymentType.trim().toUpperCase() === "CREDIT CARD"
        ? t("Credit_Card_03")
        : item.paymentType.trim().toUpperCase() === "DEBIT CARD"
        ? t("Debit_Card_4")
        : item.paymentType.trim().toUpperCase() === "DIRECT DEBIT"
        ? t("Direct_Debit_6")
        : item.paymentType
      : "- - -",
    item.requestGeneratedDate ?? "---",
    item.aprovedDate ?? "---",
    item.sclClientCode ?? "---",
    item.partnerCompanyName ?? "---",
    statusMap[item.status] || item.status,
    item.rejectedReason ?? "---"
  ]);

    // 1. Summary row table
doc.autoTable({
  startY: 50,
  head: [[
    {
      content: `${t('032')}: ${totalRecords}`,
      colSpan: Math.floor(columnHeaders.length / 2),
      styles: {
        halign: 'left',
        fillColor: [41, 128, 185],
        textColor: [255, 255, 255],
        fontSize: 6
      }
    },
    
  ]],
  body: [],
  margin: { left: 10, right: 10 }
});


  // Generate table
  doc.autoTable({
    startY: 70,
    head: [columnHeaders],
    body: rows,
    styles: {
      fontSize: 7,
      cellPadding: 2,
      overflow: 'linebreak',
      halign: 'center'
    },
    headStyles: {
      fillColor: [41, 128, 185],
      fontSize: 8,
      halign: 'center',
      textColor: 255
    },
    theme: 'grid',
    margin: { top: 70, left: 10, right: 10 }
  });

  // End of report footer
  doc.setFontSize(10);
  doc.setFont(undefined, 'italic');
  doc.text(t('0171'), doc.internal.pageSize.getWidth() / 2, doc.lastAutoTable.finalY + 20, { align: 'center' });

  doc.save('Payment_Alerts_History_Report.pdf');
};


  


const exportAsCSV = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  const formatAmount = (value) => {
    const num = parseFloat(value);
    return !isNaN(num) ? num.toFixed(2) : '0.00';
  };

  const formatDateTime = (value) => {
    if (!value) return "---";
    const date = new Date(value);
    if (isNaN(date.getTime())) return value;
    const pad = (n) => (n < 10 ? '0' + n : n);
    return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

  const columnHeaders = [
    t('2472_33'), t('2472_30'), t('2472_34'), t('2472_32'), t('2472_35'),
    t('2472_36'), t('2472_37'), t('251620'), t('2472_49'), t('2472_38'),
    t('2472_39'), t('2472_40'), t('2472_41'), t('2472_42'), t('2472_43')
  ];

  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;
  const rows = [];

  rows.push([t('2472_48')]);
  rows.push([]);
  rows.push([`${t('032')}: ${totalRecords}`]);
  rows.push([]);
  rows.push(columnHeaders);

  const statusMap = {
    A: t('2472_44'),
    R: t('2472_46'),
    P: t('2472_45'),
  };

  downloadItems.forEach(item => {
    rows.push([
      item.requestId ?? "---",
      item.paymentRefNo ?? "---",

      formatAmount(item.requestedAmount),
      formatAmount(item.aprovedAmount),
      formatAmount(item.discountAmount),
      formatAmount(item.taxAmount),
      formatAmount(item.sclPaymentAmount),

      item.distCurrencyId ?? "---",
      item.paymentType
        ? item.paymentType.trim().toUpperCase() === "CASH"
          ? t("cash_1")
          : item.paymentType.trim().toUpperCase() === "BANK"
          ? t("Bank_REP2")
          : item.paymentType.trim().toUpperCase() === "CREDIT CARD"
          ? t("Credit_Card_03")
          : item.paymentType.trim().toUpperCase() === "DEBIT CARD"
          ? t("Debit_Card_4")
          : item.paymentType.trim().toUpperCase() === "DIRECT DEBIT"
          ? t("Direct_Debit_6")
          : item.paymentType
        : "- - -",

      formatDateTime(item.requestGeneratedDate),
      formatDateTime(item.aprovedDate),
      item.sclClientCode ?? "---",
      item.partnerCompanyName ?? "---",
      statusMap[item.status] || item.status,
      item.rejectedReason ?? "---"
    ]);
  });

  rows.push([]);
  rows.push([t('0171')]);

const csvContent = rows
  .map(row =>
    row.map(val => {
      const strVal = String(val ?? '').trim();

      // Format floats and date-like strings for Excel-safe display
      if (/^\d{1,3}(,\d{3})*(\.\d{2})?$/.test(strVal) || /^\d+\.\d{2}$/.test(strVal)) {
        return `="${strVal}"`; // Excel-safe numeric text
      } else if (/^\d{2}\/\d{2}\/\d{4}/.test(strVal)) {
        return `="${strVal}"`; // Excel-safe date
      } else {
        return `"${strVal.replace(/"/g, '""')}"`;
      }
    }).join(',')
  )
  .join('\n');


  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'Payment_Alerts_History_Report.csv';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};








   const handleDownload = async (type) => {
  setAnchorEl(null);
  if (type === 'excel') {
    await exportAsExcel();
  } else if (type === 'pdf') {
    await exportAsPdf();
  } else if (type === 'csv') {
     await exportAsCSV();
  }
};

const handleChangePage = async (event, newPage) => {
  event.preventDefault();

   const isValid = validateDateRange({
         startDateTime,
         endDateTime,
         reportDays,
         toast,
         toastId,
         t,
         submit
       });
   
    if (!isValid) {
    setSubmit(false);  // reset submit flag
    return;
  }
  
  if(!apply){
  
  if (!toast.isActive(toastId.current)) {
        toastId.current = toast.error(t('apply_validation'));
       setSubmit(false);
      }
  return false;
  
  }
  setPage(newPage);
  await fetchData(newPage); // fetch data for the selected page
};
// useEffect(() => {
//   fetchData(page); // will run when page changes
// }, [page]);



    const totalPages = Math.ceil(totalRecords / recordsPerPage);
  startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);





    const highlightSelectedLink = (e) => {
        var x = document.querySelector(".subLinkVisited");
        if (x !== null) {
            x.classList.replace("subLinkVisited", "subLink");
        }
        e.target.classList.replace("subLink", "subLinkVisited");
    }

    const [selectedStatus, setSelectedStatus] = useState(' ');


  function handlePaymentType(e) {
  const val = e.target.value;
  setPaymentTypeValue(val);
  if (val === 'bank') {
    setSelectedBank(true);
    // Set default bankName to first bank or a fixed value
    if (bankList.length > 0) {
      setbankName(`${bankList[0].BANK_ID}:${bankList[0].BANK_NAME}`);
    } else {
      setbankName('1:BANAMEX'); // fallback default
    }
    getBanks(); // fetch bank list
  } else {
    setSelectedBank(false);
     setbankName(''); 
    setBankList([]);
  }
}


  const handleDoubleClick = (e) => {
    e.preventDefault(); // Prevent default behavior
    e.stopPropagation(); // Stop event propagation
  };

  const getBanks = async() => {
     
      try {
          const apiUrl = window.config.apiUrl + process.env.REACT_APP_GETBANKS;
          const response = await axios.post(apiUrl, {
            userName,
            password,
            partnerLoginId
          });
          const data = response.data;
  
          console.log("response"+data.BANK_LIST);
  
          setBankList(data.BANK_LIST);
  
      } catch (error) {
        console.log("error in getBanks");
      }
    }
    const clearData=()=>{
      setSequenceISO('');
      setAmountRequested('');
      setAprovedAmt('');
      setPaymentTypeValue('cash');
      setSelectedStatus(' ');
      setEndDateTime(now); 
      setStartDateTime(midnightToday);
      setHierarchyMode('N');
  }
  



const handleSort = (key) => {
  setSortConfig((prev) => ({
    key,
    direction:
      prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc',
  }));
};
const getSortIcon = (key) => {
  if (sortConfig.key !== key) return null;
  return sortConfig.direction === 'asc' ? ' 🔼' : ' 🔽';
};

const sortedItems = useMemo(() => {
  if (!sortConfig.key) return items;
  return [...items].sort((a, b) => {
    const aValue = a[sortConfig.key];
    const bValue = b[sortConfig.key];
    
    if (aValue === null || aValue === undefined) return 1;
    if (bValue === null || bValue === undefined) return -1;

    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return sortConfig.direction === 'asc' ? aValue - bValue : bValue - aValue;
    }

    return sortConfig.direction === 'asc'
      ? String(aValue).localeCompare(String(bValue))
      : String(bValue).localeCompare(String(aValue));
  });
}, [items, sortConfig]);

 const RedAsterisk = styled('span')({
    color: 'red',
  });

   const handleHover = (event) => {
    clearTimeout(closeTimeoutRef.current);
    setAnchorEl(event.currentTarget);
  };
 
  const handleClose = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200); // 200ms delay to prevent flicker
  };

   return (
  <div>
            <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <tbody>
                    <Header />
                    <tr height="65px">
                        <PaymentManagerHeading />
                        <TopMenu menuLink={localeVar === 'en' ? "Distributor Payments History" : "Historia Alertas Distribuidor de pago"} />
                    </tr>

                    <tr>
          
                            <LeftBgImage />
                     
                        <td valign="top">
                            <title>Distributor Payments History</title>
                            <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
                                <tbody>
                                    <tr>
                                        <td>
                                            <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="center">
                                                <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
                                                        <td>
                                                            <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" height="100%">
                                                                <tbody>
                                                                    {/* <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
                                                                        <Tabs style={{ minHeight: '35px' }}>
                                                                            <NavLink
                                                                                to="/distributorPaymentsHistoryReport"
                                                                                onClick={(e) => highlightSelectedLink(e)}
                                                                                // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
                                                                                className={({ isActive }) =>
                                                                                    isActive ? 'activeProfilemenu' : `profile_menu 
																					${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
                                                                                }
                                                                            ><Tab label={t('2472_48')} /></NavLink>
                                                                        </Tabs>
                                                                    </Box> */}

<tbody>
    <ProfileMenu/>
    <tr>

    </tr>
  </tbody>
      <div className={'mL8 input_boxess'}>
           <tr valign="top">
                <td width="80%">
            {/* body starts */}

                      

<table border={0} cellPadding={0} cellSpacing={0} width="100%" align="center" style={{ marginTop: '15px' }}>
  <tbody>
    <tr>
      <td width="100%">
        <table border={0} borderColor="green" width="100%" cellSpacing={0} align="left">
          <tbody>
            {/* Spacer row (optional) */}
           
            {/* Input Fields Row */}
            <tr>
              <td>
                {/* <Box style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}> */}
                 <Box style={{ display: 'flex', gap: '12px',  whiteSpace: 'nowrap' }}>
                  <TextField
                    label={t('2472_30')}
                    size="15"
                    className={"sampleInput mb5"}
                    style={{ maxWidth: '250px', width: '150px' }}
                    onChange={e => setSequenceISO(e.target.value)}
                     name="sequenceISO"
                    value={sequenceISO}
                    type="text"
                    autoComplete="off"
                  />

                  <TextField
                    type="text"
                    name="amountRequested"
                    label={<span>{`${t('2472_31')}`}</span>}
                    style={{ maxWidth: '250px', width: '150px' }}
                    className={'sampleInput mb5'}
                    value={amountRequested}
                    onChange={e => setAmountRequested(e.target.value)}
                    autoComplete="off"
                  />

                  <TextField
                    type="text"
                    name="aprovedAmt"
                    label={<span>{`${t('2472_32')}`}</span>}
                    style={{ maxWidth: '250px', width: '150px' }}
                    className={'sampleInput mb5'}
                    value={aprovedAmt}
                    onChange={e => setAprovedAmt(e.target.value)}
                    autoComplete="off"
                  />

 <FormControl className={'selected_formcontrol'}  sx={{ minWidth: 150, maxWidth: 150, width: 150 }}  size="small">
                            <InputLabel id="demo-select-small-label">{t('2472_49')}<RedAsterisk>*</RedAsterisk></InputLabel>
                                   <Select
                                     label={t('2472_49')}
                                       className={'bankSelect'}
                                         labelId="demo-select-small-label"
                                         id="demo-select-small"
                                           value={paymentTypeValue}
                                             onChange={handlePaymentType}
                                               onDoubleClick={handleDoubleClick}
                                              >
                                           <MenuItem value="cash">{t('020')}</MenuItem>
                                            <MenuItem value="bank">{t('021')}</MenuItem>
                                           </Select>
                                     </FormControl>

                                         {paymentTypeValue === 'cash' ? (
  <FormControl className="selected_formcontrol"  sx={{ minWidth: 150, maxWidth: 150, width: 150 }}  size="small">
    <InputLabel id="demo-select-small-label">{t('2472_29')}<RedAsterisk>*</RedAsterisk></InputLabel>
    <Select
      label={t('2472_29')}
      name="bankName"
      size="1"
      id="bankName"
      labelId="demo-select-small-label"
      value={" "}
      onChange={(e) => setbankName(e.target.value)}
      className="bankSelect selected_dropdown">
      <MenuItem value=" " selected>---</MenuItem>
    </Select>
  </FormControl>
) : (
  <FormControl className="selected_formcontrol"  sx={{ minWidth: 150, maxWidth: 150, width: 150 }}  size="small">
    <InputLabel id="demo-select-small-label">{t('2472_29')}<RedAsterisk>*</RedAsterisk></InputLabel>
    <Select
      label={t('2472_29')}
      name="bankName"
      size="1"
      id="bankName"
      labelId="demo-select-small-label"
      value={bankName}
      onChange={(e) => setbankName(e.target.value)}
      className="bankSelect selected_dropdown"
    >
      {bankList.map((bank) => (
        <MenuItem key={bank.BANK_ID} value={`${bank.BANK_ID}:${bank.BANK_NAME}`}>
          {bank.BANK_NAME}
        </MenuItem>
      ))}
    </Select>
  </FormControl>
)}

                </Box>
              </td>
            </tr>

        
          <tr>
              <td>
                <Box style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
        
               <FormControl className={'selected_formcontrol'}  sx={{ minWidth: 150, maxWidth: 150, width: 150 }}  size="small">
                      <InputLabel id="demo-select-small-label" sx={{
                      backgroundColor: '#fff',
                      padding: '0 5px',
                    }}>{t('2472_42')}</InputLabel>

                      <Select className={'bankSelect'} style={{ maxWidth: '250px', width: '150px' }} labelId="demo-select-small-label" id="demo-select-small"
                      label="selectedStatus"value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)}>
                        <MenuItem value=" " selected>---</MenuItem>
                        <MenuItem value="A" >{t('2472_44')}</MenuItem>
                        <MenuItem value="P">{t('2472_45')}</MenuItem>
                        <MenuItem value="R">{t('2472_46')}</MenuItem>
                      
                      
                      </Select>
                  
                    </FormControl>

           <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                           <DateTimePicker
                             style={{ maxWidth: '150px' }}
                             className={'datePickerrr'}
                             // label="Select Date and Time"
                             value={startDateTime}
                             onChange={handleStartDateTimeChange}
                             ampm={false} // Disable AM/PM, use 24-hour format
                             // label={t('80')} // This serves as the floating label
                             label={
                               <span>
                                 {`${t('80')}`}
                                 <RedAsterisk>*</RedAsterisk>
                               </span>}
                               format="DD/MM/YYYY HH:mm:ss"
                             inputFormat=" " // Keeps the input field empty unless a date is selected
                             renderInput={(params) => <TextField
                               {...params}
                               InputLabelProps={{
                                 shrink: true, // Always shrink the label to allow for a floating effect
                               }}
                               placeholder={!startDateTime ? t('80') : ''} // Show the placeholder only if no date is selected
                               fullWidth
                               variant="outlined"
                               sx={{ width: "140px", height: "40px", padding: '20px' }}
                             />}
                           />
                           
                         </LocalizationProvider>
                       <LocalizationProvider dateAdapter={AdapterDayjs} style={{marginLeft: '5px'}}  adapterLocale={localeVar === 'en' ? 'en' : 'es'}>
                           <DateTimePicker
                             style={{ marginTop: '20px', maxWidth: '150px' }}
                          className={'datePickerrr mt20'}
                          label={
                           <span>
                             {`${t('81')}`}
                             <RedAsterisk>*</RedAsterisk>
                           </span>}
                           format="DD/MM/YYYY HH:mm:ss"
                             value={endDateTime}
                             onChange={handleEndDateTimeChange}
                             ampm={false} // Disable AM/PM, use 24-hour format
                          renderInput={(params) => <TextField {...params} />} />
           
                         </LocalizationProvider>


           <FormControl className={'selected_formcontrol'}  sx={{ minWidth: 150, maxWidth: 150, width: 150 }}  size="small">
                      <InputLabel id="demo-select-small-label" sx={{
                      backgroundColor: '#fff',
                      padding: '0 5px',
                    }}>{t('2472_25')}<RedAsterisk>*</RedAsterisk></InputLabel>

                      <Select className={'bankSelect'} style={{ maxWidth: '250px', width: '150px' }} labelId="demo-select-small-label" id="demo-select-small"
                      label="hierarchyMode"value={hierarchyMode} onChange={e => setHierarchyMode(e.target.value)}>
                        <MenuItem value="N" selected>{t('2472_51')}</MenuItem>
                        <MenuItem value="Y">{t('2472_50')}</MenuItem>
                      </Select>
                    </FormControl>

          <Box style={{display: 'flex', alignItems: 'center', gap:'8px', justifyContent :'flex-end', marginTop:'-16px'}}>
                  <Button
                    style={{ height: '27px' }}
                    className={'hoverEffectButton'}
                    size="small"
                    variant="contained"
                    endIcon={<CheckCircleIcon />}
                    onClick={handleSubmit1}
                  >
                    {t('2472_26')}
                  </Button>
                  <Button
                    style={{ height: '27px' }}
                    className={'hoverEffectButton'}
                    size="small"
                    variant="contained"
                     endIcon={<RestartAltIcon />}
                    onClick={clearData}
                  >
                    {t('2472_27')}
                  </Button>
                    {/* <Button
                    style={{ height: '27px' }}
                    className={'hoverEffectButton'}
                    size="small"
                    variant="contained"
                    endIcon={<SaveIcon />}
                    onClick={handleSubmit1}
                  >
                    {t('2472_28')}
                  </Button> */}
                </Box>

                </Box>
              </td>
            </tr>

            {/* Submit Button Row */}
            <tr>
              <td>
              
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>





      <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                  {/* <span className={"strongerTxtLable"}>
                          {t('032')} :  {totalRecords}
                  </span> */}
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
              </Grid>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
          <TableRow className="darkgray">
            <TableCell align="center">{t('2472_33')}</TableCell>
            <TableCell align="center">{t('2472_30')}</TableCell>
            <TableCell align="center">{t('2472_34')}</TableCell>
            <TableCell align="center">{t('2472_32')}</TableCell>
            <TableCell align="center">{t('2472_35')}</TableCell>
            <TableCell align="center">{t('2472_36')}</TableCell>
            <TableCell align="center">{t('2472_37')}</TableCell>
           <TableCell align="center">{t('251620')}</TableCell>
            <TableCell align="center">{t('2472_49')}</TableCell>
            {/* <TableCell align="center">{t('2472_38')}</TableCell> */}
            <TableCell
  align="center"
  onClick={() => handleSort('requestGeneratedDate')}
  style={{ cursor: 'pointer', textDecoration: 'underline' }}
>
  {t('2472_38')}
  {sortConfig.key === 'requestGeneratedDate' &&
    (sortConfig.direction === 'asc' ? ' 🔼' : ' 🔽')}
</TableCell>
            <TableCell align="center">{t('2472_39')}</TableCell>
            <TableCell align="center">{t('2472_40')}</TableCell>
            <TableCell align="center">{t('2472_41')}</TableCell>
            <TableCell align="center">{t('2472_42')}</TableCell>
            <TableCell align="center">{t('2472_43')}</TableCell>
            
             
          </TableRow>
        </TableHead>
        <TableBody>
  {isLoading ? (
    <TableRow>
      <TableCell colSpan={25} align="center" className="spinnerDiv">
        {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
      </TableCell>
    </TableRow>
  ) : Array.isArray(items) && items.length > 0 ? (
    sortedItems.map((item, index) => (
      <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
        <TableCell align="center">&nbsp;{item.requestId}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.paymentRefNo}&nbsp;</TableCell>
         <TableCell align="center">&nbsp;{typeof item.requestedAmount === 'number' ? item.requestedAmount .toFixed(2) : "---"}&nbsp;</TableCell>
         <TableCell align="center">&nbsp;{typeof item.aprovedAmount === 'number' ? item.aprovedAmount .toFixed(2) : "---"}&nbsp;</TableCell>
         <TableCell align="center">&nbsp;{typeof item.discountAmount === 'number' ? item.discountAmount .toFixed(2) : "---"}&nbsp;</TableCell>
         <TableCell align="center">&nbsp;{typeof item.taxAmount === 'number' ? item.taxAmount .toFixed(2) : "---"}&nbsp;</TableCell>
        <TableCell align="center"> &nbsp;{!isNaN(item.sclPaymentAmount) ? parseFloat(item.sclPaymentAmount).toFixed(2) : "---"}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.distCurrencyId}&nbsp;</TableCell>
       
       <TableCell align="center">
  &nbsp;
  {
    item.paymentType
      ? item.paymentType.trim().toUpperCase() === "CASH"
        ? t("cash_1")
        : item.paymentType.trim().toUpperCase() === "BANK"
        ? t("Bank_REP2")
        : item.paymentType.trim().toUpperCase() === "CREDIT CARD"
        ? t("Credit_Card_03")
        : item.paymentType.trim().toUpperCase() === "DEBIT CARD"
        ? t("Debit_Card_4")
        : item.paymentType.trim().toUpperCase() === "DIRECT DEBIT"
        ? t("Direct_Debit_6")
        : item.paymentType
      : "- - -"
  }
  &nbsp;
</TableCell>

       
        
        
        {/* <TableCell align="center">&nbsp;{item.paymentType}&nbsp;</TableCell> */}
        
        
        <TableCell align="center">&nbsp;{item.requestGeneratedDate}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.aprovedDate}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.sclClientCode}&nbsp;</TableCell>

        <TableCell align="center">&nbsp;{item.partnerCompanyName}&nbsp;</TableCell>
      
      
      <TableCell align="center">
  &nbsp;
  {
    item.status
      ? item.status === "A"
        ? t("6142")
        : item.status === "R"
        ? t("6143")
        : item.status === "P"
        ? t("6144")
        : item.status
      : "- - -"
  }
  &nbsp;
</TableCell>

      
      {/* <TableCell align="center">&nbsp;{item.status}&nbsp;</TableCell> */}
      
        
        <TableCell align="center">&nbsp;{item.rejectedReason}&nbsp;</TableCell>
      
      </TableRow>
    ))
  ) : (
    <TableRow>
      <TableCell colSpan={25} className="redTxt" style={{ color: 'red' }} align="center">
          {submit ? t("2481_061") : t("2472_57")} 
      </TableCell>
    </TableRow>
  )}
</TableBody>


      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', width: '100%' }}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length > 0 && (
  <Pagination
    count={totalPages}
    page={page}
    onChange={handleChangePage}
    showFirstButton
    showLastButton
  />
)}
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
      <div style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}>
      {items.length > 0 ?
                                               <div onMouseLeave={handleClose}>
                                               <Button
                                                 className="hoverEffectButton"
                                                 size="small"
                                                 variant="contained"
                                                 endIcon={<CloudDownload />}
                                                 onMouseEnter={handleHover}
                                               >
                                                 {t('089')}
                                               </Button>
                                         
                                               <Menu
                                                 anchorEl={anchorEl}
                                                 open={Boolean(anchorEl)}
                                                 onClose={() => setAnchorEl(null)}
                                                 anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                                 transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                                 MenuListProps={{
                                                   onMouseEnter: () => clearTimeout(closeTimeoutRef.current),
                                                   onMouseLeave: handleClose,style: { minWidth: 85 }
                                                 }}
                                                 PaperProps={{
                                                  sx: { minWidth: 85, mt: 0.5 },
                                                }}
                                               >
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownload('pdf'); }}> {t("2472_54")}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownload('excel'); }}> {t("2472_55")}</MenuItem>
                                                 <MenuItem onClick={() => { setAnchorEl(null); handleDownload('csv'); }}> {t("2472_56")}</MenuItem>
                                               </Menu>
                                             </div>
                                              : <></>}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>

</td></tr>
</div>

</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>

<ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />

<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  )
}

export default DistributorPaymentsHistoryReport;
