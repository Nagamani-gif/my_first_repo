import { useEffect } from 'react';

const useLoadScript = (url) => {
  useEffect(() => {
    const existingScript = document.getElementById('googleMapsScript');

    if (!existingScript) {
      const script = document.createElement('script');
      script.src = url;
      script.id = 'googleMapsScript';
      script.async = true;
      document.body.appendChild(script);

      script.onload = () => {
        console.log('Google Maps API script loaded');
      };

      script.onerror = () => {
        console.error('Error loading Google Maps API script');
      };
    }

    return () => {
      if (existingScript) {
        existingScript.remove();
      }
    };
  }, [url]);
};

export default useLoadScript;
