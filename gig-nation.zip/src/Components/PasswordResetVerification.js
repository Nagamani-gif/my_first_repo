import { Footer, Header, LeftBgImage, LeftMenu, PaymentManagerHeading, ProfileMenu } from './PageComponents';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import {useEffect, useState} from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import TopMenu from './TopMenu';
import { KeyboardReturn } from '@mui/icons-material';
import { Box, Button, FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import RotateLeftIcon from '@mui/icons-material/RotateLeft';
import i18n from './i18n';

function PasswordResetVerification() {


    const exampleData = JSON.parse(localStorage.getItem("userData")) // Select the data from the Redux store
    console.log("exampleData LOGIN_ID====>"+exampleData.LOGIN_ID);
     //setting For user login
  const partnerLoginId = exampleData.LOGIN_ID;
    const {t} = useTranslation();

    const location = useLocation();
    const query = new URLSearchParams(location.search);
    
    const distId = query.get('distId');
    const company = query.get('company');
    const fName = query.get('fName');
    const lName = query.get('lName');
    const eMail = query.get('eMail');
    const mdn = query.get('mdn');

    console.log("distId="+distId);
    console.log("company="+company);
    console.log("fName="+fName);
    console.log("lName="+lName);
    console.log("eMail="+eMail);
    console.log("mdn="+mdn);

    const [result, setResult] = useState('');
    const [selectedChannels, setSelectedChannels] = useState('W');
    const localeVar = i18n.language;
    let userName = process.env.REACT_APP_USERNAME;
    let password = process.env.REACT_APP_PASSWORD;



    useEffect(() => {
        // Set the browser title
        document.title = t('2472_029');
      }, []);

    const resetPassword = async() => {
        console.log("in resetPassword");
        var channel = document.getElementById('channel').value;
       console.log("CHANNEL", channel)
        try{
            const apiUrl = window.config.apiUrl + process.env.REACT_APP_RESETPWD;
            const response = await axios.post(apiUrl, {
                                     userName,
                                     password,
                                      partnerLoginId,
                                      distId,
                                      company,
                                      fName,
                                      lName,
                                      eMail,
                                      mdn,
                                      localeVar,
                                      "channel":selectedChannels
                                    });
        
            const responseData = response.data;

            console.log("responseData.result = "+responseData.result);

            setResult(responseData.result);

            } catch {
              console.log('error in resetPassword');
            }
        
    }
 
    const navigate = useNavigate();
    const handleReturn = () => {
      navigate(-1);
    };

    return (
        <>
            <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
                <tbody>
                            <Header />
                    <tr height="65px">
                    <PaymentManagerHeading />
                     <TopMenu menuLink= {localeVar==='en'?"Profile":"Perfil"}/>
                    </tr>
                    <tr>
                        <LeftBgImage />

                        <td valign="top">
                <meta
                  httpEquiv="Content-Type"
                  content="text/html; charset=ISO-8859-1"
                />
                  <title>homepage</title>
                <ProfileMenu menu="highlightmenu" />
                <form method="post" className={'mL8'}>
                  <table
                    width="100%"
                    height="100%"
                    cellSpacing={20}
                    cellPadding={150}
                    border={0}
                    align="left"
                  ></table>

                            <table width="60%" border="0" bordercolor="red">
                                <tbody>
                                    <tr>
                                        {/* <td width="100%" colspan="3" className="headingText" align="center">{/*Password Reset Verification}{t('040')}&nbsp;&nbsp;</td> */}
                                    </tr>
                                    <tr>
                                        <td colspan="3" class="redTxt" style={{color: 'red'}} align="left">
                                        
                                            {result !== '' ? result : ""}
                                        
                                        </td>
                                    </tr>
                                    <tr><td></td></tr>
                                    <tr><td colspan="3">&nbsp;</td></tr>
                                    <tr>
                                        {/* <td width="10%">&nbsp;</td> */}
                                        <td  nowrap="nowrap" class="strongerTxtLable" align="left">{/*Partner Id*/} {t('034')}&nbsp;&nbsp;:
                                        <span class="labelTextBold"> {distId}</span> </td>
                                    </tr>
                                    <tr><td>&nbsp;</td></tr>
                                    <tr>
                                        {/* <td width="10%">&nbsp;</td> */}
                                        <td nowrap="nowrap" class="strongerTxtLable" align="left">{/*Company Name*/} {t('resetpassword1')}&nbsp;&nbsp;:
                                        <span class="labelTextBold">{company}</span></td>
                                    </tr>

                                    <tr><td>&nbsp;</td></tr>

                                    <tr>
                                        {/* <td width="10%">&nbsp;</td> */}
                                        <td nowrap="nowrap" class="strongerTxtLable" align="left">{/*First Name*/}{t('resetpassword2')}&nbsp;&nbsp;:
                                        <span class="labelTextBold" >{fName}</span></td>
                                    </tr>

                                    <tr><td>&nbsp;</td></tr>

                                    <tr>
                                        {/* <td width="10%">&nbsp;</td> */}
                                        <td class="strongerTxtLable" align="left">{/*Last Name*/}{t('resetpassword3')}&nbsp;&nbsp;:
                                        <span class="labelTextBold">{lName}</span></td>
                                    </tr>

                                    <tr><td>&nbsp;</td></tr>

                                    <tr>
                                        {/* <td width="10%">&nbsp;</td> */}
                                        <td class="strongerTxtLable" align="left">{/*e-mail Address*/}{t('037')}&nbsp;&nbsp;:
                                        <span class="labelTextBold">{eMail}</span></td>
                                    </tr>

                                    <tr><td>&nbsp;</td></tr>

                                    <tr>
                                        {/* <td width="10%">&nbsp;</td> */}
                                        <td class="strongerTxtLable" align="left">{/*MDN*/}{t('030')}&nbsp;&nbsp;:
                                        <span class="labelTextBold">{mdn}</span></td>

                                    </tr>

                                    <tr><td>&nbsp;</td></tr>

                                    <tr>
                                        {/* <td width="10%">&nbsp;</td> */}
                                        <td class="strongerTxtLable" align="left">{/*Channels*/}{t('041')}&nbsp;&nbsp;:&nbsp;&nbsp;
                                            {/* <select name="channel" id="channel" size="1" class="selectBox">
                                                <option value="W">WEB</option>
                                                <option value="U">USSD/OTHER</option>
                                            </select> */}
                                            <FormControl sx={{minWidth: 120 }} size="small">
      <Select
      sx={{
        '& legend': { display: 'none' },
        '& .MuiInputLabel-shrink': { opacity: 0, transition: "all 0.2s ease-in" }
      }}
        labelId="demo-select-small-label"
        id="channel"
        className={'selected_dropdown'}
        name="selectedChannels" 
        value={selectedChannels} onChange={(e) => setSelectedChannels(e.target.value)}
      >
        <MenuItem value='W'>WEB</MenuItem>
        <MenuItem value='U'>USSD/{t("other")}</MenuItem>
        {/* <MenuItem value={30}>Thirty</MenuItem> */}
      </Select>
    </FormControl>
                                        </td>
                                    </tr>

                                    <tr><td>&nbsp;</td></tr>
                                    <tr>
                                        <td width="100%" colspan="3" valign="bottom" nowrap="nowrap" align="left">
                                       <Box style={{marginBottom: '10px'}}>
                                       <Button className={'hoverEffectButton'} size="small" onClick={resetPassword} variant="contained" endIcon={<RotateLeftIcon />}>
                                        {t('029')}
      </Button><Button className={'hoverEffectButton'} size="small" style={{marginLeft: '8px'}} onClick={handleReturn} variant="contained" endIcon={<KeyboardReturn />}>
      {t('013')}
      </Button>
                                       </Box>
                                            {/* <input type="button" value={t('029')} class="inputButton" onClick={resetPassword} />&nbsp;
                                            <input type="button" value={t('013')} class="inputButton" onClick={handleReturn} /> */}
                                        </td>
                                    </tr>

                                </tbody>
                                </table>
                                </form>
                        </td>

                        

                    </tr>

                    <tr height="60px">
                        <td colSpan={2}>

                            <Footer />

                        </td>
                    </tr>

                </tbody>
            </table>
        </>

    );
}

export {PasswordResetVerification} ;
