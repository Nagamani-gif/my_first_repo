/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react-hooks/rules-of-hooks */
import React, { useRef } from 'react'
import { Footer, Header, LeftBgImage, PaymentManagerHeading, ProfileMenu } from './PageComponents'
// import { Link } from 'react-router-dom';
import { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import TopMenu from './TopMenu';
import axios from 'axios';
import { useSelector } from 'react-redux';
import i18n from './i18n';
import { Box, Button, Checkbox, FormControl, Grid, InputLabel, MenuItem, Select, Table, TableBody, TableCell, TableContainer, TextField } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { FindInPageRounded, KeyboardReturn, AddCardRounded } from '@mui/icons-material';
import SendIcon from '@mui/icons-material/Send';
import { Paper, TableHead, TableRow } from '@mui/material';
import { ToastContainer, toast } from "react-toastify";
import { CircularProgress } from '@mui/joy';
import { Pagination } from '@mui/material';

export default function NotificationConfigMain() {
  //sessionStorage.setItem("selectedIndex", 1);
 sessionStorage.setItem("selectedLink", "a_profile");
  const {t} = useTranslation();
  const toastId = useRef(null);
    const exampleData = JSON.parse(localStorage.getItem("userData"))
    const partnerLoginId = exampleData.LOGIN_ID;
    let localeVar=i18n.language;
    console.log(localeVar);

    const [submit, setSubmit] = useState(false);
    const [partnerId, setPartnerId] = useState('');
    const [eventId, setEventId] = useState('S');
    const [status, setStatus] = useState('E');
    const [addList, setAddList] = useState([]);


//adding for Response data
  const [notifConfigList, setNotifConfigList] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsFound, setRecordsFound] = useState(0);
  const [eventArray,setEventArrey] =useState([]);
  const [eventIdDB, setEventIdDB] = useState('');

  const [showAddBtn,setShowAddBtn] =useState(true);
  const [showSubmitButton, setShowSubmitButton] = useState(false);
  const [showAddRow, setShowAddRow] = useState(false);
  const [showModifybtn, setShowModifybtn] = useState(false);
  const [showSearchData, setShowSearchData] = useState(false);
  const [rowCountString,setRowCountString ]=useState(0);
  const [checkBox,setCheckBox ]=useState(0);
  // const [checkBoxs, setCheckBoxs] = useState({
  //   0: true, // Checkbox at index 0 is checked by default
  //   1: true, // Checkbox at index 1 is checked by default
  //   // Add more as needed
  // });
  const [checkBoxs, setCheckBoxs] = useState({});
  
  
  const [error, setError] = useState('');
  const [checkBoxdisabled, setCheckBoxdisabled] = useState(true);
  const [showpagination, setShowpagination] = useState(false);

  // adding For Add/Modify Operation
  const [jobFlag, setJobFlag] = useState('');
  const [editableRows, setEditableRows] = useState({});
  const [addPartnerIdd, setAddPartnerIdd] = useState('');
  // let addPartnerIdd='';
  
  let statusNotif="E";
  let eventTempId="S";

  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
  const tableRef = useRef(null);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;


  useEffect(() => {
    // Set the browser title
    document.title = t('2472_014');
  }, []);

      useEffect(() => {
        dropdown(); // Fetch data when the component mounts
      },[]);

const dropdown = async ()=>{
  const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_EVENTDESC;
  const response = await axios.post(apiUrl, {
    userName,
    password,
      partnerLoginId,
      localeVar

  });
  const responseDropDown = response.data;
  setEventArrey(responseDropDown.searchByEventId);
  setEventIdDB(responseDropDown.eventIdDB);
  console.log(responseDropDown.searchByEventId);
 }
 if(eventId==="S"){
  eventTempId="";
}else{
  eventTempId =eventId;
}


let startRecord = 0;
let endRecord = 10;


const handleChangePage = (event, newPage) => {
  setPage(newPage);
  setShowSearchData(true);
  setError('');
  if (tableRef.current) {
    tableRef.current.scrollTop = 0;
  }
  setCheckBox('');
  // setCheckBoxs('')
  // fetchData();
};

if(status==="E"){
  statusNotif="";
}else if(status==="A"){
  statusNotif="A";
}else if(status==="I"){
  statusNotif="I";
}
// useEffect(() => {
//   fetchData(); // Fetch data when the component mounts
// }, [startRecord,endRecord]); // Empty dependency array ensures this effect runs only once on mount

useEffect(()=>{
  console.log(page, "page??????????????");
  if(page>0 && showSearchData){
    fetchData();
  }
},[page, startRecord, endRecord])



    const fetchData = async () => {
      console.log("endRecord:::::",endRecord);
        try {
          // Fetch data from API
          const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL;
          const response = await axios.post(apiUrl, {
            userName,
            password,
            partnerLoginId,
            partnerId,
            localeVar,
            eventId:eventTempId,
            status:statusNotif,
            startPageNo:startRecord - 1,
            endPageNo:endRecord < 10 ? '10' : endRecord

          });
          const responseData = response.data;
          console.log("REsponse Data:::::",responseData);
          if(responseData.responseCode==="00"){
            // setIsLoading(false);
            setNotifConfigList(responseData.cnArrayList);
            console.log(responseData.cnArrayList);
            setTotalRecords(responseData.totalRecords);
            setRecordsFound(responseData.recordsFound);
            console.log("totalRecords***",responseData.totalRecords)
            console.log("recordsFound*****",responseData.recordsFound);
           }
           setPartnerId('');
          //  setStatus('E');
          //  setEventId('S');

      // if(responseData.responseDescription ==='No record Found'){

      //   console.log("responseDescription===", responseData.responseDescription)

      // }
          // Set data from response
        } catch (error) {
          console.error("An error occurred:", error);
        }
      };







  const Update = async () => {
    
      if(jobFlag === 'U'){
          const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_ADD;
          const response = await axios.post(apiUrl, {
            userName,
            password,
            localeVar,
            partnerLoginId,
            jobFlag,
            rowCountString,
           notifConfigList
        });
        const responseModifyData = response.data;
        console.log('responseModifyData::::::', responseModifyData);
        setError(responseModifyData.errorMsg);
        console.log('ErrorMsg::::::', error);
        fetchData();
        if(responseModifyData.errorMsg ==="Modified successfully."){
          setShowSubmitButton(false);
          setShowpagination(true);
        }
        setShowSubmitButton(false);
        setRowCountString(0);
        setEditableRows(false);
        setCheckBoxdisabled(true);
        setShowAddBtn(true);
        setShowModifybtn(true);

      }else if(jobFlag === 'I'){
          try {
            // Fetch data from API
            const apiUrl = window.config.apiUrl + process.env.REACT_APP_NOTIFICATION_URL_ADD;
            const response = await axios.post(apiUrl, {
              userName,
              password,
              localeVar,
              partnerLoginId,
              jobFlag,
              rowCountString,
              addList,
            });
    // debugger;
            const responseAddData = response.data;
            setError(responseAddData.errorMsg);
            console.log('ErrorMsg::::::', error);

console.log("responseAddData :::", responseAddData)
          // if(addPartnerIdd===''){
          //   toast.error("Please enter PartnerId");
          //   setShowSubmitButton(true);
          // }

          if (addPartnerIdd==='' ){
            if(!toast.isActive(toastId.current) )  {
            toastId.current = toast.error(t('2480_004')); 
            setShowSubmitButton(true);
          }
        }
          
          else if(responseAddData.errorMsg ==="Added Successfully." || responseAddData.errorMsg ==="Se lo ha añadido exitosamente."){
            endRecord=totalRecords+rowCountString;
            console.log('END RECORD...', endRecord);
            console.log('ROW COUNT STRINGGGGGG', rowCountString);
           await fetchData();
            setShowAddRow(false);
            setShowpagination(true);
            // Reset the row count after submission
            setRowCountString(0);
            setShowModifybtn(true);
            setShowSubmitButton(false);
          }else{
            setShowSubmitButton(true);
          }

            console.log('Response Data ADD:', error);
        
          } catch (error) {
            console.error('An error occurred:', error);
            // Handle error, e.g., display error message to the user
          }
        }
      };


      const Submit = ()=>{
       Update();
        //setShowSubmitButton(false);
        setCheckBox("");
        // setCheckBoxs("");
      }


const doSearch = async ()=>{ 
  try {

    setAddList([]); 
    await fetchData(); // Fetch data when search is triggered
    setPage(1);
    setShowSubmitButton(false);
    setShowModifybtn(true);
    setShowAddRow(false);
    setError('');
    setShowSearchData(true);
    setShowpagination(true);
  } catch (error) {
    console.error("An error occurred:", error);
  }
  setSubmit(true);
}

const firstEventId = eventArray.length > 0 ? eventArray[0].eventIdDB : '';
console.log("firstEventId====",firstEventId);

const addNotificationConfig = async () => {
  setError(" ");
  setShowpagination(false);

  // Clear previous rows' fields and ensure each row's checkbox is checked
  setAddList((prevList) =>
    prevList.map((item) => ({
      ...item,
      partnerId: "",                 // Clear the previous partnerId
      deliveryMethod: "E",            // Reset to default
      selfAlert: "N",
      eventId: firstEventId,          // Set default value for eventId
      childAlertSubscription: "NA",
      status: "A",
      otherDistributionList: "",
    }))
  );

  // Add a new row with default values
  setAddList((prevRows) => [
    ...prevRows,
    {
      partnerId: "",
      deliveryMethod: "E",
      selfAlert: "N",
      eventId: firstEventId,
      childAlertSubscription: "NA",
      status: "A",
      otherDistributionList: "",
    },
  ]);

  setAddPartnerIdd("");

  // Update checkboxes to ensure all are checked
  setCheckBoxs((prevState) => {
    const newState = { ...prevState };
    Object.keys(newState).forEach((key) => {
      newState[key] = true; // Mark each checkbox as checked
    });
    newState[Object.keys(newState).length] = true; // Add a checked state for the new row
    return newState;
  });

  await fetchData();
  setShowSubmitButton(true);
  setShowAddRow(true);
  setShowModifybtn(false);
  setRowCountString(prevCount => prevCount + 1);
  setJobFlag("I");
};

const checkvalueSelfArlet = (index, isChecked) => {
  const value = isChecked ? 'Y' : 'N';
  handleAdd(index, 'selfAlert', value);
  console.log("selfAlert=====",value)
};


const handleCheckboxChange = (index, checked) => {
  setCheckBox(prev => ({
    ...prev,
    [index]: checked
  }));
};

const handleCheckboxChanges = (index, checked) => {
  setCheckBoxs(prev => ({
    ...prev,
    [index]: checked
  }));
  
};

const Modify = () => {
  setJobFlag("U");
  setShowpagination(false);
  setError('');
  // Get selected rows (those with a checked checkbox)
  const selectedRows = Object.keys(checkBox).filter(index => checkBox[index]);
  console.log("selectedRows====", selectedRows);
  // Validation: check if there are no selected rows
  if (selectedRows.length === 0) {
    if (!toast.isActive(toastId.current)) {
      toastId.current = toast.error(t('6099'));
    }
    return; // Exit the function early if no rows are selected
  }else{
  // Update other state variables
  setShowSubmitButton(true);
  setShowModifybtn(false);
  setShowAddBtn(false);
  setCheckBoxdisabled(false);
  // Set editable rows for selected rows
  selectedRows.forEach(index => {
    setEditableRows(prevRows => ({
      ...prevRows,
      [index]: true
    }));
  });
  console.log("notifConfigList", notifConfigList);
  console.log("Editable Rows...", editableRows)
  }
};





const handleCheckboxSelfAlert = (index, isChecked, field) => {
  console.log("isChecked#############",isChecked);
  const value=isChecked ? 'Y' : 'N'
  handleInputChange(index,value ,field);
};
const handleInputChange = (index, value,field) => {
    console.log("INDEX////////////////", index);
    const updatedList = notifConfigList.map((item, i) => {
      if (i === index) {
        return {
          ...item,
         // otherDistributionList: value,
          [field]: value,

        };
      }
      return item;
    });
    setNotifConfigList(updatedList);
    console.log("updatedList====",updatedList);
    
};


//adding into list
const handleAdd = (index, field, value) => {
  const newRows = [...addList];
  newRows[index][field] = value;
  setAddList(newRows);
  console.log("newRows*******************",newRows);
};


const navigate = useNavigate();
const handleReturn = () => {
  // Go back to the previous page
  navigate(-1);
}
startRecord = (page - 1) * perpage + 1;
console.log("startRecord::::",startRecord);
endRecord = totalRecords > 0 
    ? Math.min(startRecord + perpage - 1, totalRecords) 
    : (page === 1 ? 10 : page * perpage);
    
console.log("endRecord::::",endRecord);
const totalPages = Math.ceil(totalRecords / perpage);

  return (
    <div>
    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
     <tbody>
       <Header/> 
    <tr height="65px">
    <PaymentManagerHeading />
    <TopMenu menuLink= {localeVar==='en'?"Profile":"Perfil"}/>
    </tr>
    <tr>
  
   <LeftBgImage />
  
<td valign="top">
  <title> Prepaid Movistar - Configure Notifications</title>
  <table border={0} width="100%" cellSpacing={0} cellPadding={1}>
                            <tbody>
                                <ProfileMenu />
                                <tr>
                                    <td align="center">&nbsp;</td>
                                    <td align="center">&nbsp;</td>
                                </tr>
                            </tbody>
                        </table>
  <div className={'mL8 input_boxess'}>
                <table border={0} cellPadding={0} cellSpacing={1} width="100%" bordercolor="blue" align="left">
    <tbody>
        {/* <tr><td colspan="6" class="headerTxt" align="center">&nbsp;</td></tr> */}
        {/* <tr><td colSpan={6} className="headerTxt" align="center">Configure Notifications</td></tr>
        <td colSpan={6}>&nbsp;</td> */}
        <tr>
        <td>

<Box style={{display:'flex', gap:'20px'}}>
<TextField type="text" name="partnerId" id="pid" className={'sampleInput mb5'}
                                  onChange={e => setPartnerId(e.target.value)} value={partnerId} label={
                                    <span>
                                      {`${t('092')}`}
                                    </span>} style={{maxWidth:'250px'}} />
                                    <FormControl className={'selected_formcontrol'} sx={{ minWidth: 120 }} size="small">
                      <InputLabel id="demo-select-small-label">{t('055')}</InputLabel>

                                  <Select className={'bankSelect'}labelId="demo-select-small-label" id="demo-select-small"
                                    label={t('055')} value={status} onChange={e => setStatus(e.target.value)}>
                                    <MenuItem value="E">{t('056')}</MenuItem>
                                    <MenuItem value="A">{t('057')}</MenuItem>
                                    <MenuItem value="I">{t('058')}</MenuItem>
                                  </Select>
                    </FormControl>
                                    <FormControl className={'selected_formcontrol'} sx={{ minWidth: 320, marginLeft:'0px' }} size="small" align="left">
                                  <InputLabel id="demo-select-small-label">{t('000')}</InputLabel>

                                  <Select className={'bankSelect'} value={eventId} labelId="demo-select-small-label" id="demo-select-small"
                                    label={t('000')} onChange={e => setEventId(e.target.value)} >


                                    <MenuItem value="S">{t("2616011")}</MenuItem>
                                    {eventArray.map(event => (
                                      <MenuItem value={event.eventIdDB}>{event.eventDescription}</MenuItem>
                                    ))}
                                  </Select>
                              </FormControl>

                    <Box>
                    <Button className={'hoverEffectButton'} style={{marginTop:'3px'}} size="small" variant="contained" onClick={() => doSearch()} endIcon={<FindInPageRounded />}>{t('043')}</Button>
                    </Box>

</Box>
</td></tr>
<tr><td>&nbsp;</td></tr>

{error && (
                  <tr>
                    <td colSpan={6} align="center">
                      <div className="redTxt" style={{color: 'red'}}>{error}</div>
                    </td>
                  </tr>
)}

<tr>
  <td>
{notifConfigList.length > 0 ? (
<>
<Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "10px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
                <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                    <span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span>
                      
                </Grid>      
              </Grid>

 {/* <table border={0} width="100%"cellPadding={0}>
 <tr class="">
  <td width="55%" className={"strongerTxtLable"} align="left">{t('059')} : {totalRecords}</td>
  <td width="45%" className={"strongerTxtLable"} align="right">{t('060')} : {startRecord}-{endRecord} </td> 
</tr>
</table> */}
</>
 ) : (
  <table border={0} width="100%"cellPadding={0}>
  <tr class="darkgray">
 </tr>
 </table>

 )}
{/* <Table border={0} cellPadding={1} className="cellSpacing" width="100%" bordercolor="red"> */}
<TableContainer ref={tableRef} component={Paper} className={'shadowTable configTable'} style={{ maxHeight: '300px', marginTop: notifConfigList.length > 0 ? '5px' : '10px', overflowX: 'hidden' }}>
<Table size="small" className={''} stickyHeader aria-label="sticky table"> 
<TableHead>
    {/* <TableRow>
      <TableCell colSpan={8}></TableCell>
    </TableRow> */}
    <TableRow className="darkgray">
      <TableCell className="whiteboldtext" align="center" />
      <TableCell className="whiteboldtext" align="center">{t('034')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('000')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('838')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('839')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('840')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('841')}</TableCell>
      <TableCell className="whiteboldtext" align="center">{t('0162')}</TableCell>
    </TableRow>
  </TableHead>  
  <TableBody>
    {/* {showData && notifConfigList.length > 0 ? ( */}



                              {notifConfigList.length > 0 || submit || showSubmitButton ? <></> :

                                <TableRow align="center">
                                  <TableCell colspan="9" style={{ color: 'red' }} class="redTxt" align="center">
                                    {/*Please provide search criteria.*/}
                                    {t('038')}
                                  </TableCell>
                                </TableRow>

                              }

                              {notifConfigList.length === 0 && submit && !showSubmitButton ?
                                <TableRow align="center">
                                  <TableCell colspan="9" class="redTxt" style={{ color: 'red' }} align="center">
                                    {/*No data found for the given search criteria.*/}
                                    {t('7058')}
                                  </TableCell>
                                </TableRow>
                                : <></>
                              }

    {notifConfigList.length > 0 ? (
    notifConfigList.map((item, index) => (
        <TableRow key={index} className={index % 2 === 0 ? "lightgreen" : "lightyellow"}>
            <TableCell className="smallerTxt" align="center" style={{padding: '0'}}>

            <Checkbox //checked={editableRows[index] || false}
            checked={checkBox[index] || false}
            disabled={checkBoxdisabled ? false : true}
            onChange={e => handleCheckboxChange(index, e.target.checked)}/>
            </TableCell>


            <TableCell className="smallerTxt" align="center">{item.partnerId}</TableCell>
            <TableCell className="smallerTxt" align="center">{item.eventDesc}</TableCell>
            <TableCell className="smallerTxt" align="center">{item.deliveryMethod === 'E' ? <>{t("Email")} </>: "SMS"}</TableCell>
            <TableCell className="smallerTxt" align="center" style={{padding: '0'}}>
                {editableRows[index] ? (
                    <Checkbox
                    value={item.selfAlert}
                    checked={item.selfAlert === 'Y'}
                    onChange={e => handleCheckboxSelfAlert(index, e.target.checked,'selfAlert')}/>
                ) : (
                  item.selfAlert === 'Y' ? <>{t("yes")}</> : <>{t("No_config")}</>
                )}
            </TableCell>
            <TableCell className="smallerTxt" align="center" style={{overflowWrap:"anywhere"}}>
                                {editableRows[index] ? (
                                    <textarea 
                                    className={'textBoxSmall'}
                                    style={{height:'auto'}}
                                    value={item.otherDistributionList}
                                    onChange={e => handleInputChange(index, e.target.value, 'otherDistributionList')}
                                    />
                                ) : (
                                   item.otherDistributionList
                                )}
            </TableCell>
            <TableCell className="smallerTxt" align="center" style={{padding:'0'}}>
                {editableRows[index] ? (
                    <Select  value={item.childAlertSubscription === 'C' ? "C" : "NA"} className={'selected_dropdown'}
                    onChange={e => handleInputChange(index, e.target.value, 'childAlertSubscription')}>
                    <MenuItem value="NA">{t('842')}</MenuItem>
                    <MenuItem value="C">{t('843')}</MenuItem>
                    </Select>
                ) : (
                    item.childAlertSubscription === 'C' ? <>{t('843')}</> : <>{t('842')}</>
                )}
            </TableCell>
            <TableCell className="smallerTxt" align="center">
                {editableRows[index] ? (
                    <Select  value={item.status === 'A' ?"A":"I"} className={'selected_dropdown'}
                    onChange={e => handleInputChange(index, e.target.value, 'status')}>
                       <MenuItem value="A">{t('057')}</MenuItem>
                      <MenuItem value="I">{t('058')}</MenuItem>
                    </Select>
                ) : (
                    item.status === 'A' ? <>{t("2616014")}</> : <>{t("2616015")}</>
                )}
            </TableCell>
        </TableRow>
    ))
 ) :<></>} 
{/* //     <TableRow>
//         <TableCell colSpan={8} align="center" style={{color: 'red'}} className="redTxt">
//             Please provide search criteria.
//         </TableCell>
//     </TableRow>
//  */}




{showAddRow && (<>
   {addList.map((item, index) => (
                                    <TableRow
                                      className="lightyellow"
                                      key={`addRow-${index}`}
                                    >
                                      {/* ... other cells */}
                                      <TableCell
                                        className="smallerTxt"
                                        align="center"
                                        style={{ padding: "0" }}
                                      >
                                        <Checkbox
                                          name={`chkBox-${index}`}
                                          id={`chkBox-${index}`}
                                          // checked={checkBox[index]}
                                          checked={checkBoxs[index] || false}
                                          onChange={(e) =>
                                            handleCheckboxChanges(
                                              index,
                                              e.target.checked
                                            )
                                          }
                                        />
                                      </TableCell>
                                      <TableCell
                                        className="smallerTxt"
                                        align="center"
                                      >
                                        <input
                                          className="textBoxSmall"
                                          type="text"
                                          style={{ width: "50px" }}
                                          name={`partnerIdAdd-${index}`}
                                          id={`addPartnerId-${index}`}
                                          value={item.partnerId}
                                          onChange={(e) =>
                                           {
                                            handleAdd(
                                              index,
                                              "partnerId",
                                              e.target.value
                                            );
                                            setAddPartnerIdd(e.target.value);
                                           }
                                          }
                                        />
           </TableCell>
        <TableCell align="center" colSpan={0}>
          <Select name={`eventIdAdd-${index}`}
          style={{width:'195px'}}
          value={addList[index]?.eventId || (eventArray.length > 0 ? eventArray[0].eventIdDB : '')} // Set default value
           onChange={e => handleAdd(index, 'eventId', e.target.value)} className={'selected_dropdown'}>
          {/* onChange={e => setEventSearch(e.target.value)}> */}
            {/* <option value="" selected="selected">Select</option> */}
            {eventArray.map(event => (
              <MenuItem key={event.eventIdDB} value={event.eventIdDB}>{event.eventDescription}</MenuItem>
            ))}
          </Select>
        </TableCell>
        <TableCell align="center" colSpan={0}>
          <Select name={`deliveryMethodAdd-${index}`} id={`deliveryMethodAdd-${index}`}
           value={addList[index]?.deliveryMethod || 'E'} // Set default value to 'E'
            onChange={e => handleAdd(index, 'deliveryMethod', e.target.value)} className={'selected_dropdown'}>
           {/* onChange={e => setDeliveryMethodAdd(e.target.value)}> */}
            <MenuItem value="E">{t("Email")}</MenuItem>
            <MenuItem value="S">SMS</MenuItem>
          </Select>
        </TableCell>
        <TableCell align="center" colSpan={0} style={{padding: '0'}}>

        <Checkbox id={`selfAlertAdd-${index}`} name={`selfAlertAdd-${index}` }
        checked={addList[index]?.selfAlert === 'Y'}
        onChange={e => checkvalueSelfArlet(index, e.target.checked)}/>
        </TableCell>
        
        <TableCell align="center" colSpan={0}>
          <textarea style={{height:'auto'}}
        name={`otherDistributionListAdd-${index}`} value={item.otherDistributionList} className="textBoxSmall" id={`otherDistributionListAdd-${index}`} rows={2} cols={20} maxLength={512} 
          onChange={e => handleAdd(index, 'otherDistributionList', e.target.value)}/>
            
          {/* onChange={e => setOtherDistributionList(e.target.value)}/> */}
        </TableCell>
        <TableCell align="center" colSpan={0}>
          <Select name={`childAlertSubscriptionAdd-${index}`} id={`childAlertSubscriptionAdd-${index}`} 
          value={addList[index]?.childAlertSubscription || 'NA'} // Set default value to 'NA'
          onChange={e => handleAdd(index, 'childAlertSubscription', e.target.value)} className={'selected_dropdown'}>

           {/* onChange={e => setChildAlertSubscriptionAdd(e.target.value)}> */}
            <MenuItem value="NA">{t('842')}</MenuItem>
            <MenuItem value="C">{t('843')}</MenuItem>
          </Select>
        </TableCell>
        <TableCell align="center">
          <Select name={`serachByStatusAdd-${index}`} id={`serachByStatusAdd-${index}`} 
           value={addList[index]?.status || 'A'} // Set default value to 'A'
          // onChange={e => setSearchByStatus(e.target.value)} >
          onChange={e => handleAdd(index, 'status', e.target.value)} className={'selected_dropdown'}>
            <MenuItem value="A" selected>{t('057')}</MenuItem>
            <MenuItem value="I">{t('058')}</MenuItem>
          </Select>
        </TableCell>
      </TableRow>
    ))}
  </>
)}

</TableBody>
  </Table>
  </TableContainer>


 {/* )} */}

</td>
  </tr>
  
    </tbody>
    <tr><td>&nbsp;</td></tr>

                  {notifConfigList.length > 0 && showpagination? <Pagination
                    count={totalPages}
                    page={page}
                    onChange={handleChangePage}
                    showFirstButton
                    showLastButton
                  /> : <></>}
                  <Table>

                    <tfoot>
                      <Box style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box
                          sx={{
                            textAlign: "right",
                            padding: "4px 0px 4px 0 !important",
                          }}
                          className={'displayFlex'}
                        >
                        </Box>
                      </Box>

                      <tr>

                      </tr>
                    </tfoot>
                  </Table>



    <tr>
   <td align="center" colspan="3">
   <Box className={'displayFlexCenter'} gap={1}>
   {showAddBtn && (
   <Button id="submitImg" onClick={() => addNotificationConfig()} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<AddCardRounded />}>
        {/* Add */}{t('10')}
      </Button>
    )}
    {/* <input type="button" id="submitImg" value="Add" className="inputButton" onClick={() => addNotificationConfig()} /> */}
   {showModifybtn && notifConfigList.length !== 0 && (
      <Button id="submitImg" onClick={() =>Modify()} className={'hoverEffectButton'} size="small" variant="contained" endIcon={<AddCardRounded />}>
      {/* Modify */}{t('11')}
    </Button>
    // <input type="button" id="submitImg" Value="Modify" className="inputButton"onClick={() =>Modify()}/>
    )}
    {showSubmitButton && (
      <Button  id="submitImg" className={'hoverEffectButton'} onClick={() =>Submit()} size="small" variant="contained" endIcon={<SendIcon />}>
      {/* Submit */}{t('242409')}
    </Button>
    // <input type="button" id="submitImg" Value="Submit" className="inputButton"onClick={() =>Submit()}/>
    )}
     <Button className={'hoverEffectButton'} onClick={handleReturn} size="small" variant="contained" endIcon={<KeyboardReturn />}>
        {/* Return */} {t('242410')}
      </Button>
   </Box>
    {/* <input type="button" defaultValue="Return" className="inputButton" onClick={handleReturn}/> */}
    </td>
    {/* <td>{modificatonList.map((list)=>(
      <>
      <p>{list.otherDistributionList} <br /></p>
      <p>{list.status} <br /></p>
      <p>{list.selfAlert} <br /></p>
      <p>{list.childAlertSubscription} <br /></p></>
    ))}</td> */}
    </tr>
    <tr>&nbsp;</tr>
    </table>
    <ToastContainer 
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      /> 

  </div>

</td>
</tr>

<tr height="60px"><td colSpan={2}>
      <Footer/>
      </td>
    </tr>
    </tbody>
</table>
    </div>
  )
}
