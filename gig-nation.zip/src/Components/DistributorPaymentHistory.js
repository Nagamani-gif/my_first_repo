import React, { useState, useEffect } from 'react';
import TopMenu from './TopMenu';
import { useTranslation } from 'react-i18next';
import { Footer, Header, LeftBgImage,JasperTopMenu, PaymentManagerHeading, ProfileMenu } from './PageComponents';
import axios from 'axios';
import i18n from './i18n';
import { Box, Grid, Tab, Tabs } from '@mui/material';
import { NavLink, useLocation, useNavigationType } from 'react-router-dom';
import { CalendarMonth, CalendarToday, CallMade, PendingActions, PieChart, Today } from '@mui/icons-material';
import numeral from 'numeral';
import PieChartIcon from '@mui/icons-material/PieChart';


export default function DistributorpaymentHistory() {
    const { t } = useTranslation();
    const localVar=i18n.language
    console.log("llll="+i18n);
 sessionStorage.setItem("selectedLink", "a_profile");
   useEffect(()=>{
    var x = document.querySelector(".subLinkVisited1");
    if(x !== null){
      x.classList.replace("subLinkVisited1", "activeProfilemenu");
      x.classList.remove("profile_menu");
    }
   },[])
        //   e.target.classList.replace("activeProfilemenu", "subLinkVisited1");
        
  return (
    <div>
      <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">
        <tbody>
          
                  <Header />
          <tr height="65px">
          <PaymentManagerHeading />
          <TopMenu menuLink= {localVar==='en'?"Home":"Hogar"}/>
          </tr>
          <tr>
          <LeftBgImage />
            {/* <td valign="top" style={{ width:"100px" ,borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)" }}> */}
          {/* <img src={bg} alt="" style={{width:'100%', height:'100%', objectFit:'cover'}} /> */}
            {/* </td> */}
            <td valign="top">
              <meta httpEquiv="Content-Type" content="text/html; charset=ISO-8859-1" />
              <title>Distributor Payments</title>
            {/* {data && <JasperTopMenu />}   */}
            <ProfileMenu />
              {/* <div>
                <h1>Welcome to the Home Page!</h1>
                {data ? (
                  <>
                    <p>Site Language: {data.siteLanguage}</p>
                    <p>Locale: {data.localeValue}</p>
                    <p>Country: {data.countryValue}</p>
                  </>
                ) : (
                  <p>Loading...</p>
                )}
              </div> */}
              
            </td>
          </tr>
          <tr height="55px">
            <td colSpan={2}>
              <link href="/airmanage/networkadmin/stylesheets/abcstyles-new.css" rel="stylesheet" type="text/css" />
               <Footer />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
