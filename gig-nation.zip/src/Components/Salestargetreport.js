/* eslint-disable no-undef */
 /* eslint-disable react-hooks/exhaustive-deps */
 /* eslint-disable no-unused-vars */
 /* eslint-disable jsx-a11y/anchor-is-valid */
 /* eslint-disable react/jsx-no-comment-textnodes */
 /* eslint-disable no-script-url */
 /* eslint-disable jsx-a11y/alt-text */
 import React, { useState, useEffect , useRef,useCallback } from 'react';
 import { Footer, Header, JasperTopMenu, LeftBgImage, PaymentManagerHeading, ReportsTopMenu, SubDistMenu, TransactionTopMenu } from './PageComponents'
 import TopMenu from './TopMenu'
 import axios from 'axios';
 import { Link, useNavigate,NavLink } from 'react-router-dom';
 import { useSelector } from 'react-redux';
 import { Box, Button, Grid, Pagination, Paper, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, Typography,TextField,MenuItem,FormControl ,InputLabel,Select,FormLabel,RadioGroup,FormControlLabel,Radio,Menu,styled } from '@mui/material';
 import { KeyboardReturn,CloudDownload } from '@mui/icons-material';
 import i18n from './i18n';
 import { useTranslation } from 'react-i18next';
 import { CircularProgress } from '@mui/joy';
 import * as XLSX from 'xlsx';
 import { utils, writeFile } from 'xlsx';
 import ExcelJS from 'exceljs';
import SendIcon from '@mui/icons-material/Send';
import {CancelRounded} from '@mui/icons-material';
import { DatePicker, DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import SaveIcon from '@mui/icons-material/Save'; //Save
import RestartAltIcon from '@mui/icons-material/RestartAlt'; // For Reset
import CheckCircleIcon from '@mui/icons-material/CheckCircle'; //Apply  As of now use these icons for buttons later if needed we will change 

import jsPDF from 'jspdf';
import 'jspdf-autotable';

// import 'jspdf-autotable';

const Salestargetreport = () => {
    sessionStorage.setItem("selectedLink", "e_transactions");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [recordsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
  const navigate = useNavigate();
  const [salesPersonId, setSalesPersonId] = useState('');
  const [anchorEl, setAnchorEl] = useState(null);

  console.log("totalRecords++++++++++++",totalRecords)
let startRecord=0;
  let endRecord =10;



  const styleObj = {
    minHeight: '30px',
    fontSize: '14px',
    padding: '7px 10px',
    maxHeight: '27px',
    margin: '10px 5px 5px 5px',
    borderRadius: '5px',
    color: '#1976d2',
    transition: '0.5s',
    opacity: '1',
    background: '#fff',
    color: '#3399FF',
    border: '1px solid #1976d2',
    textTransform: 'capitalize',
    "&:hover": {
      background: '#3399FF',
      color: '#fff',
      border: '1px solid #3399FF',
      borderRadius: '5px',
    },
   "&.Mui-selected": {
    color: '#fff',
    background: '#3399FF',border:' 1px solid #3399FF',
  }
  };

  const handleSubmit1 = async (e) => {
  e.preventDefault();
  const firstPage = 1;
  setPage(firstPage);
  await fetchData(firstPage); // fetch data for page 1
};

const clearData=()=>{
  setSalesPersonId('');
}



const formatSpanishNumbers = (date) => {
    return new Intl.DateTimeFormat('es-ES', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);

//  debugger;
  const fetchData = async (pageNumber = 1) => {
  const startRecord = (pageNumber - 1) * perpage + 1;
  const endRecord = startRecord + perpage - 1;
    setIsLoading(true);
    try {

      const apiUrl = window.config.apiUrlJasper+'/salesTargetReport';
     
      const response = await axios.post(apiUrl, {          
        userName,
        password,
        localeVar,
        partnerId : salesPersonId,
        startPageNo: startRecord,
        endPageNo: endRecord
      
       });
        
      console.log("response::::::",response.data);
      if (response.status === 200 && Array.isArray(response.data)) {
       setItems(response.data);
       setTotalRecords(response.data[0]?.noOfRows ?? 0); // Safely get noOfRows
      
    }
  } catch (error) {
    console.error('An error occurred:', error);
  } finally {
    setIsLoading(false);
  }
};
//  debugger;
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };

 
  const fetchDataDownload = async () => {
    try {
      const userName = process.env.REACT_APP_USERNAME;
      const password = process.env.REACT_APP_PASSWORD;
      const localeVar = 'en';
      const apiUrlDownload = window.config.apiUrlJasper+'/salesTargetReport';

      const response = await axios.post(apiUrlDownload, {
        userName,
        password,
        localeVar,
        // partnerLoginId,
      });

        if (!Array.isArray(response.data)) {
      throw new Error('Invalid API response: Expected array');
    }

       return response.data;
    } catch (error) {
      console.error('Error fetching data:', error);
      return [];
    }
  };

  const exportAsExcel = async () => {
    const downloadItems = await fetchDataDownload();
    if (!downloadItems || downloadItems.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('SalesTarget_Report');

    const numberOfColumns = 27;
    const headingRow1 = worksheet.addRow([t('2472_47')]);
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    headingRow1.getCell(1).font = { bold: true };
    headingRow1.getCell(1).alignment = { horizontal: 'center' };
    worksheet.addRow([]);
  
    const columnHeaders = [
      t('2472_03'), t('023'), t('0117'),t('2472_04'), t('0140'), t('034'), t('2472_10')    
    ];

const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;

const totalRecordsRow = worksheet.addRow([`${t('032')}: ${totalRecords}`]);
worksheet.mergeCells(totalRecordsRow.number, 1, totalRecordsRow.number, numberOfColumns);
totalRecordsRow.getCell(1).font = { bold: true };
totalRecordsRow.getCell(1).alignment = { horizontal: 'left' };

    const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' }, left: { style: 'thin' },
        bottom: { style: 'thin' }, right: { style: 'thin' },
      };
    });

    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
      item.orderId,
      item.orderDate,
      item.transactionID,
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      item.currency,
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      ]);
       dataRow.eachCell(cell => {
      cell.border = {
        top: { style: 'thin' }, left: { style: 'thin' },
        bottom: { style: 'thin' }, right: { style: 'thin' },
      };
      cell.alignment = { horizontal: 'center' };
    });
  });

  worksheet.addRow([]);
  const endOfReportRow = worksheet.addRow([t('0171')]);
  worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
  const endOfReportCell = endOfReportRow.getCell(1);
  endOfReportCell.font = { italic: true, underline: true, bold: true };
  endOfReportCell.alignment = { horizontal: 'center' };

  worksheet.columns.forEach(column => {
    let maxLength = 10;
    column.eachCell({ includeEmpty: true }, cell => {
      const cellValue = cell.value ? cell.value.toString() : '';
      maxLength = Math.max(maxLength, cellValue.length + 2); // Add padding
    });
    column.width = maxLength > 40 ? 40 : maxLength; // Optional: cap width to 40
  });

  worksheet.protect('yourPassword', {
    selectLockedCells: true,
    selectUnlockedCells: true,
  });

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });

  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'SalesTarget_Report.xlsx';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


const exportAsPdf = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  // Use A2 for wider space to fit all columns
  const doc = new jsPDF({
    orientation: 'landscape',
     format: [500, 1000],
    unit: 'pt'
  });

  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;

  // Heading
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text(t('2472_47'), doc.internal.pageSize.getWidth() / 2, 40, { align: 'center' });

  // Total records
  doc.setFontSize(10);
  doc.setFont(undefined, 'normal');
  doc.text(`${t('032')}: ${totalRecords}`, 40, 60);

  const columnHeaders = [
    t('2472_03'), t('023'), t('0117'), t('2472_04'), t('0140'), t('034'), t('2472_10')   
  ];

  const rows = downloadItems.map(item => [
    item.orderId,
      item.orderDate,
      item.transactionID,
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      item.currency,
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
  ]);

  // AutoTable
  doc.autoTable({
    startY: 70,
    head: [columnHeaders],
    body: rows,
    styles: {
      fontSize: 5,       // Smaller font for more data
      overflow: 'linebreak',
      cellPadding: 1
    },
    headStyles: {
      
      fillColor: [41, 128, 185],
      halign: 'center',
      fontSize: 6
    },
    theme: 'grid',
    margin: { top: 70, left: 10, right: 10 }
  });

  // Footer
  doc.setFontSize(10);
  doc.setFont(undefined, 'italic');
  doc.text(t('0171'), doc.internal.pageSize.getWidth() / 2, doc.lastAutoTable.finalY + 20, { align: 'center' });

  doc.save('SalesTarget_Report.pdf');
};

const exportAsCSV = async () => {
  const downloadItems = await fetchDataDownload();
  if (!downloadItems || downloadItems.length === 0) return;

  const numberOfColumns = 27;

  const columnHeaders = [
    t('2472_03'), t('023'), t('0117'), t('2472_04'), t('0140'), t('034'), t('2472_10')
   
  ];

  const totalRecords = downloadItems[0]?.noOfRows || downloadItems.length;

  // CSV Rows
  const rows = [];

  // Add title
  rows.push([t('2472_47')]);
  rows.push([]);

  // Add total records
  rows.push([`${t('032')}: ${totalRecords}`]);
  rows.push([]);

  // Add headers
  rows.push(columnHeaders);

  // Add data rows
  downloadItems.forEach(item => {
    rows.push([
      item.orderId,
      item.orderDate,
      item.transactionID,
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      item.currency,
      typeof item.orderAmount === 'number' ? item.orderAmount.toFixed(2) : "---",
      
    ]);
  });

  // Add end-of-report
  rows.push([]);
  rows.push([t('0171')]);

  // Convert to CSV string
  const csvContent = rows
    .map(row => row.map(val => `"${val != null ? val : ''}"`).join(','))
    .join('\n');

  // Download as .csv
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'SalesTarget_Report.csv';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};


 const handleDownload = async (type) => {
  setAnchorEl(null);
  if (type === 'excel') {
    await exportAsExcel();
  } else if (type === 'pdf') {
    await exportAsPdf();
  } else if (type === 'csv') {
     await exportAsCSV();
  }
};

  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  startRecord = (page - 1) * perpage + 1;
  endRecord =  totalRecords > 0 
  ? Math.min(startRecord + perpage - 1, totalRecords) 
  : (page === 1 ? 10 : page * perpage);


const handleChangePage = async (event, newPage) => {
  event.preventDefault();
  setPage(newPage);
  await fetchData(newPage); // fetch data for the selected page
};

const highlightSelectedLink = (e) => {
  var x = document.querySelector(".subLinkVisited");
  if(x !== null){
    x.classList.replace("subLinkVisited", "subLink");
  }
  e.target.classList.replace("subLink", "subLinkVisited");
}

 const RedAsterisk = styled('span')({
    color: 'red',
  });
return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Transactions":"Transacciones"}/>
  </tr>

  <tr>
   

  <LeftBgImage />

<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', width: '100%', marginTop: '10px' }} className={'fundsTab'}>
   <Tabs style={{minHeight: '35px'}}>
   <NavLink
            to="/salestargetreportp"
            onClick={(e) => highlightSelectedLink(e)}
            // className={`profile_menu ${props.menu === "menuHighlight" ? 'addingClass' : ''}`}
            className={({ isActive }) => 
              isActive ? 'activeProfilemenu' : `profile_menu 
            ${props.menu === "menuHighlight" ? 'addingDynClass' : ''}`
            }
          ><Tab label={t('x_salestargetreportp')} /></NavLink>
   </Tabs>
  </Box>

  <div className={'mL8 input_boxess'}>
     <tr valign="top">
       <td width="60%%">
            {/* body starts */}

          

            
<table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>

          
                <Box style={{display:'flex',gap:'20px', marginTop:'10px'}}>
                 
                   <TextField
                    type="text"
                    name="salesPersonId"
                    label={<span>{`${t('2472_01')}`}<RedAsterisk>*</RedAsterisk></span>}
                    style={{ maxWidth: '250px', width: '210px' }}
                    className={'sampleInput mb5'}
                    value={salesPersonId}
                    onChange={e => setSalesPersonId(e.target.value)}
                    autoComplete="off"
                  />

                  <Box style={{display: 'flex', alignItems: 'center', gap:'2px', justifyContent :'flex-end', marginTop:'-16px'}}>
          
                  <Button
                    style={{ height: '27px' }}
                    className={'hoverEffectButton'}
                    size="small"
                    variant="contained"
                    endIcon={<CheckCircleIcon />}
                    onClick={handleSubmit1}
                  >
                    {t('2472_26')}
                  </Button>
&nbsp;&nbsp;
                    <Button
                    style={{ height: '27px' }}
                    className={'hoverEffectButton'}
                    size="small"
                    variant="contained"
                     endIcon={<RestartAltIcon />}
                    onClick={clearData}
                  >
                    {t('2472_27')}
                  </Button>
      
                </Box>

              </Box>
                 
          

         

            {/* Submit Button Row */}

  
</table>





      <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
  item
  xs={5}
  sx={{ textAlign: "right", padding: "0 !important" }}
>
  {/*  {items.length > 0 ? (
    <>
      <span className={"strongerTxtLable"}>
        {t('032')} : {totalRecords}
      </span>
      <span className={"strongerTxtLable"}>
        &nbsp; / &nbsp;
        {t('033')} : {startRecord} - {endRecord}
      </span>
    </>
  ) : null}*/}
</Grid>

        </Grid>
    <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        {/* <TableHead>
          <TableRow className="darkgray">
            <TableCell align="center">{t('2472_03')}</TableCell>
            <TableCell align="center">{t('023')}</TableCell>
            <TableCell align="center">{t('0117')}</TableCell>
            <TableCell align="center">{t('2472_04')}</TableCell>
            <TableCell align="center">{t('0140')}</TableCell>
            <TableCell align="center">{t('0140')}</TableCell>
            <TableCell align="center">{t('0140')}</TableCell>
              
          </TableRow>
        </TableHead> */}
        <TableBody>
  {isLoading ? (
    <TableRow>
      <TableCell colSpan={25} align="center" className="spinnerDiv">
        {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
      </TableCell>
    </TableRow>
  ) : Array.isArray(items) && items.length > 0 ? (
    items.map((item, index) => (
      <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
       
        {/* <TableCell align="center">&nbsp;{item.orderId}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.orderDate}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.transactionID}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{typeof item.orderAmount === 'number' ? item.orderAmount .toFixed(2) : "---"}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{typeof item.orderAmount === 'number' ? item.orderAmount .toFixed(2) : "---"}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{item.authorizationID}&nbsp;</TableCell>
        <TableCell align="center">&nbsp;{typeof item.orderAmount === 'number' ? item.orderAmount .toFixed(2) : "---"}&nbsp;</TableCell> */}

      </TableRow>
    ))
  ) : (
    <TableRow>
      <TableCell colSpan={25} className="redTxt" style={{ color: 'red' }} align="center">
        {t("7058")}
      </TableCell>
    </TableRow>
  )}
</TableBody>


      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
{/* <Box style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}> */}
  <Box style={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', width: '100%' }}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{/* {items.length>0?
<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> } */}
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
   
      <div  style={{ display: 'flex', justifyContent: 'flex-start', marginTop: '10px', gap: '8px' }}
  onMouseEnter={(e) => setAnchorEl(e.currentTarget)}
  onMouseLeave={() => setAnchorEl(null)}
>
  {/* {items.length > 0 && (
    <div style={{ display: 'inline-block' }}>
      <Button
        className="hoverEffectButton"
        size="small"
        variant="contained"
        endIcon={<CloudDownload />}
        type="button"
        aria-controls={Boolean(anchorEl) ? 'download-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={Boolean(anchorEl) ? 'true' : undefined}
      >
        {t('089')}
      </Button>

      <Menu
        id="download-menu"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        MenuListProps={{
          style: { minWidth: 85 },
        }}
        PaperProps={{
          sx: { minWidth: 85, mt: 0.1 },
        }}
      >
        <MenuItem onClick={() => handleDownload('pdf')}>As PDF</MenuItem>
        <MenuItem onClick={() => handleDownload('excel')}>As Excel</MenuItem>
        <MenuItem onClick={() => handleDownload('csv')}>As CSV</MenuItem>
          </Menu>
        </div>
      )} */}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>

</td></tr>
</div>

</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
  )
}

export default Salestargetreport
