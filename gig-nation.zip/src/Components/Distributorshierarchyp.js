/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable react/jsx-no-comment-textnodes */
/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect , useRef,useCallback } from 'react';
import { Footer, Header, JasperTopMenu, LeftBgImage, PaymentManagerHeading, SubDistMenu } from './PageComponents'
import TopMenu from './TopMenu'
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Box, Button, Grid, Pagination, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { KeyboardReturn,CloudDownload } from '@mui/icons-material';
import i18n from './i18n';
import { useTranslation } from 'react-i18next';
import { CircularProgress } from '@mui/joy';
import * as XLSX from 'xlsx';
import { utils, writeFile } from 'xlsx';
import ExcelJS from 'exceljs';

const Distributorshierarchyp = () => {
  //sessionStorage.setItem("selectedIndex", 4);
  sessionStorage.setItem("selectedLink", "d_subdistributors");

  const {t} = useTranslation();
  const localeVar=i18n.language;
  const exampleData = JSON.parse(localStorage.getItem("userData")) 
  const [partnerLoginId ,setPartnerLoginId]= useState(exampleData.LOGIN_ID);
  const [items, setItems] = useState([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [recordsPerPage] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const [page, setPage] = useState(1);
  const [perpage, setPerPage] = useState(10);
   

  const navigate = useNavigate();
 
  // let startRecord = 0;
  // let endRecord = 10;

  // console.log("startRecord++++++++++++",startRecord)
  // console.log("endRecord++++++++++++",endRecord)

  console.log("totalRecords++++++++++++",totalRecords)

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  useEffect(() => {
    if (partnerLoginId) {
      fetchData();
    }
  }, [partnerLoginId, page]);

  const fetchChannels=async () => {
    //const apiUrl =  process.env.REACT_GET_CHANNELS_URL;
    const apiUrl3 = window.config.apiUrl + process.env.REACT_APP_GET_CHANNELS;
    console.log(apiUrl3);
    const response3 = await axios.post(apiUrl3, {
      userName,
      password,
      localeVar,
      channelTransAl: "",
    });
    // const[channels]=response.data;
 
    localStorage.setItem("channels", JSON.stringify(response3.data.channels));
    //console.log(JSON.stringify(response.data.channels));
    //  setsalesData(JSON.stringify(response.data.channels));
  }


  useEffect(() => {
    // Set the browser title
      document.title = t('2472_018');
  }, []);



useEffect(()=>{
fetchChannels();
})
  const fetchData = async () => {
    localStorage.removeItem('channels');
    setIsLoading(true);
    try {
      const apiUrl = window.config.apiUrl + process.env.REACT_APP_DISTRIBUTORSHIERA_URL;
      const response = await axios.post(apiUrl, {          
        userName,
        password,
        partnerLoginId,
        start: startRecord-1,
        end: endRecord < 10 ? '10' :endRecord
      });
      console.log("response::::::",response);
      if (response.status === 200) {
        setItems(response.data.distArrayBuilder);
        setTotalRecords(response.data.totalRecords);
      }
    } catch (error) {
      console.error('An error occurred:', error);
    } finally {
      setIsLoading(false);
    }
  };
  //  const navigate = useNavigate();
  const handleReturn = () => {
    navigate(-1);
  };
  const fetchDataDownload = async () => {
    try {
      let userName = process.env.REACT_APP_USERNAME;
      let password = process.env.REACT_APP_PASSWORD;
        const apiUrlDownload = window.config.apiUrl + process.env.REACT_APP_DISTRIBUTORS_HIERARCHYDOWNLOAD_URL;
        console.log('API URL:', apiUrlDownload);
        console.log('Partner Login ID:', partnerLoginId);

        const responseDownload = await axios.post(apiUrlDownload, {
            partnerLoginId,
            userName,
            password,
        });

        console.log('Response:', responseDownload);

        if (!responseDownload.data || !responseDownload.data.list) {
            throw new Error('Invalid API response');
        }
        const downloadData = responseDownload.data.list.map(partner => ({
            PARTNER_ID: partner.PARTNER_ID,
            PARTNER_FIRST_NAME: partner.PARTNER_FIRST_NAME,
            PARTNER_LAST_NAME: partner.PARTNER_LAST_NAME,
            PARTNER_TYPE: partner.PARTNER_TYPE,
            CITY: partner.CITY,
            PARTNER_EMAIL_ID: partner.PARTNER_EMAIL_ID,
            HIERARCHY_LEVEL: partner.HIERARCHY_LEVEL,
            ACCT_BALANCE: partner.ACCT_BALANCE,
        }));

        console.log('Download Data:', downloadData);

        return downloadData;
    } catch (error) {
        console.error('Error fetching data:', error);
        return [];
    }
};
  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

  const handleDownload = async () => {
   const downloadItems = await fetchDataDownload();
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('DistributorsHierarchy');
    const headingRow1 = worksheet.addRow([t('0172')]);
    const numberOfColumns = 8; // Adjust this to match the number of columns in your table
    worksheet.mergeCells(headingRow1.number, 1, headingRow1.number, numberOfColumns);
    const headingCell = headingRow1.getCell(1);
    headingCell.font = { bold: true };
    headingCell.alignment = { horizontal: 'center' };
    worksheet.addRow([]); // Empty row
    const headingRow2 = worksheet.addRow([`${t('069')}: ${partnerLoginId}`]);
    worksheet.mergeCells(headingRow2.number, 1, headingRow2.number, numberOfColumns);
    const headingCell2 = headingRow2.getCell(1);
    headingCell2.value = {
        richText: [
            { text: `${t('069')}: `, font: { bold: true } },
            { text: '   ' },
            { text: partnerLoginId, font: { bold: false } }
        ]
    };
    worksheet.addRow([]); // Empty row
    
    const columnHeaders = [
      t('5597'), t('distributorhirer1'), t('distributorhirer2'), t('072'), t('062'), t('037'), t('0170'), t('009')
    ];
    const headerRow = worksheet.addRow(columnHeaders);
    headerRow.eachCell(cell => {
        cell.font = { bold: true };
        cell.alignment = { horizontal: 'center' };
        cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
        };
    });
    downloadItems.forEach(item => {
      const dataRow = worksheet.addRow([
          item.PARTNER_ID,
          item.PARTNER_FIRST_NAME,
          item.PARTNER_LAST_NAME,
          item.PARTNER_TYPE,
          item.CITY,
          item.PARTNER_EMAIL_ID,
          item.HIERARCHY_LEVEL || '----',
          item.ACCT_BALANCE
      ]);
        dataRow.eachCell(cell => {
            cell.border = {
                top: { style: 'thin' },
                left: { style: 'thin' },
                bottom: { style: 'thin' },
                right: { style: 'thin' }
            };
            cell.alignment = { horizontal: 'center' }; // Center-align the cell content
        });
    });
      worksheet.addRow([]);

    const emptyRow3 = worksheet.addRow([]);
    emptyRow3.hidden = true; // Hide the empty row
    const endOfReportText = t('0171'); // Replace with your translated text
    const endOfReportRow = worksheet.addRow([endOfReportText]);
    worksheet.mergeCells(endOfReportRow.number, 1, endOfReportRow.number, columnHeaders.length);
      // Style the "End of Report" cell
      const endOfReportCell = endOfReportRow.getCell(1);
      endOfReportCell.font = { italic: true, underline: true, bold: true };
      endOfReportCell.alignment = { horizontal: 'center' };
    worksheet.columns = [
        { width: 22 },
        { width: 20 },
        { width: 18 },
        { width: 18 },
        { width: 20 },
        { width: 30 },
        { width: 22 },
        { width: 20 }
    ];

    // Protect the worksheet to make it read-only
    worksheet.protect('yourPassword', {
        selectLockedCells: true,
        selectUnlockedCells: true,
        formatCells: false,
        formatColumns: false,
        formatRows: false,
        insertColumns: false,
        insertRows: false,
        insertHyperlinks: false,
        deleteColumns: false,
        deleteRows: false,
        sort: false,
        autoFilter: false,
        pivotTables: false
    });

    // Generate and download the Excel file
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'distributorsHierarchy.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

const goToViewSubDistributors = useCallback(async (partnerId) => {
  setPartnerLoginId(partnerId);
  setPage(1);
}, []);

const handleSubGroupNavigation = (distId) => {
  navigate('/profile', { state: { distId } });
  setPartnerLoginId(distId);
  setPage(1);
};


let startRecord = (page - 1) * perpage + 1;
let endRecord = totalRecords > 0 
? Math.min(startRecord + perpage - 1, totalRecords) 
: (page === 1 ? 10 : page * perpage);

return (
  <div>
  <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
   <tbody>
    <Header/>
  <tr height="65px">
  <PaymentManagerHeading />
  <TopMenu menuLink= {localeVar==='en'?"Subdistributors":"Subdistribuidores"}/>
  </tr>

  <tr>
    {/* <td valign="top"style={{ borderRightStyle: "solid", borderRightWidth: "1pt",borderColor: "rgb(51 153 255)"}}nowrap="nowrap">

    </td> */}
<LeftBgImage />
<td valign="top">
<title>Prepaid Movistar -View Sub Distributor</title>
<table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%" align="left">
<tbody>
  <tr>
   <td>
     <table border={0} cellPadding={0} cellSpacing={0} width="100%" height="100%"align="center">
      <tbody>
                  {/* MIDDLE ROW STARTS */}
 <tr>
  <td>
  <table border={0} cellPadding={0} cellSpacing={0} width="100%"align="center"height="100%">
    <tbody>
    <JasperTopMenu />
     <tr valign="top">
       <td width="80%">
            {/* body starts */}
          
<div className={'mL8'}>
            <table border={0} cellPadding={0} cellSpacing={0} width="100%" align="left" style={{marginTop: '5px'}}>
             
    {/* <tr>
        <td width="95%" align="left">
          <table border={0} width="100%" cellSpacing={0}>
              <tr>
                <td width="50%" align="left" className="labelText" style={{}}>{t('069')}:<b> {partnerLoginId}</b></td>
              </tr>
              
           </table>
        </td>
      </tr> */}
      <Grid
                container
                spacing={2}
                sx={{ width: 1 }}
                className={""}
                style={{
                  justifyContent: "center",
                  marginTop: "5px",
                  marginBottom: '0px',
                  marginLeft: "0px",
                  borderBottom: "1px solid #fff",
                  paddingInline: "0px",
                }}
              >
                <Grid
                  item
                  xs={4}
                  sx={{ textAlign: "left", padding: "0 !important" }}
                >
                  {/* <span className={"strongerTxtLable"}>
                          {t('032')} :  {totalRecords}
                  </span> */}
                </Grid>
                <Grid
                  item
                  xs={3}
                  sx={{ textAlign: "center", padding: "0 !important" }}
                ></Grid>
               <Grid
                  item
                  xs={5}
                  sx={{ textAlign: "right", padding: "0 !important" }}>
                 {totalRecords >0 ?
                    <><span className={"strongerTxtLable"}>
                                              {t('032')} : {totalRecords}
                                            </span><span className={"strongerTxtLable"}>
                                                &nbsp; / &nbsp;
                                                {t('033')} : {startRecord} - {endRecord}
                                              </span></>   :
                      <></>}
                </Grid>
              </Grid>
              <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
      <Table sx={{ minWidth: 650 }} size="small" stickyHeader aria-label="sticky table">
        <TableHead>
          <TableRow className="darkgray">
            <TableCell align="center">{t('070')}</TableCell>
            <TableCell align="center">{t('071')}</TableCell>
            <TableCell align="center">{t('072')}</TableCell>
            <TableCell align="center">{t('073')}</TableCell>
            <TableCell align="center">{t('037')}</TableCell>
            <TableCell align="center">{t('074')}</TableCell>
            <TableCell align="center">{t('009')}</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading ? (
            // Show loading spinner while data is being fetched
            <TableRow>
              <TableCell colSpan={7} align="center" className={'spinnerDiv'}>
              {t("Processing...")} <CircularProgress style={{ transform: 'translate(0, 7px)' }} size="sm" />
              </TableCell>
            </TableRow>
          ) : items.length > 0 ? (
            // Show table rows when data is available
            items.map((item, index) => (
              <TableRow className={index % 2 === 0 ? 'lightgreen' : 'lightyellow'} key={index}>
                <TableCell className="arlCtrBlk" style={{ color: "#3399FF", cursor: 'pointer' }} align="center"
                  onClick={() => { handleSubGroupNavigation(item.PARTNER_ID) }}
                >
                  {item.PARTNER_ID}
                </TableCell>
                <TableCell align="center">&nbsp;{item.PARTNER_FIRST_NAME}&nbsp; {item.PARTNER_LAST_NAME}&nbsp;</TableCell>
                <TableCell align="center">&nbsp;{item.PARTNER_TYPE}&nbsp;</TableCell>
                <TableCell align="center">{item.CITY}</TableCell>
                <TableCell align="center">&nbsp;{item.PARTNER_EMAIL_ID}&nbsp;</TableCell>
                <TableCell align="center">
                  {item.flagList ? (
                    '---'
                  ) : (<Link to="/distributorshierarchyp"
                      onClick={() => {
                        goToViewSubDistributors(item.PARTNER_ID);
                      }}
                      style={{justifyContent:'center'}}
                      className="nav"
                    >
                      {t('5547')}
                    </Link>
                  )}
                </TableCell>
                <TableCell align="center">&nbsp;{item.ACCT_BALANCE}&nbsp;</TableCell>
              </TableRow>
            ))
          ) : (
            // Show 'No data found' message if no items are found after loading
            <TableRow>
              <TableCell colSpan="7" className="redTxt" style={{ color: 'red' }} align="center">
                {t("2480_006")} {/* No data found for the given search criteria */}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
    <br></br>
<Table>
<tfoot>
<Box style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
<Box
sx={{textAlign: "right",padding: "4px 0px 4px 0 !important"}}
className={'displayFlex'}></Box>


{items.length>0?<Pagination
                                                                    count={totalPages}
                                                                    page={page}
                                                                    onChange={handleChangePage}
                                                                    showFirstButton
                                                                    showLastButton
                                                                  />: <></> }
</Box>
<tr>
</tr>
</tfoot>
</Table>                              
    <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '10px', gap:'8px' }}>
      {items.length>0?
      <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CloudDownload />}
        onClick={handleDownload}>
         {t('089')} 
         </Button> 
       :<></>}

     <Button
    className={"hoverEffectButton"}
    size="small"
    variant="contained"
    onClick={handleReturn}
    endIcon={<KeyboardReturn />}
  > {t('013')}</Button>
</div>
 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</div>
</td></tr>
</tbody>
</table>
</td>
</tr>{/* MIDDLE ROW ENDS HERE  */}
</tbody>
</table>
</td></tr>
</tbody>
</table>
</td></tr>
<tr height="60px"><td colSpan={2}>
    <Footer/>
    </td>
  </tr>
  </tbody>
</table>
  </div>
)
};
export default Distributorshierarchyp;
