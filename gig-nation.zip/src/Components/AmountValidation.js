

function amountValidation(amount, setAmount, maxIntPart, maxDeciPart) {
    if (!amount || amount.length === 0) {
        setAmount(formatDecimal("0", true, maxDeciPart));
        return;
    }

    let tempAmount = removeCharContains(amount, ","); // Remove commas
    tempAmount = removeCharContains(tempAmount, " "); // Remove spaces

    if (isNaN(tempAmount)) {
        setAmount(formatDecimal("0", true, maxDeciPart));
        return;
    }

    let retAmt = formatDecimal(tempAmount, true, maxDeciPart);
    console.log("Formatted Amount:", retAmt); // Debugging

    setAmount(retAmt); // Final formatted value
}

// Function to remove specific characters
function removeCharContains(amount, charToBeRemove) {
    return amount.split(charToBeRemove).join(""); 
}
function formatDecimal(value, addzero, decimalPlaces) {
    if (isNaN(value) || value.trim() === "") {
        return "0.00"; // Default invalid values to 0.00
    }

    let numValue = parseFloat(value);

    if (decimalPlaces > 0) {
        numValue = decimalRound(numValue, decimalPlaces);
    } else {
        numValue = Math.round(numValue).toString();
    }

    if (addzero) {
        let [intPart, decPart = ""] = numValue.toString().split(".");
        while (decPart.length < decimalPlaces) {
            decPart += "0";
        }
        return decimalPlaces > 0 ? `${intPart}.${decPart}` : intPart;
    }
    return numValue.toString();
}


function decimalRound(value, decimalPlaces) {
    let factor = Math.pow(10, decimalPlaces);
    return (Math.round(parseFloat(value) * factor) / factor).toFixed(decimalPlaces);
}

export { amountValidation };
