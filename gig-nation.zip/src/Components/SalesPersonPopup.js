import React, { useEffect, useState } from 'react'
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import ThumbUpAltIcon from '@mui/icons-material/ThumbUpAlt';
import useMediaQuery from "@mui/material/useMediaQuery";
import { Box, Button, Checkbox, FormGroup, Grid, Paper, Table, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material'
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
// import salesData from '../salesData.json'
import SendIcon from '@mui/icons-material/Send';
import { useTheme } from "@mui/material/styles";
import { t } from 'i18next';
import axios from "axios";
import i18n from "./i18n";
import { ArrowRight } from '@mui/icons-material';
function SalesPersonPopup({setChannelsAssociation,flag,reset}) {

  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  const localeVar = i18n.language;
 const [open, setOpen] = useState(false);
  const [submitCheck, setSubmitCheck] = useState(true);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
  const [headerCheckbox, setHeaderCheckbox] = useState(false);
  const [mainHeader, setMainHeader] = useState(false);
  const [storedCheck, setStoredCheck] = useState(false);
  const [checkedRows, setCheckedRows] = useState([]);
  const [temporaryCheckedRows, setTemporaryCheckedRows] = useState([]);
  const [channels, setChannels] = useState([]);
  const [channelsCopy, setChannelsCopy] = useState([]);
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [initialChannels, setInitialChannels] = useState([]);
  const [allcheck, setAllcheck] = useState('');

  
let salesData='';
// Load initial state from local storage or salesData

 // Outside Header Checkbox - Global Control
 const handleOutsideHeaderCheckboxChange = (event) => {
  console.log('sssss==='+event.target);
  const { checked } = event.target;
  setHeaderCheckbox(checked);
  setMainHeader(checked);
  const updatedChannels = channels.map(sales => ({
    ...sales,
    checkVal: checked ? 'checked' : ''
  }));




  

 //setTemporaryCheckedRows([]);
//   setChannels(updatedChannels);
//   const updatedCheckedRows = checked ? updatedChannels.map(sales => sales.topUpId) : [];
//   const updatedCheckedchannels = checked ? channels.map(sales=>sales) : [];
//   setCheckedRows(updatedCheckedRows);
//   setChannelsAssociation(updatedCheckedchannels,checked);

//   // Persist the changes
//   localStorage.setItem('channels', JSON.stringify(updatedChannels));


  setChannels(updatedChannels);
//setCheckedRows(updatedChannels);
const selectedRowsData = updatedChannels.filter(sales => sales.checkVal === "checked");
console.log(checkedRows); // Selected Row Id's
console.log(selectedRowsData); // Selected Row data
setAllcheck('channel');
// Save updated channels to local storage
  localStorage.setItem('channels', JSON.stringify(updatedChannels));
setChannelsAssociation(selectedRowsData,checked)
};

// Outside Header Checkbox - Global Control
const forclear = async (event) => {
  
  //setHeaderCheckbox(event.target)
    const apiUrl4 = window.config.apiUrl +  process.env.REACT_APP_GET_CHANNELS;
    console.log(apiUrl4);
    const response4 = await axios.post(apiUrl4, {
      userName,
      password,
      localeVar,
      channelTransAl: "",
    });
    // const[channels]=response.data;

 localStorage.setItem("channels", JSON.stringify(response4.data.channels));

 const parsedData = response4.data.channels;
 setChannels(parsedData);
 const initiallyCheckedRows = parsedData.filter(sales => sales.checkVal === "checked").map(sales => sales.topUpId);
 setCheckedRows(initiallyCheckedRows);
 setTemporaryCheckedRows(initiallyCheckedRows);
 setHeaderCheckbox(initiallyCheckedRows.length === parsedData.length);
 setInitialChannels(parsedData); // Store initial state
 setMainHeader(event.target);
 //setStoredCheck(true)
 reset(false);
};




useEffect(() => {
  
  let storedData = localStorage.getItem('channels');
  
   
 // alert("hiii"+storedCheck)
 
  if (storedData) {
  
    const parsedData = JSON.parse(storedData);
    setChannels(parsedData);
    const initiallyCheckedRows = parsedData.filter(sales => sales.checkVal === "checked").map(sales => sales.topUpId);
    setCheckedRows(initiallyCheckedRows);
    setTemporaryCheckedRows(initiallyCheckedRows);
    setHeaderCheckbox(initiallyCheckedRows.length === parsedData.length);
    setInitialChannels(parsedData); // Store initial state
  } else if (submitCheck) {
    if(open){
  salesData = JSON.parse(localStorage.getItem('salesData'));
//  console.log("hiiiiiiiiiiii"+salesData)
    setChannels(salesData);
    const initiallyCheckedRows = salesData.filter(sales => sales.checkVal === "checked").map(sales => sales.topUpId);
    setCheckedRows(initiallyCheckedRows);
    setTemporaryCheckedRows(initiallyCheckedRows);
    setHeaderCheckbox(initiallyCheckedRows.length === salesData.length);
    setInitialChannels(salesData); // Store initial state
  }
  }
  

}, [salesData, submitCheck,mainHeader,setChannelsAssociation]);

useEffect(()=>{
  if(flag){
    headerclear();
  }
},[flag])


const headerclear=()=>{
    //fetchChannels();
    var Object={
     'target':false
    };
    forclear(Object);
 }


const handleClickOpen = (value, id) => {
  setOpen(true);
};

const handleClose = () => {



  setOpen(false);
  setSubmitCheck(true);
  // Revert to initial state on close without submit
  setChannels(initialChannels);
  const initiallyCheckedRows = initialChannels.filter(sales => sales.checkVal === "checked").map(sales => sales.topUpId);
  setCheckedRows(initiallyCheckedRows);
  setTemporaryCheckedRows(initiallyCheckedRows);
  setHeaderCheckbox(initiallyCheckedRows.length === initialChannels.length);
};

const handleRowCheckboxChange = (event, id) => {
  const isChecked = event.target.checked;
  const newCheckedRows = isChecked
    ? [...temporaryCheckedRows, id]
    : temporaryCheckedRows.filter((rowId) => rowId !== id);

  setTemporaryCheckedRows(newCheckedRows);
  setHeaderCheckbox(newCheckedRows.length === channels.length);
};

  

console.log(channels, "Chanelsss")

const handleHeaderCheckboxChange = (event) => {
  const { checked } = event.target;
  setHeaderCheckbox(checked);
  setAllcheck('channel');
  const updatedCheckedRows = checked ? channels.map(sales => sales.topUpId) : [];
  const updatedCheckedchannels = checked ? channels.map(sales=>sales) : [];
  setTemporaryCheckedRows(updatedCheckedRows);
 // setChannelsAssociation(updatedCheckedchannels,checked,allcheck);
//  localStorage.setItem('channels', JSON.stringify(updatedCheckedchannels));

};

const handleSalesSubmit = () => {
  const updatedChannels = channels.map(channel =>
    temporaryCheckedRows.includes(channel.topUpId)
      ? { ...channel, checkVal: 'checked' }
      : { ...channel, checkVal: '' }
  );
  setChannels(updatedChannels);
  setCheckedRows(temporaryCheckedRows);
  setSubmitCheck(false);

  const selectedRowsData = updatedChannels.filter(sales => sales.checkVal === "checked");
  console.log(checkedRows); // Selected Row Id's
  console.log(selectedRowsData); // Selected Row data
  console.log("uuuu"+updatedChannels.length);
  console.log("sssss"+selectedRowsData.length);
  if(updatedChannels.length!==selectedRowsData.length)
  setHeaderCheckbox(false);
  
  // Save updated channels to local storage
 localStorage.setItem('channels', JSON.stringify(updatedChannels));
 setChannelsAssociation(selectedRowsData,headerCheckbox)
  setOpen(false)
};

  return (
    <>
        <ArrowRight className="animated-arrow" style={{color:'#39f'}} />  
      <a className="underline-link" onClick={handleClickOpen}> <span>{t("6812")}</span></a>
        <Checkbox checked={headerCheckbox}
                          onChange={handleOutsideHeaderCheckboxChange} />
      {/* MODAL STARTS HERE */}
      <Dialog
          fullScreen={fullScreen}
          open={open}
          onClose={handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "25px", paddingBottom: '0' }}
            className={"headerTxt"}
            align="center"
          >
            {t("6813")}
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[800],
            }}
          >
            <CloseIcon />
          </IconButton>
          <DialogContent>
            <DialogContentText>
              
            <TableContainer component={Paper} className={'shadowTable'} style={{ maxHeight: '300px' }}>
           
              {/* <Box style={{display:'flex', justifyContent: 'space-between', marginTop: '10px', marginRight: '10px'}}>
              <Checkbox />
                <Box style={{display: 'flex', gap: '10px', marginBottom: '10px'}}>
                <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<SendIcon />}>
                  Submit
                </Button>
                <Button className={'hoverEffectButton'} size="small" variant="contained" endIcon={<CloseIcon />}>
                  Close
                </Button>
                </Box>
              </Box> */}
              <Table sx={{ minWidth: 500 }} size="small" className={''} stickyHeader aria-label="sticky table"> 
                  <TableHead>
                    <TableRow className={"darkgray"}>
                      <TableCell></TableCell>
                      <TableCell align="center" className={"whiteBldTxt"}>
                      {t('6814')}
                      </TableCell>
                      <TableCell align="center" className={"whiteBldTxt"}>
                      {t('6807')}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  {channels.map((sales) =>(
                    <TableRow className={""}>
                    <TableCell key={sales.topUpId} style={{padding: '0'}}> <Checkbox
                  // checked={temporaryCheckedRows.includes(sales.topUpId) || sales.checkVal === "checked"}
                  checked={temporaryCheckedRows.includes(sales.topUpId)}
                  onChange={(event) => handleRowCheckboxChange(event, sales.topUpId)}
                /></TableCell>
                    <TableCell>{sales.topupTypeDesc}</TableCell>
                    <TableCell>{sales.transCategory}</TableCell>
                    </TableRow>
                  )
                )}
                </Table>
                <Box style={{display:'flex', justifyContent: 'space-between', paddingTop: '10px', paddingRight: '10px', position: 'sticky',bottom: 0, zIndex: '999',
    background: '#fff'}}>
              <Checkbox checked={headerCheckbox}
                          onChange={handleHeaderCheckboxChange} />
                <Box style={{display: 'flex', gap: '10px', marginBottom: '10px'}}>
                <Button className={'hoverEffectButton'} size="small" onClick={handleSalesSubmit} variant="contained" endIcon={<SendIcon />}>
                {t("26160199")}
                </Button>
                <Button className={'hoverEffectButton'} size="small" onClick={handleClose} variant="contained" endIcon={<CloseIcon />}>
                  {t("6810")}
                </Button>
                </Box>
              </Box>
              </TableContainer>
            </DialogContentText>
          </DialogContent>
        </Dialog>
        {/* MODAL ENDS HERE */}
    </>
  )
}

export default SalesPersonPopup;