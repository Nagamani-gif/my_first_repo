/* eslint-disable no-script-url */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */

import TopMenu from "./TopMenu";
import {  Header, Footer, PaymentManagerHeading, JasperLeftMenu, JasperTopMenu, ProfileMenu, ReportsTopMenu, TransactionTopMenu, LeftBgImage } from './PageComponents';
import i18n from "./i18n";
import { Box } from "@mui/material";
import React, { useState, useEffect } from 'react';
// import i18n from './i18n';
import { useTranslation } from 'react-i18next';

function JasperReports(){
const localeVar=i18n.language;
sessionStorage.setItem("selectedLink", "e_transactions");

useEffect(() => {
  // Set the browser title
  document.title = t('2472_010');
}, []);

const {t} = useTranslation();

  return (
      
    <table border={0} cellPadding={0} cellSpacing={0} id="inSideLayoutTable" height={600} width={1000} align="center">  
    <tbody>
         <Header/>
      <tr height="65px">
      <PaymentManagerHeading />
      <TopMenu menuLink= {localeVar==='en'?"Transactions":"Transacciones"}/>
      </tr>
      <tr>
       <LeftBgImage />
        <td valign="top">
          <meta httpEquiv="Content-Type" content="text/html; charset=ISO-8859-1" />
          <title>homepage</title>

        <table width="100%" height="100%" cellSpacing={2} cellPadding={2} border={0} align="center">
          <tbody>
              <tr valign="top">
                  <td align="left" className="headerTxt" style={{padding: '0'}}> 
                 <TransactionTopMenu />
                 <ReportsTopMenu />
                 <br />
                  </td>
                </tr>   
            </tbody>
        </table>

        </td>
      </tr>

      
      <tr height="60px">
        <td colSpan={2}>
       <Footer/>
        </td>
      </tr>
    </tbody></table>
  );
}

export default JasperReports;
