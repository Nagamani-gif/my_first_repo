import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from 'axios'; // Import axios
import i18n from '../Components/i18n';


// Define an initial state
const initialState = {
  status: "idle", // Possible statuses: idle, loading, succeeded, failed
  data: null,
  error: null,
  isLoggedIn: false,
  sessionId: null,
  user: null,
};

// Define an async thunk to handle userData
export const fetchData = createAsyncThunk(
  "example/fetchData", // Action type prefix
  async (userData, thunkAPI) => { // Thunk payload creator
    // No asynchronous operation, just return the userData
    return userData;
  }
);


export const logout = () => ({
  type: 'LOGOUT',
});
export const logoutUser = () => {
  let userName = process.env.REACT_APP_USERNAME;
  let password = process.env.REACT_APP_PASSWORD;
  return async (dispatch) => {
    try {
      // Make an API call to logout endpoint
      const localeVar=i18n.language;
      console.log(" logout lang", localeVar);


      const apiurl=window.config.apiUrl + process.env.REACT_APP_LOGOUT
      await axios.post(apiurl, {   userName,
        password,localeVar: localeVar });
      
      // Dispatch the logout action
      dispatch(logout());
      localStorage.removeItem('sessionId');
      localStorage.removeItem('userData'); 
       localStorage.removeItem('isLoggedIn'); // Remove sessionId on logout
       localStorage.removeItem('channels');
       localStorage.removeItem('denominations');

      // Optionally, clear other session-related data as needed
    } catch (error) {
      console.error('Logout failed:', error);
      // Handle logout failure if needed
    }
  };
};


// Define a slice
const exampleSlice = createSlice({
  name: "example", // Slice name
  initialState, // Initial state
  reducers: {
    setUserSession: (state, action) => {
      state.user = action.payload.user;
      state.sessionId = action.payload.sessionId;
      state.isLoggedIn = true;
     
    },
    // Additional synchronous actions can be defined here
    // For example:
    resetData(state) {
      state.data = null;
      state.error = null;
      state.isLoggedIn = false;
      state.sessionId = null;
      state.user = null;
    },
    // logout(state) {
    //   state.status = "idle"; // Reset status to idle
    //   state.data = null; // Clear user data
    //   state.error = null; // Clear error
    // },
  },
  extraReducers: (builder) => {
    // Add extra reducers for handling async action lifecycle
    builder.addCase(fetchData.pending, (state) => {
      state.status = "loading"; // Update status when pending
    });
    builder.addCase(fetchData.fulfilled, (state, action) => {
      state.status = "succeeded"; // Update status when fulfilled
      state.data = action.payload; // Update data with payload (userData)
    });
    builder.addCase(fetchData.rejected, (state, action) => {
      state.status = "failed"; // Update status when rejected
      state.error = action.payload; // Update error with payload (error message)
    });
  },
});

// Export actions and reducer
export const { resetData,setUserSession } = exampleSlice.actions;
export default exampleSlice.reducer;
