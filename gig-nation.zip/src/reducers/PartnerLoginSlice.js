import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

// Define an initial state
const initialState = {
  status: "idle", // Possible statuses: idle, loading, succeeded, failed
  data: null,
  error: null,
};

// Define an async thunk to fetch data from an API
export const fetchData = createAsyncThunk(
  "PartnerLogin/fetchData", // Action type prefix
  async ({ apiUrl, body }, thunkAPI) => {
    try {
      // Perform asynchronous operation (e.g., fetching data from an API)
      const response = await fetch(apiUrl,{
        method:'POST',
        headers:{
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      });
      const data = await response.json();
      return data; // Return data to be dispatched on success
    } catch (error) {
      // Handle errors
      return thunkAPI.rejectWithValue(error.message); // Return error message
    }
  }
);

// Define a slice
const PartnerLoginSlice = createSlice({
  name: "PartnerLogin", // Slice name
  initialState, // Initial state
  reducers: {
    // Additional synchronous actions can be defined here
    // For example:
    resetData(state) {
      state.data = null;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    // Add extra reducers for handling async action lifecycle
    builder.addCase(fetchData.pending, (state) => {
      state.status = "loading"; // Update status when pending
    });
    builder.addCase(fetchData.fulfilled, (state, action) => {
      state.status = "succeeded"; // Update status when fulfilled
      state.data = action.payload; // Update data with payload
    });
    builder.addCase(fetchData.rejected, (state, action) => {
      state.status = "failed"; // Update status when rejected
      state.error = action.payload; // Update error with payload
    });
  },
});

// Export actions and reducer
export const { resetData } = PartnerLoginSlice.actions;
export default PartnerLoginSlice.reducer;
