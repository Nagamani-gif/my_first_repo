
import './App.css';

 
import {
  BrowserRouter,
  Route,
  Routes,Navigate
} from "react-router-dom";
import LoginPage from './Components/LoginPage';
import Transactions from './Components/Transactions';

import Home from './Components/Home';
import SalesPeople from './Components/SalesPeople';
import ChangePassword from './Components/ChangePassword';
import DistAccntBalCredit from './Components/DistAccntBalCredit';
import Profile from './Components/Profile';
import NotificationConfigMain from './Components/NotificationConfigMain';
import Subdistributors from './Components/Subdistributors';
import Distributorshierarchyp from './Components/Distributorshierarchyp';
import Postpaidpaymentsp from './Components/Postpaidpaymentsp';
import { useDispatch,useSelector } from 'react-redux';
import { fetchData, logoutUser } from './reducers/exampleSlice'; // Import the fetchData async thunk
import { useState,useEffect, useCallback } from 'react';
import {ResetPassword} from './Components/ResetPassword';
import {PasswordResetVerification} from './Components/PasswordResetVerification';
import {FeatureAssociation} from './Components/FeatureAssociation';
import { QuickTransfer } from './Components/QuickTransfer';
import Samplexius from './Components/Samplexius';
import PublicTelephoneEnquiry from './Components/PublicTelephoneEnquiry';
import PublicTelephones from './Components/PublicTelephones';
//import DistributorFundTransfer from './Components/DistributorFundTransfer';
import BulkTransfer from './Components/BulkTransfer';
import ElectronicRecharge from './Components/EloctronicRecharge';
import DistributorFundTransferSample from './Components/DistributorFundTransferSample';
import RechargePreview from './Components/RechargePreview';
import DataPurchasePreview from './Components/DataPurchasePreview';
import { BalanceAnnulment } from './Components/BalanceAnnulment';
import { BalanceAnnulmentSubmit } from './Components/BalanceAnnulmentSubmit';
// Importing toastify module
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import PostpaidTransaction from './Components/postpaidTransactionReport';
import { setUserSession, resetData } from './reducers/exampleSlice'; // Adjust path as needed
import AddSalesPeople from './Components/AddSalesPeople';
import AddSubdistributor from './Components/AddSubdistributor';
import ModifyProfile from './Components/ModifyProfile';
import CancelPage from './Components/CancelPage';
import BlockPage from './Components/BlockPage';
import ChangePasswordPage from './Components/ChangePasswordPage';
import CsrfAttack from './Components/CsrfAttack';
import { Button, IconButton, useMediaQuery, useTheme } from '@mui/material';
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import CloseIcon from "@mui/icons-material/Close";
import useIdleTimer from './Components/useIdleTimer';
import { LoginOutlined } from '@mui/icons-material';
import SendIcon from '@mui/icons-material/Send';
import TermsAndConditions from './Components/TermsAndConditions';
import useSessionInterceptor from './Components/useSessionInterceptor';
import { t } from 'i18next';
import BlankPage from './Components/BlankPage';
import ExpireSoonPage from './Components/ExpireSoonPage';
import Distributorpaymentsp from './Components/DistributorPayment';
import DistributorpaymentHistory from './Components/DistributorPaymentHistory';

import PortInReport from './Components/PortInReport';
import JasperReports from './Components/JasperReports';
import BalanceAnnulmentReport from './Components/BalanceAnnulmentreport';
import PendingTrans from './Components/PendingTrans';
import DistributorPaymentsHistoryReport from './Components/DistributorPaymentsHistoryReport'; 
import DistributorPayments from './Components/DistributorPayments';
import Packetsales from './Components/Packetsales';
import BillPaymentsReport from './Components/BillPaymentsReport';
import AccountStatusReport from './Components/AccountStatusReport';
import FundTransferReport from './Components/FundTransferReport';
import FundTransferReversalReport from './Components/FundTransferReversalReport';
import POSTransactionsReport from './Components/POSTransactionsReport';
import ReversalTrasactionReport from './Components/ReversalTrasactionReport';
import MassiveTransfers from './Components/MassiveTransfers';
import Lateralfundreversalreport from './Components/Lateralfundreversalreport';
import PartnerStatusReport from './Components/PartnerStatusReport';
import Mvnereportp from './Components/Mvnereportp';
import Salestargetreport from './Components/Salestargetreport';


function App() {
  const dispatch = useDispatch();
  let isLoggedIn = useSelector((state) => state.example.isLoggedIn); // Get isLoggedIn from Redux state
  console.log("isLoggedIn===>",isLoggedIn);

    // Initialize the session and network error interceptor on app load
    useSessionInterceptor();

  useEffect(() => {
    const sessionId = localStorage.getItem('sessionId');
    const user = JSON.parse(localStorage.getItem('user'));
    if (sessionId && user) {
      dispatch(setUserSession({ sessionId, user }));
    } else {
      dispatch(resetData());
    }
  }, [dispatch]);

  const currentPath = window.location.pathname.trim();
  console.log('currentPath:::::::::::::::',currentPath)
  const authToken = localStorage.getItem('sessionId');
  if (authToken && currentPath !== '/gig-nation') {
    isLoggedIn = localStorage.getItem("isLoggedIn");
   const storedUserData = localStorage.getItem("userData");

    if (storedUserData) {
        try {
            const parsedUserData = JSON.parse(storedUserData);
            console.log("userdata===", parsedUserData);
            dispatch(fetchData(parsedUserData));
        } catch (error) {
            console.error("Failed to parse userData:", error);
        }
    } else {
        console.log("No userData found in localStorage.");
    }
}



  // useEffect(() => {
  //   // Check if authentication token is present in localStorage or sessionStorage
  //   const authToken = localStorage.getItem('sessionId'); // or sessionStorage.getItem('authToken');
  //   console.log("authToken===>",authToken);
  //   let sessionTimeout;
  //   if (authToken) {
  //     sessionTimeout = setTimeout(() => {
  //       handleSessionTimeout();
  //     }, 10 * 60 * 1000); // 10 minutes 10 * 60 * 1000
  //   }

  //   return () => {
  //     if (sessionTimeout) {
  //       clearTimeout(sessionTimeout);
  //     }
  //   };
  // }, [isLoggedIn]); // Depend on isLoggedIn to reset the timeout on login state change
// SESSION TIMEOUT STARTS ========================
const theme = useTheme();
const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
const [open, setOpen] = useState(false);
const [counter, setCounter] = useState(15);

const handleClose = () => {
  setOpen(false);
}; 
const handleIdle = () => {
  // Perform logout logic here, e.g., redirect to login page
  // toast.info('Session timed out. Redirecting to login page.');
  setOpen(true);
};
  useEffect(() => {
  if (open) {
    setCounter(15);
    const countdown = setInterval(() => {
      setCounter(prevCounter => (prevCounter > 0 ? prevCounter - 1 : prevCounter));
    }, 1000);

    return () => clearInterval(countdown);
    }
}, [open]);



const handleSessionTimeout = useCallback(() => {
  //  alert('Session timed out. Redirecting to login page.');
    dispatch(logoutUser());
    // setIsLoggedIn(false);
    isLoggedIn=false;
    window.location.href = '/gig-nation'; // Adjust to your login page path
  });

useIdleTimer(handleIdle, 600000, isLoggedIn); // 10 minutes timeout


// IF USER CLOSSES THE TAB DIRECTLY
// useEffect(() => {
//   const clearLocalStorage = () => {
//     localStorage.clear();
//   };
 
//   window.addEventListener('unload', clearLocalStorage);
 
//   // Clean up the event listener on component unmount
//   return () => {
//     window.removeEventListener('unload', clearLocalStorage);
//   };
// }, []);

      useEffect(() => {
        if (counter === 0) {
          handleSessionTimeout();
        }
      }, [counter, handleSessionTimeout]);
      // SESSION TIMEOUT ENDS ===========================



const setData=(userData)=>{
  console.log("user data===",userData)
localStorage.setItem("userData", JSON.stringify(userData));
localStorage.setItem("isLoggedIn",true);
  dispatch(fetchData(userData)); // Dispatch fetchData with userData
}

console.log("isLoggedIn===>",isLoggedIn);


return (
  <>
  <BrowserRouter basename="/gig-nation">
  {/* <div className="container my-2" style={{marginTop: '-16px !important'}}> */}
  <div className="container telefonica_container" style={{marginTop: '3px'}}>

    <Routes>
      <Route path="/" element={<LoginPage gettingdata={setData}/> } />
      <Route path="/showTermsConditions" element={<TermsAndConditions /> }></Route>
      <Route path='/blockpage' element={<BlockPage  gettingdata={setData} />} ></Route>
      <Route path='/expiresoon' element={<ExpireSoonPage  gettingdata={setData} />} ></Route>
      <Route path="/logout" element={<CancelPage gettingdata={setData} ></CancelPage>} ></Route>
     {isLoggedIn ? ( 
        <> 
          <Route path="/changepasswordpage" element={<ChangePasswordPage gettingdata={setData} ></ChangePasswordPage>} ></Route>  
          <Route path="/home" element={<Home/> } />
          <Route path="/blankpage" element={<BlankPage/> } />
          <Route path="/transaction" element={<JasperReports/>} />
          <Route path="/sales-people" element={<SalesPeople/>} />
          <Route path="/changePassword" element={<ChangePassword/>} />
          <Route path="/profile" element={<Profile/>} />
          <Route path="/newPaymentAlerts" element={<DistAccntBalCredit/>} />
          <Route path="/notificationConfigMain" element={<NotificationConfigMain/>} />
          <Route path="/subdistributors" element={<Subdistributors/> } />
          <Route path="/distributorshierarchyp" element={<Distributorshierarchyp/> } />
          <Route path="/postpaid-payments" element={<Postpaidpaymentsp/> } />
          <Route path="/resetPassword" element={<ResetPassword/> }></Route>
          <Route path="/passwordResetVerification" element={<PasswordResetVerification/> }></Route>
          <Route path="/featureAssociation" element={<FeatureAssociation/> }></Route>
          <Route path="/quickTransfer" element={<QuickTransfer/> }></Route>
          <Route path="/public-telephones-Enquiry" element={<PublicTelephoneEnquiry/> }></Route>
          <Route path="/public-telephones" element={<PublicTelephones/> }></Route>
           <Route path="/bulk-transfer" element={<BulkTransfer/> }></Route>
          <Route path="/electronic-recharge" element={<ElectronicRecharge/> }></Route>
          <Route path="/distributor-fund-transfer" element={<DistributorFundTransferSample/> }></Route>
          <Route path="/sample" element={<Samplexius/> }></Route>
          <Route path="/recharge-preview" element={<RechargePreview/> }></Route>
          <Route path="/data-purchase-preview" element={<DataPurchasePreview/> }></Route>
          <Route path="/balanceAnnulment" element={<BalanceAnnulment/> }></Route>
          <Route path="/balanceAnnulmentSubmit" element={<BalanceAnnulmentSubmit/> }></Route>
          <Route path="/postpaidtransactionreportp" element={<PostpaidTransaction/> }></Route>
          <Route path="/postpaid-payments" element={<Postpaidpaymentsp/> }></Route>
          <Route path="/transaction" element={<Transactions/> }></Route>
          <Route path="/addsalespersonp" element={<AddSalesPeople/> }></Route>
          <Route path="/addsubgroupp" element={<AddSubdistributor /> }></Route> 
          <Route path="/modifyProfile" element={<ModifyProfile /> }></Route>
          <Route path="/distributorpayment" element={<Distributorpaymentsp /> }></Route>
          <Route path="/distributorpaymenthistory" element={<DistributorpaymentHistory /> }></Route>
          
          <Route path="/accountstatusreportp" element={<AccountStatusReport /> }></Route>
          <Route path="/portinreport" element={<PortInReport /> }></Route>
          <Route path="/transactions" element={<Transactions /> }></Route>
          <Route path="/balanceAnnulmentReportp" element={<BalanceAnnulmentReport /> }></Route>
          <Route path="/pendingtransactions" element={<PendingTrans /> }></Route>
          <Route path="/distributorPaymentsHistoryReport" element={<DistributorPaymentsHistoryReport /> }></Route>
          <Route path="/distributorpayments" element={<DistributorPayments /> }></Route>
          <Route path="/packetsalesreportp" element={<Packetsales /> }></Route>
          <Route path="/billpaymentsreportp" element={<BillPaymentsReport /> }></Route>
          <Route path="/fundtransferreportsp" element={<FundTransferReport /> }></Route>
          <Route path="/distributortransferreversalreportp" element={<FundTransferReversalReport /> }></Route>
          
          <Route path="/postranslogrptp" element={<POSTransactionsReport /> }></Route>
          <Route path="/reversaltransactionreport" element={<ReversalTrasactionReport /> }></Route>
          <Route path="/massivetransferssreportp" element={<MassiveTransfers /> }></Route>
          <Route path="/lateralfundreversalreport" element={<Lateralfundreversalreport /> }></Route>

          <Route path="/partnerStatusReportp" element={<PartnerStatusReport /> }></Route>
          <Route path="/mvnereportp" element={<Mvnereportp /> }></Route>
          <Route path="/salestargetreportp" element={<Salestargetreport /> }></Route>









          
          
          {/* <Route path="/csrf" element={<CsrfAttack /> }></Route> */}


         </>
     ) : (
        <Route path="*" element={<Navigate to="/" replace />} /> 
    )}  
    </Routes>
  </div>
</BrowserRouter> 

{currentPath !== '/gig-nation' && (
<Dialog
          fullScreen={fullScreen}
          open={open}
          onClose={handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle
            id="responsive-dialog-title"
            sx={{ paddingTop: "25px" }}
            className={"headerTxt"}
            align="center"
          >
            {""}
          </DialogTitle>
          
          <DialogContent>
            <DialogContentText>
              <p style={{color: '#000',fontSize: '13px'}}>Your session is about to expire. Click on <span style={{color: '#3399FF'}}>“Keep me signed In”</span> to Continue.</p>
              <p style={{textAlign:'center',fontSize: '13px'}}><span className={'timerr'}>00.{counter<10 ? '0'+counter : counter}</span> seconds left</p>
            <div align="center" className={"maxLimit_buttons"} gap={1}>
                <Button className={'hoverEffectButton'} onClick={handleSessionTimeout} size="small" variant="contained" endIcon={<LoginOutlined />}> 
                 {t("Logout")}
                </Button>
                <Button className={'hoverEffectButton'} onClick={handleClose} size="small" variant="contained" endIcon={<SendIcon />}>
                   Keep me signed In
                </Button>
              </div>
            </DialogContentText>
          </DialogContent>
        </Dialog>
         )}
        {/* MODAL ENDS HERE */}
        
       {/* <ToastContainer containerId="GlobalApplicationToast"
                        position="top-right"
                        autoClose={3000}
                        hideProgressBar={false}
                        newestOnTop={false}
                        closeOnClick
                        rtl={false}
                        pauseOnFocusLoss
                        draggable
                        pauseOnHover
                        style={{
                          width: "fit-content",
                          minWidth: "300px",
                          minHeight: "100px",
                          fontSize: "18px",
                        }}
                      />  */}
                   
   </>
  );
}


export default App;
