
// eslint-disable-next-line no-undef
//apiUrl="http://192.168.144.61:8085/airmanage/rest/partner"
// eslint-disable-next-line no-undef
apiUrl="http://10.10.19.35:8080/airmanage/rest/partner";

// eslint-disable-next-line no-undef
apiUrlJasper="http://10.10.19.35:8080/airmanage/rest/jasper"
// eslint-disable-next-line no-undef
//apiUrlJasper="http://192.168.144.61:8085/airmanage/rest/jasper"

// eslint-disable-next-line no-undef
apiUrlUpload="http://10.10.19.35:8080/airmanage/rest/upload"    ;

// eslint-disable-next-line no-undef
pdfFilePath='/gig-nation/user_manual.pdf';
  
//pdfFilePath1='/gig-nation/user_manual.pdf';